# Meimiao - Social Content Sharing Platform

A social content-sharing platform built with ThinkPHP 8.x, similar to WeChat Moments. Supports posting articles, comments, likes, file uploads, music sharing, and more.

## Tech Stack

- PHP >= 8.0
- ThinkPHP 8.x
- MySQL (utf8mb4)
- PHPMailer 6.x

## Features

- **Content Publishing** - Post articles with Markdown support, image/video uploads, tags, and location
- **Long-form Articles** - Rich text articles with table of contents, Mermaid diagrams, KaTeX math formulas
- **Comments & Likes** - Guest commenting, spam detection, comment audit workflow
- **Draft System** - Auto-save drafts with version history
- **File Upload** - Image/video/file upload with cloud storage (S3) support
- **Music Integration** - Share music from Netease, QQ, Kugou, Kuwo with server-side audio proxy
- **Content Moderation** - Article and comment audit pipelines
- **User System** - Registration, login, 2FA/TOTP, profile management, avatar/cover upload
- **Privacy Control** - Per-article visibility settings, site-wide password protection
- **Notifications** - Email notifications with customizable templates
- **RSS Feed** - Built-in RSS generation
- **Admin Panel** - Dashboard, site settings, user management, database backup/restore, config versioning
- **Security** - CSRF protection, rate limiting, external request guard

## Project Structure

```
app/
├── controller/
│   ├── api/          # API endpoints
│   ├── admin/        # Admin panel controllers
│   ├── Base.php      # Base controller
│   ├── Home.php      # Homepage
│   ├── View.php      # Article detail
│   └── Edit.php      # Article editor
├── model/            # Eloquent models
├── middleware/        # Request middleware
├── service/          # Business logic services
├── validate/         # Input validation
└── view/             # Templates (admin + frontend)
config/               # Configuration files
public/               # Web root (assets, uploads)
route/                # Route definitions
```
