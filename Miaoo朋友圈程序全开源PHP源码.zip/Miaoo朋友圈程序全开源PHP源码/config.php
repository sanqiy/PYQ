<?php
$servername = "localhost";//数据库地址
$username = "123_rlxx_vip";//数据库账号
$password = "123_rlxx_vip";//数据库密码
$dbname = "123_rlxx_vip";//数据库名
?>