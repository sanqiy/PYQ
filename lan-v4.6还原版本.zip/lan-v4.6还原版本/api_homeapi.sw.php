<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$num9=8003;
$isArray=is_array($_POST);
if($isArray){
    $num9=160;
}else{
    $num9=400;
}
switch($num9){
    case 160:{
    $page=&$_POST['page'];
        break;
    }
    case 400:{
        $page=$_POST['page'];
        break;
    }
}
$timestamp=htmlspecialchars($page);
unset($page);
$escaped=addslashes($timestamp);
$page=$escaped;
$num10=8010;
$isArray=is_array($_POST);
if($isArray){
    $num10=400;
}else{
    $num10=400;
    $num10=9516;
}
switch($num10){
    case 4958:{
    $page=$_POST['getuser'];
        break;
    }
    case 400:{
        $page=&$_POST['getuser'];
        break;
    }
}
$timestamp=htmlspecialchars($page);
unset($page);
$escaped=addslashes($timestamp);
$getuser=$escaped;
$tmp2=$user_zh=="";
$tmp3=(bool)$tmp2;
$tmp4=!$tmp3;
if($tmp4){
    $tmp5=$user_passid=="";
    $tmp3=(bool)$tmp5;
}
if($tmp3)goto L2xeWjgxm;
goto L2xldMhxm;
L2xeWjgxm:
$tmp2=$getuser=="";
if($tmp2)goto L2xeWjgxk;
goto L2xxl;
goto L2xxl;
L2xeWjgxk:
exit("请先登录!");
goto L2xxl;
L2xldMhxm:
L2xxl:
if($page==""){
    exit("参数为空!");
}
$tmp2=include '../config.php';
$tmp2=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp2;
if($conn->connect_error){
    exit("连接数据库失败");
}
$timestamp=htmlspecialchars($user_zh);
$dateStr=addslashes($timestamp);
$user_zhsg=$dateStr;
$tmp2="select * from user where username='" . $user_zhsg;
$sqls=$tmp2 . "'";
$row=mysqli_query($conn, $sqls);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$data2s_row=$row;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$str="select * from user where username='" . $user_zh;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
if($user_passid!=$passid){
    $timestamp=time();
    $str=$timestamp+ -1;
    $dateStr=setcookie("username", "", $str, "/");
    $timestamp=time();
    $str=$timestamp+ -1;
    $dateStr=setcookie("passid", "", $str, "/");
    exit("账号信息异常,请重新登录!");
}
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($sentinel))break;
    $name=$row["name"];
    $name=$row["subtitle"];
    $icon=$row["icon"];
    $logo=$row["logo"];
    $zt=$row["zt"];
    $username=$row["username"];
    $glyadmin=$row["username"];
    $homimg=$row["homimg"];
    $sign=$row["sign"];
    $essgs=$row["essgs"];
    $commgs=$row["commgs"];
    $kqsy=$row["kqsy"];
    $daymoed=$row["daymoed"];
    $gotop=$row["gotop"];
    $search=$row["search"];
    $videoauplay=$row["videoauplay"];
}
L2xx16:
if($getuser!="")goto L2xeWjgx1t;
goto L2xldMhx1t;
L2xeWjgx1t:
$sql="SELECT * FROM user";
$result=$conn->query($sql);
$result=$result;
$data=$val3;
$tmp2=$result->num_rows>0;
if($tmp2)goto L2xeWjgx1b;
goto L2xldMhx1b;
goto L2xldMhx1b;
L2xeWjgx1b:
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!$sentinel)break;
    $isArray=is_array($row);
    if($isArray){
        $page=&$row["username"];
    }else{
        $page=$row["username"];
    }
    $timestamp=md5($page);
    unset($page);
    $escaped=md5($timestamp);
    $encrypted_username=$escaped;
    $sentinel=$row["username"];
    $data[$encrypted_username]=$sentinel;
}
goto L2xx1a;
L2xldMhx1b:
exit("用户不存在");
L2xx1a:
$row=array_key_exists($getuser, $data);
if($row){
    $getuser=$data[$getuser];
}else{
    exit("此用户不存在");
}
$tmp2="select * from user where username= '" . $getuser;
$sql=$tmp2 . "'";
$row=mysqli_query($conn, $sql);
$result=$row;
$row=mysqli_num_rows($result);
$tmp2=$row>0;
if($tmp2)goto L2xeWjgx1n;
goto L2xldMhx1n;
goto L2xldMhx1n;
L2xeWjgx1n:
L2xx1o:
$row=mysqli_fetch_assoc($result);
$row=$row;
if($sentinel)goto L2xx1o;
goto L2xx1s;
goto L2xx1s;
goto L2xx1s;
L2xldMhx1n:
exit("此用户不存在");
L2xldMhx1t:
L2xx1s:
$dqgs=0;
$dqs=0;
$prevDay='';
$prevMonth=$sentinel;
$prevYear=$sentinel;
$timebss='';
$num=8006;
$tmp2=$getuser!="";
$tmp3=(bool)$tmp2;
if($tmp3){
    $tmp5=$getuser!=null;
    $tmp3=(bool)$tmp5;
}
if($tmp3){
    $num=361;
}else{
    $num=200;
}
$tmp2=51;
$tmp5=361;
$tmp3=$num==361;
if($tmp3)goto L2xeWjgx2e;
goto L2xldMhx2e;
L2xeWjgx2e:
$tmp2="SELECT * FROM essay WHERE ptpys='1' and ptpaud='1' and ptpuser = '" . $getuser;
$query=$tmp2 . "'";
goto L2xx2d;
L2xldMhx2e:
$tmp2=304;
$tmp5=200;
$tmp3=$num==200;
if($tmp3)goto L2xeWjgx2f;
goto L2xldMhx2f;
L2xeWjgx2f:
$tmp2=$user_zh==$glyadmin;
if($tmp2)goto L2xeWjgx2c;
goto L2xldMhx2c;
goto L2xldMhx2c;
L2xeWjgx2c:
$query="SELECT * FROM essay WHERE ptpaud='1'";
goto L2xx2d;
L2xldMhx2c:
$tmp2="SELECT * FROM essay WHERE ptpaud='1' and ptpuser = '" . $user_zh;
$query=$tmp2 . "'";
L2xldMhx2f:
L2xx2d:
$row=mysqli_query($conn, $query);
$result=$row;
$ptptime_values=$val3;
while(true){
    $row=mysqli_fetch_assoc($result);
    $row=$row;
    if(!($sentinel))break;
    $num2=8003;
    $isArray=is_array($row);
    if($isArray){
        $num2=152;
    }else{
        $num2=380;
    }
    switch($num2){
        case 152:{
        $page=&$row['ptptime'];
            break;
        }
        case 380:{
            $page=$row['ptptime'];
            break;
        }
    }
    $timestamp=strtotime($page);
    unset($page);
    $escaped=date('Y', $timestamp);
    $num3=8006;
    $isArray2=is_array($row);
    if($isArray2){
        $num3=160;
    }else{
        $num3=160;
        $num3=2842;
    }
    switch($num3){
        case 160:{
        $key=&$row['ptptime'];
            break;
        }
        case 1501:{
            $key=$row['ptptime'];
            break;
        }
    }
    $timestamp2=strtotime($key);
    unset($key);
    $dateStr2=date('m', $timestamp2);
    $tmp6=$escaped . $dateStr2;
    $num4=8003;
    $isArray3=is_array($row);
    if($isArray3){
        $num4=80;
    }else{
        $num4=200;
    }
    switch($num4){
        case 200:{
        $key2=$row['ptptime'];
            break;
        }
        case 80:{
            $key2=&$row['ptptime'];
            break;
        }
    }
    $timestamp3=strtotime($key2);
    unset($key2);
    $dateStr3=date('d', $timestamp3);
    $tmp7=$tmp6 . $dateStr3;
    $num5=8003;
    $isArray4=is_array($row);
    if($isArray4){
        $num5=80;
    }else{
        $num5=160;
    }
    $tmp8=20;
    $tmp9=160;
    $tmp10=$num5==160;
    if($tmp10){
        $key3=$row['ptptime'];
    }else{
        $tmp11=200;
        $tmp12=80;
        $tmp13=$num5==80;
        if($tmp13){
            $key3=&$row['ptptime'];
        }
    }
    $timestamp4=strtotime($key3);
    unset($key3);
    $dateStr4=date('H', $timestamp4);
    $tmp14=$tmp7 . $dateStr4;
    $num6=8012;
    $isArray5=is_array($row);
    if($isArray5){
        $num6=190;
    }else{
        $num6=400;
    }
    $tmp15=$num6==190;
    if($tmp15){
        $key4=&$row['ptptime'];
    }else{
        $tmp16=400;
        $tmp17=$num6==400;
        if($tmp17){
            $key4=$row['ptptime'];
        }
    }
    $timestamp5=strtotime($key4);
    unset($key4);
    $dateStr5=date('i', $timestamp5);
    $tmp18=$tmp14 . $dateStr5;
    $num7=8017;
    $isArray6=is_array($row);
    if($isArray6){
        $num7=190;
    }else{
        $num7=200;
    }
    $tmp19=13;
    $tmp20=190;
    $tmp21=$num7==190;
    if($tmp21){
        $key5=&$row['ptptime'];
    }else{
        $tmp22=266;
        $tmp23=200;
        $tmp24=$num7==200;
        if($tmp24){
            $key5=$row['ptptime'];
        }
    }
    $timestamp6=strtotime($key5);
    unset($key5);
    $dateStr6=date('s', $timestamp6);
    $ptptime=$tmp18 . $dateStr6;
    $num8=8008;
    $row=strpos($ptptime, '-');
    $tmp2=$row!==false;
    if($tmp2){
        $num8=400;
    }else{
        $num8=400;
        $num8=11858;
    }
    switch($num8){
        case 400:{
        $row=strtotime($ptptime);
        $timestamp=$row;
            break;
        }
        case 6129:{
            $sentinel=DateTime::createFromFormat('YmdHis',$ptptime)->getTimestamp();
            $timestamp=$sentinel;
            break;
        }
    }
    $sentinel=$row;
    $ptptime_values[$timestamp]=$sentinel;
}
L2xx4t:
$row=krsort($ptptime_values);
unset($tmp);
foreach($ptptime_values as $row){$tmp[]=$row;
}
$tmp25=0;
while(true){
    $row=count($tmp);
    $tmp2=$tmp25<$row;
    if(!($tmp2))break;
    $keys=array_keys($tmp);
    $keys=$keys[$tmp25];
    $row=$tmp[$keys];
    $dqgs=$dqgs+1;
    $tmp2=$dqgs>$page;
if($tmp2)goto L2xeWjgx78;
goto L2xldMhx78;
goto L2xldMhx78;
goto L2xldMhx78;
goto L2xldMhx78;
L2xeWjgx78:
    $dqs=$dqs+1;
    $tmp2=$dqs>$essgs;
if($tmp2)goto L2xeWjgx66;
goto L2xldMhx66;
goto L2xldMhx66;
goto L2xldMhx66;
goto L2xldMhx66;
goto L2xldMhx66;
L2xeWjgx66:
    $dqgs=$dqgs-1;
goto L2xx8k;
goto L2xx65;
L2xldMhx66:
L2xx65:
    $ptpuser=$row["ptpuser"];
    $ptpimg=$row["ptpimg"];
    $ptpname=$row["ptpname"];
    $ptptext=$row["ptptext"];
    $ptpimag=$row["ptpimag"];
    $ptpvideo=$row["ptpvideo"];
    $ptpmusic=$row["ptpmusic"];
    $ptplx=$row["ptplx"];
    $ptpdw=$row["ptpdw"];
    $ptptime=$row["ptptime"];
    $ptpgg=$row["ptpgg"];
    $ptpggurl=$row["ptpggurl"];
    $ptpys=$row["ptpys"];
    $commauth=$row["commauth"];
    $ptpaud=$row["ptpaud"];
    $ptpip=$row["ip"];
    $cid=$row["cid"];
    $wid=$row["id"];
    $row=explode("|", $ptpvideo);
    $partssp=$row;
    $ptpvideo=$partssp[0];
    $ptpvideofm=$partssp[1];
    $timestamp=strtotime($ptptime);
    $dateStr=date('Y', $timestamp);
    $year=$dateStr;
    $timestamp=strtotime($ptptime);
    $dateStr=date('m', $timestamp);
    $month=$dateStr;
    $timestamp=strtotime($ptptime);
    $dateStr=date('d', $timestamp);
    $day=$dateStr;
    $tmp2=$year . "-";
    $tmp5=$tmp2 . $month;
    $tmp3=$tmp5 . "-";
    $givenDates=$tmp3 . $day;
    $tmp2=$year!=$prevYear;
    if($tmp2){
        $row=date('Y');
        $tmp2=$row!=$year;
        if($tmp2){
            $tmp2='<h2 class="sh-homecontent-timed">' . $year;
            $tmp5=$tmp2 . '<span class="sh-homecontent-timed-n">年</span></h2>';
            echo $tmp5;
        }
        $prevYear=$year;
    }
    $tmp2=$ptpys==0;
    if($tmp2){
        $wzsdbs='<i class="iconfont icon-suoding sh-homecontent-wzsbs"></i>';
    }else{
        $wzsdbs="";
    }
    $tmp2=$ptplx=="mony";
if($tmp2)goto L2xeWjgx6e;
goto L2xldMhx6e;
goto L2xldMhx6e;
goto L2xldMhx6e;
goto L2xldMhx6e;
goto L2xldMhx6e;
L2xeWjgx6e:
    $tmp2=$wzsdbs=="";
if($tmp2)goto L2xeWjgx6g;
goto L2xldMhx6g;
goto L2xldMhx6g;
goto L2xldMhx6g;
goto L2xldMhx6g;
goto L2xldMhx6g;
L2xeWjgx6g:
    $wzsdbs=132424;
goto L2xx6d;
L2xldMhx6g:
    $wzsdbs='<i class="iconfont icon-hongbao sh-homecontent-wzsbs" title="红包" style="font-size: 13px;color: #ed2424;bottom: 6px;right: 20px;"></i>' . $wzsdbs;
L2xldMhx6e:
L2xx6d:
    $tmp2=$ptplx=="img";
if($tmp2)goto L2xeWjgx6i;
goto L2xldMhx6i;
goto L2xldMhx6i;
goto L2xldMhx6i;
goto L2xldMhx6i;
goto L2xldMhx6i;
L2xeWjgx6i:
    $row=explode('(+@+)', $ptpimag);
    $imgar=$row;
    $row=count($imgar);
    $coun=$row;
    $tmp2=$coun==1;
if($tmp2)goto L2xeWjgx6k;
goto L2xldMhx6k;
goto L2xldMhx6k;
goto L2xldMhx6k;
goto L2xldMhx6k;
goto L2xldMhx6k;
L2xeWjgx6k:
    $tmp2='<div class="sh-homecontent-lie">
    <!-- 左边 -->
    <div class="sh-homecontent-left">
    <!-- 日期 -->
    <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
    $tmp5=$tmp2 . '" style="';
    $tmp3=$tmp5 . $shougbsx;
    $tmp4=$tmp3 . '">
    <span class="homecontent-left-time-h">';
    $tmp26=$tmp4 . $day;
    $tmp27=$tmp26 . '</span>
    <span class="homecontent-left-time-y">';
    $tmp28=$tmp27 . $month;
    $tmp29=$tmp28 . '月</span>
    </div>
    <!-- 地址 -->
    <div class="sh-homecontent-left-time-dw">';
    $tmp30=$tmp29 . $ptpdw;
    $tmp31=$tmp30 . '</div>
    </div>
    <!-- 右边内容框架 -->
    <div class="sh-homecontent-right-wk">
    <!-- 右边内容主体 -->
    <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
    $tmp32=$tmp31 . $cid;
    $tmp33=$tmp32 . '\';">
    <!-- 图片 -->
    <div class="homecontent-right-tw">
    <!-- 图片 -->
    <div class="homecontent-right-tw-img" style="grid-template-columns: 1fr;grid-template-rows: 1fr;">
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp6=$tmp33 . $imgar[0];
    $tmp34=$tmp6 . '" alt=""></div>
    ';
    $tmp35=$tmp34 . $wzsdbs;
    $tmp36=$tmp35 . '
    </div>
    </div>
    <!-- 文字内容 -->
    <div class="homecontent-right-nr">
    <div class="homecontent-right-nr-text">';
    $tmp37=$tmp36 . $ptptext;
    $tmp38=$tmp37 . '</div>
    <p class="homecontent-right-nr-tus">共';
    $tmp39=$tmp38 . $coun;
    $tmp7=$tmp39 . '张</p>
    </div>
    </div>
    </div>
    </div>';
    $wzbank=$tmp7;
goto L2xx6h;
L2xldMhx6k:
    $tmp2=$coun==2;
if($tmp2)goto L2xeWjgx6l;
goto L2xldMhx6l;
goto L2xldMhx6l;
goto L2xldMhx6l;
goto L2xldMhx6l;
goto L2xldMhx6l;
L2xeWjgx6l:
    $tmp2='<div class="sh-homecontent-lie">
    <!-- 左边 -->
    <div class="sh-homecontent-left">
    <!-- 日期 -->
    <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
    $tmp5=$tmp2 . '" style="';
    $tmp3=$tmp5 . $shougbsx;
    $tmp4=$tmp3 . '">
    <span class="homecontent-left-time-h">';
    $tmp26=$tmp4 . $day;
    $tmp27=$tmp26 . '</span>
    <span class="homecontent-left-time-y">';
    $tmp28=$tmp27 . $month;
    $tmp29=$tmp28 . '月</span>
    </div>
    <!-- 地址 -->
    <div class="sh-homecontent-left-time-dw">';
    $tmp30=$tmp29 . $ptpdw;
    $tmp31=$tmp30 . '</div>
    </div>
    <!-- 右边内容框架 -->
    <div class="sh-homecontent-right-wk">
    <!-- 右边内容主体 -->
    <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
    $tmp32=$tmp31 . $cid;
    $tmp33=$tmp32 . '\';">
    <!-- 图片 -->
    <div class="homecontent-right-tw">
    <!-- 图片 -->
    <div class="homecontent-right-tw-img">
    <div class="homecontent-right-tw-img-wk" style="grid-row: 1 / 3;"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp6=$tmp33 . $imgar[0];
    $tmp34=$tmp6 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk" style="grid-row: 1 / 3;"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp35=$tmp34 . $imgar[1];
    $tmp36=$tmp35 . '" alt=""></div>
    ';
    $tmp37=$tmp36 . $wzsdbs;
    $tmp38=$tmp37 . '
    </div>
    </div>
    <!-- 文字内容 -->
    <div class="homecontent-right-nr">
    <div class="homecontent-right-nr-text">';
    $tmp39=$tmp38 . $ptptext;
    $tmp7=$tmp39 . '</div>
    <p class="homecontent-right-nr-tus">共';
    $tmp8=$tmp7 . $coun;
    $tmp9=$tmp8 . '张</p>
    </div>
    </div>
    </div>
    </div>';
    $wzbank=$tmp9;
goto L2xx6h;
L2xldMhx6l:
    $tmp2=$coun==3;
if($tmp2)goto L2xeWjgx6m;
goto L2xldMhx6m;
goto L2xldMhx6m;
goto L2xldMhx6m;
goto L2xldMhx6m;
goto L2xldMhx6m;
L2xeWjgx6m:
    $tmp2='<div class="sh-homecontent-lie">
    <!-- 左边 -->
    <div class="sh-homecontent-left">
    <!-- 日期 -->
    <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
    $tmp5=$tmp2 . '" style="';
    $tmp3=$tmp5 . $shougbsx;
    $tmp4=$tmp3 . '">
    <span class="homecontent-left-time-h">';
    $tmp26=$tmp4 . $day;
    $tmp27=$tmp26 . '</span>
    <span class="homecontent-left-time-y">';
    $tmp28=$tmp27 . $month;
    $tmp29=$tmp28 . '月</span>
    </div>
    <!-- 地址 -->
    <div class="sh-homecontent-left-time-dw">';
    $tmp30=$tmp29 . $ptpdw;
    $tmp31=$tmp30 . '</div>
    </div>
    <!-- 右边内容框架 -->
    <div class="sh-homecontent-right-wk">
    <!-- 右边内容主体 -->
    <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
    $tmp32=$tmp31 . $cid;
    $tmp33=$tmp32 . '\';">
    <!-- 图片 -->
    <div class="homecontent-right-tw">
    <!-- 图片 -->
    <div class="homecontent-right-tw-img">
    <div class="homecontent-right-tw-img-wk" style="grid-row: 1 / 3;"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp6=$tmp33 . $imgar[0];
    $tmp34=$tmp6 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp35=$tmp34 . $imgar[1];
    $tmp36=$tmp35 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp37=$tmp36 . $imgar[2];
    $tmp38=$tmp37 . '" alt=""></div>
    ';
    $tmp39=$tmp38 . $wzsdbs;
    $tmp7=$tmp39 . '
    </div>
    </div>
    <!-- 文字内容 -->
    <div class="homecontent-right-nr">
    <div class="homecontent-right-nr-text">';
    $tmp8=$tmp7 . $ptptext;
    $tmp9=$tmp8 . '</div>
    <p class="homecontent-right-nr-tus">共';
    $tmp10=$tmp9 . $coun;
    $tmp11=$tmp10 . '张</p>
    </div>
    </div>
    </div>
    </div>';
    $wzbank=$tmp11;
goto L2xx6h;
L2xldMhx6m:
    $tmp2=$coun==4;
    $tmp3=(bool)$tmp2;
    $tmp4=!$tmp3;
    if($tmp4){
        $tmp5=$coun>=4;
        $tmp3=(bool)$tmp5;
    }
if($tmp3)goto L2xeWjgx6p;
goto L2xx6h;
goto L2xx6h;
goto L2xx6h;
goto L2xx6h;
goto L2xx6h;
L2xeWjgx6p:
    $tmp2='<div class="sh-homecontent-lie">
    <!-- 左边 -->
    <div class="sh-homecontent-left">
    <!-- 日期 -->
    <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
    $tmp5=$tmp2 . '" style="';
    $tmp3=$tmp5 . $shougbsx;
    $tmp4=$tmp3 . '">
    <span class="homecontent-left-time-h">';
    $tmp26=$tmp4 . $day;
    $tmp27=$tmp26 . '</span>
    <span class="homecontent-left-time-y">';
    $tmp28=$tmp27 . $month;
    $tmp29=$tmp28 . '月</span>
    </div>
    <!-- 地址 -->
    <div class="sh-homecontent-left-time-dw">';
    $tmp30=$tmp29 . $ptpdw;
    $tmp31=$tmp30 . '</div>
    </div>
    <!-- 右边内容框架 -->
    <div class="sh-homecontent-right-wk">
    <!-- 右边内容主体 -->
    <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
    $tmp32=$tmp31 . $cid;
    $tmp33=$tmp32 . '\';">
    <!-- 图片 -->
    <div class="homecontent-right-tw">
    <!-- 图片 -->
    <div class="homecontent-right-tw-img">
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp6=$tmp33 . $imgar[0];
    $tmp34=$tmp6 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp35=$tmp34 . $imgar[1];
    $tmp36=$tmp35 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp37=$tmp36 . $imgar[2];
    $tmp38=$tmp37 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp39=$tmp38 . $imgar[3];
    $tmp7=$tmp39 . '" alt=""></div>
    ';
    $tmp8=$tmp7 . $wzsdbs;
    $tmp9=$tmp8 . '
    </div>
    </div>
    <!-- 文字内容 -->
    <div class="homecontent-right-nr">
    <div class="homecontent-right-nr-text">';
    $tmp10=$tmp9 . $ptptext;
    $tmp11=$tmp10 . '</div>
    <p class="homecontent-right-nr-tus">共';
    $tmp12=$tmp11 . $coun;
    $tmp13=$tmp12 . '张</p>
    </div>
    </div>
    </div>
    </div>';
    $wzbank=$tmp13;
goto L2xx6h;
L2xldMhx6i:
    $tmp2=$ptplx=="video";
    if($tmp2){
        $tmp2=$videoauplay==1;
        if($tmp2){
            $videobf='autoplay';
            $videobfplas='';
        }else{
            $videobf='';
            $tmp2='<i class="iconfont icon-sa4f56" id="sh-content-video-videobfb-' . $cid;
            $tmp5=$tmp2 . '" style="width: fit-content;height: fit-content;grid-column: 1;grid-row: 1;z-index: 5;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);font-size: 30px;color: #ffffff;display: flex;cursor: pointer;padding: 15px;pointer-events: none;"></i>';
            $videobfplas=$tmp5;
        }
        $tmp2='<div class="sh-homecontent-lie">
        <!-- 左边 -->
        <div class="sh-homecontent-left">
        <!-- 日期 -->
        <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
        $tmp5=$tmp2 . '" style="';
        $tmp3=$tmp5 . $shougbsx;
        $tmp4=$tmp3 . '">
        <span class="homecontent-left-time-h">';
        $tmp26=$tmp4 . $day;
        $tmp27=$tmp26 . '</span>
        <span class="homecontent-left-time-y">';
        $tmp28=$tmp27 . $month;
        $tmp29=$tmp28 . '月</span>
        </div>
        <!-- 地址 -->
        <div class="sh-homecontent-left-time-dw">';
        $tmp30=$tmp29 . $ptpdw;
        $tmp31=$tmp30 . '</div>
        </div>
        <!-- 右边内容框架 -->
        <div class="sh-homecontent-right-wk">
        <!-- 右边内容主体 -->
        <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
        $tmp32=$tmp31 . $cid;
        $tmp33=$tmp32 . '\';">
        <!-- 视频 -->
        <div class="homecontent-right-tw">
        <!-- 视频 -->
        <div class="homecontent-right-tw-video">
        <video class="homecontent-right-tw-videoau" poster="';
        $tmp6=$tmp33 . $ptpvideofm;
        $tmp34=$tmp6 . '" src="';
        $tmp35=$tmp34 . $ptpvideo;
        $tmp36=$tmp35 . '" playsinline="" webkit-playsinline="" preload="metadata" ';
        $tmp37=$tmp36 . $videobf;
        $tmp38=$tmp37 . ' muted="" loop=""></video>
        ';
        $tmp39=$tmp38 . $videobfplas;
        $tmp7=$tmp39 . '
        <span class="sh-video-span" style="left: 4px;bottom: 4px;">MP4</span>
        ';
        $tmp8=$tmp7 . $wzsdbs;
        $tmp9=$tmp8 . '
        </div>
        </div>
        <!-- 文字内容 -->
        <div class="homecontent-right-nr">
        <div class="homecontent-right-nr-text">';
        $tmp10=$tmp9 . $ptptext;
        $tmp11=$tmp10 . '</div>
        </div>
        </div>
        </div>
        </div>';
        $wzbank=$tmp11;
    }else{
        $tmp2=$ptplx=="music";
        if($tmp2){
            $row=explode('|', $ptpmusic);
            $mus=$row;
            $musm=$mus[1];
            $muss=$mus[2];
            $musimg=$mus[3];
            $tmp2=$musm=="";
            if($tmp2){
                $musm='-';
            }
            $tmp2=$muss=="";
            if($tmp2){
                $muss='-';
            }
            $tmp2=$musimg=="";
            if($tmp2){
                $musimg="./assets/img/musicba.jpg";
            }else{
                $musimg=$mus[3];
            }
            $row=is_numeric($ptpmusic);
            if($row){
                $musm='网易云音乐播放器已移除';
            }
            $tmp2=$ptptext=="";
            if($tmp2){
                $ptpnr='';
            }else{
                $tmp2='<div class="sh-homecontent-right-lie-music-title">' . $ptptext;
                $ptpnr=$tmp2 . '</div>';
            }
            $tmp2='<div class="sh-homecontent-lie">
            <!-- 左边 -->
            <div class="sh-homecontent-left">
            <!-- 日期 -->
            <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
            $tmp5=$tmp2 . '" style="';
            $tmp3=$tmp5 . $shougbsx;
            $tmp4=$tmp3 . '">
            <span class="homecontent-left-time-h">';
            $tmp26=$tmp4 . $day;
            $tmp27=$tmp26 . '</span>
            <span class="homecontent-left-time-y">';
            $tmp28=$tmp27 . $month;
            $tmp29=$tmp28 . '月</span>
            </div>
            <!-- 地址 -->
            <div class="sh-homecontent-left-time-dw">';
            $tmp30=$tmp29 . $ptpdw;
            $tmp31=$tmp30 . '</div>
            </div>
            <!-- 右边内容框架 -->
            <div class="sh-homecontent-right-wk">
            <!-- 右边内容主体 -->
            <div class="sh-homecontent-right-lie-musicwk" onclick="window.location.href = \'./view.php?cid=';
            $tmp32=$tmp31 . $cid;
            $tmp33=$tmp32 . '\';">';
            $tmp6=$tmp33 . $wzsdbs;
            $tmp34=$tmp6 . '
            ';
            $tmp35=$tmp34 . $ptpnr;
            $tmp36=$tmp35 . '
            <div class="sh-homecontent-right-lie sh-homecontent-right-lie-music">
            <!-- 音乐 -->
            <div class="homecontent-right-tw homecontent-right-tw-music">
            <!-- 图片 -->
            <div class="homecontent-right-tw-img" style="grid-template-columns: 1fr;grid-template-rows: 1fr;">
            <div class="homecontent-right-tw-img-wk homecontent-right-tw-img-wk-music"><img src="./assets/img/thumbnail.svg" data-src="';
            $tmp37=$tmp36 . $musimg;
            $tmp38=$tmp37 . '" alt=""><i class="iconfont icon-sa4f56"></i></div>
            </div>
            </div>
            <!-- 文字内容 -->
            <div class="homecontent-right-nr homecontent-right-nr-music">
            <div class="homecontent-right-nr-text homecontent-right-nr-text-music" style="color: var(--thetitle);">';
            $tmp39=$tmp38 . $musm;
            $tmp7=$tmp39 . '</div>
            <p class="homecontent-right-nr-text-music-p homecontent-right-nr-text-music">';
            $tmp8=$tmp7 . $muss;
            $tmp9=$tmp8 . '</p>
            </div>
            </div>
            </div>
            </div>
            </div>';
            $wzbank=$tmp9;
        }else{
            $tmp2=$ptplx=="only";
            if($tmp2){
                $tmp2='<div class="sh-homecontent-lie">
                <!-- 左边 -->
                <div class="sh-homecontent-left">
                <!-- 日期 -->
                <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
                $tmp5=$tmp2 . '" style="';
                $tmp3=$tmp5 . $shougbsx;
                $tmp4=$tmp3 . '">
                <span class="homecontent-left-time-h">';
                $tmp26=$tmp4 . $day;
                $tmp27=$tmp26 . '</span>
                <span class="homecontent-left-time-y">';
                $tmp28=$tmp27 . $month;
                $tmp29=$tmp28 . '月</span>
                </div>
                <!-- 地址 -->
                <div class="sh-homecontent-left-time-dw">';
                $tmp30=$tmp29 . $ptpdw;
                $tmp31=$tmp30 . '</div>
                </div>
                <div class="sh-homecontent-right-wk">
                <!-- 右边内容主体 -->
                <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
                $tmp32=$tmp31 . $cid;
                $tmp33=$tmp32 . '\';">
                <!-- 仅文字 -->
                <!-- 文字内容 -->
                <div class="homecontent-right-nr" style="min-height: 10px;background: var(--fgxys);position:relative;">
                <div class="homecontent-right-nr-text homecontent-right-nr-textjw" style="margin: 10px;">';
                $tmp6=$tmp33 . $ptptext;
                $tmp34=$tmp6 . '</div>
                ';
                $tmp35=$tmp34 . $wzsdbs;
                $tmp36=$tmp35 . '
                </div>
                </div>
                </div>
                </div>';
                $wzbank=$tmp36;
            }else{
                $tmp2=$ptplx=="mony";
                if($tmp2){
                    $tmp2='<div class="sh-homecontent-lie">
                    <!-- 左边 -->
                    <div class="sh-homecontent-left">
                    <!-- 日期 -->
                    <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
                    $tmp5=$tmp2 . '" style="';
                    $tmp3=$tmp5 . $shougbsx;
                    $tmp4=$tmp3 . '">
                    <span class="homecontent-left-time-h">';
                    $tmp26=$tmp4 . $day;
                    $tmp27=$tmp26 . '</span>
                    <span class="homecontent-left-time-y">';
                    $tmp28=$tmp27 . $month;
                    $tmp29=$tmp28 . '</span>
                    </div>
                    <!-- 地址 -->
                    <div class="sh-homecontent-left-time-dw">';
                    $tmp30=$tmp29 . $ptpdw;
                    $tmp31=$tmp30 . '</div>
                    </div>
                    <div class="sh-homecontent-right-wk">
                    <!-- 右边内容主体 -->
                    <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
                    $tmp32=$tmp31 . $cid;
                    $tmp33=$tmp32 . '\';">
                    <!-- 仅文字 -->
                    <!-- 文字内容 -->
                    <div class="homecontent-right-nr" style="min-height: 10px;background: var(--fgxys);position:relative;">
                    <div class="homecontent-right-nr-text homecontent-right-nr-textjw" style="margin: 10px;">';
                    $tmp6=$tmp33 . $ptptext;
                    $tmp34=$tmp6 . '</div>
                    ';
                    $tmp35=$tmp34 . $wzsdbs;
                    $tmp36=$tmp35 . '
                    </div>
                    </div>
                    </div>
                    </div>';
                    $wzbank=$tmp36;
                }
L2xx6h:
            }
        }
    }
    echo $wzbank;
goto L2xx77;
L2xldMhx78:
L2xx77:
    $tmp25=$tmp25+1;
}
L2xxbe:
L2xx8k:
$tmp2='8965896582315263skfjskfjsgdfgdgddjskdjgdsdsjhd' . $dqgs;
$tmp5=$tmp2 . 'fedfrtgg6h5j8u5j5d45hgd5s4fh5sd5gdf8w5dss48sd1fds56ds156';
echo $tmp5;
$result=$conn->close();