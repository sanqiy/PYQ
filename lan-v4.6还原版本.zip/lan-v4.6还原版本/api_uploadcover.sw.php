<?php
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp=$user_zh=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$user_passid=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit("请先登录!");
}
$tmp=include '../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$currentTime=htmlspecialchars($user_zh);
$cookieResult=addslashes($currentTime);
$user_zhsg=$cookieResult;
$tmp="select * from user where username='" . $user_zhsg;
$sqls=$tmp . "'";
$row=mysqli_query($conn, $sqls);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$data2s_row=$row;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($sentinel))break;
    $glyzhuser=$row["username"];
}
L2xxf:
$str="select * from user where username='" . $user_zh;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
$zid=$data2_row["id"];
$zjpassword=$data2_row["password"];
if($user_passid!=$passid){
    $currentTime=time();
    $str=$currentTime+ -1;
    $cookieResult=setcookie("username", "", $str, "/");
    $currentTime=time();
    $str=$currentTime+ -1;
    $cookieResult=setcookie("passid", "", $str, "/");
    exit("账号信息异常,请重新登录!");
}
$auth_keylocation='./key.php';
$auth_keyauth='./auth.php';
$num=3393;
$row=file_exists($auth_keyauth);
if($row){
    $num=130;
}else{
    $num=100;
}
$tmp=78;
$tmp4=100;
$tmp2=$num==100;
if($tmp2)goto L2xeWjgxs;
goto L2xldMhxs;
L2xeWjgxs:
exit("授权验证文件不存在或被篡改,请确保文件完整且未篡改!");
goto L2xxr;
L2xldMhxs:
$tmp=280;
$tmp4=130;
$tmp2=$num==130;
if($tmp2)goto L2xeWjgxt;
goto L2xldMhxt;
L2xeWjgxt:
$tmp=require $auth_keyauth;
$tmp=!defined("sh_auth_state");
if($tmp){
    exit('授权验证失败,请确保文件完整且未篡改!');
}
$tmp=sh_auth_state!="ok";
if($tmp)goto L2xeWjgxq;
goto L2xxr;
goto L2xxr;
L2xeWjgxq:
exit('程序未授权,您的请求已被拒绝,请授权后使用!');
goto L2xxr;
L2xldMhxt:
L2xxr:
$str="../user/";
$row=iconv("UTF-8", "GBK", $str);
$dir=$row;
$num2=3380;
$row=file_exists($dir);
$tmp=!$row;
if($tmp){
    $num2=45;
}else{
    $num2=30;
}
$tmp=40;
$tmp4=45;
$tmp2=$num2==45;
if($tmp2)goto L2xeWjgx12;
goto L2xldMhx12;
L2xeWjgx12:
$row=mkdir($dir, true);
goto L2xx11;
L2xldMhx12:
$tmp=8;
$tmp4=30;
$tmp2=$num2==30;
if($tmp2)goto L2xx11;
L2xx11:
$str="../user/cover/";
$row=iconv("UTF-8", "GBK", $str);
$dir=$row;
$num3=3385;
$row=file_exists($dir);
$tmp=!$row;
if($tmp){
    $num3=15;
}else{
    $num3=50;
}
$tmp=221;
$tmp4=50;
$tmp2=$num3==50;
if($tmp2)goto L2xx16;
switch($num3){
    case 15:{
    $row=mkdir($dir, true);
        break;
    }
}
L2xx16:
$file=$_FILES['file'];
$val[]="gif";
$val[]="jpeg";
$val[]="jpg";
$val[]="png";
$val[]="webp";
$allowedExts=$val;
$num4=3384;
$isArray=is_array($_FILES);
if($isArray){
    $file=&$_FILES["file"];
}else{
    $file=$_FILES["file"];
}
$isArray2=is_array($file);
unset($file);
if($isArray2){
    $num4=100;
}else{
    $num4=75;
}
switch($num4){
    case 75:{
    $file2=$_FILES["file"]["name"];
        break;
    }
    case 100:{
        $file2=&$_FILES["file"]["name"];
        break;
    }
}
$row=explode(".", $file2);
unset($file2);
$temp=$row;
$row=end($temp);
$extension=$row;
if($extension==''){
    exit("未选择图片!");
}
$isArray3=is_array($_FILES);
if($isArray3){
    $file3=&$_FILES["file"];
}else{
    $file3=$_FILES["file"];
}
$isArray4=is_array($file3);
unset($file3);
if($isArray4){
    $file2=&$_FILES["file"]["name"];
}else{
    $file2=$_FILES["file"]["name"];
}
$row=strpos($file2, "php");
unset($file2);
$tmp=$row!==false;
$tmp2=(bool)$tmp;
$tmp5=!$tmp2;
if($tmp5){
    $isArray5=is_array($_FILES);
    if($isArray5){
        $file4=&$_FILES["file"];
    }else{
        $file4=$_FILES["file"];
    }
    $isArray6=is_array($file4);
    unset($file4);
    if($isArray6){
        $file=&$_FILES["file"]["name"];
    }else{
        $file=$_FILES["file"]["name"];
    }
    $isArray2=strpos($file, "js");
    unset($file);
    $tmp4=$isArray2!==false;
    $tmp2=(bool)$tmp4;
}
$tmp6=(bool)$tmp2;
$tmp7=!$tmp6;
if($tmp7){
    $isArray7=is_array($_FILES);
    if($isArray7){
        $file5=&$_FILES["file"];
    }else{
        $file5=$_FILES["file"];
    }
    $isArray8=is_array($file5);
    unset($file5);
    if($isArray8){
        $file6=&$_FILES["file"]["name"];
    }else{
        $file6=$_FILES["file"]["name"];
    }
    $isArray=strpos($file6, "html");
    unset($file6);
    $tmp3=$isArray!==false;
    $tmp6=(bool)$tmp3;
}
if($tmp2){
    exit("文件有风险，请重试!");
}
$num5=3378;
$tmp=$file['type']=='image/jpeg';
$tmp2=(bool)$tmp;
$tmp8=!$tmp2;
if($tmp8){
    $tmp4=$file['type']=='image/png';
    $tmp2=(bool)$tmp4;
}
$tmp6=(bool)$tmp2;
$tmp9=!$tmp6;
if($tmp9){
    $tmp3=$file['type']=='image/jpg';
    $tmp6=(bool)$tmp3;
}
$tmp10=(bool)$tmp6;
$tmp11=!$tmp10;
if($tmp11){
    $tmp7=$file['type']=='image/gif';
    $tmp5=(bool)$tmp7;
    if($tmp5){
        $row=in_array($extension, $allowedExts);
        $tmp5=(bool)$row;
    }
    $tmp10=(bool)$tmp5;
}
if($tmp10){
    $num5=195;
}else{
    $num5=9;
}
$tmp=270;
$tmp4=9;
$tmp2=$num5==9;
if($tmp2)goto L2xeWjgx2g;
goto L2xldMhx2g;
L2xeWjgx2g:
exit("文件类型错误,请上传图片!");
goto L2xx2f;
L2xldMhx2g:
$tmp=64;
$tmp4=195;
$tmp2=$num5==195;
if($tmp2)goto L2xx2f;
L2xx2f:
if($file["size"]>5242880){
    exit("请上传5MB以内的图片!");
}
$tmp="select * from user where username= '" . $zjzhq;
$sql=$tmp . "'";
$row=mysqli_query($conn, $sql);
$result=$row;
$row=mysqli_num_rows($result);
$tmp=$row>0;
if($tmp)goto L2xeWjgx2t;
goto L2xldMhx2t;
L2xeWjgx2t:
$row=mysqli_fetch_assoc($result);
$row=$row;
$bdhomebjt='.' . $row["homeimg"];
$row=strstr($bdhomebjt, "/user/cover");
if($row)goto L2xeWjgx2p;
goto L2xx2s;
goto L2xx2s;
L2xeWjgx2p:
$row=file_exists($bdhomebjt);
if($row)goto L2xeWjgx2r;
goto L2xx2s;
goto L2xx2s;
L2xeWjgx2r:
$row=unlink($bdhomebjt);
goto L2xx2s;
L2xldMhx2t:
L2xx2s:
$path="../user/cover/";
$row=mt_rand();
$microtime=microtime(true);
$replaced=str_replace('.', '', $microtime);
$tmp=$row . $replaced;
$hash=md5($zjzhq);
$substr=substr($hash);
$tmp4=$tmp . $substr;
$file_name=$tmp4 . $file["name"];
$file_path=$path . $file_name;
$row=strpos($file_path, "php");
$tmp=$row!==false;
$tmp2=(bool)$tmp;
$tmp5=!$tmp2;
if($tmp5){
    $cookieResult=strpos($file_path, "js");
    $tmp4=$cookieResult!==false;
    $tmp2=(bool)$tmp4;
}
$tmp6=(bool)$tmp2;
$tmp7=!$tmp6;
if($tmp7){
    $replaced=strpos($file_path, "html");
    $tmp3=$replaced!==false;
    $tmp6=(bool)$tmp3;
}
if($tmp2){
    exit("文件有风险，请重试!");
}
$userimg="./user/cover/" . $file_name;
$num6=3389;
$isArray2=is_array($file);
if($isArray2){
    $file2=&$file["tmp_name"];
}else{
    $file2=$file["tmp_name"];
}
$row=move_uploaded_file($file2, $file_path);
unset($file2);
if($row){
    $num6=30;
}else{
    $num6=75;
}
$tmp=30;
$tmp4=30;
$tmp2=$num6==30;
if($tmp2)goto L2xeWjgx3e;
goto L2xldMhx3e;
L2xeWjgx3e:
$tmp="UPDATE user SET homeimg='" . $userimg;
$tmp4=$tmp . "' WHERE username='";
$tmp2=$tmp4 . $zjzhq;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx3c;
goto L2xx3d;
goto L2xx3d;
L2xeWjgx3c:
exit("修改封面成功");
goto L2xx3d;
L2xldMhx3e:
switch($num6){
    case 75:{
    exit("修改封面失败");
        break;
    }
}
L2xx3d:
$result=$conn->close();