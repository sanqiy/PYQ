<?php
if($_GET['close']!="true"){
    exit("非法访问!");
}
echo "<!DOCTYPE html>";
echo "
<html lang=\"en\">";
echo "
<head>";
echo "
<meta charset=\"UTF-8\">";
echo "
<title>页面出错!</title>";
echo "
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0,minimum-scale=1.0, user-scalable=no minimal-ui\">";
echo "
<style>*{margin: 0;padding: 0;}.content{padding: 10px 25px;}.title{font-size: 100px;color: #3e3e3e;}.text{font-size: 30px;margin-top: 20px;color: #3e3e3e;}.time{font-size: 18px;margin-top: 15px;color: #3e3e3e;}</style>";
echo "
</head>";
echo "
<body>";
echo "
<div class=\"content\">";
echo "
<div class=\"title\">:(</div>";
echo "
<h2 class=\"text\">暂时无法完成你的请求，请重试!</h2>";
echo "
<p class=\"time\">Time：";
$dateStr=date("Y-m-d H:i:s");
echo $dateStr;
echo "</p>";
echo "
</div>";
echo "
</body>";
echo "
</html>";

