<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val4[]=$val;
    $arr=$val4;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$filterupy="";
$sql="SELECT text FROM configx WHERE title = 'upyun'";
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0){
    $result=$result->fetch_assoc();
    $row=$result;
    $filterupy=$row['text'];
}
if($filterupy!=""){
    $curlOptResult=json_decode($filterupy, true);
    $array=$curlOptResult;
    $bucketName=$array['bucketName'];
    $operatorName=$array['operatorName'];
    $operatorPassword=$array['operatorPassword'];
    $operatorurl=$array['operatorurl'];
}
$num=8003;
$tmp=$bucketName=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$operatorName=="";
    $tmp2=(bool)$tmp4;
}
$tmp5=(bool)$tmp2;
$tmp6=!$tmp5;
if($tmp6){
    $tmp7=$operatorPassword=="";
    $tmp5=(bool)$tmp7;
}
$tmp8=(bool)$tmp5;
$tmp9=!$tmp8;
if($tmp9){
    $tmp10=$operatorurl=="";
    $tmp8=(bool)$tmp10;
}
if($tmp8){
    $num=49;
}else{
    $num=35;
}
$tmp=75;
$tmp4=49;
$tmp2=$num==49;
if($tmp2)goto L2xeWjgxq;
goto L2xldMhxq;
L2xeWjgxq:
$upy=0;
goto L2xxp;
L2xldMhxq:
$tmp=112;
$tmp4=35;
$tmp2=$num==35;
if($tmp2)goto L2xeWjgxr;
goto L2xldMhxr;
L2xeWjgxr:
$bucketName=$bucketName;
$operatorName=$operatorName;
$operatorPassword=$operatorPassword;
$uploadUrl='http://v0.api.upyun.com/' . $bucketName;
$cow="/lan/";
$imagePath=$newFile;
$imageName=$upylu;
$val2=$operatorName . ':';
$val3=$val2 . $operatorPassword;
$fileSize=base64_encode($val3);
$str='Authorization: Basic ' . $fileSize;
$val5[]=$str;
$val5[]='Content-Type: application/octet-stream';
$val5[]='Expect:';
$headers=$val5;
$curlOptResult=fopen($imagePath, 'r');
$handle=$curlOptResult;
$curlOptResult=curl_init();
$ch=$curlOptResult;
$val6=$uploadUrl . $cow;
$val7=$val6 . $imageName;
$curlOptResult=curl_setopt($ch, CURLOPT_URL, $val7);
$curlOptResult=curl_setopt($ch, CURLOPT_PUT, true);
$curlOptResult=curl_setopt($ch, CURLOPT_INFILE, $handle);
$fileSize=filesize($imagePath);
$curlOptResult2=curl_setopt($ch, CURLOPT_INFILESIZE, $fileSize);
$curlOptResult=curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$curlOptResult=curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$curlOptResult=curl_exec($ch);
$response=$curlOptResult;
$curlOptResult=curl_getinfo($ch, CURLINFO_HTTP_CODE);
$httpCode=$curlOptResult;
$curlOptResult=curl_close($ch);
$curlOptResult=fclose($handle);
$tmp=$httpCode==200;
if($tmp)goto L2xeWjgxm;
goto L2xldMhxm;
goto L2xldMhxm;
L2xeWjgxm:
$val6=$operatorurl . $cow;
$val7=$val6 . $upylu;
$curlOptResult=array_push($arr, $val7);
$upy=1;
$curlOptResult=file_exists($newFile);
if($curlOptResult)goto L2xeWjgxo;
goto L2xxp;
goto L2xxp;
L2xeWjgxo:
$curlOptResult=unlink($newFile);
goto L2xxp;
L2xldMhxm:
$upy=0;
L2xldMhxr:
L2xxp:

