<?php
$iteace=1;
$replaced=is_file('../config.php');
if($replaced){
    $tmp=include '../config.php';
}
$tmp=include '../api/wz.php';
if($userdlzt==0){
    $replaced=header('location: ./login.php');
    exit();
}
$num9=2744;
$tmp=$user_zh==$glyadmin;
if($tmp){
    $num9=15;
}else{
    $num9=15;
    $num9=899;
}
$tmp=90;
$tmp2=15;
$tmp3=$num9==15;
if($tmp3)goto L2xeWjgxe;
goto L2xldMhxe;
L2xeWjgxe:
$tmp=$user_passid!=$passid;
if($tmp)goto L2xeWjgxc;
goto L2xxd;
goto L2xxd;
L2xeWjgxc:
exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="./login.php";</script>;');
goto L2xxd;
L2xldMhxe:
switch($num9){
    case 457:{
    exit('<script language="JavaScript">;alert("没有权限!");location.href="../index.php";</script>;');
        break;
    }
}
L2xxd:
$num10=2758;
$isArray=is_array($_POST);
if($isArray){
    $num10=45;
}else{
    $num10=42;
}
switch($num10){
    case 45:{
    $type=&$_POST['wzxgcid'];
        break;
    }
    case 42:{
        $type=$_POST['wzxgcid'];
        break;
    }
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$wzxgcid=$escaped2;
if($wzxgcid!="")goto L2xeWjgx1l;
goto L2xldMhx1l;
L2xeWjgx1l:
$isArray=is_array($_POST);
if($isArray){
    $type=&$_POST['exampleRadios'];
}else{
    $type=$_POST['exampleRadios'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$exampleRadios=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $type=&$_POST['ptpnr'];
}else{
    $type=$_POST['ptpnr'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$ptpnr=$escaped2;
$replaced=str_replace(PHP_EOL, "<br>", $ptpnr);
$ptpnr=$replaced;
$isArray=is_array($_POST);
if($isArray){
    $type=&$_POST['ptptup'];
}else{
    $type=$_POST['ptptup'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$ptptup=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $type=&$_POST['ptpsp'];
}else{
    $type=$_POST['ptpsp'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$ptpsp=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $type=&$_POST['ptpyy'];
}else{
    $type=$_POST['ptpyy'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$ptpyy=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $type=&$_POST['ptpdw'];
}else{
    $type=$_POST['ptpdw'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$ptpdw=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $type=&$_POST['ptpgg'];
}else{
    $type=$_POST['ptpgg'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$ptpgg=$escaped2;
$replaced=str_replace(PHP_EOL, "(+@+)", $ptptup);
$ptptup=$replaced;
$tmp=$exampleRadios!="";
if($tmp){
    $tmp="UPDATE essay SET ptplx='" . $exampleRadios;
    $tmp2=$tmp . "' WHERE cid='";
    $tmp3=$tmp2 . $wzxgcid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$ptpnr!="";
if($tmp){
    $tmp="UPDATE essay SET ptptext='" . $ptpnr;
    $tmp2=$tmp . "' WHERE cid='";
    $tmp3=$tmp2 . $wzxgcid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$ptptup!="";
if($tmp){
    $tmp="UPDATE essay SET ptpimag='" . $ptptup;
    $tmp2=$tmp . "' WHERE cid='";
    $tmp3=$tmp2 . $wzxgcid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$ptpsp!="";
if($tmp){
    $tmp="UPDATE essay SET ptpvideo='" . $ptpsp;
    $tmp2=$tmp . "' WHERE cid='";
    $tmp3=$tmp2 . $wzxgcid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$ptpyy!="";
if($tmp){
    $tmp="UPDATE essay SET ptpmusic='" . $ptpyy;
    $tmp2=$tmp . "' WHERE cid='";
    $tmp3=$tmp2 . $wzxgcid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$ptpdw!="";
if($tmp){
    $tmp="UPDATE essay SET ptpdw='" . $ptpdw;
    $tmp2=$tmp . "' WHERE cid='";
    $tmp3=$tmp2 . $wzxgcid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$ptpgg!="";
if($tmp){
    $tmp="UPDATE essay SET ptpggurl='" . $ptpgg;
    $tmp2=$tmp . "' WHERE cid='";
    $tmp3=$tmp2 . $wzxgcid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp="UPDATE essay SET ptptext='" . $text;
$tmp2=$tmp . "',ptpdw='";
$tmp3=$tmp2 . $dw;
$tmp4=$tmp3 . "' ";
$tmp5=$tmp4 . $wftime;
$tmp6=$tmp5 . ",ptpgg='";
$tmp7=$tmp6 . $gg;
$tmp8=$tmp7 . "',ptpggurl='";
$tmp9=$tmp8 . $gglj;
$tmp10=$tmp9 . "',commauth='";
$tmp11=$tmp10 . $yxplkg;
$tmp12=$tmp11 . "' WHERE id='";
$tmp13=$tmp12 . $edbjwzid;
$sql=$tmp13 . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx1j;
goto L2xldMhx1j;
goto L2xldMhx1j;
L2xeWjgx1j:
$replaced=header("location:./auditesli.php?type=all");
goto L2xx1k;
L2xldMhx1j:
$referer=$_SERVER['HTTP_REFERER'];
$tmp='<script language="JavaScript">;alert("文章编辑出错,请重试");location.href="' . $referer;
exit($tmp . '";</script>;');
L2xldMhx1l:
L2xx1k:
echo "<!doctype html>";
echo "
<html lang=\"en\">";
echo "
<head>";
echo "
<meta charset=\"utf-8\">";
echo "
<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0\">";
echo "
<title>文章列表 - ";
echo $name;
echo "</title>";
echo "
<meta name=\"keywords\" content=\"";
echo $filterkeyw;
echo "\">";
echo "
<meta name=\"description\" content=\"";
echo $subtitle;
echo "\">";
echo "
<meta name=\"author\" content=\"";
echo $name;
echo "\">";
echo "
<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"";
$num3=2763;
$replaced=strpos($icon, 'http');
$tmp=$replaced!==false;
if($tmp){
    $num3=30;
}else{
    $num3=70;
}
switch($num3){
    case 30:{
    echo $icon;
        break;
    }
    case 70:{
        $tmp='.' . $icon;
        echo $tmp;
        break;
    }
}
echo "\">";
echo "
<link rel=\"stylesheet\" href=\"assets/css/css2.css\">";
echo "
<link rel=\"stylesheet\" id=\"css-main\" href=\"assets/css/oneui.min.css\">";
echo "
</head>";
echo "
<body>";
echo "
<div id=\"page-container\" class=\"sidebar-o sidebar-dark page-header-fixed main-content-narrow\">";
echo "
<nav id=\"sidebar\" aria-label=\"Main Navigation\">";
echo "
<!-- Side Header -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Logo -->";
echo "
<a class=\"fw-semibold text-dual\" href=\"index.php\">";
echo "
<span class=\"smini-visible\">";
echo "
<i class=\"fa fa-circle-notch text-primary\"></i>";
echo "
</span>";
echo "
<span class=\"smini-hide fs-5 tracking-wider\">后台管理</span>";
echo "
</a>";
echo "
<!-- END Logo -->";
echo "
";
echo "
<!-- Extra -->";
echo "
<div>";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" data-toggle=\"layout\" data-action=\"dark_mode_toggle\">";
echo "
<i class=\"far fa-moon\"></i>";
echo "
</button>";
echo "
<!-- END Dark Mode -->";
echo "
";
echo "
<!-- Options -->";
echo "
<div class=\"dropdown d-inline-block ms-1\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" id=\"sidebar-themes-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<i class=\"far fa-circle\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-end fs-sm smini-hide border-0\" aria-labelledby=\"sidebar-themes-dropdown\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"default\" href=\"#\">";
echo "
<span>默认</span>";
echo "
<i class=\"fa fa-circle text-default\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/amethyst.min.css\" href=\"#\">";
echo "
<span>紫色</span>";
echo "
<i class=\"fa fa-circle text-amethyst\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/city.min.css\" href=\"#\">";
echo "
<span>红色</span>";
echo "
<i class=\"fa fa-circle text-city\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/flat.min.css\" href=\"#\">";
echo "
<span>青色</span>";
echo "
<i class=\"fa fa-circle text-flat\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/modern.min.css\" href=\"#\">";
echo "
<span>蓝色</span>";
echo "
<i class=\"fa fa-circle text-modern\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/smooth.min.css\" href=\"#\">";
echo "
<span>粉色</span>";
echo "
<i class=\"fa fa-circle text-smooth\"></i>";
echo "
</a>";
echo "
<!-- END Color Themes -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_light\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 黑色</span>";
echo "
</a>";
echo "
<!-- END Sidebar Styles -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_light\" href=\"javascript:void(0)\">";
echo "
<span>导航 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>导航 黑色</span>";
echo "
</a>";
echo "
<!-- END Header Styles -->";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Options -->";
echo "
<a class=\"d-lg-none btn btn-sm btn-alt-secondary ms-1\" data-toggle=\"layout\" data-action=\"sidebar_close\" href=\"javascript:void(0)\">";
echo "
<i class=\"fa fa-fw fa-times\"></i>";
echo "
</a>";
echo "
<!-- END Close Sidebar -->";
echo "
</div>";
echo "
<!-- END Extra -->";
echo "
</div>";
echo "
<!-- END Side Header -->";
echo "
";
echo "
<!-- Sidebar Scrolling -->";
echo "
<div class=\"js-sidebar-scroll\">";
echo "
<!-- Side Navigation -->";
echo "
<div class=\"content-side\">";
echo "
<ul class=\"nav-main\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./index.php\">";
echo "
<i class=\"nav-main-link-icon si si-speedometer\"></i>";
echo "
<span class=\"nav-main-link-name\">后台首页</span>";
echo "
</a>";
echo "
</li>";
echo "
";
echo "
<li class=\"nav-main-heading\">设置</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-energy\"></i>";
echo "
<span class=\"nav-main-link-name\">网站设置</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./basic.php\">";
echo "
<span class=\"nav-main-link-name\">基础设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./authority.php\">";
echo "
<span class=\"nav-main-link-name\">权限设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./imgset.php\">";
echo "
<span class=\"nav-main-link-name\">图像设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./emailset.php\">";
echo "
<span class=\"nav-main-link-name\">邮箱设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./calis.php\">";
echo "
<span class=\"nav-main-link-name\">卡密管理</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-users\"></i>";
echo "
<span class=\"nav-main-link-name\">用户管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./userlist.php\">";
echo "
<span class=\"nav-main-link-name\">用户列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item open\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-book-open\"></i>";
echo "
<span class=\"nav-main-link-name\">文章管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link active\" href=\"./auditesli.php\">";
echo "
<span class=\"nav-main-link-name\">文章列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditessh.php\">";
echo "
<span class=\"nav-main-link-name\">审核文章</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-speech\"></i>";
echo "
<span class=\"nav-main-link-name\">评论管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditcoli.php\">";
echo "
<span class=\"nav-main-link-name\">评论列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditcosh.php\">";
echo "
<span class=\"nav-main-link-name\">审核评论</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-paper-clip\"></i>";
echo "
<span class=\"nav-main-link-name\">友链管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./linkset.php\">";
echo "
<span class=\"nav-main-link-name\">友链列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
</ul>";
echo "
</div>";
echo "
<!-- END Side Navigation -->";
echo "
</div>";
echo "
<!-- END Sidebar Scrolling -->";
echo "
</nav>";
echo "
<!-- END Sidebar -->";
echo "
";
echo "
<!-- Header -->";
echo "
<header id=\"page-header\">";
echo "
<!-- Header Content -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Left Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- Toggle Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-lg-none\" data-toggle=\"layout\" data-action=\"sidebar_toggle\">";
echo "
<i class=\"fa fa-fw fa-bars\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Sidebar -->";
echo "
";
echo "
<!-- Toggle Mini Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-none d-lg-inline-block\" data-toggle=\"layout\" data-action=\"sidebar_mini_toggle\">";
echo "
<i class=\"fa fa-fw fa-ellipsis-v\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Mini Sidebar -->";
echo "
";
echo "
<!-- Open Search Section (visible on smaller screens) -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
";
echo "
<!-- END Open Search Section -->";
echo "
";
echo "
<!-- Search Form (visible on larger screens) -->";
echo "
";
echo "
<!-- END Search Form -->";
echo "
</div>";
echo "
<!-- END Left Section -->";
echo "
";
echo "
<!-- Right Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- User Dropdown -->";
echo "
<div class=\"dropdown d-inline-block ms-2\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary d-flex align-items-center\" id=\"page-header-user-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<img class=\"rounded-circle\" src=\"";
$num4=2759;
$replaced=strpos($user_img, 'http');
$tmp=$replaced!==false;
if($tmp){
    $num4=42;
}else{
    $num4=90;
}
switch($num4){
    case 42:{
    echo $user_img;
        break;
    }
    case 90:{
        $tmp='.' . $user_img;
        echo $tmp;
        break;
    }
}
echo "\" alt=\"Header Avatar\" style=\"width: 21px;\">";
echo "
<span class=\"d-none d-sm-inline-block ms-2\">";
echo $user_name;
echo "</span>";
echo "
<i class=\"fa fa-fw fa-angle-down d-none d-sm-inline-block opacity-50 ms-1 mt-1\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-md dropdown-menu-end p-0 border-0\" aria-labelledby=\"page-header-user-dropdown\">";
echo "
<div class=\"p-3 text-center bg-body-light border-bottom rounded-top\">";
echo "
<img class=\"img-avatar img-avatar48 img-avatar-thumb\" src=\"";
$num5=2761;
$replaced=strpos($user_img, 'http');
$tmp=$replaced!==false;
if($tmp){
    $num5=15;
}else{
    $num5=196;
}
switch($num5){
    case 15:{
    echo $user_img;
        break;
    }
    case 196:{
        $tmp='.' . $user_img;
        echo $tmp;
        break;
    }
}
echo "\" alt=\"\">";
echo "
<p class=\"mt-2 mb-0 fw-medium\">";
echo $user_name;
echo "</p>";
echo "
<!--p class=\"mb-0 text-muted fs-sm fw-medium\">介绍</p-->";
echo "
</div>";
echo "
<div role=\"separator\" class=\"dropdown-divider m-0\"></div>";
echo "
<div class=\"p-2\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"../\">";
echo "
<span class=\"fs-sm fw-medium\">返回前台</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"JavaScript:;\" onclick=\"logut()\">";
echo "
<span class=\"fs-sm fw-medium\">退出登录</span>";
echo "
</a>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
<!-- END User Dropdown -->";
echo "
";
echo "
<!-- Notifications Dropdown -->";
echo "
";
echo "
<!-- END Notifications Dropdown -->";
echo "
";
echo "
<!-- Toggle Side Overlay -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
<!-- END Toggle Side Overlay -->";
echo "
</div>";
echo "
<!-- END Right Section -->";
echo "
</div>";
echo "
<!-- END Header Content -->";
echo "
";
echo "
<!-- Header Loader -->";
echo "
<!-- Please check out the Loaders page under Components category to see examples of showing/hiding it -->";
echo "
<div id=\"page-header-loader\" class=\"overlay-header bg-body-extra-light\">";
echo "
<div class=\"content-header\">";
echo "
<div class=\"w-100 text-center\">";
echo "
<i class=\"fa fa-fw fa-circle-notch fa-spin\"></i>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Header Loader -->";
echo "
</header>";
echo "
<!-- END Header -->";
echo "
";
echo "
<!-- Main Container -->";
echo "
<main id=\"main-container\">";
echo "
";
echo "
<!-- Page Content -->";
echo "
<div class=\"content\">";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
$num6=2761;
$isArray=is_array($_GET);
if($isArray){
    $num6=90;
}else{
    $num6=90;
    $num6=3618;
}
switch($num6){
    case 90:{
    $type=&$_GET['edit'];
        break;
    }
    case 1854:{
        $type=$_GET['edit'];
        break;
    }
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$edwzcid=$escaped2;
if($edwzcid!="")goto L2xeWjgx47;
goto L2xldMhx47;
L2xeWjgx47:
$tmp="SELECT * FROM essay WHERE cid = '" . $edwzcid;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
$tmp=$result->num_rows>0;
if($tmp)goto L2xeWjgx35;
goto L2xx46;
goto L2xx46;
L2xeWjgx35:
L2xx36:
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!$cond)break;
    $ptpuser=$row["ptpuser"];
    $ptpimg=$row["ptpimg"];
    $ptpname=$row["ptpname"];
    $ptptext=$row["ptptext"];
    $ptpimag=$row["ptpimag"];
    $ptpvideo=$row["ptpvideo"];
    $ptpmusic=$row["ptpmusic"];
    $ptplx=$row["ptplx"];
    $ptpdw=$row["ptpdw"];
    $ptptime=$row["ptptime"];
    $ptpgg=$row["ptpgg"];
    $ptpggurl=$row["ptpggurl"];
    $ptpys=$row["ptpys"];
    $commauth=$row["commauth"];
    $ptpaud=$row["ptpaud"];
    $ptpip=$row["ip"];
    $cid=$row["cid"];
    $wid=$row["id"];
    $replaced=explode("|", $ptpvideo);
    $partssp=$replaced;
    $ptpvideo=$partssp[0];
    $ptpvideofm=$partssp[1];
    $tmp=$ptpgg==1;
    if($tmp){
        $ggdiv=-22;
    }else{
        $ggdiv='';
    }
    $tmp=$ptplx=="img";
if($tmp)goto L2xeWjgx3b;
goto L2xldMhx3b;
goto L2xldMhx3b;
goto L2xldMhx3b;
L2xeWjgx3b:
    $cond='<div class="col-3">
    <label class="form-label">文章类型</label>
    <div class="form-check" style="margin-right: 5px;">
    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1t" value="img" checked="">
    <label class="form-check-label">
    图片
    </label>
    </div>
    </div>
    <div class="col-3">
    <label class="form-label"></label>
    <div class="form-check" style="margin-right: 5px;">
    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1s" value="video">
    <label class="form-check-label">
    视频
    </label>
    </div>
    </div>
    <div class="col-3">
    <label class="form-label"></label>
    <div class="form-check" style="margin-right: 5px;">
    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1y" value="music">
    <label class="form-check-label">
    音乐
    </label>
    </div>
    </div>
    <div class="col-3">
    <label class="form-label"></label>
    <div class="form-check">
    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1w" value="only">
    <label class="form-check-label">
    仅文字
    </label>
    </div>
    </div>';
    $ptlxx=$cond;
goto L2xx36;
L2xldMhx3b:
    $tmp=$ptplx=="video";
if($tmp)goto L2xeWjgx3c;
goto L2xldMhx3c;
goto L2xldMhx3c;
goto L2xldMhx3c;
L2xeWjgx3c:
    $cond='<div class="col-3">
    <label class="form-label">文章类型</label>
    <div class="form-check" style="margin-right: 5px;">
    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1t" value="img">
    <label class="form-check-label">
    图片
    </label>
    </div>
    </div>
    <div class="col-3">
    <label class="form-label"></label>
    <div class="form-check" style="margin-right: 5px;">
    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1s" value="video" checked="">
    <label class="form-check-label">
    视频
    </label>
    </div>
    </div>
    <div class="col-3">
    <label class="form-label"></label>
    <div class="form-check" style="margin-right: 5px;">
    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1y" value="music">
    <label class="form-check-label">
    音乐
    </label>
    </div>
    </div>
    <div class="col-3">
    <label class="form-label"></label>
    <div class="form-check">
    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1w" value="only">
    <label class="form-check-label">
    仅文字
    </label>
    </div>
    </div>';
    $ptlxx=$cond;
goto L2xx36;
L2xldMhx3c:
    $tmp=$ptplx=="music";
if($tmp)goto L2xeWjgx3d;
goto L2xldMhx3d;
goto L2xldMhx3d;
goto L2xldMhx3d;
L2xeWjgx3d:
    $cond='<div class="col-3">
    <label class="form-label">文章类型</label>
    <div class="form-check" style="margin-right: 5px;">
    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1t" value="img">
    <label class="form-check-label">
    图片
    </label>
    </div>
    </div>
    <div class="col-3">
    <label class="form-label"></label>
    <div class="form-check" style="margin-right: 5px;">
    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1s" value="video">
    <label class="form-check-label">
    视频
    </label>
    </div>
    </div>
    <div class="col-3">
    <label class="form-label"></label>
    <div class="form-check" style="margin-right: 5px;">
    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1y" value="music" checked="">
    <label class="form-check-label">
    音乐
    </label>
    </div>
    </div>
    <div class="col-3">
    <label class="form-label"></label>
    <div class="form-check">
    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1w" value="only">
    <label class="form-check-label">
    仅文字
    </label>
    </div>
    </div>';
    $ptlxx=$cond;
goto L2xx36;
L2xldMhx3d:
    $tmp=$ptplx=="only";
if($tmp)goto L2xeWjgx3e;
goto L2xx36;
goto L2xx36;
goto L2xx36;
L2xeWjgx3e:
    $cond='<div class="col-3">
    <label class="form-label">文章类型</label>
    <div class="form-check" style="margin-right: 5px;">
    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1t" value="img">
    <label class="form-check-label">
    图片
    </label>
    </div>
    </div>
    <div class="col-3">
    <label class="form-label"></label>
    <div class="form-check" style="margin-right: 5px;">
    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1s" value="video">
    <label class="form-check-label">
    视频
    </label>
    </div>
    </div>
    <div class="col-3">
    <label class="form-label"></label>
    <div class="form-check" style="margin-right: 5px;">
    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1y" value="music">
    <label class="form-check-label">
    音乐
    </label>
    </div>
    </div>
    <div class="col-3">
    <label class="form-label"></label>
    <div class="form-check">
    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1w" value="only" checked="">
    <label class="form-check-label">
    仅文字
    </label>
    </div>
    </div>';
    $ptlxx=$cond;
}
L2xx3f:
$val["title"]="::(呵呵)";
$val["img"]="./assets/owo/paopao/E591B5E591B5_2x.png";
$val2["title"]="::(哈哈)";
$val2["img"]="./assets/owo/paopao/E59388E59388_2x.png";
$val3["title"]="::(吐舌)";
$val3["img"]="./assets/owo/paopao/E59090E8888C_2x.png";
$val4["title"]="::(太开心)";
$val4["img"]="./assets/owo/paopao/E5A4AAE5BC80E5BF83_2x.png";
$val5["title"]="::(笑眼)";
$val5["img"]="./assets/owo/paopao/E7AC91E79CBC_2x.png";
$val6["title"]="::(花心)";
$val6["img"]="./assets/owo/paopao/E88AB1E5BF83_2x.png";
$val7["title"]="::(小乖)";
$val7["img"]="./assets/owo/paopao/E5B08FE4B996_2x.png";
$val8["title"]="::(乖)";
$val8["img"]="./assets/owo/paopao/E4B996_2x.png";
$val9["title"]="::(捂嘴笑)";
$val9["img"]="./assets/owo/paopao/E68D82E598B4E7AC91_2x.png";
$val10["title"]="::(滑稽)";
$val10["img"]="./assets/owo/paopao/E6BB91E7A8BD_2x.png";
$val11["title"]="::(你懂的)";
$val11["img"]="./assets/owo/paopao/E4BDA0E68782E79A84_2x.png";
$val12["title"]="::(不高兴)";
$val12["img"]="./assets/owo/paopao/E4B88DE9AB98E585B4_2x.png";
$val13["title"]="::(怒)";
$val13["img"]="./assets/owo/paopao/E68092_2x.png";
$val14["title"]="::(汗)";
$val14["img"]="./assets/owo/paopao/E6B197_2x.png";
$val15["title"]="::(黑线)";
$val15["img"]="./assets/owo/paopao/E9BB91E7BABF_2x.png";
$val16["title"]="::(泪)";
$val16["img"]="./assets/owo/paopao/E6B3AA_2x.png";
$val17["title"]="::(真棒)";
$val17["img"]="./assets/owo/paopao/E79C9FE6A392_2x.png";
$val18["title"]="::(喷)";
$val18["img"]="./assets/owo/paopao/E596B7_2x.png";
$val19["title"]="::(惊哭)";
$val19["img"]="./assets/owo/paopao/E6838AE593AD_2x.png";
$val20["title"]="::(阴险)";
$val20["img"]="./assets/owo/paopao/E998B4E999A9_2x.png";
$val21["title"]="::(鄙视)";
$val21["img"]="./assets/owo/paopao/E98499E8A786_2x.png";
$val22["title"]="::(酷)";
$val22["img"]="./assets/owo/paopao/E985B7_2x.png";
$val23["title"]="::(啊)";
$val23["img"]="./assets/owo/paopao/E5958A_2x.png";
$val24["title"]="::(狂汗)";
$val24["img"]="./assets/owo/paopao/E78B82E6B197_2x.png";
$val25["title"]="::(what)";
$val25["img"]="./assets/owo/paopao/what_2x.png";
$val26["title"]="::(疑问)";
$val26["img"]="./assets/owo/paopao/E79691E997AE_2x.png";
$val27["title"]="::(酸爽)";
$val27["img"]="./assets/owo/paopao/E985B8E788BD_2x.png";
$val28["title"]="::(呀咩蹀)";
$val28["img"]="./assets/owo/paopao/E59180E592A9E788B9_2x.png";
$val29["title"]="::(委屈)";
$val29["img"]="./assets/owo/paopao/E5A794E5B188_2x.png";
$val30["title"]="::(惊讶)";
$val30["img"]="./assets/owo/paopao/E6838AE8AEB6_2x.png";
$val31["title"]="::(睡觉)";
$val31["img"]="./assets/owo/paopao/E79DA1E8A789_2x.png";
$val32["title"]="::(笑尿)";
$val32["img"]="./assets/owo/paopao/E7AC91E5B0BF_2x.png";
$val33["title"]="::(挖鼻)";
$val33["img"]="./assets/owo/paopao/E68C96E9BCBB_2x.png";
$val34["title"]="::(吐)";
$val34["img"]="./assets/owo/paopao/E59090_2x.png";
$val35["title"]="::(犀利)";
$val35["img"]="./assets/owo/paopao/E78A80E588A9_2x.png";
$val36["title"]="::(小红脸)";
$val36["img"]="./assets/owo/paopao/E5B08FE7BAA2E884B8_2x.png";
$val37["title"]="::(懒得理)";
$val37["img"]="./assets/owo/paopao/E68792E5BE97E79086_2x.png";
$val38["title"]="::(勉强)";
$val38["img"]="./assets/owo/paopao/E58B89E5BCBA_2x.png";
$val39["title"]="::(爱心)";
$val39["img"]="./assets/owo/paopao/E788B1E5BF83_2x.png";
$val40["title"]="::(心碎)";
$val40["img"]="./assets/owo/paopao/E5BF83E7A28E_2x.png";
$val41["title"]="::(玫瑰)";
$val41["img"]="./assets/owo/paopao/E78EABE791B0_2x.png";
$val42["title"]="::(礼物)";
$val42["img"]="./assets/owo/paopao/E7A4BCE789A9_2x.png";
$val43["title"]="::(彩虹)";
$val43["img"]="./assets/owo/paopao/E5BDA9E899B9_2x.png";
$val44["title"]="::(太阳)";
$val44["img"]="./assets/owo/paopao/E5A4AAE998B3_2x.png";
$val45["title"]="::(星星月亮)";
$val45["img"]="./assets/owo/paopao/E6989FE6989FE69C88E4BAAE_2x.png";
$val46["title"]="::(钱币)";
$val46["img"]="./assets/owo/paopao/E992B1E5B881_2x.png";
$val47["title"]="::(茶杯)";
$val47["img"]="./assets/owo/paopao/E88CB6E69DAF_2x.png";
$val48["title"]="::(蛋糕)";
$val48["img"]="./assets/owo/paopao/E89B8BE7B395_2x.png";
$val49["title"]="::(大拇指)";
$val49["img"]="./assets/owo/paopao/E5A4A7E68B87E68C87_2x.png";
$val50["title"]="::(胜利)";
$val50["img"]="./assets/owo/paopao/E8839CE588A9_2x.png";
$val51["title"]="::(haha)";
$val51["img"]="./assets/owo/paopao/haha_2x.png";
$val52["title"]="::(OK)";
$val52["img"]="./assets/owo/paopao/OK_2x.png";
$val53["title"]="::(沙发)";
$val53["img"]="./assets/owo/paopao/E6B299E58F91_2x.png";
$val54["title"]="::手纸";
$val54["img"]="./assets/owo/paopao/E6898BE7BAB8_2x.png";
$val55["title"]="::(香蕉)";
$val55["img"]="./assets/owo/paopao/E9A699E89589_2x.png";
$val56["title"]="::(便便)";
$val56["img"]="./assets/owo/paopao/E4BEBFE4BEBF_2x.png";
$val57["title"]="::(药丸)";
$val57["img"]="./assets/owo/paopao/E88DAFE4B8B8_2x.png";
$val58["title"]="::(红领巾)";
$val58["img"]="./assets/owo/paopao/E7BAA2E9A286E5B7BE_2x.png";
$val59["title"]="::(蜡烛)";
$val59["img"]="./assets/owo/paopao/E89CA1E7839B_2x.png";
$val60["title"]="::(音乐)";
$val60["img"]="./assets/owo/paopao/E99FB3E4B990_2x.png";
$val61["title"]="::(灯泡)";
$val61["img"]="./assets/owo/paopao/E781AFE6B3A1_2x.png";
$val62[]=$val;
$val62[]=$val2;
$val62[]=$val3;
$val62[]=$val4;
$val62[]=$val5;
$val62[]=$val6;
$val62[]=$val7;
$val62[]=$val8;
$val62[]=$val9;
$val62[]=$val10;
$val62[]=$val11;
$val62[]=$val12;
$val62[]=$val13;
$val62[]=$val14;
$val62[]=$val15;
$val62[]=$val16;
$val62[]=$val17;
$val62[]=$val18;
$val62[]=$val19;
$val62[]=$val20;
$val62[]=$val21;
$val62[]=$val22;
$val62[]=$val23;
$val62[]=$val24;
$val62[]=$val25;
$val62[]=$val26;
$val62[]=$val27;
$val62[]=$val28;
$val62[]=$val29;
$val62[]=$val30;
$val62[]=$val31;
$val62[]=$val32;
$val62[]=$val33;
$val62[]=$val34;
$val62[]=$val35;
$val62[]=$val36;
$val62[]=$val37;
$val62[]=$val38;
$val62[]=$val39;
$val62[]=$val40;
$val62[]=$val41;
$val62[]=$val42;
$val62[]=$val43;
$val62[]=$val44;
$val62[]=$val45;
$val62[]=$val46;
$val62[]=$val47;
$val62[]=$val48;
$val62[]=$val49;
$val62[]=$val50;
$val62[]=$val51;
$val62[]=$val52;
$val62[]=$val53;
$val62[]=$val54;
$val62[]=$val55;
$val62[]=$val56;
$val62[]=$val57;
$val62[]=$val58;
$val62[]=$val59;
$val62[]=$val60;
$val62[]=$val61;
$arr=$val62;
$cond=0;
$i=$cond;
while(true){
    $replaced=count($arr);
    $tmp=$i<$replaced;
    if(!$tmp)break;
    $danm=$arr[$i]["title"];
    $dang=$arr[$i]["img"];
    $tmp='<span class="sh-nr-bq-img-wk"><img src="./assets/img/thumbnail.svg" data-src="' . $dang;
    $tmp2=$tmp . '" class="sh-nr-bq-img" alt="';
    $tmp3=$tmp2 . $danm;
    $aeimg=$tmp3 . '"></span>';
    $replaced=str_ireplace($aeimg, $danm, $ptptext);
    $ptptext=$replaced;
    $tmp='<img src="./assets/img/thumbnail.svg" data-src="' . $dang;
    $aeimg=$tmp . '" class="sh-nr-bq-img">';
    $replaced=str_ireplace($aeimg, $danm, $ptptext);
    $ptptext=$replaced;
    $pattern='/<a\s+.*?\bhref=["\'](.*?)["\'].*.*?<\/a>/i';
    $replacement=' $1 ';
    $cond=preg_replace($pattern,$replacement,$ptptext);
    $ptptext=$cond;
    $replaced=str_replace("<br>", "", $ptptext);
    $ptptext=$replaced;
    $obj=$i;
    $obj2=$i+1;
    $cond=$obj2;
    $i=$cond;
}
L2xx3u:
$tmp='<div class="modal show" id="modal-block-normal" tabindex="-1" role="dialog" aria-labelledby="modal-block-normal" aria-modal="true" style="display: block;">
<form class="modal-dialog" role="document" action="./auditesli.php" method="post" enctype="multipart/form-data">
<div class="modal-content">
<div class="block block-rounded block-transparent mb-0">
<div class="block-header block-header-default">
<h3 class="block-title">编辑文章</h3>
<div class="block-options">
<button type="button" class="btn-block-option" data-bs-dismiss="modal" aria-label="Close">
<i class="fa fa-fw fa-times"></i>
</button>
</div>
</div>
<div class="block-content fs-sm" style="overflow-x: hidden;overflow-y: scroll;overscroll-behavior-y: contain;max-height: 500px;">
<div class="block-content">
<div class="row justify-content: flex-start;">
<div class="col-sm-12 col-md-12 block">
<div class="row g-2">
' . $ptlxx;
$tmp2=$tmp . '
<div class="col-12">
<label class="form-label">文章内容</label>
<textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 76px;" name="ptpnr">';
$tmp3=$tmp2 . $ptptext;
$tmp4=$tmp3 . '</textarea>
</div>
<div class="col-12">
<label class="form-label">文章图片</label>
<textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 76px;" name="ptptup">';
echo $tmp4;
$replaced=explode('(+@+)', $ptpimag);
$imgar=$replaced;
$replaced=count($imgar);
$coun=$replaced;
$cond=0;
$i=$cond;
while(true){
    $tmp=$i<$coun;
    if(!$tmp)break;
    $tmp=$coun-1;
    $tmp2=$i==$tmp;
    if($tmp2){
        echo $imgar[$i];
    }else{
        $tmp=$imgar[$i] . PHP_EOL;
        echo $tmp;
    }
    $obj2=$i;
    $obj3=$i+1;
    $cond=$obj3;
    $i=$cond;
}
L2xx42:
echo '</textarea>
<small id="passwordHelpBlock" class="form-text text-muted">
格式：一行一张，最多15张
</small>
</div>
<div class="col-12">
<label class="form-label">文章视频</label>
<textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 76px;" name="ptpsp">';
echo $ptpvideo;
echo '</textarea>
<small id="passwordHelpBlock" class="form-text text-muted">
格式：视频链接|封面链接
</small>
</div>
<div class="col-12">
<label class="form-label">文章音乐</label>
<textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="" style="margin-top: 0px; margin-bottom: 0px; height: 76px;" name="ptpyy">';
echo $ptpmusic;
$tmp='</textarea>
<small id="passwordHelpBlock" class="form-text text-muted">
格式：ID/音乐链接|歌名|歌手|封面链接<br>
网易云音乐格式：网易音乐|音乐ID
</small>
</div>
<div class="col-12">
<label class="form-label">当前位置</label>
<input type="text" class="form-control" id="inputAddress2" placeholder="" value="' . $ptpdw;
$tmp2=$tmp . '" name="ptpdw">
<small id="passwordHelpBlock" class="form-text text-muted">
当前所在位置(例：美国·洛杉矶·威尼斯海滩游乐场)
</small>
</div>
<div class="col-12">
<label class="form-label">广告地址</label>
<input type="text" class="form-control" id="inputAddress2" placeholder="" value="';
$tmp3=$tmp2 . $ptpggurl;
$tmp4=$tmp3 . '" name="ptpgg">
<small id="passwordHelpBlock" class="form-text text-muted">
格式：直接填写广告跳转链接(不设置广告请留空)
</small>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="block-content block-content-full text-end bg-body">
<input type="hidden" class="form-control" id="inputAddress2" value="';
$tmp5=$tmp4 . $cid;
$tmp6=$tmp5 . '" name="wzxgcid">
<button type="submit" class="btn btn-sm btn-primary">保存</button>
</div>
</div>
</div></form>
</div>
<div class="modal-backdrop show"></div>';
echo $tmp6;
goto L2xx46;
L2xldMhx47:
L2xx46:
echo "          ";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\">文章列表</h3>";
echo "
<div class=\"block-options space-x-1\">";
echo "
<button id=\"so-search\" type=\"button\" class=\"btn btn-sm btn-alt-secondary js-class-toggle-enabled\" data-toggle=\"class-toggle\" data-target=\"#one-dashboard-search-orders\" data-class=\"d-none\">";
echo "
<i class=\"fa fa-search\"></i>";
echo "
</button>";
echo "
";
echo "
</div>";
echo "
</div>";
echo "
<div id=\"one-dashboard-search-orders\" class=\"block-content border-bottom d-none\">";
echo "
<!-- Search Form -->";
echo "
<form action=\"be_pages_dashboard.php\" method=\"POST\" onsubmit=\"return false;\">";
echo "
<div class=\"push\">";
echo "
<div class=\"input-group\">";
echo "
<input type=\"text\" class=\"form-control form-control-alt\" id=\"one-ecom-orders-search\" name=\"one-ecom-orders-search\" placeholder=\"Search all orders..\">";
echo "
<span class=\"input-group-text bg-body border-0\">";
echo "
<i class=\"fa fa-search\"></i>";
echo "
</span>";
echo "
</div>";
echo "
</div>";
echo "
</form>";
echo "
<!-- END Search Form -->";
echo "
</div>";
echo "
<div class=\"block-content block-content-full\">";
echo "
<!-- Recent Orders Table -->";
echo "
";
$num7=2745;
$isArray=is_array($_GET);
if($isArray){
    $type=&$_GET['page'];
}else{
    $type=$_GET['page'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$tmp=$escaped2!="";
if($tmp){
    $num7=15;
}else{
    $num7=30;
}
switch($num7){
    case 15:{
    $page=$_GET['page'];
        break;
    }
    case 30:{
        $page=1;
        break;
    }
}
$perPage=20;
$tmp=$page-1;
$offset=$tmp*20;
$tmp="SELECT * FROM essay where ptpaud= '1' order by id desc LIMIT " . 20;
$tmp2=$tmp . " OFFSET ";
$sql=$tmp2 . $offset;
$result=$conn->query("SELECT COUNT(*) AS total FROM essay where ptpaud= '1'");
$row=$result->fetch_assoc();
$totalRecords=$row;
$num8=2748;
$isArray=is_array($_GET);
if($isArray){
    $num8=15;
}else{
    $num8=25;
}
switch($num8){
    case 15:{
    $type=&$_GET['keyword'];
        break;
    }
    case 25:{
        $type=$_GET['keyword'];
        break;
    }
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$keyword=$escaped2;
if($keyword!=""){
    $tmp="SELECT * FROM essay where ptpaud= '1' and ptptext LIKE '%" . $keyword;
    $sql=$tmp . "%' order by id desc";
}
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0)goto L2xeWjgx79;
goto L2xldMhx79;
L2xeWjgx79:
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!$cond)break;
    $ptpuser=$row["ptpuser"];
    $ptpimg=$row["ptpimg"];
    $ptpname=$row["ptpname"];
    $ptptext=$row["ptptext"];
    $ptpimag=$row["ptpimag"];
    $ptpvideo=$row["ptpvideo"];
    $ptpmusic=$row["ptpmusic"];
    $ptplx=$row["ptplx"];
    $ptpdw=$row["ptpdw"];
    $ptptime=$row["ptptime"];
    $ptpgg=$row["ptpgg"];
    $ptpggurl=$row["ptpggurl"];
    $ptpys=$row["ptpys"];
    $commauth=$row["commauth"];
    $ptpaud=$row["ptpaud"];
    $ptpip=$row["ip"];
    $cid=$row["cid"];
    $wid=$row["id"];
    $replaced=explode("|", $ptpvideo);
    $partssp=$replaced;
    $ptpvideo=$partssp[0];
    $ptpvideofm=$partssp[1];
    $tmp=$ptpimg=="./assets/img/tx.png";
    if($tmp){
        $ptpimg="../../assets/img/tx.png";
    }else{
        $replaced=strpos($ptpimg, './user/headimg/');
        $tmp=$replaced!==false;
        if($tmp){
            $ptpimg="../." . $ptpimg;
        }else{
            $replaced=strpos($ptpimg, './assets/img/');
            $tmp=$replaced!==false;
            if($tmp){
                $ptpimg="../." . $ptpimg;
            }
        }
    }
    $replaced=str_replace('./assets/owo/paopao/', '../../assets/owo/paopao/', $ptptext, $count);
    $ptptext=$replaced;
    $ptptext=$ptptext . PHP_EOL;
    $replaced=str_replace('src="./assets/img/thumbnail.svg"', '', $ptptext, $count);
    $ptptext=$replaced;
    $ptptext=$ptptext . PHP_EOL;
    $replaced=str_replace('data-src="', 'src="', $ptptext, $count);
    $ptptext=$replaced;
    $ptptext=$ptptext . PHP_EOL;
    $replaced=str_replace('<img ', '<img style="width: 24px;height: 24px;" ', $ptptext, $count);
    $ptptext=$replaced;
    $ptptext=$ptptext . PHP_EOL;
    $tmp=$ptpgg==1;
    if($tmp){
        $ggdiv=-22;
    }else{
        $ggdiv='';
    }
    $replaced=strtotime($ptptime);
    $time=$replaced;
    $replaced=ReckonTime($time);
    $wzfbsj=$replaced;
    $tmp='
    <div class="col-sm-12" style="padding: 0px;margin-bottom:10px;" id="sh-content-' . $cid;
    $tmp2=$tmp . '">
    <div class="card">
    <header class="card-header" style="display: flex;justify-content: space-between;align-items: baseline;">
    <div class="card-title"><img class="img-avatar img-avatar-48 m-r-10 rounded" alt="48x48" src="';
    $tmp3=$tmp2 . $ptpimg;
    $tmp4=$tmp3 . '" style="object-fit: cover;margin-right: 10px;" data-holder-rendered="true">';
    $tmp5=$tmp4 . $ptpname;
    $tmp6=$tmp5 . $ggdiv;
    $tmp7=$tmp6 . '</div>
    <ul class="card-actions">
    <li class="dropdown show">';
    $tmp8=$tmp7 . $wzfbsj;
    $tmp9=$tmp8 . '</li>
    </ul>
    </header>
    <div class="card-body">
    <p>';
    $tmp10=$tmp9 . $ptptext;
    $tmp11=$tmp10 . '</p>
    <div class="border-example-border-utils">
    ';
    echo $tmp11;
    $tmp=$ptplx=="img";
if($tmp)goto L2xeWjgx5k;
goto L2xldMhx5k;
goto L2xldMhx5k;
goto L2xldMhx5k;
L2xeWjgx5k:
    $replaced=explode('(+@+)', $ptpimag);
    $imgar=$replaced;
    $replaced=count($imgar);
    $coun=$replaced;
    $cond=0;
    $i=$cond;
    while(true){
        $tmp=$i<$coun;
        if(!$tmp)break;
        $isArray=is_array($imgar);
        if($isArray){
            $val63=&$imgar[$i];
        }else{
            $val63=$imgar[$i];
        }
        $replaced=strpos($val63, './upload/');
        unset($val63);
        $tmp=$replaced!==false;
if($tmp)goto L2xeWjgx5r;
goto L2xldMhx5r;
goto L2xldMhx5r;
goto L2xldMhx5r;
goto L2xldMhx5r;
L2xeWjgx5r:
        $tuimg="../." . $imgar[$i];
        $isArray=is_array($imgar);
        if($isArray){
            $val63=&$imgar[$i];
        }else{
            $val63=$imgar[$i];
        }
        $replaced=strpos($val63, '../upload/');
        unset($val63);
        $tmp=$replaced!==false;
if($tmp)goto L2xeWjgx5v;
goto L2xx5o;
goto L2xx5o;
goto L2xx5o;
goto L2xx5o;
L2xeWjgx5v:
        $tuimg="../" . $imgar[$i];
goto L2xx5o;
L2xldMhx5r:
        $tuimg=$imgar[$i];
L2xx5o:
        $tmp='<img src="' . $tuimg;
        $tmp2=$tmp . '" width="70" alt="图片" class="rounded-sm" style="width:70px;height: 100vw;max-height: 100px;object-fit: cover;margin-bottom: 10px;margin-right: 5px;">';
        echo $tmp2;
        $obj3=$i;
        $obj4=$i+1;
        $cond=$obj4;
        $i=$cond;
    }
goto L2xx5j;
L2xldMhx5k:
    $tmp=$ptplx=="video";
if($tmp)goto L2xeWjgx67;
goto L2xldMhx67;
goto L2xldMhx67;
goto L2xldMhx67;
L2xeWjgx67:
    $tmp='<div class="sh-video">
    <iframe src="../site/library/player.php?url=' . $ptpvideo;
    $tmp2=$tmp . '" allowfullscreen="allowfullscreen" mozallowfullscreen="mozallowfullscreen" msallowfullscreen="msallowfullscreen" oallowfullscreen="oallowfullscreen" webkitallowfullscreen="webkitallowfullscreen" frameBorder="" style="width: fit-content;max-width: 100%;height:100vw;min-height:200px;max-height:400px;border-radius: 4px;"></iframe>
    </div>';
    echo $tmp2;
goto L2xx5j;
L2xldMhx67:
    $tmp=$ptplx=="music";
if($tmp)goto L2xeWjgx68;
goto L2xldMhx68;
goto L2xldMhx68;
goto L2xldMhx68;
L2xeWjgx68:
    $replaced=is_numeric($ptpmusic);
if($replaced)goto L2xeWjgx6a;
goto L2xldMhx6a;
goto L2xldMhx6a;
goto L2xldMhx6a;
L2xeWjgx6a:
    echo "<span>网易云音乐播放器已取消</span>";
goto L2xx5j;
L2xldMhx6a:
    $replaced=explode('|', $ptpmusic);
    $mus=$replaced;
    $tmp='<audio controls style="width: 100%;">
    <source src="' . $mus[0];
    $tmp2=$tmp . '" type="audio/mp3">
    </audio>';
    echo $tmp2;
L2xldMhx68:
L2xx5j:
    $tmp='
    </div>
    </div>
    <footer class="card-footer text-right">
    <button class="btn btn-label btn-danger" style="margin-top: 5px;" lang="' . $cid;
    $tmp2=$tmp . '" onclick="scwzsg()"><label><i class="mdi mdi-close"></i></label> 驳回</button>';
    echo $tmp2;
    $tmp=$page!="";
    if($tmp){
        $tmp='?page=' . $page;
        $pagey=$tmp . '&';
    }else{
        $pagey='?';
    }
    $tmp='<button class="btn btn-label btn-warning" style="margin-top: 5px;margin-left: 5px;" lang="' . $cid;
    $tmp2=$tmp . '" onclick="window.location.href = \'';
    $tmp3=$tmp2 . $pagey;
    $tmp4=$tmp3 . 'edit=';
    $tmp5=$tmp4 . $cid;
    $tmp6=$tmp5 . '\'"><label><i class="mdi mdi-pencil"></i></label> 编辑</button>';
    echo $tmp6;
    echo '
    </footer>
    </div>
    </div>';
}
goto L2xx78;
L2xldMhx79:
L2xx78:
$totalRecords=$totalRecords['total'];
$num11=$totalRecords/$perPage;
$replaced=ceil($num11);
$maxPages=$replaced;
$tmp='<div class="fixed-table-pagination callout" style="background-color: rgb(255 255 255 / 0%);display: flex;justify-content: space-between;align-items: center;">
<div class="float-left pagination-detail" style="margin-bottom: 10px;">
<span class="pagination-info">
每页显示' . $perPage;
$tmp2=$tmp . '条数据，总共';
$tmp3=$tmp2 . $totalRecords;
$tmp4=$tmp3 . '条数据
</span>
</div>
<div class="float-right pagination">
<ul class="pagination">';
echo $tmp4;
$num=2747;
$isArray=is_array($_GET);
if($isArray){
    $type=&$_GET['type'];
}else{
    $type=$_GET['type'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$tmp=$escaped2!="";
if($tmp){
    $num=15;
}else{
    $num=81;
}
switch($num){
    case 81:{
    $typez="";
        break;
    }
    case 15:{
        $isArray=is_array($_GET);
        if($isArray){
            $type=&$_GET['type'];
        }else{
            $type=$_GET['type'];
        }
        $escaped=htmlspecialchars($type);
        unset($type);
        $escaped2=addslashes($escaped);
        $tmp='type=' . $escaped2;
        $typez=$tmp . '&';
        break;
    }
}
if($maxPages>1)goto L2xeWjgx91;
goto L2xldMhx91;
L2xeWjgx91:
$tmp=$page>1;
if($tmp){
    $tmp='<li class="page-item"><a class="page-link" aria-label="首页" href="./auditesli.php?' . $typez;
    $tmp2=$tmp . 'page=1">首页</a></li>';
    echo $tmp2;
    $tmp='<li class="page-item page-pre"><a class="page-link" aria-label="上一页" href="./auditesli.php?' . $typez;
    $tmp2=$tmp . 'page=';
    $tmp3=$page-1;
    $tmp4=$tmp2 . $tmp3;
    $tmp5=$tmp4 . '">‹</a></li>';
    echo $tmp5;
}
$num11=$page-1;
$replaced=max($num11);
$start=$replaced;
$num11=$page+1;
$replaced=min($num11, $maxPages);
$end=$replaced;
$tmp=$start>1;
if(!($tmp)){
}else{
    $cond=$start;
    $i=$cond;
}
while(true){
    $tmp=$i<=$end;
    if(!$tmp)break;
    $tmp=$i==$page;
    if($tmp){
        $tmp='<li class="page-item active"><a class="page-link" aria-label="第' . $i;
        $tmp2=$tmp . '页" href="./auditesli.php?';
        $tmp3=$tmp2 . $typez;
        $tmp4=$tmp3 . 'page=';
        $tmp5=$tmp4 . $i;
        $tmp6=$tmp5 . '">';
        $tmp7=$tmp6 . $i;
        $tmp8=$tmp7 . '</a></li>';
        echo $tmp8;
    }else{
        $tmp='<li class="page-item "><a class="page-link" aria-label="第' . $i;
        $tmp2=$tmp . '页" href="./auditesli.php?';
        $tmp3=$tmp2 . $typez;
        $tmp4=$tmp3 . 'page=';
        $tmp5=$tmp4 . $i;
        $tmp6=$tmp5 . '">';
        $tmp7=$tmp6 . $i;
        $tmp8=$tmp7 . '</a></li>';
        echo $tmp8;
    }
    $obj4=$i;
    $obj5=$i+1;
    $cond=$obj5;
    $i=$cond;
}
L2xx8r:
$tmp=$end<$maxPages;
if($tmp){
    echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
}
$tmp=$page<$maxPages;
if($tmp)goto L2xeWjgx8y;
goto L2xx9z;
goto L2xx9z;
L2xeWjgx8y:
$tmp='<li class="page-item page-pre"><a class="page-link" aria-label="下一页" href="./auditesli.php?' . $typez;
$tmp2=$tmp . 'page=';
$tmp3=$page+1;
$tmp4=$tmp2 . $tmp3;
$tmp5=$tmp4 . '">›</a></li>';
echo $tmp5;
$tmp='<li class="page-item"><a class="page-link" aria-label="尾页" href="./auditesli.php?' . $typez;
$tmp2=$tmp . 'page=';
$tmp3=$tmp2 . $maxPages;
$tmp4=$tmp3 . '">尾页</a></li>';
echo $tmp4;
goto L2xx9z;
L2xldMhx91:
L2xx9z:
echo '
</ul>
</div>
</div>';
echo "                  <!-- END Recent Orders Table -->";
echo "
</div>";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
</div>";
echo "
<!-- END Page Content -->";
echo "
</main>";
echo "
<!-- END Main Container -->";
echo "
";
echo "
<!-- Footer -->";
echo "
<footer id=\"page-footer\" class=\"bg-body-light\">";
echo "
<div class=\"content py-3\">";
echo "
<div class=\"row fs-sm\">";
echo "
<div class=\"col-sm-6 order-sm-2 py-1 text-center text-sm-end\">";
echo "
Crafted with <i class=\"fa fa-heart text-danger\"></i> by <a class=\"fw-semibold\" href=\"https://qemao.com\" target=\"_blank\">苏画</a>";
echo "
</div>";
echo "
<div class=\"col-sm-6 order-sm-1 py-1 text-center text-sm-start\">";
echo "
<a class=\"fw-semibold\" href=\"https://www.qemao.com\" target=\"_blank\">LAN</a> &copy; <span data-toggle=\"year-copy\"></span>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</footer>";
echo "
<!-- END Footer -->";
echo "
</div>";
echo "
<!-- END Page Container -->";
echo "
";
echo "
<!--";
echo "
OneUI JS";
echo "
";
echo "
Core libraries and functionality";
echo "
webpack is putting everything together at assets/_js/main/app.js";
echo "
-->";
echo "
<script src=\"assets/js/oneui.app.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Plugins -->";
echo "
<script src=\"assets/js/chart.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Code -->";
echo "
<script src=\"assets/js/be_pages_dashboard.min.js\"></script>";
echo "
<script type=\"text/javascript\">";
echo "
//驳回文章事件";
echo "
;function scwzsg() {
    ";echo "
    var ele = window.event.srcElement.lang;
    ";echo "
    var xhr = new XMLHttpRequest();
    ";echo "
    xhr.open('post', './api/escoaud.php');
    ";echo "
    xhr.setRequestHeader(\"Content-type\", \"application/x-www-form-urlencoded\");";
    echo "
    // 将数据通过send方法传递";
    echo "
    xhr.send('ztm=bhwz&cs='+ele);";
    echo "
    // 发送并接受返回值";
    echo "
    xhr.onreadystatechange = function () {";
    echo "
    // 这步为判断服务器是否正确响应";
    echo "
    if (xhr.readyState == 4 && xhr.status == 200) {";
    echo "
    if (xhr.responseText == \"\") {";
    echo "
    alert(\"未获取到数据!\");";
    echo "
    return;";
    echo "
}";
echo "
//alert(xhr.responseText);";
echo "
if (xhr.responseText == \"200\") {";
echo "
var x = document.getElementById(\"sh-content-\"+ele);";
echo "
//如果对象x不为空";
echo "
if (x != null){";
echo "
x.remove();";
echo "
}";
echo "
}else{";
echo "
alert(xhr.responseText);";
echo "
}";
echo "
}";
echo "
};";
echo "
}";echo "
</script>";echo "
</body>";echo "
</html>";echo "
";function ReckonTime($time) {
    $replaced=time();
    $NowTime=$replaced;
    if($time>$NowTime){
        return false;
    }
    $TimePoor=$NowTime-$time;
    $num2=6877;
    $tmp=$TimePoor==0;
    if($tmp){
        $num2=304;
    }else{
        $tmp=$TimePoor<60;
        $tmp3=(bool)$tmp;
        if($tmp3){
            $tmp2=$TimePoor>0;
            $tmp3=(bool)$tmp2;
        }
        if($tmp3){
            $num2=304;
            $num2=3136;
        }else{
            $tmp=$TimePoor>=60;
            $tmp4=(bool)$tmp;
            if($tmp4){
                $tmp2=3600;
                $tmp3=$TimePoor<=3600;
                $tmp4=(bool)$tmp3;
            }
            if($tmp4){
                $num2=256;
            }else{
                $tmp=3600;
                $tmp2=$TimePoor>3600;
                $tmp5=(bool)$tmp2;
                if($tmp5){
                    $tmp3=86400;
                    $tmp4=$TimePoor<=86400;
                    $tmp5=(bool)$tmp4;
                }
                if($tmp5){
                    $num2=80;
                }else{
                    $tmp=86400;
                    $tmp2=$TimePoor>86400;
                    $tmp6=(bool)$tmp2;
                    if($tmp6){
                        $tmp3=86400;
                        $tmp4=604800;
                        $tmp5=$TimePoor<=604800;
                        $tmp6=(bool)$tmp5;
                    }
                    if($tmp6){
                        $num2=95;
                    }else{
                        $tmp=86400;
                        $tmp2=604800;
                        $tmp3=$TimePoor>604800;
                        if($tmp3){
                            $num2=80;
                            $num2=3528;
                        }
                    }
                }
            }
        }
    }
    $tmp=154;
    $tmp2=80;
    $tmp3=$num2==80;
if($tmp3)goto L2xeWjgxa2;
goto L2xldMhxa2;
L2xeWjgxa2:
    $num11=$TimePoor/3600;
    $replaced=floor($num11);
    $str=$replaced . '小时前';
goto L2xxa1;
L2xldMhxa2:
    $tmp=112;
    $tmp2=304;
    $tmp3=$num2==304;
if($tmp3)goto L2xeWjgxa3;
goto L2xldMhxa3;
L2xeWjgxa3:
    $str='一眨眼之间';
goto L2xxa1;
L2xldMhxa3:
    $tmp=81;
    $tmp2=1720;
    $tmp3=$num2==1720;
if($tmp3)goto L2xeWjgxa4;
goto L2xldMhxa4;
L2xeWjgxa4:
    $str=$TimePoor . '秒之前';
goto L2xxa1;
L2xldMhxa4:
    $tmp=2;
    $tmp2=256;
    $tmp3=$num2==256;
if($tmp3)goto L2xeWjgxa5;
goto L2xldMhxa5;
L2xeWjgxa5:
    $num11=$TimePoor/60;
    $replaced=floor($num11);
    $str=$replaced . '分钟前';
goto L2xxa1;
L2xldMhxa5:
    $tmp=17;
    $tmp2=95;
    $tmp3=$num2==95;
if($tmp3)goto L2xeWjgxa6;
goto L2xldMhxa6;
L2xeWjgxa6:
    $num11=86400;
    $val64=$TimePoor/86400;
    $replaced=floor($val64);
    $tmp3=$replaced==1;
if($tmp3)goto L2xeWjgx9x;
goto L2xldMhx9x;
goto L2xldMhx9x;
L2xeWjgx9x:
    $str="昨天";
goto L2xxa1;
L2xldMhx9x:
    $num11=86400;
    $val64=$TimePoor/86400;
    $replaced=floor($val64);
    $tmp3=$replaced==2;
if($tmp3)goto L2xeWjgx9y;
goto L2xldMhx9y;
goto L2xldMhx9y;
L2xeWjgx9y:
    $str="前天";
goto L2xxa1;
L2xldMhx9y:
    $num11=86400;
    $val64=$TimePoor/86400;
    $replaced=floor($val64);
    $str=$replaced . '天前';
L2xldMhxa6:
    switch($num2){
        case 1804:{
        $replaced=date("Y-m-d", $time);
        $str=$replaced;
            break;
        }
    }
L2xxa1:
    return $str;
}