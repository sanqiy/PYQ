<?php
$iteace=1;
$pos=is_file('../config.php');
if($pos){
    $tmp=include '../config.php';
}
$tmp=include '../api/wz.php';
if($userdlzt==0){
    $pos=header('location: ./login.php');
    exit();
}
$num4=5847;
$tmp=$user_zh==$glyadmin;
if($tmp){
    $num4=36;
}else{
    $num4=25;
}
$tmp=228;
$tmp2=36;
$tmp3=$num4==36;
if($tmp3)goto L2xeWjgxe;
goto L2xldMhxe;
L2xeWjgxe:
$tmp=$user_passid!=$passid;
if($tmp)goto L2xeWjgxc;
goto L2xxd;
goto L2xxd;
L2xeWjgxc:
exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="./login.php";</script>;');
goto L2xxd;
L2xldMhxe:
switch($num4){
    case 25:{
    exit('<script language="JavaScript">;alert("没有权限!");location.href="../index.php";</script>;');
        break;
    }
}
L2xxd:
echo "<!doctype html>";
echo "
<html lang=\"en\">";
echo "
<head>";
echo "
<meta charset=\"utf-8\">";
echo "
<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0\">";
echo "
<title>图像设置 - ";
echo $name;
echo "</title>";
echo "
<meta name=\"keywords\" content=\"";
echo $filterkeyw;
echo "\">";
echo "
<meta name=\"description\" content=\"";
echo $subtitle;
echo "\">";
echo "
<meta name=\"author\" content=\"";
echo $name;
echo "\">";
echo "
<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"";
$num5=5846;
$pos=strpos($icon, 'http');
$tmp=$pos!==false;
if($tmp){
    $num5=306;
}else{
    $num5=90;
}
switch($num5){
    case 306:{
    echo $icon;
        break;
    }
    case 90:{
        $tmp='.' . $icon;
        echo $tmp;
        break;
    }
}
echo "\">";
echo "
<link rel=\"stylesheet\" href=\"assets/css/css2.css\">";
echo "
<link rel=\"stylesheet\" id=\"css-main\" href=\"assets/css/oneui.min.css\">";
echo "
</head>";
echo "
<body>";
echo "
<div id=\"page-container\" class=\"sidebar-o sidebar-dark page-header-fixed main-content-narrow\">";
echo "
<nav id=\"sidebar\" aria-label=\"Main Navigation\">";
echo "
<!-- Side Header -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Logo -->";
echo "
<a class=\"fw-semibold text-dual\" href=\"index.php\">";
echo "
<span class=\"smini-visible\">";
echo "
<i class=\"fa fa-circle-notch text-primary\"></i>";
echo "
</span>";
echo "
<span class=\"smini-hide fs-5 tracking-wider\">后台管理</span>";
echo "
</a>";
echo "
<!-- END Logo -->";
echo "
";
echo "
<!-- Extra -->";
echo "
<div>";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" data-toggle=\"layout\" data-action=\"dark_mode_toggle\">";
echo "
<i class=\"far fa-moon\"></i>";
echo "
</button>";
echo "
<!-- END Dark Mode -->";
echo "
";
echo "
<!-- Options -->";
echo "
<div class=\"dropdown d-inline-block ms-1\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" id=\"sidebar-themes-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<i class=\"far fa-circle\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-end fs-sm smini-hide border-0\" aria-labelledby=\"sidebar-themes-dropdown\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"default\" href=\"#\">";
echo "
<span>默认</span>";
echo "
<i class=\"fa fa-circle text-default\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/amethyst.min.css\" href=\"#\">";
echo "
<span>紫色</span>";
echo "
<i class=\"fa fa-circle text-amethyst\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/city.min.css\" href=\"#\">";
echo "
<span>红色</span>";
echo "
<i class=\"fa fa-circle text-city\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/flat.min.css\" href=\"#\">";
echo "
<span>青色</span>";
echo "
<i class=\"fa fa-circle text-flat\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/modern.min.css\" href=\"#\">";
echo "
<span>蓝色</span>";
echo "
<i class=\"fa fa-circle text-modern\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/smooth.min.css\" href=\"#\">";
echo "
<span>粉色</span>";
echo "
<i class=\"fa fa-circle text-smooth\"></i>";
echo "
</a>";
echo "
<!-- END Color Themes -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_light\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 黑色</span>";
echo "
</a>";
echo "
<!-- END Sidebar Styles -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_light\" href=\"javascript:void(0)\">";
echo "
<span>导航 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>导航 黑色</span>";
echo "
</a>";
echo "
<!-- END Header Styles -->";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Options -->";
echo "
<a class=\"d-lg-none btn btn-sm btn-alt-secondary ms-1\" data-toggle=\"layout\" data-action=\"sidebar_close\" href=\"javascript:void(0)\">";
echo "
<i class=\"fa fa-fw fa-times\"></i>";
echo "
</a>";
echo "
<!-- END Close Sidebar -->";
echo "
</div>";
echo "
<!-- END Extra -->";
echo "
</div>";
echo "
<!-- END Side Header -->";
echo "
";
echo "
<!-- Sidebar Scrolling -->";
echo "
<div class=\"js-sidebar-scroll\">";
echo "
<!-- Side Navigation -->";
echo "
<div class=\"content-side\">";
echo "
<ul class=\"nav-main\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./index.php\">";
echo "
<i class=\"nav-main-link-icon si si-speedometer\"></i>";
echo "
<span class=\"nav-main-link-name\">后台首页</span>";
echo "
</a>";
echo "
</li>";
echo "
";
echo "
<li class=\"nav-main-heading\">设置</li>";
echo "
<li class=\"nav-main-item  open\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-energy\"></i>";
echo "
<span class=\"nav-main-link-name\">网站设置</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./basic.php\">";
echo "
<span class=\"nav-main-link-name\">基础设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./authority.php\">";
echo "
<span class=\"nav-main-link-name\">权限设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link active\" href=\"./imgset.php\">";
echo "
<span class=\"nav-main-link-name\">图像设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./emailset.php\">";
echo "
<span class=\"nav-main-link-name\">邮箱设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./calis.php\">";
echo "
<span class=\"nav-main-link-name\">卡密管理</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-users\"></i>";
echo "
<span class=\"nav-main-link-name\">用户管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./userlist.php\">";
echo "
<span class=\"nav-main-link-name\">用户列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-book-open\"></i>";
echo "
<span class=\"nav-main-link-name\">文章管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditesli.php\">";
echo "
<span class=\"nav-main-link-name\">文章列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditessh.php\">";
echo "
<span class=\"nav-main-link-name\">审核文章</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-speech\"></i>";
echo "
<span class=\"nav-main-link-name\">评论管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditcoli.php\">";
echo "
<span class=\"nav-main-link-name\">评论列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditcosh.php\">";
echo "
<span class=\"nav-main-link-name\">审核评论</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-paper-clip\"></i>";
echo "
<span class=\"nav-main-link-name\">友链管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./linkset.php\">";
echo "
<span class=\"nav-main-link-name\">友链列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
</ul>";
echo "
</div>";
echo "
<!-- END Side Navigation -->";
echo "
</div>";
echo "
<!-- END Sidebar Scrolling -->";
echo "
</nav>";
echo "
<!-- END Sidebar -->";
echo "
";
echo "
<!-- Header -->";
echo "
<header id=\"page-header\">";
echo "
<!-- Header Content -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Left Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- Toggle Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-lg-none\" data-toggle=\"layout\" data-action=\"sidebar_toggle\">";
echo "
<i class=\"fa fa-fw fa-bars\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Sidebar -->";
echo "
";
echo "
<!-- Toggle Mini Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-none d-lg-inline-block\" data-toggle=\"layout\" data-action=\"sidebar_mini_toggle\">";
echo "
<i class=\"fa fa-fw fa-ellipsis-v\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Mini Sidebar -->";
echo "
";
echo "
<!-- Open Search Section (visible on smaller screens) -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
";
echo "
<!-- END Open Search Section -->";
echo "
";
echo "
<!-- Search Form (visible on larger screens) -->";
echo "
";
echo "
<!-- END Search Form -->";
echo "
</div>";
echo "
<!-- END Left Section -->";
echo "
";
echo "
<!-- Right Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- User Dropdown -->";
echo "
<div class=\"dropdown d-inline-block ms-2\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary d-flex align-items-center\" id=\"page-header-user-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<img class=\"rounded-circle\" src=\"";
$num=5844;
$pos=strpos($user_img, 'http');
$tmp=$pos!==false;
if($tmp){
    $num=85;
}else{
    $num=153;
}
switch($num){
    case 153:{
    $tmp='.' . $user_img;
    echo $tmp;
        break;
    }
    case 85:{
        echo $user_img;
        break;
    }
}
echo "\" alt=\"Header Avatar\" style=\"width: 21px;\">";
echo "
<span class=\"d-none d-sm-inline-block ms-2\">";
echo $user_name;
echo "</span>";
echo "
<i class=\"fa fa-fw fa-angle-down d-none d-sm-inline-block opacity-50 ms-1 mt-1\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-md dropdown-menu-end p-0 border-0\" aria-labelledby=\"page-header-user-dropdown\">";
echo "
<div class=\"p-3 text-center bg-body-light border-bottom rounded-top\">";
echo "
<img class=\"img-avatar img-avatar48 img-avatar-thumb\" src=\"";
$num2=5841;
$pos=strpos($user_img, 'http');
$tmp=$pos!==false;
if($tmp){
    $num2=85;
}else{
    $num2=289;
}
switch($num2){
    case 85:{
    echo $user_img;
        break;
    }
    case 289:{
        $tmp='.' . $user_img;
        echo $tmp;
        break;
    }
}
echo "\" alt=\"\">";
echo "
<p class=\"mt-2 mb-0 fw-medium\">";
echo $user_name;
echo "</p>";
echo "
<!--p class=\"mb-0 text-muted fs-sm fw-medium\">介绍</p-->";
echo "
</div>";
echo "
<div role=\"separator\" class=\"dropdown-divider m-0\"></div>";
echo "
<div class=\"p-2\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"../\">";
echo "
<span class=\"fs-sm fw-medium\">返回前台</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"JavaScript:;\" onclick=\"logut()\">";
echo "
<span class=\"fs-sm fw-medium\">退出登录</span>";
echo "
</a>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
<!-- END User Dropdown -->";
echo "
";
echo "
<!-- Notifications Dropdown -->";
echo "
";
echo "
<!-- END Notifications Dropdown -->";
echo "
";
echo "
<!-- Toggle Side Overlay -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
<!-- END Toggle Side Overlay -->";
echo "
</div>";
echo "
<!-- END Right Section -->";
echo "
</div>";
echo "
<!-- END Header Content -->";
echo "
";
echo "
<!-- Header Loader -->";
echo "
<!-- Please check out the Loaders page under Components category to see examples of showing/hiding it -->";
echo "
<div id=\"page-header-loader\" class=\"overlay-header bg-body-extra-light\">";
echo "
<div class=\"content-header\">";
echo "
<div class=\"w-100 text-center\">";
echo "
<i class=\"fa fa-fw fa-circle-notch fa-spin\"></i>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Header Loader -->";
echo "
</header>";
echo "
<!-- END Header -->";
echo "
";
echo "
<!-- Main Container -->";
echo "
<main id=\"main-container\">";
echo "
";
echo "
<!-- Page Content -->";
echo "
<div class=\"content\">";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"row\">";
echo "
<div class=\"col-md-12\">";
echo "
<form action=\"./api/adminupdata.php\" method=\"post\" enctype=\"multipart/form-data\">";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\">云储存配置</h3>";
echo "
<div class=\"block-options\">";
echo "
<button type=\"submit\" class=\"btn btn-sm btn-primary\">保存</button>";
echo "
<input type=\"hidden\" value=\"imgyuncxg\" name=\"lx\">";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"block-content block-content-full\">";
echo "
<div class=\"mb-4\">";
echo "
<select class=\"form-select\" id=\"example-select\" name=\"imgyuncxgli\">";
echo "
";
$num3=5850;
$tmp=$imgyunc=="0";
if($tmp){
    $num3=324;
}else{
    $tmp=$imgyunc=="upyun";
    if($tmp){
        $num3=30;
    }else{
        $tmp=$imgyunc=="aliyun";
        if($tmp){
            $num3=306;
        }else{
            $num3=162;
        }
    }
}
switch($num3){
    case 306:{
    echo '<option value="aliyun">阿里云</option>
    <option value="upyun">又拍云</option>
    <option value="0">本地</option>';
        break;
    }
    case 324:{
        echo '<option value="0">本地</option>
        <option value="upyun">又拍云</option>
        <option value="aliyun">阿里云</option>';
        break;
    }
    case 30:{
            echo '<option value="upyun">又拍云</option>
            <option value="aliyun">阿里云</option>
            <option value="0">本地</option>';
        break;
    }
    case 162:{
                echo '<option value="-1">请选择云储存</option>
                <option value="upyun">又拍云</option>
                <option value="aliyun">阿里云</option>
                <option value="0">本地</option>';
        break;
    }
}
echo "                                  </select>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</form>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
if($filteraliyun!=""){
    $pos=json_decode($filteraliyun, true);
    $array=$pos;
    $AccessKeyID=$array['AccessKeyID'];
    $AccessKeySecret=$array['AccessKeySecret'];
    $Bucket=$array['Bucket'];
    $Endpoint=$array['Endpoint'];
}
echo "              <div class=\"row\">";
echo "
<div class=\"col-md-12\">";
echo "
<form action=\"./api/adminupdata.php\" method=\"post\" enctype=\"multipart/form-data\">";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\">阿里云图像储存</h3>";
echo "
<div class=\"block-options\">";
echo "
<button type=\"submit\" class=\"btn btn-sm btn-primary\">保存</button>";
echo "
<input type=\"hidden\" value=\"aliyun\" name=\"lx\">";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"block-content block-content-full\">";
echo "
<div class=\"row\">";
echo "
<div class=\"col-lg-4\">";
echo "
<p class=\"fs-sm text-muted\">配置你的阿里云OSS对象储存信息</p>";
echo "
</div>";
echo "
<div class=\"col-lg-8 col-xl-5\">";
echo "
<div class=\"mb-4\">";
echo "
<div class=\"input-group\">";
echo "
<span class=\"input-group-text\">AccessKey ID</span>";
echo "
<input type=\"text\" class=\"form-control\" id=\"example-group1-input1\" name=\"alifm\" placeholder=\"\" value=\"";
echo $AccessKeyID;
echo "\">";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<div class=\"input-group\">";
echo "
<span class=\"input-group-text\">AccessKey Secret";
echo "
</span>";
echo "
<input type=\"text\" class=\"form-control\" id=\"example-group1-input1\" name=\"alicz\" placeholder=\"\" value=\"";
echo $AccessKeySecret;
echo "\">";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<div class=\"input-group\">";
echo "
<span class=\"input-group-text\">Bucket名称";
echo "
</span>";
echo "
<input type=\"text\" class=\"form-control\" id=\"example-group1-input1\" name=\"alicm\" placeholder=\"\" value=\"";
echo $Bucket;
echo "\">";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<div class=\"input-group\">";
echo "
<span class=\"input-group-text\">Endpoint";
echo "
</span>";
echo "
<input type=\"text\" class=\"form-control\" id=\"example-group1-input1\" name=\"aliby\" placeholder=\"\" value=\"";
echo $Endpoint;
echo "\">";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</form>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
if($filterupy!=""){
    $pos=json_decode($filterupy, true);
    $array=$pos;
    $bucketName=$array['bucketName'];
    $operatorName=$array['operatorName'];
    $operatorPassword=$array['operatorPassword'];
    $operatorurl=$array['operatorurl'];
}
echo "              <div class=\"row\">";
echo "
<div class=\"col-md-12\">";
echo "
<form action=\"./api/adminupdata.php\" method=\"post\" enctype=\"multipart/form-data\">";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\">又拍云图像储存</h3>";
echo "
<div class=\"block-options\">";
echo "
<button type=\"submit\" class=\"btn btn-sm btn-primary\">保存</button>";
echo "
<input type=\"hidden\" value=\"upyun\" name=\"lx\">";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"block-content block-content-full\">";
echo "
<div class=\"row\">";
echo "
<div class=\"col-lg-4\">";
echo "
<p class=\"fs-sm text-muted\">配置你的又拍云储存信息</p>";
echo "
</div>";
echo "
<div class=\"col-lg-8 col-xl-5\">";
echo "
<div class=\"mb-4\">";
echo "
<div class=\"input-group\">";
echo "
<span class=\"input-group-text\">服务器名称</span>";
echo "
<input type=\"text\" class=\"form-control\" id=\"example-group1-input1\" name=\"upfm\" placeholder=\"\" value=\"";
echo $bucketName;
echo "\">";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<div class=\"input-group\">";
echo "
<span class=\"input-group-text\">操作员账号";
echo "
</span>";
echo "
<input type=\"text\" class=\"form-control\" id=\"example-group1-input1\" name=\"upcz\" placeholder=\"\" value=\"";
echo $operatorName;
echo "\">";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<div class=\"input-group\">";
echo "
<span class=\"input-group-text\">操作员密码";
echo "
</span>";
echo "
<input type=\"text\" class=\"form-control\" id=\"example-group1-input1\" name=\"upcm\" placeholder=\"\" value=\"";
echo $operatorPassword;
echo "\">";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<div class=\"input-group\">";
echo "
<span class=\"input-group-text\">绑定的域名";
echo "
</span>";
echo "
<input type=\"text\" class=\"form-control\" id=\"example-group1-input1\" name=\"upby\" placeholder=\"\" value=\"";
echo $operatorurl;
echo "\">";
echo "
</div>";
echo "
<p class=\"fs-sm text-muted\">";
echo "
请填写又拍云绑定域名,注意http(s)://开头,最后不要加/</p>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</form>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"row\">";
echo "
<div class=\"col-md-12\">";
echo "
<form form class=\"form-group\" action=\"./api/adminupdata.php\" method=\"post\" enctype=\"multipart/form-data\">";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\">Favicon图标</h3>";
echo "
<div class=\"block-options\">";
echo "
<button type=\"submit\" class=\"btn btn-sm btn-primary\">保存</button>";
echo "
<input type=\"hidden\" value=\"icon\" name=\"lx\">";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"block-content block-content-full\">";
echo "
<div class=\"row\">";
echo "
<div class=\"col-lg-4\">";
echo "
<p class=\"fs-sm text-muted\">上传浏览器地址栏显示的图标</p>";
echo "
</div>";
echo "
<div class=\"col-lg-8 col-xl-5\">";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"example-file-input\">上传</label>";
echo "
<input class=\"form-control\" type=\"file\" multiple=\"\" accept=\"image/*\" id=\"icon-file\" name=\"file\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"example-file-input\">链接</label>";
echo "
<div class=\"input-group\">";
echo "
<span class=\"input-group-text\">远程链接</span>";
echo "
<input type=\"text\" class=\"form-control\" id=\"icon-group\" name=\"iconurl\" placeholder=\"输入icon图标链接\" value=\"";
echo $icon;
echo "\">";
echo "
</div>";
echo "
<p class=\"fs-sm text-muted\">";
echo "
自定义浏览器Favicon图标(优先级：链接 &gt; 上传图片)</p>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</form>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"row\">";
echo "
<div class=\"col-md-12\">";
echo "
<form action=\"./api/adminupdata.php\" method=\"post\" enctype=\"multipart/form-data\">";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\">LOGO图标</h3>";
echo "
<div class=\"block-options\">";
echo "
<button type=\"submit\" class=\"btn btn-sm btn-primary\">保存</button>";
echo "
<input type=\"hidden\" value=\"logo\" name=\"lx\">";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"block-content block-content-full\">";
echo "
<div class=\"row\">";
echo "
<div class=\"col-lg-4\">";
echo "
<p class=\"fs-sm text-muted\">上传LOGO图标</p>";
echo "
</div>";
echo "
<div class=\"col-lg-8 col-xl-5\">";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"example-file-input\">上传</label>";
echo "
<input class=\"form-control\" type=\"file\" multiple=\"\" accept=\"image/*\" id=\"logo-file\" name=\"file\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"example-file-input\">链接</label>";
echo "
<div class=\"input-group\">";
echo "
<span class=\"input-group-text\">远程链接</span>";
echo "
<input type=\"text\" class=\"form-control\" id=\"logo-url\" name=\"logourl\" placeholder=\"输入Logo图标链接\" value=\"";
echo $logo;
echo "\">";
echo "
</div>";
echo "
<p class=\"fs-sm text-muted\">";
echo "
自定义Logo图标(优先级：链接 &gt; 上传图片)</p>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</form>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"row\">";
echo "
<div class=\"col-md-12\">";
echo "
<form action=\"./api/adminupdata.php\" method=\"post\" enctype=\"multipart/form-data\">";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\">相册封面</h3>";
echo "
<div class=\"block-options\">";
echo "
<button type=\"submit\" class=\"btn btn-sm btn-primary\">保存</button>";
echo "
<input type=\"hidden\" value=\"coverimg\" name=\"lx\">";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"block-content block-content-full\">";
echo "
<div class=\"row\">";
echo "
<div class=\"col-lg-4\">";
echo "
<p class=\"fs-sm text-muted\">上传网站首页顶部相册封面图</p>";
echo "
</div>";
echo "
<div class=\"col-lg-8 col-xl-5\">";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"example-file-input\">上传</label>";
echo "
<input class=\"form-control\" type=\"file\" id=\"myFileInput2\" multiple=\"\" accept=\"image/*\" name=\"file\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"example-file-input\">链接</label>";
echo "
<div class=\"input-group\">";
echo "
<span class=\"input-group-text\">远程链接</span>";
echo "
<input type=\"text\" class=\"form-control\" id=\"coverimgurl\" name=\"coverimgurl\" placeholder=\"输入相册封面链接\" value=\"";
echo $homimg;
echo "\">";
echo "
</div>";
echo "
<p class=\"fs-sm text-muted\">";
echo "
自定义网站相册封面(优先级：链接 &gt; 上传图片)</p>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</form>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"row\">";
echo "
<div class=\"col-md-12\">";
echo "
<form action=\"./api/adminupdata.php\" method=\"post\" enctype=\"multipart/form-data\">";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\">网页背景图</h3>";
echo "
<div class=\"block-options\">";
echo "
<button type=\"submit\" class=\"btn btn-sm btn-primary\">保存</button>";
echo "
<input id=\"biaos\" type=\"hidden\" value=\"bobgsc\" name=\"lx\">";
echo "
<button type=\"submit\" class=\"btn btn-sm btn-alt-danger\" onclick=\"bgde()\">删除</button>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"block-content block-content-full\">";
echo "
<div class=\"row\">";
echo "
<div class=\"col-lg-4\">";
echo "
<p class=\"fs-sm text-muted\">上传网页背景图片</p>";
echo "
</div>";
echo "
<div class=\"col-lg-8 col-xl-5\">";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"example-file-input\">上传</label>";
echo "
<input class=\"form-control\" type=\"file\" multiple=\"\" accept=\"image/*\" id=\"myFileInput3\" name=\"file\">";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</form>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
</div>";
echo "
<!-- END Page Content -->";
echo "
</main>";
echo "
<!-- END Main Container -->";
echo "
";
echo "
<!-- Footer -->";
echo "
<footer id=\"page-footer\" class=\"bg-body-light\">";
echo "
<div class=\"content py-3\">";
echo "
<div class=\"row fs-sm\">";
echo "
<div class=\"col-sm-6 order-sm-2 py-1 text-center text-sm-end\">";
echo "
Crafted with <i class=\"fa fa-heart text-danger\"></i> by <a class=\"fw-semibold\" href=\"https://qemao.com\" target=\"_blank\">苏画</a>";
echo "
</div>";
echo "
<div class=\"col-sm-6 order-sm-1 py-1 text-center text-sm-start\">";
echo "
<a class=\"fw-semibold\" href=\"https://www.qemao.com\" target=\"_blank\">LAN</a> &copy; <span data-toggle=\"year-copy\"></span>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</footer>";
echo "
<!-- END Footer -->";
echo "
</div>";
echo "
<!-- END Page Container -->";
echo "
";
echo "
<!--";
echo "
OneUI JS";
echo "
";
echo "
Core libraries and functionality";
echo "
webpack is putting everything together at assets/_js/main/app.js";
echo "
-->";
echo "
<script src=\"assets/js/oneui.app.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Plugins -->";
echo "
<script src=\"assets/js/chart.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Code -->";
echo "
<script src=\"assets/js/be_pages_dashboard.min.js\"></script>";
echo "
<script>";
echo "
;function bgde() {
    ";echo "
    document.getElementById(\"biaos\").value=\"bobgde\";";
    echo "
}";echo "
";echo "
document.addEventListener('DOMContentLoaded', function() {";echo "
// 获取元素";echo "
const iconFile = document.getElementById('icon-file');";echo "
const iconGroup = document.getElementById('icon-group');";echo "
const logoFile = document.getElementById('logo-file');";echo "
const logoGroup = document.getElementById('logo-url');";echo "
const myFileInput2 = document.getElementById('myFileInput2');";echo "
const coverimgurl = document.getElementById('coverimgurl');";echo "
";echo "
// 监听 icon-file 的 change 事件";echo "
iconFile.addEventListener('change', function() {";echo "
if (iconFile.files.length > 0) {";echo "
// 清空 icon-group 的值";echo "
iconGroup.value = '';";echo "
}";echo "
});";echo "
";echo "
// 监听 logo-file 的 change 事件";echo "
logoFile.addEventListener('change', function() {";echo "
if (logoFile.files.length > 0) {";echo "
// 清空 logo-group 的值";echo "
logoGroup.value = '';";echo "
}";echo "
});";echo "
";echo "
// 监听 myFileInput2 的 change 事件";echo "
myFileInput2.addEventListener('change', function() {";echo "
if (myFileInput2.files.length > 0) {";echo "
// 清空 coverimgurl 的值";echo "
coverimgurl.value = '';";echo "
}";echo "
});";echo "
});";echo "
";echo "
";echo "
";echo "
";echo "
</script>";echo "
</body>";echo "
</html>";echo "
";

