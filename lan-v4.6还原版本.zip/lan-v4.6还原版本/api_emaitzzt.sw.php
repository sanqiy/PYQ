<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp=$user_zh=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$user_passid=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit("请先登录!");
}
$num2=5836;
$isArray=is_array($_POST);
if($isArray){
    $num2=81;
}else{
    $num2=162;
}
switch($num2){
    case 81:{
    $ztm=&$_POST['ztm'];
        break;
    }
    case 162:{
        $ztm=$_POST['ztm'];
        break;
    }
}
$escaped=htmlspecialchars($ztm);
unset($ztm);
$escaped2=addslashes($escaped);
$ztm=$escaped2;
if($ztm==""){
    exit("参数不完整!");
}
$tmp=include '../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    exit("连接数据库失败");
}
$escaped=htmlspecialchars($user_zh);
$cookieResult=addslashes($escaped);
$user_zhsg=$cookieResult;
$tmp="select * from user where username='" . $user_zhsg;
$sqls=$tmp . "'";
$row=mysqli_query($conn, $sqls);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$data2s_row=$row;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$str="select * from user where username='" . $user_zh;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
if($user_passid!=$passid){
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("username", "", $str, "/");
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("passid", "", $str, "/");
    exit("账号信息异常,请重新登录!");
}
$str="select * from user where username='" . $user_zh;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zid=$data2_row["id"];
$num=5835;
$tmp=$ztm==0;
if($tmp){
    $num=324;
}else{
    $tmp=$ztm==1;
    if($tmp){
        $num=169;
    }
}
$tmp=35;
$tmp4=324;
$tmp2=$num==324;
if($tmp2)goto L2xeWjgx11;
goto L2xldMhx11;
L2xeWjgx11:
$tmp="UPDATE user SET esseam='1' WHERE id='" . $zid;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgxv;
goto L2xldMhxv;
goto L2xldMhxv;
L2xeWjgxv:
echo "邮件通知已开启";
goto L2xxz;
L2xldMhxv:
echo "邮件通知开启失败";
L2xldMhx11:
$tmp=91;
$tmp4=169;
$tmp2=$num==169;
if($tmp2)goto L2xeWjgx14;
goto L2xldMhx14;
L2xeWjgx14:
$tmp="UPDATE user SET esseam='0' WHERE id='" . $zid;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgxy;
goto L2xldMhxy;
goto L2xldMhxy;
L2xeWjgxy:
echo "邮件通知已关闭";
goto L2xxz;
L2xldMhxy:
echo "邮件通知关闭失败";
L2xldMhx14:
L2xxz:
$result=$conn->close();

