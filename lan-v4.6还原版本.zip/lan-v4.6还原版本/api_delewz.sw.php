<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp=$user_zh=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$user_passid=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit("请先登录!");
}
$num3=8010;
$isArray=is_array($_POST);
if($isArray){
    $num3=140;
}else{
    $num3=80;
}
switch($num3){
    case 140:{
    $wzdid=&$_POST['wzdid'];
        break;
    }
    case 80:{
        $wzdid=$_POST['wzdid'];
        break;
    }
}
$escaped=htmlspecialchars($wzdid);
unset($wzdid);
$escaped2=addslashes($escaped);
$wzdid=$escaped2;
if($wzdid==""){
    exit("参数不完整");
}
$tmp=include '../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    exit("连接数据库失败");
}
$escaped=htmlspecialchars($user_zh);
$cookieResult=addslashes($escaped);
$user_zhsg=$cookieResult;
$tmp="select * from user where username='" . $user_zhsg;
$sqls=$tmp . "'";
$row=mysqli_query($conn, $sqls);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$data2s_row=$row;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$str="select * from user where username='" . $user_zh;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjwallet=$data2_row["wallet"];
$zjussig=$data2_row["ussig"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
if($user_passid!=$passid){
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("username", "", $str, "/");
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("passid", "", $str, "/");
    exit("账号信息异常,请重新登录!");
}
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($num4))break;
    $glyadmin=$row["username"];
    $rnggy=$row["rnggy"];
    $dywptp=$row["dywptp"];
}
L2xxw:
$num=8016;
$tmp=$zjzhq==$glyadmin;
if($tmp){
    $num=80;
}else{
    $num=36;
}
$tmp=48;
$tmp4=36;
$tmp2=$num==36;
if($tmp2)goto L2xeWjgx16;
goto L2xldMhx16;
L2xeWjgx16:
$tmp="select * from essay where cid= '" . $wzdid;
$sql=$tmp . "'";
$row=mysqli_query($conn, $sql);
$result=$row;
$row=mysqli_num_rows($result);
$tmp=$row>0;
if($tmp){
    $row=mysqli_fetch_assoc($result);
    $row=$row;
    $ptpuser=$row["ptpuser"];
}else{
    exit("未获取到数据!");
}
$tmp=$zjzhq==$ptpuser;
if($tmp)goto L2xx15;
goto L2xldMhx14;
L2xldMhx14:
exit("您无权删除其他用户的文章!");
L2xldMhx16:
$tmp=42;
$tmp4=80;
$tmp2=$num==80;
if($tmp2)goto L2xx15;
L2xx15:
$row=date('Ymd');
$currentDate=$row;
$tmp="SELECT ptptime FROM essay WHERE ptpuser = '" . $zjzhq;
$tmp4=$tmp . "' AND ptptime LIKE '%";
$tmp2=$tmp4 . $currentDate;
$sql=$tmp2 . "%'";
$result=$conn->query($sql);
$result=$result;
$num2=8010;
$tmp=$result->num_rows>1;
if($tmp){
    $num2=80;
}else{
    $num2=28;
}
$tmp=6;
$tmp4=80;
$tmp2=$num2==80;
if($tmp2)goto L2xx1k;
$tmp=154;
$tmp4=28;
$tmp2=$num2==28;
if($tmp2)goto L2xeWjgx1m;
goto L2xldMhx1m;
L2xeWjgx1m:
$xwyaeg=$zjwallet-$dywptp;
$tmp=$zjwallet>$xwyaeg;
if($tmp)goto L2xeWjgx1f;
goto L2xx1k;
goto L2xx1k;
L2xeWjgx1f:
$tmp=$xwyaeg<1;
if($tmp){
    $xwyaeg=0;
}
$tmp="UPDATE user SET wallet = '" . $xwyaeg;
$tmp4=$tmp . "' WHERE username = '";
$tmp2=$tmp4 . $zjzhq;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$tmp=$result===TRUE;
goto L2xx1k;
L2xldMhx1m:
L2xx1k:
$sql="SELECT * FROM essay";
$result=$conn->query($sql);
$result=$result;
L2xx1t:
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($num4))break;
    $wcid=$row['cid'];
if($wcid==$wzdid)goto L2xeWjgx21;
goto L2xx1t;
goto L2xx1t;
goto L2xx1t;
L2xeWjgx21:
    $id=$row['id'];
    $ptpimag=$row['ptpimag'];
    $ptpvideo=$row['ptpvideo'];
    $ptpmusic=$row['ptpmusic'];
    $row=explode("|", $ptpvideo);
    $partssp=$row;
    $ptpvideo=$partssp[0];
    $ptpvideofm=$partssp[1];
    $tmp="delete from essay where id='" . $id;
    $sqlq=$tmp . "'";
    $result=$conn->query($sqlq);
    $resultq=$result;
if($resultq)goto L2xeWjgx1y;
goto L2xldMhx1y;
goto L2xldMhx1y;
goto L2xldMhx1y;
goto L2xldMhx1y;
L2xeWjgx1y:
    echo "已删除该文章!";
}
L2xldMhx1y:
$row=mysql_errno();
echo $row;
$sql="SELECT * FROM comm";
$result=$conn->query($sql);
$result=$result;
L2xx2k:
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($num4))break;
    $wcid=$row['wzcid'];
if($wcid==$wzdid)goto L2xeWjgx2r;
goto L2xx2k;
goto L2xx2k;
}
L2xeWjgx2r:
$id=$row['id'];
$tmp="delete from comm where id='" . $id;
$sqlq=$tmp . "'";
$result=$conn->query($sqlq);
$resultq=$result;
if($resultq)goto L2xx2k;
goto L2xldMhx2p;
goto L2xldMhx2p;
goto L2xldMhx2p;
L2xldMhx2p:
$row=mysql_errno();
echo $row;
$sql="SELECT * FROM lcke";
$result=$conn->query($sql);
$result=$result;
L2xx3b:
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($num4))break;
    $wcid=$row['lwz'];
if($wcid==$wzdid)goto L2xeWjgx3i;
goto L2xx3b;
goto L2xx3b;
}
L2xeWjgx3i:
$id=$row['id'];
$tmp="delete from lcke where id='" . $id;
$sqlq=$tmp . "'";
$result=$conn->query($sqlq);
$resultq=$result;
if($resultq)goto L2xx3b;
goto L2xldMhx3g;
goto L2xldMhx3g;
goto L2xldMhx3g;
L2xldMhx3g:
$row=mysql_errno();
echo $row;
if($ptpimag!="")goto L2xeWjgx4i;
goto L2xldMhx4i;
L2xeWjgx4i:
$row=explode('(+@+)', $ptpimag);
$imgar=$row;
$row=count($imgar);
$coun=$row;
$num4=0;
$i=$num4;
while(true){
    $tmp=$i<$coun;
    if(!$tmp)break;
    $tuimg=$imgar[$i];
    $row=strpos($tuimg, '/upload/');
    $tmp=$row!==false;
if($tmp)goto L2xeWjgx48;
goto L2xldMhx48;
goto L2xldMhx48;
goto L2xldMhx48;
L2xeWjgx48:
    $str='.' . $tuimg;
    $row=realpath($str);
    $abstu=$row;
    $row=is_file($abstu);
    $tmp=!$row;
    if(!($tmp)){
        $row=unlink($abstu);
L2xldMhx48:
    }
    $obj=$i;
    $obj2=$i+1;
    $num4=$obj2;
    $i=$num4;
}
goto L2xx4h;
L2xldMhx4i:
L2xx4h:
if($ptpvideo!="")goto L2xeWjgx4w;
goto L2xldMhx4w;
L2xeWjgx4w:
$row=strpos($ptpvideo, '/upload/');
$tmp=$row!==false;
if($tmp)goto L2xeWjgx4s;
goto L2xx4v;
goto L2xx4v;
L2xeWjgx4s:
$str='..' . $ptpvideo;
$row=realpath($str);
$absolutePath=$row;
$row=is_file($absolutePath);
$tmp=!$row;
if($tmp)goto L2xx4v;
goto L2xldMhx4u;
L2xldMhx4u:
$row=unlink($absolutePath);
L2xldMhx4w:
L2xx4v:
$result=$conn->close();