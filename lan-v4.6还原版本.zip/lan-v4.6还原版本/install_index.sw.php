<?php
$file="ins.bak";
$fileExists=file_exists($file);
if($fileExists){
    echo '你已经安装过了!若您是首次使用请先进行安装,删除文件夹 <span style="color: red;">[install/]</span> 下的 <span style="color: red;">[ins.bak]</span> 文件后进行安装。';
    exit();
}
$iteace=2;
$fileExists=is_file('../config.php');
if($fileExists){
    $tmp=include '../config.php';
}
echo "<html lang=\"en\"><head>";
echo "
<meta charset=\"utf-8\">";
echo "
<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0\">";
echo "
<title>安装程序 - LAN - 更简洁，更优雅</title>";
echo "
<meta name=\"keywords\" content=\"LAN,LAN朋友圈主题,朋友圈主题,朋友圈程序,LAN朋友圈程序\">";
echo "
<meta name=\"description\" content=\"兰 - 更简洁，更优雅\">";
echo "
<meta name=\"author\" content=\"兰 - 更简洁，更优雅\">";
echo "
<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"../../admin/assets/img/favicon.png\">";
echo "
<link rel=\"stylesheet\" href=\"../admin/assets/css/css2.css\">";
echo "
<link rel=\"stylesheet\" id=\"css-main\" href=\"../admin/assets/css/oneui.min.css\">";
echo "
</head>";
echo "
<body>";
echo "
<div id=\"page-container\" class=\"sidebar-dark page-header-fixed main-content-narrow side-trans-enabled\">";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<!-- Main Container -->";
echo "
<main id=\"main-container\">";
echo "
";
echo "
<!-- Page Content -->";
echo "
<div class=\"content\">";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"row\" style=\"display: flex;justify-content: center;\">";
echo "
<div class=\"col-md-8\">";
echo "
<form action=\"install.php\" method=\"post\" enctype=\"multipart/form-data\">";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\">LAN 安装程序</h3>";
echo "
<div class=\"block-options\">";
echo "
<button type=\"submit\" class=\"btn btn-sm btn-primary\">安装</button>";
echo "
<input type=\"hidden\" value=\"wzpz\" name=\"lx\">";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"block-content\">";
echo "
<div class=\"row justify-content: flex-start;\">";
echo "
<div class=\"col-sm-12 col-md-12\">";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-username\">数据库地址</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-username\" name=\"servername\" placeholder=\"\" value=\"localhost\" required=\"required\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">数据库名</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" name=\"dbname\" placeholder=\"\" required=\"required\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">数据库账号</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" name=\"username\" placeholder=\"\" required=\"required\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">数据库密码</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" name=\"password\" placeholder=\"\" required=\"required\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">设置管理员账号</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" name=\"admin\" placeholder=\"默认密码:123456\" required=\"required\" minlength=\"5\" maxlength=\"32\" onKeyUp=\"value=value.replace(/[\\W]/g,'')\">";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</form>";
echo "
</div>";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
</div>";
echo "
<!-- END Page Content -->";
echo "
</main>";
echo "
<!-- END Main Container -->";
echo "
";
echo "
";
echo "
";
echo "
</div>";
echo "
<!-- END Page Container -->";
echo "
";
echo "
<!--";
echo "
OneUI JS";
echo "
";
echo "
Core libraries and functionality";
echo "
webpack is putting everything together at ../admin/assets/_js/main/app.js";
echo "
-->";
echo "
<script src=\"../admin/assets/js/oneui.app.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Plugins -->";
echo "
<script src=\"../admin/assets/js/chart.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Code -->";
echo "
<script src=\"../admin/assets/js/be_pages_dashboard.min.js\"></script>";
echo "
";
echo "
";
echo "
</body></html>";

