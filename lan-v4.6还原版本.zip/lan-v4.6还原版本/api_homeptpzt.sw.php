<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp=$user_zh=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$user_passid=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit("请先登录");
}
$num3=4105;
$isArray=is_array($_POST);
if($isArray){
    $num3=16;
}else{
    $num3=16;
    $num3=214;
}
switch($num3){
    case 115:{
    $ztys=$_POST['ztys'];
        break;
    }
    case 16:{
        $ztys=&$_POST['ztys'];
        break;
    }
}
$escaped=htmlspecialchars($ztys);
unset($ztys);
$escaped2=addslashes($escaped);
$ztys=$escaped2;
$num4=4102;
$isArray=is_array($_POST);
if($isArray){
    $num4=169;
}else{
    $num4=96;
}
switch($num4){
    case 169:{
    $ztys=&$_POST['ztwid'];
        break;
    }
    case 96:{
        $ztys=$_POST['ztwid'];
        break;
    }
}
$escaped=htmlspecialchars($ztys);
unset($ztys);
$escaped2=addslashes($escaped);
$ztwid=$escaped2;
$tmp=$ztys=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$ztwid=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit("参数不完整");
}
$tmp=include '../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    exit("连接数据库失败");
}
$escaped=htmlspecialchars($user_zh);
$cookieResult=addslashes($escaped);
$user_zhsg=$cookieResult;
$tmp="select * from user where username='" . $user_zhsg;
$sqls=$tmp . "'";
$row=mysqli_query($conn, $sqls);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$data2s_row=$row;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$str="select * from user where username='" . $user_zh;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
if($user_passid!=$passid){
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("username", "", $str, "/");
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("passid", "", $str, "/");
    exit("账号信息异常,请重新登录");
}
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($sentinel))break;
    $glyadmin=$row["username"];
}
L2xx14:
$num=4112;
$tmp=$zjzhq==$glyadmin;
if($tmp){
    $num=52;
}else{
    $num=117;
}
$tmp=48;
$tmp4=117;
$tmp2=$num==117;
if($tmp2)goto L2xeWjgx1d;
goto L2xldMhx1d;
L2xeWjgx1d:
$tmp="select * from essay where cid= '" . $ztys;
$sql=$tmp . "'";
$row=mysqli_query($conn, $sql);
$result=$row;
$row=mysqli_num_rows($result);
$tmp=$row>0;
if($tmp){
    $row=mysqli_fetch_assoc($result);
    $row=$row;
    $ptpuser=$row["ptpuser"];
}else{
    exit("未获取到数据!");
}
$tmp=$zjzhq==$ptpuser;
if($tmp)goto L2xx1c;
goto L2xldMhx1b;
L2xldMhx1b:
exit("您无权操作其他用户的文章!");
L2xldMhx1d:
$tmp=342;
$tmp4=52;
$tmp2=$num==52;
if($tmp2)goto L2xx1c;
L2xx1c:
$num2=4104;
$tmp=$ztwid==0;
if($tmp){
    $num2=78;
}else{
    $tmp=$ztwid==1;
    if($tmp){
        $num2=24;
    }
}
$tmp=60;
$tmp4=78;
$tmp2=$num2==78;
if($tmp2)goto L2xeWjgx1r;
goto L2xldMhx1r;
L2xeWjgx1r:
$str="select * from essay where cid='" . $ztys;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data_row=$row;
$zid=$data_row["id"];
$tmp="UPDATE essay SET ptpys='1' WHERE id='" . $zid;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx1m;
goto L2xldMhx1m;
goto L2xldMhx1m;
L2xeWjgx1m:
echo "已解除私密";
goto L2xx1q;
L2xldMhx1m:
echo "解除私密失败";
L2xldMhx1r:
$tmp=132;
$tmp4=24;
$tmp2=$num2==24;
if($tmp2)goto L2xeWjgx1u;
goto L2xldMhx1u;
L2xeWjgx1u:
$str="select * from essay where cid='" . $ztys;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data_row=$row;
$zid=$data_row["id"];
$tmp="UPDATE essay SET ptpys='0' WHERE id='" . $zid;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx1p;
goto L2xldMhx1p;
goto L2xldMhx1p;
L2xeWjgx1p:
echo "已设置私密";
goto L2xx1q;
L2xldMhx1p:
echo "设置私密失败";
L2xldMhx1u:
L2xx1q:
$result=$conn->close();