<?php
$iteace=1;
$pos=is_file('../config.php');
if($pos){
    $tmp=include '../config.php';
}
$tmp=include '../api/wz.php';
if($userdlzt==0){
    $pos=header('location: ./login.php');
    exit();
}
$num7=5833;
$tmp=$user_zh==$glyadmin;
if($tmp){
    $num7=36;
}else{
    $num7=30;
}
$tmp=35;
$tmp2=30;
$tmp3=$num7==30;
if($tmp3)goto L2xeWjgxe;
goto L2xldMhxe;
L2xeWjgxe:
exit('<script language="JavaScript">;alert("没有权限!");location.href="../index.php";</script>;');
goto L2xxd;
L2xldMhxe:
$tmp=38;
$tmp2=36;
$tmp3=$num7==36;
if($tmp3)goto L2xeWjgxf;
goto L2xldMhxf;
L2xeWjgxf:
$tmp=$user_passid!=$passid;
if($tmp)goto L2xeWjgxc;
goto L2xxd;
goto L2xxd;
L2xeWjgxc:
exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="./login.php";</script>;');
goto L2xxd;
L2xldMhxf:
L2xxd:
echo "<!doctype html>";
echo "
<html lang=\"en\">";
echo "
<head>";
echo "
<meta charset=\"utf-8\">";
echo "
<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0\">";
echo "
<title>生成卡密 - ";
echo $name;
echo "</title>";
echo "
<meta name=\"keywords\" content=\"";
echo $filterkeyw;
echo "\">";
echo "
<meta name=\"description\" content=\"";
echo $subtitle;
echo "\">";
echo "
<meta name=\"author\" content=\"";
echo $name;
echo "\">";
echo "
<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"";
$num8=5834;
$pos=strpos($icon, 'http');
$tmp=$pos!==false;
if($tmp){
    $num8=108;
}else{
    $num8=90;
}
switch($num8){
    case 108:{
    echo $icon;
        break;
    }
    case 90:{
        $tmp='.' . $icon;
        echo $tmp;
        break;
    }
}
echo "\">";
echo "
<link rel=\"stylesheet\" href=\"assets/css/css2.css\">";
echo "
<link rel=\"stylesheet\" id=\"css-main\" href=\"assets/css/oneui.min.css\">";
echo "
</head>";
echo "
<body>";
echo "
<div id=\"page-container\" class=\"sidebar-o sidebar-dark page-header-fixed main-content-narrow\">";
echo "
<nav id=\"sidebar\" aria-label=\"Main Navigation\">";
echo "
<!-- Side Header -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Logo -->";
echo "
<a class=\"fw-semibold text-dual\" href=\"index.php\">";
echo "
<span class=\"smini-visible\">";
echo "
<i class=\"fa fa-circle-notch text-primary\"></i>";
echo "
</span>";
echo "
<span class=\"smini-hide fs-5 tracking-wider\">后台管理</span>";
echo "
</a>";
echo "
<!-- END Logo -->";
echo "
";
echo "
<!-- Extra -->";
echo "
<div>";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" data-toggle=\"layout\" data-action=\"dark_mode_toggle\">";
echo "
<i class=\"far fa-moon\"></i>";
echo "
</button>";
echo "
<!-- END Dark Mode -->";
echo "
";
echo "
<!-- Options -->";
echo "
<div class=\"dropdown d-inline-block ms-1\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" id=\"sidebar-themes-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<i class=\"far fa-circle\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-end fs-sm smini-hide border-0\" aria-labelledby=\"sidebar-themes-dropdown\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"default\" href=\"#\">";
echo "
<span>默认</span>";
echo "
<i class=\"fa fa-circle text-default\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/amethyst.min.css\" href=\"#\">";
echo "
<span>紫色</span>";
echo "
<i class=\"fa fa-circle text-amethyst\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/city.min.css\" href=\"#\">";
echo "
<span>红色</span>";
echo "
<i class=\"fa fa-circle text-city\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/flat.min.css\" href=\"#\">";
echo "
<span>青色</span>";
echo "
<i class=\"fa fa-circle text-flat\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/modern.min.css\" href=\"#\">";
echo "
<span>蓝色</span>";
echo "
<i class=\"fa fa-circle text-modern\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/smooth.min.css\" href=\"#\">";
echo "
<span>粉色</span>";
echo "
<i class=\"fa fa-circle text-smooth\"></i>";
echo "
</a>";
echo "
<!-- END Color Themes -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_light\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 黑色</span>";
echo "
</a>";
echo "
<!-- END Sidebar Styles -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_light\" href=\"javascript:void(0)\">";
echo "
<span>导航 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>导航 黑色</span>";
echo "
</a>";
echo "
<!-- END Header Styles -->";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Options -->";
echo "
<a class=\"d-lg-none btn btn-sm btn-alt-secondary ms-1\" data-toggle=\"layout\" data-action=\"sidebar_close\" href=\"javascript:void(0)\">";
echo "
<i class=\"fa fa-fw fa-times\"></i>";
echo "
</a>";
echo "
<!-- END Close Sidebar -->";
echo "
</div>";
echo "
<!-- END Extra -->";
echo "
</div>";
echo "
<!-- END Side Header -->";
echo "
";
echo "
<!-- Sidebar Scrolling -->";
echo "
<div class=\"js-sidebar-scroll\">";
echo "
<!-- Side Navigation -->";
echo "
<div class=\"content-side\">";
echo "
<ul class=\"nav-main\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./index.php\">";
echo "
<i class=\"nav-main-link-icon si si-speedometer\"></i>";
echo "
<span class=\"nav-main-link-name\">后台首页</span>";
echo "
</a>";
echo "
</li>";
echo "
";
echo "
<li class=\"nav-main-heading\">设置</li>";
echo "
<li class=\"nav-main-item  open\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-energy\"></i>";
echo "
<span class=\"nav-main-link-name\">网站设置</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./basic.php\">";
echo "
<span class=\"nav-main-link-name\">基础设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./authority.php\">";
echo "
<span class=\"nav-main-link-name\">权限设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./imgset.php\">";
echo "
<span class=\"nav-main-link-name\">图像设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./emailset.php\">";
echo "
<span class=\"nav-main-link-name\">邮箱设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link active\" href=\"./calis.php\">";
echo "
<span class=\"nav-main-link-name\">卡密管理</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-users\"></i>";
echo "
<span class=\"nav-main-link-name\">用户管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./userlist.php\">";
echo "
<span class=\"nav-main-link-name\">用户列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-book-open\"></i>";
echo "
<span class=\"nav-main-link-name\">文章管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditesli.php\">";
echo "
<span class=\"nav-main-link-name\">文章列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditessh.php\">";
echo "
<span class=\"nav-main-link-name\">审核文章</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-speech\"></i>";
echo "
<span class=\"nav-main-link-name\">评论管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditcoli.php\">";
echo "
<span class=\"nav-main-link-name\">评论列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditcosh.php\">";
echo "
<span class=\"nav-main-link-name\">审核评论</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-paper-clip\"></i>";
echo "
<span class=\"nav-main-link-name\">友链管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./linkset.php\">";
echo "
<span class=\"nav-main-link-name\">友链列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
</ul>";
echo "
</div>";
echo "
<!-- END Side Navigation -->";
echo "
</div>";
echo "
<!-- END Sidebar Scrolling -->";
echo "
</nav>";
echo "
<!-- END Sidebar -->";
echo "
";
echo "
<!-- Header -->";
echo "
<header id=\"page-header\">";
echo "
<!-- Header Content -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Left Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- Toggle Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-lg-none\" data-toggle=\"layout\" data-action=\"sidebar_toggle\">";
echo "
<i class=\"fa fa-fw fa-bars\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Sidebar -->";
echo "
";
echo "
<!-- Toggle Mini Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-none d-lg-inline-block\" data-toggle=\"layout\" data-action=\"sidebar_mini_toggle\">";
echo "
<i class=\"fa fa-fw fa-ellipsis-v\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Mini Sidebar -->";
echo "
";
echo "
<!-- Open Search Section (visible on smaller screens) -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
";
echo "
<!-- END Open Search Section -->";
echo "
";
echo "
<!-- Search Form (visible on larger screens) -->";
echo "
";
echo "
<!-- END Search Form -->";
echo "
</div>";
echo "
<!-- END Left Section -->";
echo "
";
echo "
<!-- Right Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- User Dropdown -->";
echo "
<div class=\"dropdown d-inline-block ms-2\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary d-flex align-items-center\" id=\"page-header-user-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<img class=\"rounded-circle\" src=\"";
$num=5834;
$pos=strpos($user_img, 'http');
$tmp=$pos!==false;
if($tmp){
    $num=12;
}else{
    $num=108;
}
switch($num){
    case 108:{
    $tmp='.' . $user_img;
    echo $tmp;
        break;
    }
    case 12:{
        echo $user_img;
        break;
    }
}
echo "\" alt=\"Header Avatar\" style=\"width: 21px;\">";
echo "
<span class=\"d-none d-sm-inline-block ms-2\">";
echo $user_name;
echo "</span>";
echo "
<i class=\"fa fa-fw fa-angle-down d-none d-sm-inline-block opacity-50 ms-1 mt-1\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-md dropdown-menu-end p-0 border-0\" aria-labelledby=\"page-header-user-dropdown\">";
echo "
<div class=\"p-3 text-center bg-body-light border-bottom rounded-top\">";
echo "
<img class=\"img-avatar img-avatar48 img-avatar-thumb\" src=\"";
$num2=5845;
$pos=strpos($user_img, 'http');
$tmp=$pos!==false;
if($tmp){
    $num2=30;
}else{
    $num2=72;
}
switch($num2){
    case 30:{
    echo $user_img;
        break;
    }
    case 72:{
        $tmp='.' . $user_img;
        echo $tmp;
        break;
    }
}
echo "\" alt=\"\">";
echo "
<p class=\"mt-2 mb-0 fw-medium\">";
echo $user_name;
echo "</p>";
echo "
<!--p class=\"mb-0 text-muted fs-sm fw-medium\">介绍</p-->";
echo "
</div>";
echo "
<div role=\"separator\" class=\"dropdown-divider m-0\"></div>";
echo "
<div class=\"p-2\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"../\">";
echo "
<span class=\"fs-sm fw-medium\">返回前台</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"JavaScript:;\" onclick=\"logut()\">";
echo "
<span class=\"fs-sm fw-medium\">退出登录</span>";
echo "
</a>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
<!-- END User Dropdown -->";
echo "
";
echo "
<!-- Notifications Dropdown -->";
echo "
";
echo "
<!-- END Notifications Dropdown -->";
echo "
";
echo "
<!-- Toggle Side Overlay -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
<!-- END Toggle Side Overlay -->";
echo "
</div>";
echo "
<!-- END Right Section -->";
echo "
</div>";
echo "
<!-- END Header Content -->";
echo "
";
echo "
<!-- Header Loader -->";
echo "
<!-- Please check out the Loaders page under Components category to see examples of showing/hiding it -->";
echo "
<div id=\"page-header-loader\" class=\"overlay-header bg-body-extra-light\">";
echo "
<div class=\"content-header\">";
echo "
<div class=\"w-100 text-center\">";
echo "
<i class=\"fa fa-fw fa-circle-notch fa-spin\"></i>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Header Loader -->";
echo "
</header>";
echo "
<!-- END Header -->";
echo "
";
echo "
<!-- Main Container -->";
echo "
<main id=\"main-container\">";
echo "
";
echo "
<!-- Page Content -->";
echo "
<div class=\"content\">";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"row\">";
echo "
<div class=\"col-md-12\">";
echo "
<form action=\"./api/kamisc.php\" method=\"post\">";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\">生成卡密</h3>";
echo "
<div class=\"block-options\">";
echo "
<button type=\"submit\" class=\"btn btn-sm btn-primary\">生成</button>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"block-content\">";
echo "
<div class=\"row justify-content: flex-start;\">";
echo "
<div class=\"col-sm-12 col-md-12\">";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-username\">卡密数量</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-username\" name=\"kms\" value=\"\" placeholder=\"生成几张卡密\" required>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">卡密金额</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" name=\"kmg\" value=\"\" placeholder=\"每张卡密的金额\" required>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</form>";
echo "
</div>";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\">卡密列表</h3>";
echo "
<div class=\"block-options space-x-1\">";
echo "
<button id=\"so-search\" type=\"button\" class=\"btn btn-sm btn-alt-secondary js-class-toggle-enabled\" data-toggle=\"class-toggle\" data-target=\"#one-dashboard-search-orders\" data-class=\"d-none\">";
echo "
<i class=\"fa fa-search\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown d-inline-block\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" id=\"dropdown-recent-orders-filters\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<i class=\"fa fa-fw fa-flask\"></i>";
echo "
Filters";
echo "
<i class=\"fa fa-angle-down ms-1\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-md dropdown-menu-end fs-sm\" aria-labelledby=\"dropdown-recent-orders-filters\" style=\"\">";
echo "
<a class=\"dropdown-item fw-medium d-flex align-items-center justify-content-between\" href=\"?type=0\">已使用卡密";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium d-flex align-items-center justify-content-between\" href=\"?type=1\">未使用卡密";
echo "
</a>";
echo "
";
echo "
";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
<div id=\"one-dashboard-search-orders\" class=\"block-content border-bottom d-none\">";
echo "
<!-- Search Form -->";
echo "
<form action=\"be_pages_dashboard.php\" method=\"POST\" onsubmit=\"return false;\">";
echo "
<div class=\"push\">";
echo "
<div class=\"input-group\">";
echo "
<input type=\"text\" class=\"form-control form-control-alt\" id=\"one-ecom-orders-search\" name=\"keyword\" placeholder=\"Search all orders..\">";
echo "
<span class=\"input-group-text bg-body border-0\">";
echo "
<i class=\"fa fa-search\"></i>";
echo "
</span>";
echo "
</div>";
echo "
</div>";
echo "
</form>";
echo "
<!-- END Search Form -->";
echo "
</div>";
echo "
<div class=\"block-content block-content-full\">";
echo "
<!-- Recent Orders Table -->";
echo "
<div class=\"table-responsive\">";
echo "
<table class=\"table table-hover table-vcenter\">";
echo "
<thead>";
echo "
<tr>";
echo "
<th class=\"text-center\" style=\"width: 70px;\">";
echo "
<div class=\"form-check d-inline-block\">";
echo "
<input class=\"form-check-input\" type=\"checkbox\" value=\"\" id=\"check-all\" name=\"check-all\">";
echo "
<label class=\"form-check-label\" for=\"check-all\"></label>";
echo "
</div>";
echo "
</th>";
echo "
<th>ID</th>";
echo "
<th>卡密</th>";
echo "
<th>卡密金额</th>";
echo "
<th>使用状态</th>";
echo "
<th>使用者账号</th>";
echo "
<th>使用时间</th>";
echo "
<th>操作</th>";
echo "
</tr>";
echo "
</thead>";
echo "
<tbody class=\"fs-sm\">";
echo "
";
$num3=5846;
$isArray=is_array($_GET);
if($isArray){
    $page=&$_GET['page'];
}else{
    $page=$_GET['page'];
}
$escaped=htmlspecialchars($page);
unset($page);
$escaped2=addslashes($escaped);
$tmp=$escaped2!="";
if($tmp){
    $num3=12;
}else{
    $num3=90;
}
switch($num3){
    case 90:{
    $page=1;
        break;
    }
    case 12:{
        $page=$_GET['page'];
        break;
    }
}
$perPage=50;
$tmp=$page-1;
$offset=$tmp*50;
$num4=5836;
$isArray=is_array($_GET);
if($isArray){
    $num4=24;
}else{
    $num4=9;
}
switch($num4){
    case 24:{
    $page=&$_GET["type"];
        break;
    }
    case 9:{
        $page=$_GET["type"];
        break;
    }
}
$escaped=htmlspecialchars($page);
unset($page);
$escaped2=addslashes($escaped);
$type=$escaped2;
$num5=5838;
$isArray=is_array($_GET);
if($isArray){
    $num5=16;
}else{
    $num5=30;
}
switch($num5){
    case 16:{
    $page=&$_GET["keyword"];
        break;
    }
    case 30:{
        $page=$_GET["keyword"];
        break;
    }
}
$escaped=htmlspecialchars($page);
unset($page);
$escaped2=addslashes($escaped);
$keyword=$escaped2;
$num6=5850;
$tmp=$type=="";
if($tmp){
    $num6=36;
}else{
    $tmp=$type=="0";
    if($tmp){
        $num6=24;
    }else{
        $tmp=$type=="1";
        if($tmp){
            $num6=72;
        }
    }
}
switch($num6){
    case 24:{
    $tmp="SELECT * FROM kami WHERE act = '0' order by id desc LIMIT " . 50;
    $tmp2=$tmp . " OFFSET ";
    $sql=$tmp2 . $offset;
        break;
    }
    case 36:{
        $tmp="SELECT * FROM kami order by id desc LIMIT " . 50;
        $tmp2=$tmp . " OFFSET ";
        $sql=$tmp2 . $offset;
        break;
    }
    case 72:{
            $tmp="SELECT * FROM kami WHERE act = '1' order by id desc LIMIT " . 50;
            $tmp2=$tmp . " OFFSET ";
            $sql=$tmp2 . $offset;
        break;
    }
}
if($keyword!=""){
    $tmp="SELECT * FROM kami WHERE kami LIKE '%" . $keyword;
    $sql=$tmp . "%' ORDER BY id DESC";
}
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0){
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!$str)break;
    $kami=$row["kami"];
    $auom=$row["auom"];
    $act=$row["act"];
    $ause=$row["ause"];
    $autm=$row["autm"];
    $kmid=$row["id"];
    $tmp=$act=='0';
    if($tmp){
        $acz=15377;
    }else{
        $tmp=$act=='1';
        if($tmp){
            $acz=44336;
        }
    }
    $tmp='<tr>
    <td class="text-center">
    <div class="form-check d-inline-block">
    <input class="form-check-input" type="checkbox" name="ids[]" value="' . $kmid;
    $tmp2=$tmp . '" id="ids-';
    $tmp3=$tmp2 . $kmid;
    $tmp4=$tmp3 . '">
    <label class="form-check-label" for="ids-';
    $tmp5=$tmp4 . $kmid;
    $tmp6=$tmp5 . '"></label>
    </div>
    </td>
    <td>';
    $tmp7=$tmp6 . $kmid;
    $tmp8=$tmp7 . '</td>
    <td>';
    $tmp9=$tmp8 . $kami;
    $tmp10=$tmp9 . '</td>
    <td>';
    $tmp11=$tmp10 . $auom;
    $tmp12=$tmp11 . '</td>
    <td>';
    $tmp13=$tmp12 . $acz;
    $tmp14=$tmp13 . '</td>
    <td>';
    $tmp15=$tmp14 . $ause;
    $tmp16=$tmp15 . '</td>
    <td>';
    $tmp17=$tmp16 . $autm;
    $tmp18=$tmp17 . '</td>
    <td><div class="btn-group"><a href="./api/kamisc.php?del=';
    $tmp19=$tmp18 . $kmid;
    $tmp20=$tmp19 . '" style="flex-shrink: 0;"><font class="text-success">删除</font></a></div></td>
    </tr>';
    echo $tmp20;
}
}else{
}
L2xx25:
echo "                      ";
echo "
</tbody>";
echo "
</table>";
echo "
</div>";
echo "
<ul class=\"pagination\" style=\"margin-top:10px;\">";
echo "
";
$str='Select count(*) as AllNum from kami';
$Query=$str;
$pos=mysqli_query($conn, $Query);
$aus=$pos;
$pos=mysqli_fetch_assoc($aus);
$bus=$pos;
$tmp='<div class="fixed-table-pagination callout" style="width: 100%;display: flex;justify-content: space-between;">
<div class="float-left pagination-detail" style="margin-bottom: 10px;">
<span class="pagination-info">
每页显示' . $perPage;
$tmp2=$tmp . '条记录，共';
$tmp3=$tmp2 . $bus['AllNum'];
$tmp4=$tmp3 . '条记录
</span>
</div>
<div class="float-right pagination">';
echo $tmp4;
$result=$conn->query("SELECT COUNT(*) AS total FROM kami");
$row=$result->fetch_assoc();
$totalRecords=$row;
$totalRecords=$totalRecords['total'];
$val=$totalRecords/$perPage;
$pos=ceil($val);
$maxPages=$pos;
if($maxPages>1)goto L2xeWjgx2x;
goto L2xldMhx2x;
L2xeWjgx2x:
$tmp=$page>1;
if($tmp){
    echo '<li class="page-item"><a class="page-link" aria-label="首页" href="calis.php?page=1">首页</a></li>';
    $tmp=$page-1;
    $tmp2='<li><a class="page-link" aria-label="上一页" href="calis.php?page=' . $tmp;
    $tmp3=$tmp2 . '">‹</a></li>';
    echo $tmp3;
}
$val=$page-1;
$pos=max($val);
$start=$pos;
$val=$page+1;
$pos=min($val, $maxPages);
$end=$pos;
$tmp=$start>1;
if($tmp){
    echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
}
$str=$start;
$i=$str;
while(true){
    $tmp=$i<=$end;
    if(!$tmp)break;
    $tmp=$i==$page;
    if($tmp){
        $tmp='<li class="page-item active"><a class="page-link" aria-label="' . $i;
        $tmp2=$tmp . '" href="calis.php?page=';
        $tmp3=$tmp2 . $i;
        $tmp4=$tmp3 . '">';
        $tmp5=$tmp4 . $i;
        $tmp6=$tmp5 . '</a></li>';
        echo $tmp6;
    }else{
        $tmp='<li class="page-item "><a class="page-link" aria-label="' . $i;
        $tmp2=$tmp . '" href="calis.php?page=';
        $tmp3=$tmp2 . $i;
        $tmp4=$tmp3 . '">';
        $tmp5=$tmp4 . $i;
        $tmp6=$tmp5 . '</a></li>';
        echo $tmp6;
    }
    $obj=$i;
    $obj2=$i+1;
    $str=$obj2;
    $i=$str;
}
L2xx2o:
$tmp=$end<$maxPages;
if($tmp){
    echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
}
$tmp=$page<$maxPages;
if($tmp)goto L2xeWjgx2v;
goto L2xx2w;
goto L2xx2w;
L2xeWjgx2v:
$tmp=$page+1;
$tmp2='<li><a class="page-link" aria-label="下一页" href="calis.php?page=' . $tmp;
$tmp3=$tmp2 . '">›</a></li>';
echo $tmp3;
$tmp='<li class="page-item"><a class="page-link" aria-label="尾页" href="calis.php?page=' . $maxPages;
$tmp2=$tmp . '">尾页</a></li>';
echo $tmp2;
goto L2xx2w;
L2xldMhx2x:
L2xx2w:
echo "</div></div>";
echo "                      </tbody>";
echo "
</table>";
echo "
</div>";
echo "
<!-- END Recent Orders Table -->";
echo "
</div>";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
</div>";
echo "
<!-- END Page Content -->";
echo "
</main>";
echo "
<!-- END Main Container -->";
echo "
";
echo "
<!-- Footer -->";
echo "
<footer id=\"page-footer\" class=\"bg-body-light\">";
echo "
<div class=\"content py-3\">";
echo "
<div class=\"row fs-sm\">";
echo "
<div class=\"col-sm-6 order-sm-2 py-1 text-center text-sm-end\">";
echo "
Crafted with <i class=\"fa fa-heart text-danger\"></i> by <a class=\"fw-semibold\" href=\"https://qemao.com\" target=\"_blank\">苏画</a>";
echo "
</div>";
echo "
<div class=\"col-sm-6 order-sm-1 py-1 text-center text-sm-start\">";
echo "
<a class=\"fw-semibold\" href=\"https://www.qemao.com\" target=\"_blank\">LAN</a> &copy; <span data-toggle=\"year-copy\"></span>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</footer>";
echo "
<!-- END Footer -->";
echo "
</div>";
echo "
<!-- END Page Container -->";
echo "
";
echo "
<!--";
echo "
OneUI JS";
echo "
";
echo "
Core libraries and functionality";
echo "
webpack is putting everything together at assets/_js/main/app.js";
echo "
-->";
echo "
<script src=\"assets/js/oneui.app.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Plugins -->";
echo "
<script src=\"assets/js/chart.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Code -->";
echo "
<script src=\"assets/js/be_pages_dashboard.min.js\"></script>";
echo "
</body>";
echo "
</html>";
echo "
";