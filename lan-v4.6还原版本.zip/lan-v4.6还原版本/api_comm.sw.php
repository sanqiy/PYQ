<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$num3=5849;
$tmp=$user_zh=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$user_passid=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    $num3=306;
}else{
    $num3=119;
}
switch($num3){
    case 306:{
    $userdlzt=0;
        break;
    }
    case 119:{
        $userdlzt=1;
        break;
    }
}
$num4=5850;
$isArray=is_array($_POST);
if($isArray){
    $num4=119;
}else{
    $num4=289;
}
switch($num4){
    case 289:{
    $page=$_POST['page'];
        break;
    }
    case 119:{
        $page=&$_POST['page'];
        break;
    }
}
$escaped=htmlspecialchars($page);
unset($page);
$escaped2=addslashes($escaped);
$page=$escaped2;
$num5=5841;
$isArray=is_array($_POST);
if($isArray){
    $num5=289;
}else{
    $num5=289;
    $num5=1223;
}
switch($num5){
    case 289:{
    $page=&$_POST['wzcidd'];
        break;
    }
    case 756:{
        $page=$_POST['wzcidd'];
        break;
    }
}
$escaped=htmlspecialchars($page);
unset($page);
$escaped2=addslashes($escaped);
$wzcidd=$escaped2;
$tmp=$page=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$wzcidd=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit("参数为空!");
}
$tmp=include '../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    exit("连接数据库失败");
}
$escaped=htmlspecialchars($user_zh);
$cookieResult=addslashes($escaped);
$user_zhsg=$cookieResult;
$tmp="select * from user where username='" . $user_zhsg;
$sqls=$tmp . "'";
$row=mysqli_query($conn, $sqls);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$data2s_row=$row;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$num=5848;
$isArray=is_array($_SERVER);
if($isArray){
    $serverVal=&$_SERVER["HTTP_REFERER"];
}else{
    $serverVal=$_SERVER["HTTP_REFERER"];
}
$row=strstr($serverVal, "home.php");
unset($serverVal);
if($row){
    $num=289;
}else{
    $num=119;
}
switch($num){
    case 289:{
    $scplan=1;
        break;
    }
    case 119:{
        $scplan="";
        break;
    }
}
$dqgs=0;
$dqs=0;
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($sentinel))break;
    $name=$row["name"];
    $name=$row["subtitle"];
    $icon=$row["icon"];
    $logo=$row["logo"];
    $zt=$row["zt"];
    $username=$row["username"];
    $glyadmin=$row["username"];
    $homimg=$row["homimg"];
    $sign=$row["sign"];
    $essgs=$row["essgs"];
    $commgs=$row["commgs"];
    $kqsy=$row["kqsy"];
    $topes=$row["topes"];
}
L2xx18:
$row=explode(PHP_EOL, $topes);
$ars=$row;
$tmp="select * from essay where cid= '" . $wzcidd;
$sql=$tmp . "'";
$row=mysqli_query($conn, $sql);
$result=$row;
$row=mysqli_num_rows($result);
$tmp=$row>0;
if($tmp){
    $row=mysqli_fetch_assoc($result);
    $roww=$row;
    $wzyonyzh=$roww["ptpuser"];
    $wzyonyid=$roww["id"];
}
if($userdlzt==1)goto L2xeWjgx1j;
goto L2xldMhx1j;
L2xeWjgx1j:
$str="select * from user where username='" . $user_zh;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
$tmp=$user_passid!=$passid;
if($tmp)goto L2xeWjgx1h;
goto L2xx1i;
goto L2xx1i;
L2xeWjgx1h:
$escaped=time();
$str=$escaped+ -1;
$cookieResult=setcookie("username", "", $str, "/");
$escaped=time();
$str=$escaped+ -1;
$cookieResult=setcookie("passid", "", $str, "/");
exit("账号信息异常,请重新登录");
goto L2xx1i;
L2xldMhx1j:
L2xx1i:
$tmp="select * from comm where wzcid= '" . $wzcidd;
$sql=$tmp . "' and comaud<>'0' and comaud<>'-1'";
$row=mysqli_query($conn, $sql);
$result=$row;
$num2=5845;
$row=mysqli_num_rows($result);
$tmp=$row>0;
if($tmp){
    $num2=187;
}else{
    $num2=126;
}
$tmp=11;
$tmp4=187;
$tmp2=$num2==187;
if($tmp2)goto L2xeWjgx33;
goto L2xldMhx33;
L2xeWjgx33:
L2xx1o:
while(true){
    $row=mysqli_fetch_assoc($result);
    $row=$row;
    if(!$sentinel)break;
    $dqgs=$dqgs+1;
    $couser=$row['couser'];
    $coimg=$row['coimg'];
    $coname=$row['coname'];
    $courl=$row["courl"];
    $coecid=$row["ecid"];
    $cotext=$row['cotext'];
    $bcouser=$row['bcouser'];
    $bconame=$row['bconame'];
    $cotime=$row['cotime'];
    $ip=$row['ip'];
    $wzcid=$row['wzcid'];
    $eid=$row['eid'];
    $comaud=$row["comaud"];
    $tmp=$comaud!=1;
    if($tmp){
        $cotext="该条评论未通过审核!";
    }
    $tmp=$courl=="";
    if($tmp){
        $plzwze='';
    }else{
        $tmp='href="' . $courl;
        $plzwze=$tmp . '" style="pointer-events: all;"';
    }
    $tmp=$dqgs>$page;
if($tmp)goto L2xeWjgx1v;
goto L2xx1o;
goto L2xx1o;
goto L2xx1o;
L2xeWjgx1v:
    $dqs=$dqs+1;
    $tmp=$dqs>10;
if($tmp)goto L2xx32;
goto L2xldMhx1x;
goto L2xldMhx1x;
goto L2xldMhx1x;
goto L2xx1w;
L2xldMhx1x:
L2xx1w:
    $tmp=$scplan==1;
if($tmp)goto L2xeWjgx2z;
goto L2xldMhx2z;
goto L2xldMhx2z;
goto L2xldMhx2z;
L2xeWjgx2z:
    $tmp=$userdlzt==1;
if($tmp)goto L2xeWjgx22;
goto L2xldMhx22;
goto L2xldMhx22;
goto L2xldMhx22;
L2xeWjgx22:
    $tmp=$user_zh==$glyadmin;
if($tmp)goto L2xeWjgx24;
goto L2xldMhx24;
goto L2xldMhx24;
goto L2xldMhx24;
L2xeWjgx24:
    $tmp='<a href="JavaScript:;" class="sh-zanp-pl-del" onclick="pldels(this)" id="' . $coecid;
    $tmp4=$tmp . '" lang="yswid-';
    $tmp2=$tmp4 . $wzcidd;
    $scplanp=$tmp2 . '">删除</a>';
    $glyszd="terewsq";
goto L2xx1y;
L2xldMhx24:
    $tmp=$wzyonyzh==$zjzhq;
if($tmp)goto L2xeWjgx26;
goto L2xldMhx26;
goto L2xldMhx26;
goto L2xldMhx26;
L2xeWjgx26:
    $row=in_array($wzyonyid, $ars);
if($row)goto L2xeWjgx28;
goto L2xldMhx28;
goto L2xldMhx28;
goto L2xldMhx28;
L2xeWjgx28:
    $scplanp='';
goto L2xx1y;
L2xldMhx28:
    $tmp='<a href="JavaScript:;" class="sh-zanp-pl-del" onclick="pldels(this)" id="' . $coecid;
    $tmp4=$tmp . '" lang="yswid-';
    $tmp2=$tmp4 . $wzcidd;
    $scplanp=$tmp2 . '">删除</a>';
L2xldMhx26:
    $scplanp='';
    $glyszd="";
L2xldMhx22:
    $scplanp='';
L2xldMhx2z:
L2xx1y:
    $tmp=$bcouser=="false";
    $tmp2=(bool)$tmp;
    $tmp3=!$tmp2;
    if($tmp3){
        $tmp4=$bconame=="false";
        $tmp2=(bool)$tmp4;
    }
if($tmp2)goto L2xeWjgx2c;
goto L2xldMhx2c;
goto L2xldMhx2c;
goto L2xldMhx2c;
L2xeWjgx2c:
    $tmp='
    <li lang="' . $coname;
    $tmp4=$tmp . '" onclick="plhuifu()" id="';
    $tmp2=$tmp4 . $wzcid;
    $tmp3=$tmp2 . '" value="';
    $tmp5=$tmp3 . $couser;
    $tmp6=$tmp5 . '" data-comkzt="0">
    <div class="sh-zanp-pl-n">
    <a ';
    $tmp7=$tmp6 . $plzwze;
    $tmp8=$tmp7 . ' class="sh-zanp-pl-n-nc" onclick="hfljurl()" target="_blank">';
    $tmp9=$tmp8 . $coname;
    $tmp10=$tmp9 . '</a>：
    <span class="sh-zanp-pl-n-nr">';
    $tmp11=$tmp10 . $cotext;
    $tmp12=$tmp11 . '</span>
    </div>
    ';
    $tmp13=$tmp12 . $scplanp;
    $tmp14=$tmp13 . '
    </li>
    ';
    echo $tmp14;
}
L2xldMhx2c:
$tmp='
<li lang="' . $coname;
$tmp4=$tmp . '" onclick="plhuifu()" id="';
$tmp2=$tmp4 . $wzcid;
$tmp3=$tmp2 . '" value="';
$tmp5=$tmp3 . $couser;
$tmp6=$tmp5 . '" data-comkzt="0">
<div class="sh-zanp-pl-n">
<a ';
$tmp7=$tmp6 . $plzwze;
$tmp8=$tmp7 . ' class="sh-zanp-pl-n-nc" onclick="hfljurl()" target="_blank">';
$tmp9=$tmp8 . $coname;
$tmp10=$tmp9 . '</a>
<span>回复</span>
<span class="sh-zanp-pl-n-nc">';
$tmp11=$tmp10 . $bconame;
$tmp12=$tmp11 . '</span>：
<span class="sh-zanp-pl-n-nr">';
$tmp13=$tmp12 . $cotext;
$tmp14=$tmp13 . '</span>
</div>
';
$tmp15=$tmp14 . $scplanp;
$tmp16=$tmp15 . '
</li>
';
echo $tmp16;
goto L2xx32;
L2xldMhx33:
$tmp=9;
$tmp4=126;
$tmp2=$num2==126;
if($tmp2)goto L2xx32;
L2xx32:
$result=$conn->close();