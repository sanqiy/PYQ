<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val3[]=$val;
    $arr=$val3;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp=$user_zh=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$user_passid=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    $val["code"]="201";
    $val["msg"]="请先登录";
    $val3[]=$val;
    $arr=$val3;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$tmp=include '../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$escaped=htmlspecialchars($user_zh);
$cookieResult=addslashes($escaped);
$user_zhsg=$cookieResult;
$tmp="select * from user where username='" . $user_zhsg;
$sqls=$tmp . "'";
$row=mysqli_query($conn, $sqls);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$data2s_row=$row;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($str3))break;
    $glyzhuser=$row["username"];
    $sigin=$row["sigin"];
}
L2xxj:
$str4="select * from user where username='" . $user_zh;
$str5=$str4 . "'";
$row=mysqli_query($conn, $str5);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjwallet=$data2_row["wallet"];
$zjussig=$data2_row["ussig"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
$zid=$data2_row["id"];
$zjpassword=$data2_row["password"];
if($user_passid!=$passid){
    $escaped=time();
    $str4=$escaped+ -1;
    $cookieResult=setcookie("username", "", $str4, "/");
    $escaped=time();
    $str4=$escaped+ -1;
    $cookieResult=setcookie("passid", "", $str4, "/");
    $val["code"]="201";
    $val["msg"]="账号信息异常,请重新登录!";
    $val3[]=$val;
    $arr=$val3;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$auth_keylocation='./key.php';
$auth_keyauth='./auth.php';
$num=6865;
$row=file_exists($auth_keyauth);
if($row){
    $num=247;
}else{
    $num=221;
}
$tmp=66;
$tmp4=247;
$tmp2=$num==247;
if($tmp2)goto L2xeWjgxw;
goto L2xldMhxw;
L2xeWjgxw:
$tmp=require $auth_keyauth;
$tmp=!defined("sh_auth_state");
if($tmp){
    $val["code"]="201";
    $val["msg"]="授权验证失败,请确保文件完整且未篡改!";
    $val3[]=$val;
    $arr=$val3;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$tmp=sh_auth_state!="ok";
if($tmp)goto L2xeWjgxu;
goto L2xxv;
goto L2xxv;
L2xeWjgxu:
$val["code"]="201";
$val["msg"]="程序未授权,您的请求已被拒绝,请授权后使用!";
$val3[]=$val;
$arr=$val3;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
goto L2xxv;
L2xldMhxw:
switch($num){
    case 221:{
    $val["code"]="201";
    $val["msg"]="授权验证文件不存在或被篡改,请确保文件完整且未篡改!";
    $val3[]=$val;
    $arr=$val3;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
        break;
    }
}
L2xxv:
$str3="Y";
$Y=$str3;
$str3="m";
$m=$str3;
$str3="d";
$d=$str3;
$str3="H";
$H=$str3;
$str3="i";
$i=$str3;
$str3="s";
$s=$str3;
$str4=$Y . "-";
$str5=$str4 . $m;
$str6=$str5 . "-";
$val4=$str6 . $d;
$str7=$val4 . " ";
$val5=$str7 . $H;
$str8=$val5 . ":";
$val6=$str8 . $i;
$str9=$val6 . ":";
$val7=$str9 . $s;
$row=date($val7);
$sj=$row;
$num2=6860;
$isArray=is_array($_POST);
if($isArray){
    $num2=289;
}else{
    $num2=169;
}
switch($num2){
    case 289:{
    $lx=&$_POST['lx'];
        break;
    }
    case 169:{
        $lx=$_POST['lx'];
        break;
    }
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped2=addslashes($escaped);
$lx=$escaped2;
if($lx=="aq")goto L2xeWjgx22;
goto L2xldMhx22;
L2xeWjgx22:
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['userzh'];
}else{
    $lx=$_POST['userzh'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped2=addslashes($escaped);
$userzh=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['usermm'];
}else{
    $lx=$_POST['usermm'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped2=addslashes($escaped);
$usermm=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['userxmm'];
}else{
    $lx=$_POST['userxmm'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped2=addslashes($escaped);
$userxmm=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['userem'];
}else{
    $lx=$_POST['userem'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped2=addslashes($escaped);
$userem=$escaped2;
$tmp=$usermm!="";
$tmp2=(bool)$tmp;
if($tmp2){
    $tmp4=$userxmm!="";
    $tmp2=(bool)$tmp4;
}
if($tmp2)goto L2xeWjgx1l;
goto L2xldMhx1l;
goto L2xldMhx1l;
L2xeWjgx1l:
$tmp=$usermm==$userxmm;
if($tmp){
    $val["code"]="201";
    $val["msg"]="新密码不能与旧密码相同";
    $val3[]=$val;
    $arr=$val3;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$row=strlen($userxmm);
$tmp=$row>3;
if($tmp)goto L2xeWjgx1p;
goto L2xldMhx1p;
goto L2xldMhx1p;
L2xeWjgx1p:
$row=md5($userxmm);
$mm=$row;
$row=md5($usermm);
$tmp=$row==$zjpassword;
if($tmp)goto L2xeWjgx1r;
goto L2xldMhx1r;
goto L2xldMhx1r;
L2xeWjgx1r:
$tmp="UPDATE user SET password='" . $mm;
$tmp4=$tmp . "' WHERE id='";
$tmp2=$tmp4 . $zid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx1t;
goto L2xldMhx1t;
goto L2xldMhx1t;
L2xeWjgx1t:
$val["code"]="200";
$val["msg"]="密码修改成功";
$val3[]=$val;
$arr=$val3;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
goto L2xx21;
L2xldMhx1t:
$env=mysql_errno();
$val2["code"]="201";
$val2["msg"]=$env;
$val8[]=$val2;
$arr=$val8;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
L2xldMhx1r:
$val["code"]="201";
$val["msg"]="旧密码错误";
$val3[]=$val;
$arr=$val3;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
L2xldMhx1p:
$val["code"]="201";
$val["msg"]="密码不可低于3位数";
$val3[]=$val;
$arr=$val3;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
L2xldMhx1l:
$tmp=$userem!="";
if($tmp)goto L2xeWjgx1v;
goto L2xx21;
goto L2xx21;
L2xeWjgx1v:
$checkmail="/\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/";
$row=preg_match($checkmail, $userem);
if($row)goto L2xx1w;
goto L2xldMhx1x;
L2xldMhx1x:
$val["code"]="201";
$val["msg"]="电子邮箱格式不正确";
$val3[]=$val;
$arr=$val3;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
exit();
L2xx1w:
$tmp="UPDATE user SET email='" . $userem;
$tmp4=$tmp . "' WHERE id='";
$tmp2=$tmp4 . $zid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx2z;
goto L2xldMhx2z;
goto L2xldMhx2z;
L2xeWjgx2z:
$val["code"]="200";
$val["msg"]="邮箱修改成功";
$val3[]=$val;
$arr=$val3;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
goto L2xx21;
L2xldMhx2z:
$env=mysql_errno();
$val2["code"]="201";
$val2["msg"]=$env;
$val8[]=$val2;
$arr=$val8;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
L2xldMhx22:
L2xx21:
if($lx=="zlnc")goto L2xeWjgx4g;
goto L2xldMhx4g;
L2xeWjgx4g:
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['usernc'];
}else{
    $lx=$_POST['usernc'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped2=addslashes($escaped);
$usernc=$escaped2;
$tmp=$usernc=="";
if($tmp){
    $val["code"]="201";
    $val["msg"]="名字不可为空";
    $val3[]=$val;
    $arr=$val3;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$row=iconv_strlen($usernc, "UTF-8");
$tmp=$row>10;
if($tmp){
    $val["code"]="201";
    $val["msg"]="名字不可超过10个字符";
    $val3[]=$val;
    $arr=$val3;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$row=strpos($usernc, "匿名用户");
$tmp=$row!==false;
if($tmp){
    $val["code"]="201";
    $val["msg"]="此昵称为禁用词";
    $val3[]=$val;
    $arr=$val3;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$tmp="select * from user where name= '" . $usernc;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
$row=mysqli_num_rows($result);
$tmp=$row>0;
if($tmp)goto L2xeWjgx35;
goto L2xldMhx35;
goto L2xldMhx35;
L2xeWjgx35:
$val["code"]="201";
$val["msg"]="昵称已存在";
$val3[]=$val;
$arr=$val3;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
goto L2xx4f;
L2xldMhx35:
$tmp=$usernc!="";
if($tmp)goto L2xeWjgx37;
goto L2xldMhx37;
goto L2xldMhx37;
L2xeWjgx37:
$row=str_replace(PHP_EOL, '', $usernc);
$usernc=$row;
$tmp="UPDATE user SET name='" . $usernc;
$tmp4=$tmp . "' WHERE id='";
$tmp2=$tmp4 . $zid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx39;
goto L2xldMhx39;
goto L2xldMhx39;
L2xeWjgx39:
$tmp="select * from essay where ptpuser= '" . $user_zh;
$sqlol=$tmp . "'";
$row=mysqli_query($conn, $sqlol);
$resultol=$row;
$row=mysqli_num_rows($resultol);
$tmp=$row>0;
if($tmp)goto L2xeWjgx3b;
goto L2xldMhx3b;
goto L2xldMhx3b;
L2xeWjgx3b:
L2xx3c:
while(true){
    $row=mysqli_fetch_assoc($resultol);
    $rowo=$row;
    if(!$str3)break;
    $ncid=$rowo['id'];
    $tmp="UPDATE essay SET ptpname='" . $usernc;
    $tmp4=$tmp . "' WHERE id='";
    $tmp2=$tmp4 . $ncid;
    $sql=$tmp2 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx3c;
}
goto L2xx3a;
L2xldMhx3b:
L2xx3a:
$tmp="select * from lcke where luser= '" . $user_zh;
$sqlol=$tmp . "'";
$row=mysqli_query($conn, $sqlol);
$resultol=$row;
$row=mysqli_num_rows($resultol);
$tmp=$row>0;
if($tmp)goto L2xeWjgx3l;
goto L2xldMhx3l;
goto L2xldMhx3l;
L2xeWjgx3l:
L2xx3m:
while(true){
    $row=mysqli_fetch_assoc($resultol);
    $rowo=$row;
    if(!$str3)break;
    $ncid=$rowo['id'];
    $tmp="UPDATE lcke SET lname='" . $usernc;
    $tmp4=$tmp . "' WHERE id='";
    $tmp2=$tmp4 . $ncid;
    $sql=$tmp2 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx3m;
}
goto L2xx3k;
L2xldMhx3l:
L2xx3k:
$tmp="select * from comm where couser= '" . $user_zh;
$sqlol=$tmp . "'";
$row=mysqli_query($conn, $sqlol);
$resultol=$row;
$row=mysqli_num_rows($resultol);
$tmp=$row>0;
if($tmp)goto L2xeWjgx3v;
goto L2xldMhx3v;
goto L2xldMhx3v;
L2xeWjgx3v:
L2xx3w:
while(true){
    $row=mysqli_fetch_assoc($resultol);
    $rowo=$row;
    if(!$str3)break;
    $ncid=$rowo['id'];
    $tmp="UPDATE comm SET coname='" . $usernc;
    $tmp4=$tmp . "' WHERE id='";
    $tmp2=$tmp4 . $ncid;
    $sql=$tmp2 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx3w;
}
goto L2xx3u;
L2xldMhx3v:
L2xx3u:
$tmp="select * from message where fuser= '" . $user_zh;
$sqlol=$tmp . "'";
$row=mysqli_query($conn, $sqlol);
$resultol=$row;
$row=mysqli_num_rows($resultol);
$tmp=$row>0;
if($tmp)goto L2xeWjgx46;
goto L2xx36;
goto L2xx36;
L2xeWjgx46:
L2xx47:
while(true){
    $row=mysqli_fetch_assoc($resultol);
    $rowo=$row;
    if(!$str3)break;
    $ncid=$rowo['id'];
    $tmp="UPDATE message SET fname='" . $usernc;
    $tmp4=$tmp . "' WHERE id='";
    $tmp2=$tmp4 . $ncid;
    $sql=$tmp2 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx47;
}
goto L2xx36;
L2xldMhx39:
$env=mysql_errno();
$val2["code"]="201";
$val2["msg"]=$env;
$val8[]=$val2;
$arr=$val8;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
L2xldMhx37:
L2xx36:
$val["code"]="200";
$val["msg"]="名字更新成功";
$val3[]=$val;
$arr=$val3;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
L2xldMhx4g:
L2xx4f:
if($lx=="zlqm")goto L2xeWjgx5t;
goto L2xldMhx5t;
L2xeWjgx5t:
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['userqm'];
}else{
    $lx=$_POST['userqm'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped2=addslashes($escaped);
$userqm=$escaped2;
$row=iconv_strlen($userqm, "UTF-8");
$tmp=$row>50;
if($tmp){
    $val["code"]="201";
    $val["msg"]="签名不可超过50个字符";
    $val3[]=$val;
    $arr=$val3;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$row=str_replace(PHP_EOL, '', $userqm);
$userqm=$row;
$tmp="UPDATE user SET sign='" . $userqm;
$tmp4=$tmp . "' WHERE id='";
$tmp2=$tmp4 . $zid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx5r;
goto L2xldMhx5r;
goto L2xldMhx5r;
L2xeWjgx5r:
$val["code"]="200";
$val["msg"]="签名更新成功";
$val3[]=$val;
$arr=$val3;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
goto L2xx5s;
L2xldMhx5r:
$env=mysql_errno();
$val2["code"]="201";
$val2["msg"]=$env;
$val8[]=$val2;
$arr=$val8;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
L2xldMhx5t:
L2xx5s:
if($lx=="zlwz")goto L2xeWjgx6o;
goto L2xldMhx6o;
L2xeWjgx6o:
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST['userurl'];
}else{
    $lx=$_POST['userurl'];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped2=addslashes($escaped);
$userurl=$escaped2;
$tmp=$userurl!="";
if($tmp)goto L2xeWjgx66;
goto L2xldMhx66;
goto L2xldMhx66;
L2xeWjgx66:
$row=strpos($userurl, 'http://');
$tmp=$row!==false;
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $cookieResult=strpos($userurl, 'https://');
    $tmp4=$cookieResult!==false;
    $tmp2=(bool)$tmp4;
}
if($tmp2)goto L2xx65;
goto L2xldMhx6a;
L2xldMhx6a:
$val["code"]="201";
$val["msg"]="网址必须含有http或https";
$val3[]=$val;
$arr=$val3;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
L2xldMhx66:
L2xx65:
$row=str_replace('#$#', '&', $userurl, $count);
$userurl=$row;
$userurl=$userurl . PHP_EOL;
$row=str_replace(PHP_EOL, '', $userurl);
$userurl=$row;
$tmp="UPDATE user SET url='" . $userurl;
$tmp4=$tmp . "' WHERE id='";
$tmp2=$tmp4 . $zid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx6c;
goto L2xldMhx6c;
goto L2xldMhx6c;
L2xeWjgx6c:
$val["code"]="200";
$val["msg"]="网址更新成功";
$val3[]=$val;
$arr=$val3;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
$tmp="select * from comm where couser= '" . $user_zh;
$sqlol=$tmp . "'";
$row=mysqli_query($conn, $sqlol);
$resultol=$row;
$row=mysqli_num_rows($resultol);
$tmp=$row>0;
if($tmp)goto L2xeWjgx6e;
goto L2xx6n;
goto L2xx6n;
L2xeWjgx6e:
L2xx6f:
while(true){
    $row=mysqli_fetch_assoc($resultol);
    $rowo=$row;
    if(!$str3)break;
    $urid=$rowo['id'];
    $tmp="UPDATE comm SET courl='" . $userurl;
    $tmp4=$tmp . "' WHERE id='";
    $tmp2=$tmp4 . $urid;
    $sql=$tmp2 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx6f;
}
goto L2xx6n;
L2xldMhx6c:
$env=mysql_errno();
$val2["code"]="201";
$val2["msg"]=$env;
$val8[]=$val2;
$arr=$val8;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
L2xldMhx6o:
L2xx6n:
if($lx=="qiandao")goto L2xeWjgx7h;
goto L2xldMhx7h;
L2xeWjgx7h:
$tmp=$sigin<1;
if($tmp){
    $val["code"]="201";
    $val["msg"]="签到功能未开启";
    $val3[]=$val;
    $arr=$val3;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$row=date("Ymd");
$dqtime=$row;
$zjwalletg=$zjwallet+$sigin;
$tmp=$dqtime==$zjussig;
if($tmp){
    $val["code"]="201";
    $val["msg"]="你已经签到过了";
    $val3[]=$val;
    $arr=$val3;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$tmp="UPDATE user SET ussig = '" . $dqtime;
$tmp4=$tmp . "' WHERE username = '";
$tmp2=$tmp4 . $zjzhq;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp)goto L2xeWjgx7d;
goto L2xldMhx7d;
goto L2xldMhx7d;
L2xeWjgx7d:
$tmp="UPDATE user SET wallet = '" . $zjwalletg;
$tmp4=$tmp . "' WHERE username = '";
$tmp2=$tmp4 . $zjzhq;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp)goto L2xeWjgx7f;
goto L2xldMhx7f;
goto L2xldMhx7f;
L2xeWjgx7f:
$str="签到成功,余额+" . $sigin;
$val["code"]="200";
$val["msg"]=$str;
$val3[]=$val;
$arr=$val3;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
goto L2xx7g;
L2xldMhx7f:
$val["code"]="201";
$val["msg"]="签到失败";
$val3[]=$val;
$arr=$val3;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
L2xldMhx7d:
$val["code"]="201";
$val["msg"]="签到失败";
$val3[]=$val;
$arr=$val3;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
L2xldMhx7h:
L2xx7g:
if($lx=="kmcz")goto L2xeWjgx87;
goto L2xldMhx87;
L2xeWjgx87:
$isArray=is_array($_POST);
if($isArray){
    $lx=&$_POST["kmkh"];
}else{
    $lx=$_POST["kmkh"];
}
$escaped=htmlspecialchars($lx);
unset($lx);
$escaped2=addslashes($escaped);
$km=$escaped2;
$tmp=$km=="";
if($tmp){
    $val["code"]="201";
    $val["msg"]="请输入充值卡密";
    $val3[]=$val;
    $arr=$val3;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}else{
    $row=strlen($km);
    $tmp=$row!=32;
    if($tmp){
        $val["code"]="201";
        $val["msg"]="卡密长度不正确";
        $val3[]=$val;
        $arr=$val3;
        exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
    }
}
$sql="SELECT * FROM kami WHERE kami = ?";
$result=$conn->prepare($sql);
$stmt=$result;
$result=$stmt->bind_param("s", $km);
$result=$stmt->execute();
$result=$stmt->get_result();
$result=$result;
$tmp=$result->num_rows>0;
if($tmp)goto L2xx7x;
goto L2xldMhx7y;
L2xldMhx7y:
$val["code"]="201";
$val["msg"]="卡密不存在";
$val3[]=$val;
$arr=$val3;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
L2xx7x:
$str4="select * from kami where kami='" . $km;
$str5=$str4 . "'";
$row=mysqli_query($conn, $str5);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data3_row=$row;
$kami=$data3_row["kami"];
$auom=$data3_row["auom"];
$act=$data3_row["act"];
$ause=$data3_row["ause"];
$autm=$data3_row["autm"];
$kmid=$data3_row["id"];
$tmp=$act!=0;
if($tmp){
    $val["code"]="201";
    $val["msg"]="卡密已被使用";
    $val3[]=$val;
    $arr=$val3;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$sql=1;
$result=$conn->prepare($sql);
$stmt=$result;
$result=$stmt->bind_param("sss", $user_zh, $sj, $kmid);
$result=$stmt->execute();
$result=$result;
if($result)goto L2xx82;
goto L2xldMhx83;
L2xldMhx83:
$val["code"]="201";
$val["msg"]="卡密使用失败，请重试";
$val3[]=$val;
$arr=$val3;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
L2xx82:
$qbye=$zjwallet+$auom;
$sql="UPDATE user SET wallet=? WHERE username=?";
$result=$conn->prepare($sql);
$stmt=$result;
$result=$stmt->bind_param("ss", $qbye, $user_zh);
$result=$stmt->execute();
$result=$result;
if($result)goto L2xeWjgx85;
goto L2xldMhx85;
goto L2xldMhx85;
L2xeWjgx85:
$str="成功充值余额:" . $auom;
$str2=$str . "元";
$val["code"]="200";
$val["msg"]=$str2;
$val["wallet"]=$qbye;
$val3[]=$val;
$arr=$val3;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
goto L2xx86;
L2xldMhx85:
$val["code"]="201";
$val["msg"]="余额充值失败";
$val3[]=$val;
$arr=$val3;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
L2xldMhx87:
L2xx86:
$result=$conn->close();