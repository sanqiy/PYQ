<?php
if($_SERVER['REQUEST_METHOD']==='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$referer=$_SERVER['HTTP_REFERER'];
$num18=6864;
$tmp2=$referer=="";
if($tmp2){
    $num18=228;
}else{
    $num18=144;
}
switch($num18){
    case 144:{
    $tiaourl=$referer;
        break;
    }
    case 228:{
        $tiaourl="./index.php";
        break;
    }
}
$num19=6863;
$isArray=is_array($_GET);
if($isArray){
    $num19=144;
}else{
    $num19=144;
    $num19=2130;
}
switch($num19){
    case 1137:{
    $user=$_GET['user'];
        break;
    }
    case 144:{
        $user=&$_GET['user'];
        break;
    }
}
$timestamp=htmlspecialchars($user);
unset($user);
$hash=addslashes($timestamp);
$arcuser=$hash;
if($arcuser==""){
    $tmp2='<script language="JavaScript">;alert("非法请求");location.href="' . $tiaourl;
    exit($tmp2 . '";</script>');
}
$iteace=0;
$num20=6859;
$fileExists=is_file('./config.php');
if($fileExists){
    $num20=228;
}else{
    $num20=156;
}
switch($num20){
    case 156:{
    exit('未检测到配置文件：<span style="color: red;">config.php</span>，若您是首次使用请先进行安装,删除文件夹 <span style="color: red;">[install/]</span> 下的 <span style="color: red;">[ins.bak]</span> 文件后进行安装。若已删除请<a href="./install/">【点击安装】</a>');
        break;
    }
    case 228:{
        $tmp2=require './config.php';
        break;
    }
}
$tmp2=require './api/wz.php';
$sql="SELECT * FROM user";
$result=$conn->query($sql);
$result=$result;
$data=$val3;
$num6=6875;
$tmp2=$result->num_rows>0;
if($tmp2){
    $num6=361;
}else{
    $num6=285;
}
$tmp2=12;
$tmp3=285;
$tmp4=$num6==285;
if($tmp4)goto L2xeWjgxz;
goto L2xldMhxz;
L2xeWjgxz:
$tmp2='<script language="JavaScript">;alert("用户不存在");location.href="' . $tiaourl;
exit($tmp2 . '";</script>');
goto L2xxy;
L2xldMhxz:
$tmp2=342;
$tmp3=361;
$tmp4=$num6==361;
if($tmp4){
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!$sentinel)break;
    $isArray=is_array($row);
    if($isArray){
        $user=&$row["username"];
    }else{
        $user=$row["username"];
    }
    $timestamp=md5($user);
    unset($user);
    $hash=md5($timestamp);
    $encrypted_username=$hash;
    $sentinel=$row["username"];
    $data[$encrypted_username]=$sentinel;
}
}else{
}
L2xxy:
$num7=6876;
$fileExists=array_key_exists($arcuser, $data);
if($fileExists){
    $num7=247;
}else{
    $num7=247;
    $num7=12623;
}
switch($num7){
    case 6435:{
    $tmp2='<script language="JavaScript">;alert("此用户不存在");location.href="' . $tiaourl;
    exit($tmp2 . '";</script>');
        break;
    }
    case 247:{
        $arcuser=$data[$arcuser];
        break;
    }
}
$tmp2="select * from user where username= '" . $arcuser;
$sql=$tmp2 . "'";
$fileExists=mysqli_query($conn, $sql);
$result=$fileExists;
$num8=6874;
$fileExists=mysqli_num_rows($result);
$tmp2=$fileExists>0;
if($tmp2){
    $num8=169;
}else{
    $num8=361;
}
$tmp2=16;
$tmp3=361;
$tmp4=$num8==361;
if($tmp4)goto L2xeWjgx1i;
goto L2xldMhx1i;
L2xeWjgx1i:
$tmp2='<script language="JavaScript">;alert("此用户不存在");location.href="' . $tiaourl;
exit($tmp2 . '";</script>');
goto L2xx1h;
L2xldMhx1i:
$tmp2=16;
$tmp3=169;
$tmp4=$num8==169;
if($tmp4){
while(true){
    $fileExists=mysqli_fetch_assoc($result);
    $row=$fileExists;
    if(!$sentinel)break;
    $arcusernc=$row["name"];
    $arcuserimg=$row["img"];
    $arcuserhomeimgy=$row["homeimg"];
    $arcusersign=$row["sign"];
}
}else{
}
L2xx1h:
if($arcuserhomeimgy==-1){
    $arcuserhomeimgy=$homimg;
}
echo "<!DOCTYPE html>";
echo "
<html lang=\"zh-CN\">";
echo "
<head>";
echo "
<meta charset=\"UTF-8\">";
echo "
<title>";
echo $arcusernc;
echo "的主页 - ";
echo $name;
echo "</title>";
echo "
<!--为搜索引擎定义关键词-->";
echo "
<meta name=\"keywords\" content=\"";
echo $filterkeyw;
echo "\">";
echo "
<!--为网页定义描述内容 用于告诉搜索引擎，你网站的主要内容-->";
echo "
<meta name=\"description\" content=\"";
echo $subtitle;
echo "\">";
echo "
<meta name=\"author\" content=\"";
echo $name;
echo "\">";
echo "
<meta name=\"copyright\" content=\"";
echo $name;
echo "\">";
echo "
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" />";
echo "
<meta http-equiv=\"cache-control\" content=\"no-cache\">";
echo "
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0,minimum-scale=1.0, user-scalable=no minimal-ui\">";
echo "
<link rel=\"apple-touch-icon\" sizes=\"57x57\" href=\"";
echo $icon;
echo "\" /><!-- Standard iPhone -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"114x114\" href=\"";
echo $icon;
echo "\" /><!-- Retina iPhone -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"72x72\" href=\"";
echo $icon;
echo "\" /><!-- Standard iPad -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"144x144\" href=\"";
echo $icon;
echo "\" /><!-- Retina iPad -->";
echo "
<link rel=\"icon\" href=\"";
echo $icon;
echo "\" type=\"image/x-icon\" />";
echo "
<meta name=\"robots\" content=\"index,follow\">";
echo "
<meta name=\"format-detection\" content=\"telephone=no\">";
echo "
<meta http-equiv=\"x-rim-auto-match\" content=\"none\">";
echo "
";
if($rosdomain==1){
    echo '<meta name="referrer" content="no-referrer">';
}
echo "    <link rel=\"stylesheet\" href=\"";
echo $iconurl_url;
echo "\">";
echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"./assets/css/style.css\">";
echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"./assets/mesg/dist/css/style.css\"><!--引入弹窗对话框-->";
echo "
";
echo $scfontzt;
echo "    ";
$folderPath='./user/bobg/';
$fileExists=file_exists($folderPath);
$tmp2=!$fileExists;
if($tmp2){
    $fileExists=mkdir($folderPath, true);
}
$num9=6863;
$fileExists=file_exists("./user/bobg/bobg.jpg");
if($fileExists){
    $num9=285;
}else{
    $fileExists=file_exists("./user/bobg/bobg.png");
    if($fileExists){
        $num9=180;
    }else{
        $fileExists=file_exists("./user/bobg/bobg.jpeg");
        if($fileExists){
            $num9=156;
        }else{
            $fileExists=file_exists("./user/bobg/bobg.gif");
            if($fileExists){
                $num9=195;
            }
        }
    }
}
switch($num9){
    case 285:{
    echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.jpg);}</style>';
        break;
    }
    case 180:{
        echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.png);}</style>';
        break;
    }
    case 156:{
            echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.jpeg);}</style>';
        break;
    }
    case 195:{
                echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.gif);}</style>';
        break;
    }
}
echo "    ";
$tmp2='<style>' . $filtercucss;
$tmp3=$tmp2 . '</style>';
echo $tmp3;
echo "</head>";
echo "
<body class=\"";
$num10=6861;
if(isset($_COOKIE['dark_theme'])){
    $num10=225;
}else{
    $num10=195;
}
$tmp2=114;
$tmp3=195;
$tmp4=$num10==195;
if($tmp4)goto L2xx2d;
$tmp2=320;
$tmp3=225;
$tmp4=$num10==225;
if($tmp4)goto L2xeWjgx2f;
goto L2xldMhx2f;
L2xeWjgx2f:
$tmp2=$_COOKIE["dark_theme"]=="dark-theme";
if($tmp2)goto L2xeWjgx2c;
goto L2xx2d;
goto L2xx2d;
L2xeWjgx2c:
echo 'dark-theme';
goto L2xx2d;
L2xldMhx2f:
L2xx2d:
echo "\">";
echo "
";
if($pagepass!="")goto L2xeWjgx2p;
goto L2xldMhx2p;
L2xeWjgx2p:
if(isset($_COOKIE['pagepass']))goto L2xeWjgx2l;
goto L2xldMhx2l;
goto L2xldMhx2l;
L2xeWjgx2l:
$timestamp=md5($pagepass);
$dateStr=md5($timestamp);
$tmp2=$_COOKIE['pagepass']!=$dateStr;
if($tmp2)goto L2xeWjgx2n;
goto L2xx2o;
goto L2xx2o;
L2xeWjgx2n:
$tmp2=include './site/pagepass.php';
goto L2xx2o;
L2xldMhx2l:
$tmp2=include './site/pagepass.php';
L2xldMhx2p:
L2xx2o:
echo "    <div class=\"centent\">";
echo "
<div class=\"sh-main\">";
echo "
<div class=\"sh-main-head\">";
echo "
<div class=\"sh-main-head-top\" id=\"sh-main-head-top\">";
echo "
<!-- 左边 -->";
echo "
<div class=\"sh-main-head-top-left\">";
echo "
<div class=\"sh-main-head-top-left-s\" onclick=\"location.href='./index.php'\">";
echo "
<i class=\"iconfont icon-weibiaoti al-sxb\" id=\"top-left-1\"></i>";
echo "
</div>";
echo "
</div>";
echo "
<!-- 右边 -->";
echo "
<div class=\"sh-main-head-top-right\">";
echo "
";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"sh-main-head-img\" style=\"background-image:url(";
echo $arcuserhomeimgy;
echo ")\">";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
<div class=\"sh-main-head-headimg\">";
echo "
<div class=\"sh-main-head-headimg-tx\">";
echo "
<h4>";
echo $arcusernc;
echo "</h4>";
echo "
<a href=\"JavaScript:;\"><img src=\"./assets/img/thumbnail.svg\" data-src=\"";
echo $arcuserimg;
echo "\" alt=\"头像\"></a>";
echo "
</div>";
echo "
<div class=\"sh-main-head-headimg-qm\">";
echo "
<p>";
echo $arcusersign;
echo "</p>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"sh-homecontent\" id=\"sh-nrbk\">";
echo "
";
$tmp2=require './config.php';
$tmp2=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp2;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$prevDay='';
$prevMonth=$sentinel;
$prevYear=$sentinel;
$timebss='';
$wzsl=0;
$tmp2="SELECT * FROM essay WHERE ptpuser = '" . $arcuser;
$query=$tmp2 . "' and ptpys='1' and ptpaud='1'";
$fileExists=mysqli_query($conn, $query);
$result=$fileExists;
$ptptime_values=$val3;
while(true){
    $fileExists=mysqli_fetch_assoc($result);
    $row=$fileExists;
    if(!($sentinel))break;
    $num11=6875;
    $isArray=is_array($row);
    if($isArray){
        $num11=195;
    }else{
        $num11=180;
    }
    switch($num11){
        case 195:{
        $user=&$row['ptptime'];
            break;
        }
        case 180:{
            $user=$row['ptptime'];
            break;
        }
    }
    $timestamp=strtotime($user);
    unset($user);
    $hash=date('Y', $timestamp);
    $num12=6878;
    $isArray2=is_array($row);
    if($isArray2){
        $num12=195;
    }else{
        $num12=144;
    }
    switch($num12){
        case 195:{
        $key=&$row['ptptime'];
            break;
        }
        case 144:{
            $key=$row['ptptime'];
            break;
        }
    }
    $timestamp2=strtotime($key);
    unset($key);
    $dateStr2=date('m', $timestamp2);
    $tmp5=$hash . $dateStr2;
    $num13=6867;
    $isArray3=is_array($row);
    if($isArray3){
        $num13=285;
    }else{
        $num13=144;
    }
    switch($num13){
        case 144:{
        $key2=$row['ptptime'];
            break;
        }
        case 285:{
            $key2=&$row['ptptime'];
            break;
        }
    }
    $timestamp3=strtotime($key2);
    unset($key2);
    $dateStr3=date('d', $timestamp3);
    $tmp6=$tmp5 . $dateStr3;
    $num14=6862;
    $isArray4=is_array($row);
    if($isArray4){
        $num14=195;
    }else{
        $num14=285;
    }
    $tmp7=162;
    $tmp8=285;
    $tmp9=$num14==285;
    if($tmp9){
        $key3=$row['ptptime'];
    }else{
        $tmp10=300;
        $tmp11=195;
        $tmp12=$num14==195;
        if($tmp12){
            $key3=&$row['ptptime'];
        }
    }
    $timestamp4=strtotime($key3);
    unset($key3);
    $dateStr4=date('H', $timestamp4);
    $tmp13=$tmp6 . $dateStr4;
    $num15=6872;
    $isArray5=is_array($row);
    if($isArray5){
        $num15=228;
    }else{
        $num15=156;
    }
    $tmp14=$num15==228;
    if($tmp14){
        $key4=&$row['ptptime'];
    }else{
        $tmp15=156;
        $tmp16=$num15==156;
        if($tmp16){
            $key4=$row['ptptime'];
        }
    }
    $timestamp5=strtotime($key4);
    unset($key4);
    $dateStr5=date('i', $timestamp5);
    $tmp17=$tmp13 . $dateStr5;
    $num16=6868;
    $isArray6=is_array($row);
    if($isArray6){
        $num16=144;
    }else{
        $num16=156;
    }
    $tmp18=19;
    $tmp19=144;
    $tmp20=$num16==144;
    if($tmp20){
        $key5=&$row['ptptime'];
    }else{
        $tmp21=36;
        $tmp22=156;
        $tmp23=$num16==156;
        if($tmp23){
            $key5=$row['ptptime'];
        }
    }
    $timestamp6=strtotime($key5);
    unset($key5);
    $dateStr6=date('s', $timestamp6);
    $ptptime=$tmp17 . $dateStr6;
    $num17=6866;
    $fileExists=strpos($ptptime, '-');
    $tmp2=$fileExists!==false;
    if($tmp2){
        $num17=285;
    }else{
        $num17=156;
    }
    switch($num17){
        case 285:{
        $fileExists=strtotime($ptptime);
        $timestamp=$fileExists;
            break;
        }
        case 156:{
            $sentinel=DateTime::createFromFormat('YmdHis',$ptptime)->getTimestamp();
            $timestamp=$sentinel;
            break;
        }
    }
    $sentinel=$row;
    $ptptime_values[$timestamp]=$sentinel;
}
L2xx5a:
$fileExists=krsort($ptptime_values);
unset($tmp);
foreach($ptptime_values as $row){$tmp[]=$row;
}
$tmp24=0;
while(true){
    $fileExists=count($tmp);
    $tmp2=$tmp24<$fileExists;
    if(!($tmp2))break;
    $keys=array_keys($tmp);
    $keys=$keys[$tmp24];
    $row=$tmp[$keys];
    $wzsl=$wzsl+1;
    $tmp2=$wzsl>$essgs;
if($tmp2)goto L2xeWjgx6m;
goto L2xldMhx6m;
goto L2xldMhx6m;
goto L2xldMhx6m;
goto L2xldMhx6m;
L2xeWjgx6m:
    $wzsl=$wzsl-1;
goto L2xx8o;
goto L2xx6l;
L2xldMhx6m:
L2xx6l:
    $ptpuser=$row["ptpuser"];
    $ptpimg=$row["ptpimg"];
    $ptpname=$row["ptpname"];
    $ptptext=$row["ptptext"];
    $ptpimag=$row["ptpimag"];
    $ptpvideo=$row["ptpvideo"];
    $ptpmusic=$row["ptpmusic"];
    $ptplx=$row["ptplx"];
    $ptpdw=$row["ptpdw"];
    $ptptime=$row["ptptime"];
    $ptpgg=$row["ptpgg"];
    $ptpggurl=$row["ptpggurl"];
    $ptpys=$row["ptpys"];
    $commauth=$row["commauth"];
    $ptpaud=$row["ptpaud"];
    $ptpip=$row["ip"];
    $cid=$row["cid"];
    $wid=$row["id"];
    $fileExists=explode("|", $ptpvideo);
    $partssp=$fileExists;
    $ptpvideo=$partssp[0];
    $ptpvideofm=$partssp[1];
    $timestamp=strtotime($ptptime);
    $dateStr=date('Y', $timestamp);
    $year=$dateStr;
    $timestamp=strtotime($ptptime);
    $dateStr=date('m', $timestamp);
    $month=$dateStr;
    $timestamp=strtotime($ptptime);
    $dateStr=date('d', $timestamp);
    $day=$dateStr;
    $timestamp=strtotime($ptptime);
    $dateStr=date('H', $timestamp);
    $hour=$dateStr;
    $timestamp=strtotime($ptptime);
    $dateStr=date('i', $timestamp);
    $minute=$dateStr;
    $timestamp=strtotime($ptptime);
    $dateStr=date('s', $timestamp);
    $second=$dateStr;
    $tmp2=$year . "-";
    $tmp3=$tmp2 . $month;
    $tmp4=$tmp3 . "-";
    $givenDates=$tmp4 . $day;
    $num=6872;
    $fileExists=date('Ymd');
    $tmp2=$year . $month;
    $tmp3=$tmp2 . $day;
    $tmp4=$fileExists-$tmp3;
    $tmp25=$tmp4=='0';
    if($tmp25){
        $num=156;
    }else{
        $fileExists=date('Ymd');
        $tmp2=$year . $month;
        $tmp3=$tmp2 . $day;
        $tmp4=$fileExists-$tmp3;
        $tmp25=$tmp4=='1';
        if($tmp25){
            $num=156;
            $num=7880;
        }else{
            $num=225;
        }
    }
    switch($num){
        case 4018:{
        $day="昨天";
        $month='';
            break;
        }
        case 156:{
            $day="今天";
            $month='';
            break;
        }
        case 225:{
                $day=$day;
                $month=$month . "月";
            break;
        }
    }
    $tmp2=$year!=$prevYear;
    if($tmp2){
        $fileExists=date('Y');
        $tmp2=$fileExists!=$year;
        if($tmp2){
            $tmp2='<h2 class="sh-homecontent-timed">' . $year;
            $tmp3=$tmp2 . '<span class="sh-homecontent-timed-n">年</span></h2>';
            echo $tmp3;
        }
        $prevYear=$year;
    }
    $num2=6876;
    $tmp2=$ptpys==0;
    if($tmp2){
        $num2=144;
    }else{
        $num2=156;
    }
    switch($num2){
        case 144:{
        $wzsdbs='<i class="iconfont icon-suoding sh-homecontent-wzsbs"></i>';
            break;
        }
        case 156:{
            $wzsdbs='';
            break;
        }
    }
    $tmp2=$ptplx=="mony";
if($tmp2)goto L2xeWjgx7d;
goto L2xldMhx7d;
goto L2xldMhx7d;
goto L2xldMhx7d;
goto L2xldMhx7d;
L2xeWjgx7d:
    $tmp2=$wzsdbs=="";
if($tmp2)goto L2xeWjgx7b;
goto L2xldMhx7b;
goto L2xldMhx7b;
goto L2xldMhx7b;
goto L2xldMhx7b;
goto L2xldMhx7b;
L2xeWjgx7b:
    $wzsdbs=132424;
goto L2xx7c;
L2xldMhx7b:
    $wzsdbs='<i class="iconfont icon-hongbao sh-homecontent-wzsbs" title="红包" style="font-size: 13px;color: #ed2424;bottom: 6px;right: 20px;"></i>' . $wzsdbs;
L2xldMhx7d:
L2xx7c:
    $num3=6874;
    $tmp2=$ptplx=="img";
    if($tmp2){
        $num3=156;
    }else{
        $tmp2=$ptplx=="video";
        if($tmp2){
            $num3=225;
        }else{
            $tmp2=$ptplx=="music";
            if($tmp2){
                $num3=144;
            }else{
                $tmp2=$ptplx=="only";
                if($tmp2){
                    $num3=195;
                }else{
                    $tmp2=$ptplx=="mony";
                    if($tmp2){
                        $num3=180;
                    }
                }
            }
        }
    }
    $tmp2=15;
    $tmp3=144;
    $tmp4=$num3==144;
if($tmp4)goto L2xeWjgx81;
goto L2xldMhx81;
goto L2xldMhx81;
goto L2xldMhx81;
goto L2xldMhx81;
L2xeWjgx81:
    $fileExists=explode('|', $ptpmusic);
    $mus=$fileExists;
    $tmp2=$mus[3]=="";
    if($tmp2){
        $musimg="./assets/img/musicba.jpg";
    }else{
        $musimg=$mus[3];
    }
    $tmp2=$ptptext=="";
    if($tmp2){
        $ptpnr='';
    }else{
        $tmp2='<div class="sh-homecontent-right-lie-music-title">' . $ptptext;
        $ptpnr=$tmp2 . '</div>';
    }
    $tmp2='<div class="sh-homecontent-lie">
    <!-- 左边 -->
    <div class="sh-homecontent-left">
    <!-- 日期 -->
    <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
    $tmp3=$tmp2 . '" style="';
    $tmp4=$tmp3 . $shougbsx;
    $tmp25=$tmp4 . '">
    <span class="homecontent-left-time-h">';
    $tmp26=$tmp25 . $day;
    $tmp27=$tmp26 . '</span>
    <span class="homecontent-left-time-y">';
    $tmp28=$tmp27 . $month;
    $tmp29=$tmp28 . '</span>
    </div>
    <!-- 地址 -->
    <div class="sh-homecontent-left-time-dw">';
    $tmp30=$tmp29 . $ptpdw;
    $tmp31=$tmp30 . '</div>
    </div>
    <!-- 右边内容框架 -->
    <div class="sh-homecontent-right-wk">
    <!-- 右边内容主体 -->
    <div class="sh-homecontent-right-lie-musicwk" onclick="window.location.href = \'./view.php?cid=';
    $tmp32=$tmp31 . $cid;
    $tmp33=$tmp32 . '\';">';
    $tmp5=$tmp33 . $wzsdbs;
    $tmp34=$tmp5 . '
    ';
    $tmp35=$tmp34 . $ptpnr;
    $tmp36=$tmp35 . '
    <div class="sh-homecontent-right-lie sh-homecontent-right-lie-music">
    <!-- 音乐 -->
    <div class="homecontent-right-tw homecontent-right-tw-music">
    <!-- 图片 -->
    <div class="homecontent-right-tw-img" style="grid-template-columns: 1fr;grid-template-rows: 1fr;">
    <div class="homecontent-right-tw-img-wk homecontent-right-tw-img-wk-music"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp37=$tmp36 . $musimg;
    $tmp38=$tmp37 . '" alt=""><i class="iconfont icon-sa4f56"></i></div>
    </div>
    </div>
    <!-- 文字内容 -->
    <div class="homecontent-right-nr homecontent-right-nr-music">
    <div class="homecontent-right-nr-text homecontent-right-nr-text-music" style="color: var(--thetitle);">';
    $tmp39=$tmp38 . $mus[1];
    $tmp6=$tmp39 . '</div>
    <p class="homecontent-right-nr-text-music-p homecontent-right-nr-text-music">';
    $tmp7=$tmp6 . $mus[2];
    $tmp8=$tmp7 . '</p>
    </div>
    </div>
    </div>
    </div>
    </div>';
    $wzbank=$tmp8;
goto L2xx8z;
L2xldMhx81:
    $tmp2=198;
    $tmp3=156;
    $tmp4=$num3==156;
if($tmp4)goto L2xeWjgx86;
goto L2xldMhx86;
goto L2xldMhx86;
goto L2xldMhx86;
goto L2xldMhx86;
L2xeWjgx86:
    $fileExists=explode('(+@+)', $ptpimag);
    $imgar=$fileExists;
    $fileExists=count($imgar);
    $coun=$fileExists;
    $tmp2=$coun==1;
if($tmp2)goto L2xeWjgx7j;
goto L2xldMhx7j;
goto L2xldMhx7j;
goto L2xldMhx7j;
goto L2xldMhx7j;
goto L2xldMhx7j;
L2xeWjgx7j:
    $tmp2='<div class="sh-homecontent-lie">
    <!-- 左边 -->
    <div class="sh-homecontent-left">
    <!-- 日期 -->
    <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
    $tmp3=$tmp2 . '" style="';
    $tmp4=$tmp3 . $shougbsx;
    $tmp25=$tmp4 . '">
    <span class="homecontent-left-time-h">';
    $tmp26=$tmp25 . $day;
    $tmp27=$tmp26 . '</span>
    <span class="homecontent-left-time-y">';
    $tmp28=$tmp27 . $month;
    $tmp29=$tmp28 . '</span>
    </div>
    <!-- 地址 -->
    <div class="sh-homecontent-left-time-dw">';
    $tmp30=$tmp29 . $ptpdw;
    $tmp31=$tmp30 . '</div>
    </div>
    <!-- 右边内容框架 -->
    <div class="sh-homecontent-right-wk">
    <!-- 右边内容主体 -->
    <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
    $tmp32=$tmp31 . $cid;
    $tmp33=$tmp32 . '\';">
    <!-- 图片 -->
    <div class="homecontent-right-tw">
    <!-- 图片 -->
    <div class="homecontent-right-tw-img" style="grid-template-columns: 1fr;grid-template-rows: 1fr;">
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp5=$tmp33 . $imgar[0];
    $tmp34=$tmp5 . '" alt=""></div>
    ';
    $tmp35=$tmp34 . $wzsdbs;
    $tmp36=$tmp35 . '
    </div>
    </div>
    <!-- 文字内容 -->
    <div class="homecontent-right-nr">
    <div class="homecontent-right-nr-text">';
    $tmp37=$tmp36 . $ptptext;
    $tmp38=$tmp37 . '</div>
    <p class="homecontent-right-nr-tus">共';
    $tmp39=$tmp38 . $coun;
    $tmp6=$tmp39 . '张</p>
    </div>
    </div>
    </div>
    </div>';
    $wzbank=$tmp6;
goto L2xx8z;
L2xldMhx7j:
    $tmp2=$coun==2;
if($tmp2)goto L2xeWjgx7k;
goto L2xldMhx7k;
goto L2xldMhx7k;
goto L2xldMhx7k;
goto L2xldMhx7k;
goto L2xldMhx7k;
L2xeWjgx7k:
    $tmp2='<div class="sh-homecontent-lie">
    <!-- 左边 -->
    <div class="sh-homecontent-left">
    <!-- 日期 -->
    <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
    $tmp3=$tmp2 . '" style="';
    $tmp4=$tmp3 . $shougbsx;
    $tmp25=$tmp4 . '">
    <span class="homecontent-left-time-h">';
    $tmp26=$tmp25 . $day;
    $tmp27=$tmp26 . '</span>
    <span class="homecontent-left-time-y">';
    $tmp28=$tmp27 . $month;
    $tmp29=$tmp28 . '</span>
    </div>
    <!-- 地址 -->
    <div class="sh-homecontent-left-time-dw">';
    $tmp30=$tmp29 . $ptpdw;
    $tmp31=$tmp30 . '</div>
    </div>
    <!-- 右边内容框架 -->
    <div class="sh-homecontent-right-wk">
    <!-- 右边内容主体 -->
    <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
    $tmp32=$tmp31 . $cid;
    $tmp33=$tmp32 . '\';">
    <!-- 图片 -->
    <div class="homecontent-right-tw">
    <!-- 图片 -->
    <div class="homecontent-right-tw-img">
    <div class="homecontent-right-tw-img-wk" style="grid-row: 1 / 3;"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp5=$tmp33 . $imgar[0];
    $tmp34=$tmp5 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk" style="grid-row: 1 / 3;"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp35=$tmp34 . $imgar[1];
    $tmp36=$tmp35 . '" alt=""></div>
    ';
    $tmp37=$tmp36 . $wzsdbs;
    $tmp38=$tmp37 . '
    </div>
    </div>
    <!-- 文字内容 -->
    <div class="homecontent-right-nr">
    <div class="homecontent-right-nr-text">';
    $tmp39=$tmp38 . $ptptext;
    $tmp6=$tmp39 . '</div>
    <p class="homecontent-right-nr-tus">共';
    $tmp7=$tmp6 . $coun;
    $tmp8=$tmp7 . '张</p>
    </div>
    </div>
    </div>
    </div>';
    $wzbank=$tmp8;
goto L2xx8z;
L2xldMhx7k:
    $tmp2=$coun==3;
if($tmp2)goto L2xeWjgx7l;
goto L2xldMhx7l;
goto L2xldMhx7l;
goto L2xldMhx7l;
goto L2xldMhx7l;
goto L2xldMhx7l;
L2xeWjgx7l:
    $tmp2='<div class="sh-homecontent-lie">
    <!-- 左边 -->
    <div class="sh-homecontent-left">
    <!-- 日期 -->
    <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
    $tmp3=$tmp2 . '" style="';
    $tmp4=$tmp3 . $shougbsx;
    $tmp25=$tmp4 . '">
    <span class="homecontent-left-time-h">';
    $tmp26=$tmp25 . $day;
    $tmp27=$tmp26 . '</span>
    <span class="homecontent-left-time-y">';
    $tmp28=$tmp27 . $month;
    $tmp29=$tmp28 . '</span>
    </div>
    <!-- 地址 -->
    <div class="sh-homecontent-left-time-dw">';
    $tmp30=$tmp29 . $ptpdw;
    $tmp31=$tmp30 . '</div>
    </div>
    <!-- 右边内容框架 -->
    <div class="sh-homecontent-right-wk">
    <!-- 右边内容主体 -->
    <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
    $tmp32=$tmp31 . $cid;
    $tmp33=$tmp32 . '\';">
    <!-- 图片 -->
    <div class="homecontent-right-tw">
    <!-- 图片 -->
    <div class="homecontent-right-tw-img">
    <div class="homecontent-right-tw-img-wk" style="grid-row: 1 / 3;"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp5=$tmp33 . $imgar[0];
    $tmp34=$tmp5 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp35=$tmp34 . $imgar[1];
    $tmp36=$tmp35 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp37=$tmp36 . $imgar[2];
    $tmp38=$tmp37 . '" alt=""></div>
    ';
    $tmp39=$tmp38 . $wzsdbs;
    $tmp6=$tmp39 . '
    </div>
    </div>
    <!-- 文字内容 -->
    <div class="homecontent-right-nr">
    <div class="homecontent-right-nr-text">';
    $tmp7=$tmp6 . $ptptext;
    $tmp8=$tmp7 . '</div>
    <p class="homecontent-right-nr-tus">共';
    $tmp9=$tmp8 . $coun;
    $tmp10=$tmp9 . '张</p>
    </div>
    </div>
    </div>
    </div>';
    $wzbank=$tmp10;
goto L2xx8z;
L2xldMhx7l:
    $tmp2=$coun==4;
    $tmp4=(bool)$tmp2;
    $tmp25=!$tmp4;
    if($tmp25){
        $tmp3=$coun>=4;
        $tmp4=(bool)$tmp3;
    }
if($tmp4)goto L2xeWjgx7o;
goto L2xx8z;
goto L2xx8z;
goto L2xx8z;
goto L2xx8z;
goto L2xx8z;
L2xeWjgx7o:
    $tmp2='<div class="sh-homecontent-lie">
    <!-- 左边 -->
    <div class="sh-homecontent-left">
    <!-- 日期 -->
    <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
    $tmp3=$tmp2 . '" style="';
    $tmp4=$tmp3 . $shougbsx;
    $tmp25=$tmp4 . '">
    <span class="homecontent-left-time-h">';
    $tmp26=$tmp25 . $day;
    $tmp27=$tmp26 . '</span>
    <span class="homecontent-left-time-y">';
    $tmp28=$tmp27 . $month;
    $tmp29=$tmp28 . '</span>
    </div>
    <!-- 地址 -->
    <div class="sh-homecontent-left-time-dw">';
    $tmp30=$tmp29 . $ptpdw;
    $tmp31=$tmp30 . '</div>
    </div>
    <!-- 右边内容框架 -->
    <div class="sh-homecontent-right-wk">
    <!-- 右边内容主体 -->
    <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
    $tmp32=$tmp31 . $cid;
    $tmp33=$tmp32 . '\';">
    <!-- 图片 -->
    <div class="homecontent-right-tw">
    <!-- 图片 -->
    <div class="homecontent-right-tw-img">
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp5=$tmp33 . $imgar[0];
    $tmp34=$tmp5 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp35=$tmp34 . $imgar[1];
    $tmp36=$tmp35 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp37=$tmp36 . $imgar[2];
    $tmp38=$tmp37 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp39=$tmp38 . $imgar[3];
    $tmp6=$tmp39 . '" alt=""></div>
    ';
    $tmp7=$tmp6 . $wzsdbs;
    $tmp8=$tmp7 . '
    </div>
    </div>
    <!-- 文字内容 -->
    <div class="homecontent-right-nr">
    <div class="homecontent-right-nr-text">';
    $tmp9=$tmp8 . $ptptext;
    $tmp10=$tmp9 . '</div>
    <p class="homecontent-right-nr-tus">共';
    $tmp11=$tmp10 . $coun;
    $tmp12=$tmp11 . '张</p>
    </div>
    </div>
    </div>
    </div>';
    $wzbank=$tmp12;
goto L2xx8z;
L2xldMhx86:
    $tmp2=88;
    $tmp3=225;
    $tmp4=$num3==225;
    if($tmp4){
        $tmp2=$videoauplay==1;
        if($tmp2){
            $videobf='autoplay';
            $videobfplas='';
        }else{
            $videobf='';
            $tmp2='<i class="iconfont icon-sa4f56" id="sh-content-video-videobfb-' . $cid;
            $tmp3=$tmp2 . '" style="width: fit-content;height: fit-content;grid-column: 1;grid-row: 1;z-index: 10;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);font-size: 30px;color: #ffffff;display: flex;cursor: pointer;padding: 15px;pointer-events: none;"></i>';
            $videobfplas=$tmp3;
        }
        $tmp2='<div class="sh-homecontent-lie">
        <!-- 左边 -->
        <div class="sh-homecontent-left">
        <!-- 日期 -->
        <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
        $tmp3=$tmp2 . '" style="';
        $tmp4=$tmp3 . $shougbsx;
        $tmp25=$tmp4 . '">
        <span class="homecontent-left-time-h">';
        $tmp26=$tmp25 . $day;
        $tmp27=$tmp26 . '</span>
        <span class="homecontent-left-time-y">';
        $tmp28=$tmp27 . $month;
        $tmp29=$tmp28 . '</span>
        </div>
        <!-- 地址 -->
        <div class="sh-homecontent-left-time-dw">';
        $tmp30=$tmp29 . $ptpdw;
        $tmp31=$tmp30 . '</div>
        </div>
        <!-- 右边内容框架 -->
        <div class="sh-homecontent-right-wk">
        <!-- 右边内容主体 -->
        <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
        $tmp32=$tmp31 . $cid;
        $tmp33=$tmp32 . '\';">
        <!-- 视频 -->
        <div class="homecontent-right-tw">
        <!-- 视频 -->
        <div class="homecontent-right-tw-video">
        <video class="homecontent-right-tw-videoau" poster="';
        $tmp5=$tmp33 . $ptpvideofm;
        $tmp34=$tmp5 . '" src="';
        $tmp35=$tmp34 . $ptpvideo;
        $tmp36=$tmp35 . '" playsinline="" webkit-playsinline="" preload="metadata" ';
        $tmp37=$tmp36 . $videobf;
        $tmp38=$tmp37 . ' muted="" loop=""></video>
        ';
        $tmp39=$tmp38 . $videobfplas;
        $tmp6=$tmp39 . '
        <span class="sh-video-span" style="left: 4px;bottom: 4px;">MP4</span>
        ';
        $tmp7=$tmp6 . $wzsdbs;
        $tmp8=$tmp7 . '
        </div>
        </div>
        <!-- 文字内容 -->
        <div class="homecontent-right-nr">
        <div class="homecontent-right-nr-text">';
        $tmp9=$tmp8 . $ptptext;
        $tmp10=$tmp9 . '</div>
        </div>
        </div>
        </div>
        </div>';
        $wzbank=$tmp10;
    }else{
        $tmp2=165;
        $tmp3=195;
        $tmp4=$num3==195;
        if($tmp4){
            $tmp2='<div class="sh-homecontent-lie">
            <!-- 左边 -->
            <div class="sh-homecontent-left">
            <!-- 日期 -->
            <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
            $tmp3=165;
            $tmp4=165 . $shougbsx;
            $tmp25=$tmp4 . '">
            <span class="homecontent-left-time-h">';
            $tmp26=$tmp25 . $day;
            $tmp27=$tmp26 . '</span>
            <span class="homecontent-left-time-y">';
            $tmp28=$tmp27 . $month;
            $tmp29=$tmp28 . '</span>
            </div>
            <!-- 地址 -->
            <div class="sh-homecontent-left-time-dw">';
            $tmp30=$tmp29 . $ptpdw;
            $tmp31=$tmp30 . '</div>
            </div>
            <div class="sh-homecontent-right-wk">
            <!-- 右边内容主体 -->
            <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
            $tmp32=$tmp31 . $cid;
            $tmp33=$tmp32 . '\';">
            <!-- 仅文字 -->
            <!-- 文字内容 -->
            <div class="homecontent-right-nr" style="min-height: 10px;background: var(--fgxys);position:relative;">
            <div class="homecontent-right-nr-text homecontent-right-nr-textjw" style="margin: 10px;">';
            $tmp5=$tmp33 . $ptptext;
            $tmp34=$tmp5 . '</div>
            ';
            $tmp35=$tmp34 . $wzsdbs;
            $tmp36=$tmp35 . '
            </div>
            </div>
            </div>
            </div>';
            $wzbank=$tmp36;
        }else{
            switch($num3){
                case 180:{
                $tmp2='<div class="sh-homecontent-lie">
                <!-- 左边 -->
                <div class="sh-homecontent-left">
                <!-- 日期 -->
                <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
                $tmp3=240;
                $tmp4=240 . $shougbsx;
                $tmp25=$tmp4 . '">
                <span class="homecontent-left-time-h">';
                $tmp26=$tmp25 . $day;
                $tmp27=$tmp26 . '</span>
                <span class="homecontent-left-time-y">';
                $tmp28=$tmp27 . $month;
                $tmp29=$tmp28 . '</span>
                </div>
                <!-- 地址 -->
                <div class="sh-homecontent-left-time-dw">';
                $tmp30=$tmp29 . $ptpdw;
                $tmp31=$tmp30 . '</div>
                </div>
                <div class="sh-homecontent-right-wk">
                <!-- 右边内容主体 -->
                <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
                $tmp32=$tmp31 . $cid;
                $tmp33=$tmp32 . '\';">
                <!-- 仅文字 -->
                <!-- 文字内容 -->
                <div class="homecontent-right-nr" style="min-height: 10px;background: var(--fgxys);position:relative;">
                <div class="homecontent-right-nr-text homecontent-right-nr-textjw" style="margin: 10px;">';
                $tmp5=$tmp33 . $ptptext;
                $tmp34=$tmp5 . '</div>
                ';
                $tmp35=$tmp34 . $wzsdbs;
                $tmp36=$tmp35 . '
                </div>
                </div>
                </div>
                </div>';
                $wzbank=$tmp36;
                    break;
                }
            }
L2xx8z:
        }
    }
    echo $wzbank;
    $tmp24=$tmp24+1;
}
L2xxcn:
L2xx8o:
echo "</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"footer\">";
echo "
<div class=\"footer-text\" id=\"footer-text-zt\" onclick=\"hqgd()\">加载更多..</div>";
echo "
<p style=\"display:none\" id=\"footer-text-hqgd\">";
echo $wzsl;
echo "</p>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<!--右下角悬浮菜单-->";
echo "
<div class=\"sh-menu\" id=\"sh-menu\">";
echo "
";
$darktheme=$_COOKIE["dark_theme"];
$num4=6868;
$tmp2=$darktheme=="dark-theme";
if($tmp2){
    $num4=169;
}else{
    $num4=156;
}
switch($num4){
    case 169:{
    echo '<div class="sh-menu-k" id="day" lang="0"><i class="iconfont icon-yueliang" id="day-i"></i></div>';
        break;
    }
    case 156:{
        echo '<div class="sh-menu-k" id="day" lang="1"><i class="iconfont icon-ai250" id="day-i"></i></div>';
        break;
    }
}
echo "    <div class=\"sh-menu-k\" id=\"scrtop\" onclick=\"scrollToTop()\"><i class=\"iconfont icon-weibiaoti-x-copy\"></i></div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
$num5=6866;
$tmp2=$musplay==0;
if($tmp2){
    $num5=228;
}else{
    $tmp2=$musplay==1;
    if($tmp2){
        $num5=156;
    }
}
switch($num5){
    case 228:{
    $tmp2=include './site/musicbk.php';
        break;
    }
    case 156:{
        $tmp2=include './site/musicbkcla.php';
        break;
    }
}
echo "";
echo "
";
echo "
";
echo auth_ts;
echo "<div class=\"sh-copyright\">";
echo "
<span class=\"sh-copyright-banquan\" id=\"sh-copyright-banquan\">";
echo $copyright;
echo "</span>&nbsp;";
echo "
";
if($beian!=""){
    $fileExists=html_entity_decode($beian);
    $tmp2='<span class="sh-copyright-banquan">' . $fileExists;
    $tmp3=$tmp2 . '</span>';
    echo $tmp3;
}
echo "</div>";
echo "
";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<script type=\"text/javascript\" src=\"./assets/js/home.js\"></script>";
echo "
<script type=\"text/javascript\" src=\"./assets/js/jquery.min.js\"></script>";
echo "
<script type=\"text/javascript\" src=\"./assets/mesg/dist/js/sh-noytf.js\"></script>";
echo "
<script type=\"text/javascript\">";
echo "
//删除重复年";
echo "
var timedElements = document.getElementsByClassName('sh-homecontent-timed');";
echo "
var timedElementsArray = Array.from(timedElements);";
echo "
";
echo "
timedElementsArray.forEach((element, index) => {";
echo "
if (index > 0 && element.innerHTML === timedElementsArray[index - 1].innerHTML) {";
echo "
element.remove();";
echo "
}";
echo "
});";
echo "
//隐藏重复日期";
echo "
var elements = document.getElementsByClassName('sh-homecontent-left-time');";
echo "
var langValues = [];";
echo "
var duplicateIndexes = [];";
echo "
for (var i = 0; i < elements.length; i++) {";
echo "
var lang = elements[i].lang;";
echo "
";
echo "
if (langValues.includes(lang)) {";
echo "
duplicateIndexes.push(i);";
echo "
} else {";
echo "
langValues.push(lang);";
echo "
}";
echo "
}";
echo "
for (var j = 0; j < elements.length; j++) {";
echo "
if (duplicateIndexes.includes(j)) {";
echo "
elements[j].style.display = 'none';";
echo "
elements[j].lang = '';";
echo "
}";
echo "
}";
echo "
";
echo "
//设置每个不同月日的顶部间距";
echo "
// 获取所有class为sh-homecontent-left-time的元素";
echo "
var elements = document.querySelectorAll('.sh-homecontent-left-time');";
echo "
// 遍历元素";
echo "
for (var i = 0; i < elements.length; i++) {";
echo "
// 判断元素是否有display: none;属性";
echo "
if (window.getComputedStyle(elements[i]).display !== 'none') {";
echo "
// 给父元素的父元素添加属性 margin-top: 20px;";
echo "
elements[i].parentNode.parentNode.style.marginTop = '25px';";
echo "
}";
echo "
}";
echo "
";
echo "
//恢复时间颜色";
echo "
document.querySelectorAll(\".homecontent-left-time-h, .homecontent-left-time-y\").forEach(function(element) {";
echo "
element.style.color = \"var(--textqh)\";";
echo "
});";
echo "
</script>";
echo "
";
$tmp2='<script type="text/javascript">' . $filtercujs;
$tmp3=$tmp2 . '</script>';
echo $tmp3;
echo "</body>";
echo "
</html>";