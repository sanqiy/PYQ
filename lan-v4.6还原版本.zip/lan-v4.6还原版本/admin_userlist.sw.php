<?php
$iteace=1;
$pos=is_file('../config.php');
if($pos){
    $tmp=include '../config.php';
}
$tmp=include '../api/wz.php';
if($userdlzt==0){
    $pos=header('location: ./login.php');
    exit();
}
$num8=5851;
$tmp=$user_zh==$glyadmin;
if($tmp){
    $num8=120;
}else{
    $num8=240;
}
$tmp=10;
$tmp2=120;
$tmp3=$num8==120;
if($tmp3)goto L2xeWjgxe;
goto L2xldMhxe;
L2xeWjgxe:
$tmp=$user_passid!=$passid;
if($tmp)goto L2xeWjgxc;
goto L2xxd;
goto L2xxd;
L2xeWjgxc:
exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="./login.php";</script>;');
goto L2xxd;
L2xldMhxe:
switch($num8){
    case 240:{
    exit('<script language="JavaScript">;alert("没有权限!");location.href="../index.php";</script>;');
        break;
    }
}
L2xxd:
echo "<!doctype html>";
echo "
<html lang=\"en\">";
echo "
<head>";
echo "
<meta charset=\"utf-8\">";
echo "
<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0\">";
echo "
<title>用户列表 - ";
echo $name;
echo "</title>";
echo "
<meta name=\"keywords\" content=\"";
echo $filterkeyw;
echo "\">";
echo "
<meta name=\"description\" content=\"";
echo $subtitle;
echo "\">";
echo "
<meta name=\"author\" content=\"";
echo $name;
echo "\">";
echo "
<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"";
$num9=5849;
$pos=strpos($icon, 'http');
$tmp=$pos!==false;
if($tmp){
    $num9=270;
}else{
    $num9=64;
}
switch($num9){
    case 64:{
    $tmp='.' . $icon;
    echo $tmp;
        break;
    }
    case 270:{
        echo $icon;
        break;
    }
}
echo "\">";
echo "
<link rel=\"stylesheet\" href=\"assets/css/css2.css\">";
echo "
<link rel=\"stylesheet\" id=\"css-main\" href=\"assets/css/oneui.min.css\">";
echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"../assets/mesg/dist/css/style.css\">";
echo "
</head>";
echo "
<body>";
echo "
<div id=\"page-container\" class=\"sidebar-o sidebar-dark page-header-fixed main-content-narrow\">";
echo "
<nav id=\"sidebar\" aria-label=\"Main Navigation\">";
echo "
<!-- Side Header -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Logo -->";
echo "
<a class=\"fw-semibold text-dual\" href=\"index.php\">";
echo "
<span class=\"smini-visible\">";
echo "
<i class=\"fa fa-circle-notch text-primary\"></i>";
echo "
</span>";
echo "
<span class=\"smini-hide fs-5 tracking-wider\">后台管理</span>";
echo "
</a>";
echo "
<!-- END Logo -->";
echo "
";
echo "
<!-- Extra -->";
echo "
<div>";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" data-toggle=\"layout\" data-action=\"dark_mode_toggle\">";
echo "
<i class=\"far fa-moon\"></i>";
echo "
</button>";
echo "
<!-- END Dark Mode -->";
echo "
";
echo "
<!-- Options -->";
echo "
<div class=\"dropdown d-inline-block ms-1\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" id=\"sidebar-themes-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<i class=\"far fa-circle\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-end fs-sm smini-hide border-0\" aria-labelledby=\"sidebar-themes-dropdown\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"default\" href=\"#\">";
echo "
<span>默认</span>";
echo "
<i class=\"fa fa-circle text-default\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/amethyst.min.css\" href=\"#\">";
echo "
<span>紫色</span>";
echo "
<i class=\"fa fa-circle text-amethyst\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/city.min.css\" href=\"#\">";
echo "
<span>红色</span>";
echo "
<i class=\"fa fa-circle text-city\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/flat.min.css\" href=\"#\">";
echo "
<span>青色</span>";
echo "
<i class=\"fa fa-circle text-flat\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/modern.min.css\" href=\"#\">";
echo "
<span>蓝色</span>";
echo "
<i class=\"fa fa-circle text-modern\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/smooth.min.css\" href=\"#\">";
echo "
<span>粉色</span>";
echo "
<i class=\"fa fa-circle text-smooth\"></i>";
echo "
</a>";
echo "
<!-- END Color Themes -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_light\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 黑色</span>";
echo "
</a>";
echo "
<!-- END Sidebar Styles -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_light\" href=\"javascript:void(0)\">";
echo "
<span>导航 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>导航 黑色</span>";
echo "
</a>";
echo "
<!-- END Header Styles -->";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Options -->";
echo "
<a class=\"d-lg-none btn btn-sm btn-alt-secondary ms-1\" data-toggle=\"layout\" data-action=\"sidebar_close\" href=\"javascript:void(0)\">";
echo "
<i class=\"fa fa-fw fa-times\"></i>";
echo "
</a>";
echo "
<!-- END Close Sidebar -->";
echo "
</div>";
echo "
<!-- END Extra -->";
echo "
</div>";
echo "
<!-- END Side Header -->";
echo "
";
echo "
<!-- Sidebar Scrolling -->";
echo "
<div class=\"js-sidebar-scroll\">";
echo "
<!-- Side Navigation -->";
echo "
<div class=\"content-side\">";
echo "
<ul class=\"nav-main\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./index.php\">";
echo "
<i class=\"nav-main-link-icon si si-speedometer\"></i>";
echo "
<span class=\"nav-main-link-name\">后台首页</span>";
echo "
</a>";
echo "
</li>";
echo "
";
echo "
<li class=\"nav-main-heading\">设置</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-energy\"></i>";
echo "
<span class=\"nav-main-link-name\">网站设置</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./basic.php\">";
echo "
<span class=\"nav-main-link-name\">基础设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./authority.php\">";
echo "
<span class=\"nav-main-link-name\">权限设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./imgset.php\">";
echo "
<span class=\"nav-main-link-name\">图像设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./emailset.php\">";
echo "
<span class=\"nav-main-link-name\">邮箱设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./calis.php\">";
echo "
<span class=\"nav-main-link-name\">卡密管理</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item   open\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-users\"></i>";
echo "
<span class=\"nav-main-link-name\">用户管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link  active\" href=\"./userlist.php\">";
echo "
<span class=\"nav-main-link-name\">用户列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-book-open\"></i>";
echo "
<span class=\"nav-main-link-name\">文章管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditesli.php\">";
echo "
<span class=\"nav-main-link-name\">文章列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditessh.php\">";
echo "
<span class=\"nav-main-link-name\">审核文章</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-speech\"></i>";
echo "
<span class=\"nav-main-link-name\">评论管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditcoli.php\">";
echo "
<span class=\"nav-main-link-name\">评论列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditcosh.php\">";
echo "
<span class=\"nav-main-link-name\">审核评论</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-paper-clip\"></i>";
echo "
<span class=\"nav-main-link-name\">友链管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./linkset.php\">";
echo "
<span class=\"nav-main-link-name\">友链列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
</ul>";
echo "
</div>";
echo "
<!-- END Side Navigation -->";
echo "
</div>";
echo "
<!-- END Sidebar Scrolling -->";
echo "
</nav>";
echo "
<!-- END Sidebar -->";
echo "
";
echo "
<!-- Header -->";
echo "
<header id=\"page-header\">";
echo "
<!-- Header Content -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Left Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- Toggle Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-lg-none\" data-toggle=\"layout\" data-action=\"sidebar_toggle\">";
echo "
<i class=\"fa fa-fw fa-bars\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Sidebar -->";
echo "
";
echo "
<!-- Toggle Mini Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-none d-lg-inline-block\" data-toggle=\"layout\" data-action=\"sidebar_mini_toggle\">";
echo "
<i class=\"fa fa-fw fa-ellipsis-v\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Mini Sidebar -->";
echo "
";
echo "
<!-- Open Search Section (visible on smaller screens) -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
";
echo "
<!-- END Open Search Section -->";
echo "
";
echo "
<!-- Search Form (visible on larger screens) -->";
echo "
";
echo "
<!-- END Search Form -->";
echo "
</div>";
echo "
<!-- END Left Section -->";
echo "
";
echo "
<!-- Right Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- User Dropdown -->";
echo "
<div class=\"dropdown d-inline-block ms-2\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary d-flex align-items-center\" id=\"page-header-user-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<img class=\"rounded-circle\" src=\"";
$num=5836;
$pos=strpos($user_img, 'http');
$tmp=$pos!==false;
if($tmp){
    $num=180;
}else{
    $num=180;
    $num=10548;
}
switch($num){
    case 180:{
    echo $user_img;
        break;
    }
    case 5364:{
        $tmp='.' . $user_img;
        echo $tmp;
        break;
    }
}
echo "\" alt=\"Header Avatar\" style=\"width: 21px;\">";
echo "
<span class=\"d-none d-sm-inline-block ms-2\">";
echo $user_name;
echo "</span>";
echo "
<i class=\"fa fa-fw fa-angle-down d-none d-sm-inline-block opacity-50 ms-1 mt-1\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-md dropdown-menu-end p-0 border-0\" aria-labelledby=\"page-header-user-dropdown\">";
echo "
<div class=\"p-3 text-center bg-body-light border-bottom rounded-top\">";
echo "
<img class=\"img-avatar img-avatar48 img-avatar-thumb\" src=\"";
$num2=5848;
$pos=strpos($user_img, 'http');
$tmp=$pos!==false;
if($tmp){
    $num2=128;
}else{
    $num2=128;
    $num2=8760;
}
switch($num2){
    case 128:{
    echo $user_img;
        break;
    }
    case 4444:{
        $tmp='.' . $user_img;
        echo $tmp;
        break;
    }
}
echo "\" alt=\"\">";
echo "
<p class=\"mt-2 mb-0 fw-medium\">";
echo $user_name;
echo "</p>";
echo "
<!--p class=\"mb-0 text-muted fs-sm fw-medium\">介绍</p-->";
echo "
</div>";
echo "
<div role=\"separator\" class=\"dropdown-divider m-0\"></div>";
echo "
<div class=\"p-2\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"../\">";
echo "
<span class=\"fs-sm fw-medium\">返回前台</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"JavaScript:;\" onclick=\"logut()\">";
echo "
<span class=\"fs-sm fw-medium\">退出登录</span>";
echo "
</a>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
<!-- END User Dropdown -->";
echo "
";
echo "
<!-- Notifications Dropdown -->";
echo "
";
echo "
<!-- END Notifications Dropdown -->";
echo "
";
echo "
<!-- Toggle Side Overlay -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
<!-- END Toggle Side Overlay -->";
echo "
</div>";
echo "
<!-- END Right Section -->";
echo "
</div>";
echo "
<!-- END Header Content -->";
echo "
";
echo "
<!-- Header Loader -->";
echo "
<!-- Please check out the Loaders page under Components category to see examples of showing/hiding it -->";
echo "
<div id=\"page-header-loader\" class=\"overlay-header bg-body-extra-light\">";
echo "
<div class=\"content-header\">";
echo "
<div class=\"w-100 text-center\">";
echo "
<i class=\"fa fa-fw fa-circle-notch fa-spin\"></i>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Header Loader -->";
echo "
</header>";
echo "
<!-- END Header -->";
echo "
";
echo "
<!-- Main Container -->";
echo "
<main id=\"main-container\">";
echo "
";
echo "
<!-- Page Content -->";
echo "
<div class=\"content\">";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\">用户列表</h3>";
echo "
<div class=\"block-options space-x-1\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-success\" onclick=\"idsx()\">解封</button>";
echo "
<a type=\"button\" class=\"btn btn-sm btn-warning\" onclick=\"idsxf()\">封禁</a>";
echo "
<button id=\"so-search\" type=\"button\" class=\"btn btn-sm btn-alt-secondary js-class-toggle-enabled\" data-toggle=\"class-toggle\" data-target=\"#one-dashboard-search-orders\" data-class=\"d-none\">";
echo "
<i class=\"fa fa-search\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown d-inline-block\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" id=\"dropdown-recent-orders-filters\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<i class=\"fa fa-fw fa-flask\"></i>";
echo "
Filters";
echo "
<i class=\"fa fa-angle-down ms-1\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-md dropdown-menu-end fs-sm\" aria-labelledby=\"dropdown-recent-orders-filters\" style=\"\">";
echo "
<a class=\"dropdown-item fw-medium d-flex align-items-center justify-content-between\" href=\"?type=0\">正常用户";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium d-flex align-items-center justify-content-between\" href=\"?type=-1\">封禁用户";
echo "
</a>";
echo "
";
echo "
";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
<div id=\"one-dashboard-search-orders\" class=\"block-content border-bottom d-none\">";
echo "
<!-- Search Form -->";
echo "
<form action=\"be_pages_dashboard.php\" method=\"POST\" onsubmit=\"return false;\">";
echo "
<div class=\"push\">";
echo "
<div class=\"input-group\">";
echo "
<input type=\"text\" class=\"form-control form-control-alt\" id=\"one-ecom-orders-search\" name=\"one-ecom-orders-search\" placeholder=\"Search all orders..\">";
echo "
<span class=\"input-group-text bg-body border-0\">";
echo "
<i class=\"fa fa-search\"></i>";
echo "
</span>";
echo "
</div>";
echo "
</div>";
echo "
</form>";
echo "
<!-- END Search Form -->";
echo "
</div>";
echo "
<div class=\"block-content block-content-full\">";
echo "
<!-- Recent Orders Table -->";
echo "
<div class=\"table-responsive\">";
echo "
<table class=\"table table-hover table-vcenter\">";
echo "
<thead>";
echo "
<tr>";
echo "
<th class=\"text-center\" style=\"width: 70px;\">";
echo "
<div class=\"form-check d-inline-block\">";
echo "
<input class=\"form-check-input\" type=\"checkbox\" value=\"\" id=\"check-all\" name=\"check-all\">";
echo "
<label class=\"form-check-label\" for=\"check-all\"></label>";
echo "
</div>";
echo "
</th>";
echo "
<th>ID</th>";
echo "
<th>头像</th>";
echo "
<th>账号</th>";
echo "
<th>邮箱</th>";
echo "
<th>余额</th>";
echo "
<th>昵称</th>";
echo "
<th>状态</th>";
echo "
<th>注册时间</th>";
echo "
<th>注册IP</th>";
echo "
<th>最后时间</th>";
echo "
<th>最后IP</th>";
echo "
<th>操作</th>";
echo "
</tr>";
echo "
</thead>";
echo "
<tbody class=\"fs-sm\">";
echo "
";
$num3=5838;
$isArray=is_array($_GET);
if($isArray){
    $page=&$_GET['page'];
}else{
    $page=$_GET['page'];
}
$escaped=htmlspecialchars($page);
unset($page);
$escaped2=addslashes($escaped);
$tmp=$escaped2!="";
if($tmp){
    $num3=120;
}else{
    $num3=120;
    $num3=11320;
}
switch($num3){
    case 120:{
    $page=$_GET['page'];
        break;
    }
    case 5720:{
        $page=1;
        break;
    }
}
$perPage=50;
$tmp=$page-1;
$offset=$tmp*50;
$num4=5841;
$isArray=is_array($_GET);
if($isArray){
    $num4=288;
}else{
    $num4=216;
}
switch($num4){
    case 288:{
    $page=&$_GET["type"];
        break;
    }
    case 216:{
        $page=$_GET["type"];
        break;
    }
}
$escaped=htmlspecialchars($page);
unset($page);
$escaped2=addslashes($escaped);
$type=$escaped2;
$num5=5839;
$isArray=is_array($_GET);
if($isArray){
    $num5=120;
}else{
    $num5=240;
}
switch($num5){
    case 240:{
    $page=$_GET["keyword"];
        break;
    }
    case 120:{
        $page=&$_GET["keyword"];
        break;
    }
}
$escaped=htmlspecialchars($page);
unset($page);
$escaped2=addslashes($escaped);
$keyword=$escaped2;
$num6=5833;
$tmp=$type=="";
if($tmp){
    $num6=270;
}else{
    $tmp=$type=="0";
    if($tmp){
        $num6=256;
    }else{
        $tmp=$type=="-1";
        if($tmp){
            $num6=120;
        }
    }
}
switch($num6){
    case 120:{
    $tmp="SELECT * FROM user WHERE ban != '0' order by id desc LIMIT " . 50;
    $tmp2=$tmp . " OFFSET ";
    $sql=$tmp2 . $offset;
        break;
    }
    case 256:{
        $tmp="SELECT * FROM user WHERE ban = '0' order by id desc LIMIT " . 50;
        $tmp2=$tmp . " OFFSET ";
        $sql=$tmp2 . $offset;
        break;
    }
    case 270:{
            $tmp="SELECT * FROM user order by id desc LIMIT " . 50;
            $tmp2=$tmp . " OFFSET ";
            $sql=$tmp2 . $offset;
        break;
    }
}
if($keyword!=""){
    $tmp="SELECT * FROM user WHERE username LIKE '%" . $keyword;
    $tmp2=$tmp . "%' OR email LIKE '%";
    $tmp3=$tmp2 . $keyword;
    $sql=$tmp3 . "%' ORDER BY id DESC";
}
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0){
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!$cond)break;
    $user2_id=$row["id"];
    $user2_username=$row["username"];
    $user2_email=$row["email"];
    $user1_zjwallet=$row["wallet"];
    $user1_zjussig=$row["ussig"];
    $user2_name=$row["name"];
    $user2_img=$row["img"];
    $user2_url=$row["url"];
    $user2_homeimg=$row["homeimg"];
    $user2_sign=$row["sign"];
    $user2_essqx=$row["essqx"];
    $user2_esseam=$row["esseam"];
    $user2_regtime=$row["regtime"];
    $user2_regip=$row["regip"];
    $user2_logtime=$row["logtime"];
    $user2_logip=$row["logip"];
    $user2_ban=$row["ban"];
    $user2_bantime=$row["bantime"];
    $tmp=$user2_img=="./assets/img/tx.png";
    if($tmp){
        $user2_img="../../assets/img/tx.png";
    }else{
        $pos=strpos($user2_img, './user/headimg/');
        $tmp=$pos!==false;
        if($tmp){
            $user2_img="../." . $user2_img;
        }
    }
    $tmp=$user2_ban==-1;
    if($tmp){
        $zhfjzt=44336;
    }else{
        $zhfjzt=15377;
    }
    $tmp='<tr>
    <td class="text-center">
    <div class="form-check d-inline-block">
    <input class="form-check-input" type="checkbox" name="ids[]" value="' . $user2_id;
    $tmp2=$tmp . '" id="ids-';
    $tmp3=$tmp2 . $user2_id;
    $tmp4=$tmp3 . '">
    <label class="form-check-label" for="ids-';
    $tmp5=$tmp4 . $user2_id;
    $tmp6=$tmp5 . '"></label>
    </div>
    </td>
    <td>';
    $tmp7=$tmp6 . $user2_id;
    $tmp8=$tmp7 . '</td>
    <td><img class="img-avatar img-avatar-48 m-r-10" src="';
    $tmp9=$tmp8 . $user2_img;
    $tmp10=$tmp9 . '"></td>
    <td>';
    $tmp11=$tmp10 . $user2_username;
    $tmp12=$tmp11 . '</td>
    <td>';
    $tmp13=$tmp12 . $user2_email;
    $tmp14=$tmp13 . '</td>
    <td>';
    $tmp15=$tmp14 . $user1_zjwallet;
    $tmp16=$tmp15 . '</td>
    <td>';
    $tmp17=$tmp16 . $user2_name;
    $tmp18=$tmp17 . '</td>
    <td>';
    $tmp19=$tmp18 . $zhfjzt;
    $tmp20=$tmp19 . '</td>
    <td>';
    $tmp21=$tmp20 . $user2_regtime;
    $tmp22=$tmp21 . '</td>
    <td>';
    $tmp23=$tmp22 . $user2_regip;
    $tmp24=$tmp23 . '</td>
    <td>';
    $tmp25=$tmp24 . $user2_logtime;
    $tmp26=$tmp25 . '</td>
    <td>';
    $tmp27=$tmp26 . $user2_logip;
    $tmp28=$tmp27 . '</td>
    <td>
    <div class="btn-group">
    <a class="btn btn-sm btn-success" style="flex-shrink: 0;" href="?useracc=';
    $tmp29=$tmp28 . $user2_username;
    $tmp30=$tmp29 . '" target-form="ids"><i class="mdi mdi-account-edit-outline"></i> 编辑</a>
    </div>
    </td>
    </tr>';
    echo $tmp30;
}
}else{
}
L2xx29:
echo "                      ";
echo "
</tbody>";
echo "
</table>";
echo "
</div>";
echo "
<ul class=\"pagination\" style=\"margin-top:10px;\">";
echo "
";
$cond='Select count(*) as AllNum from user';
$Query=$cond;
$pos=mysqli_query($conn, $Query);
$aus=$pos;
$pos=mysqli_fetch_assoc($aus);
$bus=$pos;
$tmp='<div class="fixed-table-pagination callout" style="width: 100%;display: flex;justify-content: space-between;">
<div class="float-left pagination-detail" style="margin-bottom: 10px;">
<span class="pagination-info">
每页显示' . $perPage;
$tmp2=$tmp . '位用户，共';
$tmp3=$tmp2 . $bus['AllNum'];
$tmp4=$tmp3 . '位用户
</span>
</div>
<div class="float-right pagination">';
echo $tmp4;
$result=$conn->query("SELECT COUNT(*) AS total FROM user");
$row=$result->fetch_assoc();
$totalRecords=$row;
$totalRecords=$totalRecords['total'];
$val=$totalRecords/$perPage;
$pos=ceil($val);
$maxPages=$pos;
if($maxPages>1)goto L2xeWjgx34;
goto L2xldMhx34;
L2xeWjgx34:
$tmp=$page>1;
if($tmp){
    echo '<li class="page-item"><a class="page-link" aria-label="首页" href="userlist.php?page=1">首页</a></li>';
    $tmp=$page-1;
    $tmp2='<li><a class="page-link" aria-label="上一页" href="userlist.php?page=' . $tmp;
    $tmp3=$tmp2 . '">‹</a></li>';
    echo $tmp3;
}
$val=$page-1;
$pos=max($val);
$start=$pos;
$val=$page+1;
$pos=min($val, $maxPages);
$end=$pos;
$tmp=$start>1;
if($tmp){
    echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
}
$cond=$start;
$i=$cond;
while(true){
    $tmp=$i<=$end;
    if(!$tmp)break;
    $tmp=$i==$page;
    if($tmp){
        $tmp='<li class="page-item active"><a class="page-link" aria-label="' . $i;
        $tmp2=$tmp . '" href="userlist.php?page=';
        $tmp3=$tmp2 . $i;
        $tmp4=$tmp3 . '">';
        $tmp5=$tmp4 . $i;
        $tmp6=$tmp5 . '</a></li>';
        echo $tmp6;
    }else{
        $tmp='<li class="page-item "><a class="page-link" aria-label="' . $i;
        $tmp2=$tmp . '" href="userlist.php?page=';
        $tmp3=$tmp2 . $i;
        $tmp4=$tmp3 . '">';
        $tmp5=$tmp4 . $i;
        $tmp6=$tmp5 . '</a></li>';
        echo $tmp6;
    }
    $obj=$i;
    $obj2=$i+1;
    $cond=$obj2;
    $i=$cond;
}
L2xx2u:
$tmp=$end<$maxPages;
if($tmp){
    echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
}
$tmp=$page<$maxPages;
if($tmp)goto L2xeWjgx32;
goto L2xx33;
goto L2xx33;
L2xeWjgx32:
$tmp=$page+1;
$tmp2='<li><a class="page-link" aria-label="下一页" href="userlist.php?page=' . $tmp;
$tmp3=$tmp2 . '">›</a></li>';
echo $tmp3;
$tmp='<li class="page-item"><a class="page-link" aria-label="尾页" href="userlist.php?page=' . $maxPages;
$tmp2=$tmp . '">尾页</a></li>';
echo $tmp2;
goto L2xx33;
L2xldMhx34:
L2xx33:
echo "</div></div>";
echo "                      </tbody>";
echo "
</table>";
echo "
</div>";
echo "
<!-- END Recent Orders Table -->";
echo "
</div>";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
</div>";
echo "
<!-- END Page Content -->";
echo "
</main>";
echo "
<!-- END Main Container -->";
echo "
";
echo "
<!-- Footer -->";
echo "
<footer id=\"page-footer\" class=\"bg-body-light\">";
echo "
<div class=\"content py-3\">";
echo "
<div class=\"row fs-sm\">";
echo "
<div class=\"col-sm-6 order-sm-2 py-1 text-center text-sm-end\">";
echo "
Crafted with <i class=\"fa fa-heart text-danger\"></i> by <a class=\"fw-semibold\" href=\"https://qemao.com\" target=\"_blank\">苏画</a>";
echo "
</div>";
echo "
<div class=\"col-sm-6 order-sm-1 py-1 text-center text-sm-start\">";
echo "
<a class=\"fw-semibold\" href=\"https://www.qemao.com\" target=\"_blank\">LAN</a> &copy; <span data-toggle=\"year-copy\"></span>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</footer>";
echo "
<!-- END Footer -->";
echo "
</div>";
echo "
<!-- END Page Container -->";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
$num7=5840;
$isArray=is_array($_GET);
if($isArray){
    $num7=288;
}else{
    $num7=180;
}
switch($num7){
    case 180:{
    $page=$_GET['useracc'];
        break;
    }
    case 288:{
        $page=&$_GET['useracc'];
        break;
    }
}
$escaped=htmlspecialchars($page);
unset($page);
$escaped2=addslashes($escaped);
$useracc=$escaped2;
if($useracc!="")goto L2xeWjgx4j;
goto L2xldMhx4j;
L2xeWjgx4j:
$tmp="select * from user where username= '" . $useracc;
$sql=$tmp . "'";
$pos=mysqli_query($conn, $sql);
$result=$pos;
$pos=mysqli_num_rows($result);
$tmp=$pos>0;
if($tmp)goto L2xeWjgx3p;
goto L2xx4i;
goto L2xx4i;
L2xeWjgx3p:
while(true){
    $pos=mysqli_fetch_assoc($result);
    $row=$pos;
    if(!$cond)break;
    $user1_id=$row["id"];
    $user1_username=$row["username"];
    $user1_email=$row["email"];
    $user1_zjwallet=$row["wallet"];
    $user1_zjussig=$row["ussig"];
    $user1_name=$row["name"];
    $user1_img=$row["img"];
    $user1_url=$row["url"];
    $user1_homeimg=$row["homeimg"];
    $user1_sign=$row["sign"];
    $user1_essqx=$row["essqx"];
    $user1_esseam=$row["esseam"];
    $user1_regtime=$row["regtime"];
    $user1_regip=$row["regip"];
    $user1_logtime=$row["logtime"];
    $user1_logip=$row["logip"];
    $user1_ban=$row["ban"];
    $user1_bantime=$row["bantime"];
    $tmp=$user1_essqx==1;
    if($tmp){
        $cond='<option value="1">允许</option>
        <option value="2">特权</option>
        <option value="0">不允许</option>';
        $fbwzqx=$cond;
    }else{
        $tmp=$user1_essqx==2;
        if($tmp){
            $cond='<option value="2">特权</option>
            <option value="1">允许</option>
            <option value="0">不允许</option>';
            $fbwzqx=$cond;
        }else{
            $cond='<option value="0">不允许</option>
            <option value="1">允许</option>
            <option value="2">特权</option>';
            $fbwzqx=$cond;
        }
    }
    $tmp=$user1_esseam==1;
    if($tmp){
        $cond='<option value="1">接收</option>
        <option value="0">不接收</option>';
        $esseamqx=$cond;
    }else{
        $cond='<option value="0">不接收</option>
        <option value="1">接收</option>';
        $esseamqx=$cond;
    }
    $tmp=$user1_ban==-1;
if($tmp)goto L2xeWjgx3y;
goto L2xldMhx3y;
goto L2xldMhx3y;
goto L2xldMhx3y;
L2xeWjgx3y:
    $tmp=$user1_bantime!="false";
if($tmp)goto L2xeWjgx41;
goto L2xldMhx41;
goto L2xldMhx41;
goto L2xldMhx41;
L2xeWjgx41:
    $tmp=$user1_bantime=="true";
if($tmp)goto L2xeWjgx43;
goto L2xldMhx43;
goto L2xldMhx43;
goto L2xldMhx43;
L2xeWjgx43:
    $usfjts='<code class="form-group">该账号解封时间为：永久</code>';
goto L2xx4z;
L2xldMhx43:
    $tmp='<code class="form-group">该账号解封时间为：' . $user1_bantime;
    $usfjts=$tmp . '</code>';
L2xldMhx41:
    $tmp='<code class="form-group">该账号解封时间为：' . $user1_bantime;
    $usfjts=$tmp . '</code>';
L2xx4z:
    $cond='<option value="-1">封禁</option>
    <option value="0">正常</option>';
    $uszhfjzt=$cond;
goto L2xx3x;
L2xldMhx3y:
    $cond='<option value="0">正常</option>
    <option value="-1">封禁</option>';
    $uszhfjzt=$cond;
    $usfjts='';
L2xx3x:
    $tmp='<div class="modal show" id="modal-block-normal" tabindex="-1" role="dialog" aria-labelledby="modal-block-normal" aria-modal="true" style="display: block;">
    <form class="modal-dialog" role="document" action="./api/userinfo.php" method="post" enctype="multipart/form-data">
    <div class="modal-content">
    <div class="block block-rounded block-transparent mb-0">
    <div class="block-header block-header-default">
    <h3 class="block-title">编辑用户</h3>
    <div class="block-options">
    <button type="button" class="btn-block-option" data-bs-dismiss="modal" aria-label="Close">
    <i class="fa fa-fw fa-times"></i>
    </button>
    </div>
    </div>
    <div class="block-content fs-sm" style="overflow-x: hidden;overflow-y: scroll;overscroll-behavior-y: contain;max-height: 500px;">
    <form class="form-group" action="./api/userinfo.php" method="post" enctype="multipart/form-data">
    <div class="block-content">
    <div class="row justify-content: flex-start;">
    <div class="col-sm-12 col-md-12 block">
    <div class="row g-2">
    <div class="col-6">
    <label class="form-label">账号</label>
    <input type="text" class="form-control" id="inputEmail40" placeholder="请输入账号" minlength="5" value="' . $user1_username;
    $tmp2=$tmp . '" name="uuserzh">
    </div>
    <div class="col-6">
    <label class="form-label">密码</label>
    <input type="password" class="form-control" id="inputPassword41" placeholder="请输入密码" minlength="3" value="" name="upwd">
    </div>
    <div class="col-6">
    <label class="form-label">邮箱</label>
    <input type="email" class="form-control" id="inputEmail42" placeholder="请输入邮箱" value="';
    $tmp3=$tmp2 . $user1_email;
    $tmp4=$tmp3 . '" name="uuserem">
    </div>
    <div class="col-6">
    <label class="form-label">昵称</label>
    <input type="text" class="form-control" id="inputPassword43" placeholder="请输入昵称" value="';
    $tmp5=$tmp4 . $user1_name;
    $tmp6=$tmp5 . '" name="uusername">
    </div>
    <div class="col-6">
    <label class="form-label">头像</label>
    <input type="text" class="form-control" id="inputEmail44" placeholder="请输入头像链接" value="';
    $tmp7=$tmp6 . $user1_img;
    $tmp8=$tmp7 . '" name="uuserimg">
    </div>
    <div class="col-6">
    <label class="form-label">网址</label>
    <input type="url" class="form-control" id="inputPassword45" placeholder="请输入网址" value="';
    $tmp9=$tmp8 . $user1_url;
    $tmp10=$tmp9 . '" name="uuserwz">
    </div>
    <div class="col-6">
    <label class="form-label">封面</label>
    <input type="text" class="form-control" id="inputEmail46" placeholder="请输入封面链接(不设置请填-1)" value="';
    $tmp11=$tmp10 . $user1_homeimg;
    $tmp12=$tmp11 . '" name="uuserbj">
    </div>
    <div class="col-6">
    <label class="form-label">签名</label>
    <input type="text" class="form-control" id="inputPassword47" placeholder="请输入签名" value="';
    $tmp13=$tmp12 . $user1_sign;
    $tmp14=$tmp13 . '" name="uuserqm">
    </div>
    <div class="col-6">
    <label class="form-label">余额</label>
    <input type="text" class="form-control" id="inputPassword48" placeholder="" value="';
    $tmp15=$tmp14 . $user1_zjwallet;
    $tmp16=$tmp15 . '" name="uuseryue">
    </div>
    <div class="col-6">
    <label class="form-label">发布文章</label>
    <select class="form-control" id="exampleFormControlSelect1" name="uuserqx">
    ';
    $tmp17=$tmp16 . $fbwzqx;
    $tmp18=$tmp17 . '
    </select>
    </div>
    <div class="col-6">
    <label class="form-label">邮件通知</label>
    <select class="form-control" id="exampleFormControlSelect12" name="uuseres">
    ';
    $tmp19=$tmp18 . $esseamqx;
    $tmp20=$tmp19 . '
    </select>
    </div>
    <div class="col-12">
    <div class="input-group mb-2 mr-sm-2" style="cursor: not-allowed;">
    <div class="input-group-prepend">
    <div class="input-group-text">注册时间</div>
    </div>
    <input type="text" class="form-control" id="inlineFormInputGroupUsername2" disabled="" placeholder="注册时间" value="';
    $tmp21=$tmp20 . $user1_regtime;
    $tmp22=$tmp21 . '" style="cursor: not-allowed;">
    </div>
    </div>
    <div class="col-12">
    <div class="input-group mb-2 mr-sm-2" style="cursor: not-allowed;">
    <div class="input-group-prepend">
    <div class="input-group-text">注册时IP</div>
    </div>
    <input type="text" class="form-control" id="inlineFormInputGroupUsername3" disabled="" placeholder="注册时IP" value="';
    $tmp23=$tmp22 . $user1_regip;
    $tmp24=$tmp23 . '" style="cursor: not-allowed;">
    </div>
    </div>
    <div class="col-12">
    <div class="input-group mb-2 mr-sm-2" style="cursor: not-allowed;">
    <div class="input-group-prepend">
    <div class="input-group-text">最后登录</div>
    </div>
    <input type="text" class="form-control" id="inlineFormInputGroupUsername4" disabled="" placeholder="最后登录" value="';
    $tmp25=$tmp24 . $user1_logtime;
    $tmp26=$tmp25 . '" style="cursor: not-allowed;">
    </div>
    </div>
    <div class="col-12">
    <div class="input-group mb-2 mr-sm-2" style="cursor: not-allowed;">
    <div class="input-group-prepend">
    <div class="input-group-text">最后的IP</div>
    </div>
    <input type="text" class="form-control" id="inlineFormInputGroupUsername5" disabled="" placeholder="最后的IP" value="';
    $tmp27=$tmp26 . $user1_logip;
    $tmp28=$tmp27 . '" style="cursor: not-allowed;">
    </div>
    </div>
    <div class="col-6">
    <label class="form-label">账号封禁</label>
    <select class="form-control" id="exampleFormControlSelect13" name="uuserban">
    ';
    $tmp29=$tmp28 . $uszhfjzt;
    $tmp30=$tmp29 . '
    </select>
    </div>
    <div class="col-6">
    <label class="form-label">封禁时间</label>
    <select class="form-control" id="exampleFormControlSelect14" name="uuserbantime">
    <option value="false">正常</option>
    <option value="';
    $escaped=strtotime("+1 day");
    $dateStr=date("Y-m-d H:i", $escaped);
    $tmp31=$tmp30 . $dateStr;
    $tmp32=$tmp31 . '">1天</option>
    <option value="';
    $timestamp=strtotime("+7 day");
    $dateStr2=date("Y-m-d H:i", $timestamp);
    $tmp33=$tmp32 . $dateStr2;
    $tmp34=$tmp33 . '>">7天</option>
    <option value="';
    $timestamp2=strtotime("+15 day");
    $dateStr3=date("Y-m-d H:i", $timestamp2);
    $tmp35=$tmp34 . $dateStr3;
    $tmp36=$tmp35 . '">15天</option>
    <option value="';
    $timestamp3=strtotime("+30 day");
    $dateStr4=date("Y-m-d H:i", $timestamp3);
    $tmp37=$tmp36 . $dateStr4;
    $tmp38=$tmp37 . '">30天</option>
    <option value="';
    $timestamp4=strtotime("+180 day");
    $dateStr5=date("Y-m-d H:i", $timestamp4);
    $tmp39=$tmp38 . $dateStr5;
    $tmp40=$tmp39 . '">180天</option>
    <option value="';
    $timestamp5=strtotime("+365 day");
    $dateStr6=date("Y-m-d H:i", $timestamp5);
    $tmp41=$tmp40 . $dateStr6;
    $tmp42=$tmp41 . '">1年</option>
    <option value="true">永久</option>
    </select>
    ';
    $tmp43=$tmp42 . $usfjts;
    $tmp44=$tmp43 . '
    </div>
    </div>
    </div>
    </div>
    </div>
    </form>
    </div>
    <div class="block-content block-content-full text-end bg-body">
    <input type="hidden" value="userbj" name="lx" id="lx">
    <input type="hidden" value="';
    $tmp45=$tmp44 . $user1_id;
    $tmp46=$tmp45 . '" name="userid" id="userid">
    <button type="submit" class="btn btn-sm btn-alt-secondary me-1" id="deluser" lang="';
    $tmp47=$tmp46 . $user1_id;
    $tmp48=$tmp47 . '" style="color: var(--bs-danger);">删除用户</button>
    <button type="submit" class="btn btn-sm btn-primary">更新</button>
    </div>
    </div>
    </div>
    </form>
    </div>
    <div class="modal-backdrop show"></div>';
    echo $tmp48;
}
goto L2xx4i;
L2xldMhx4j:
L2xx4i:
echo "    ";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<!--";
echo "
OneUI JS";
echo "
";
echo "
Core libraries and functionality";
echo "
webpack is putting everything together at assets/_js/main/app.js";
echo "
-->";
echo "
<script src=\"assets/js/oneui.app.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Plugins -->";
echo "
<script src=\"assets/js/chart.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Code -->";
echo "
<script src=\"assets/js/be_pages_dashboard.min.js\"></script>";
echo "
<script type=\"text/javascript\" src=\"../assets/mesg/dist/js/sh-noytf.js\"></script>";
echo "
<script type=\"text/javascript\">";
echo "
if (document.getElementById('deluser')) {";
echo "
// 如果元素存在，则给它绑定事件";
echo "
document.getElementById('deluser').addEventListener('click', function() {";
echo "
if (confirm(\"这将删除该账号的所有数据且不可撤销,是否继续?\")) {";
echo "
// 用户点击了确认按钮";
echo "
document.getElementById(\"lx\").value=\"deluser\";";
echo "
} else {";
echo "
// 用户点击了取消按钮或关闭了弹窗";
echo "
event.preventDefault(); // 阻止表单的默认提交行为";
echo "
return;";
echo "
}";
echo "
});";
echo "
}";
echo "
";
echo "
//解封";
echo "
;function idsx() {
    ";echo "
    var checkboxes = document.querySelectorAll('.form-check-input');
    ";echo "
    var selectedValues = [];
    ";echo "
    for (var i = 0;
    i < checkboxes.length;
    i++) {  ";echo "
    if (checkboxes[i].checked) {  ";echo "
    selectedValues.push(checkboxes[i].value);
    ";echo "
}  ";echo "
}  ";echo "
var data = selectedValues.join(',');
";echo "
if (data == \"\") {";
echo "
return;";
echo "
}";
echo "
";
echo "
loadpop(\"正在执行,请稍后\",'ok');";
echo "
// 创建一个XMLHttpRequest对象  ";
echo "
var xhr = new XMLHttpRequest();  ";
echo "
// 设置属性  ";
echo "
xhr.open('post', './api/userinfo.php', true); // 注意这里设置为异步请求  ";
echo "
// 设置请求头为application/x-www-form-urlencoded，以便能够通过POST请求发送数据  ";
echo "
xhr.setRequestHeader(\"Content-type\", \"application/x-www-form-urlencoded\");  ";
echo "
// 将数据通过send方法传递，注意这里将数据转换为键值对形式  ";
echo "
xhr.send('ids=' + data+'&lx=0');  ";
echo "
// 发送并处理返回值  ";
echo "
xhr.onreadystatechange = function () {  ";
echo "
// 这步为判断服务器是否正确响应  ";
echo "
if (xhr.readyState == 4 && xhr.status == 200) {";
echo "
if (xhr.responseText == \"\") {";
echo "
warnpop(\"未获取到数据\");";
echo "
return;";
echo "
}";
echo "
var obj = JSON.parse(xhr.responseText); //由JSON字符串转换为JSON对象";
echo "
//console.log(obj);";
echo "
var code =obj[0].code;//获取第一个的值 状态码";
echo "
var msg=obj[0].msg;//获取返回内容昵称";
echo "
if (code == 200) {";
echo "
successpop(msg);";
echo "
location.reload();";
echo "
}else{";
echo "
warnpop(msg);";
echo "
}";
echo "
}  ";
echo "
};";
echo "
}";echo "
";echo "
//封禁";echo "
function idsxf() {
    ";echo "
    var checkboxes = document.querySelectorAll('.form-check-input');
    ";echo "
    ";echo "
    var selectedValues = [];
    ";echo "
    for (var i = 0;
    i < checkboxes.length;
    i++) {  ";echo "
    if (checkboxes[i].checked) { ";echo "
    selectedValues.push(checkboxes[i].value);
    ";echo "
}  ";echo "
}  ";echo "
var data = selectedValues.join(',');
";echo "
if (data == \"\") {";
echo "
return;";
echo "
}";
echo "
";
echo "
loadpop(\"正在执行,请稍后\",'ok');";
echo "
// 创建一个XMLHttpRequest对象  ";
echo "
var xhr = new XMLHttpRequest();  ";
echo "
// 设置属性  ";
echo "
xhr.open('post', './api/userinfo.php', true); // 注意这里设置为异步请求  ";
echo "
// 设置请求头为application/x-www-form-urlencoded，以便能够通过POST请求发送数据  ";
echo "
xhr.setRequestHeader(\"Content-type\", \"application/x-www-form-urlencoded\");  ";
echo "
// 将数据通过send方法传递，注意这里将数据转换为键值对形式  ";
echo "
xhr.send('ids=' + data+'&lx=-1');  ";
echo "
// 发送并处理返回值  ";
echo "
xhr.onreadystatechange = function () {  ";
echo "
// 这步为判断服务器是否正确响应  ";
echo "
if (xhr.readyState == 4 && xhr.status == 200) {";
echo "
if (xhr.responseText == \"\") {";
echo "
warnpop(\"未获取到数据\");";
echo "
return;";
echo "
}";
echo "
var obj = JSON.parse(xhr.responseText); //由JSON字符串转换为JSON对象";
echo "
//console.log(obj);";
echo "
var code =obj[0].code;//获取第一个的值 状态码";
echo "
var msg=obj[0].msg;//获取返回内容昵称";
echo "
if (code == 200) {";
echo "
successpop(msg);";
echo "
location.reload();";
echo "
}else{";
echo "
warnpop(msg);";
echo "
}";
echo "
}  ";
echo "
};";
echo "
}";echo "
</script>";echo "
</body>";echo "
</html>";echo "
";