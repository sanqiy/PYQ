<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $arr[]=$val;
    $arr=$arr;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp=$user_zh=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$user_passid=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2)goto L2xeWjgx1l;
goto L2xldMhx1l;
L2xeWjgx1l:
$str2="Y";
$Y=$str2;
$str2="m";
$m=$str2;
$str2="d";
$d=$str2;
$str2="H";
$H=$str2;
$str2="i";
$i=$str2;
$str2="s";
$s=$str2;
$str3=$Y . "-";
$str4=$str3 . $m;
$str5=$str4 . "-";
$val2=$str5 . $d;
$str6=$val2 . " ";
$val3=$str6 . $H;
$str7=$val3 . ":";
$val4=$str7 . $i;
$str8=$val4 . ":";
$val5=$str8 . $s;
$row=date($val5);
$sj=$row;
if($HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"]){
    $ip=$HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"];
}else{
    if($HTTP_SERVER_VARS["HTTP_CLIENT_IP"]){
        $ip=$HTTP_SERVER_VARS["HTTP_CLIENT_IP"];
    }else{
        if($HTTP_SERVER_VARS["REMOTE_ADDR"]){
            $ip=$HTTP_SERVER_VARS["REMOTE_ADDR"];
        }else{
            $row=getenv("HTTP_X_FORWARDED_FOR");
            if($row){
                $row=getenv("HTTP_X_FORWARDED_FOR");
                $ip=$row;
            }else{
                $row=getenv("HTTP_CLIENT_IP");
                if($row){
                    $row=getenv("HTTP_CLIENT_IP");
                    $ip=$row;
                }else{
                    $row=getenv("REMOTE_ADDR");
                    if($row){
                        $row=getenv("REMOTE_ADDR");
                        $ip=$row;
                    }else{
                        $ip="Unknown";
                    }
                }
            }
        }
    }
}
$isArray=is_array($_POST);
if($isArray){
    $tieid=&$_POST['tieid'];
}else{
    $tieid=$_POST['tieid'];
}
$escaped=htmlspecialchars($tieid);
unset($tieid);
$escaped2=addslashes($escaped);
$tieid=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $tieid=&$_POST['zts'];
}else{
    $tieid=$_POST['zts'];
}
$escaped=htmlspecialchars($tieid);
unset($tieid);
$escaped2=addslashes($escaped);
$zts=$escaped2;
$tmp=$tieid=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$zts=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    $val["code"]="201";
    $val["msg"]="参数不完整!";
    $arr[]=$val;
    $arr=$arr;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$tmp=include '../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    $val["code"]="201";
    $val["msg"]="连接数据库失败";
    $arr[]=$val;
    $arr=$arr;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$row=session_start();
$isArray=is_array($_SESSION);
if($isArray){
    $tieid=&$_SESSION['visykmz_userzh'];
}else{
    $tieid=$_SESSION['visykmz_userzh'];
}
$escaped=htmlspecialchars($tieid);
unset($tieid);
$escaped2=addslashes($escaped);
$randomString=$escaped2;
$isArray=is_array($_SESSION);
if($isArray){
    $tieid=&$_SESSION['visykmz_userip'];
}else{
    $tieid=$_SESSION['visykmz_userip'];
}
$escaped=htmlspecialchars($tieid);
unset($tieid);
$escaped2=addslashes($escaped);
$randomStringip=$escaped2;
$tmp=$randomString=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$randomStringip=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2)goto L2xeWjgxx;
goto L2xldMhxx;
goto L2xldMhxx;
L2xeWjgxx:
if(1){function generateRandomString($length=5) {
    $characters='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString='';
    $i=0;
    while(true){
        $tmp=$i<$length;
        if(!($tmp))break;
        $length=strlen($characters);
        $str=$length-1;
        $rand=rand($str);
        $randomString=$randomString . $characters[$rand];
        $val6=$randomString;
        $obj=$i;
        $obj2=$i+1;
        $str2=$obj2;
        $i=$str2;
    }
    return $randomString;
}}$arr=array();
$row=generateRandomString();
$randomString2="游客" . $row;
$tmp='vis#-[' . $ip;
$user_zh=$tmp . ']-#vis';
$user_name=$randomString2;
$user_img='./assets/img/tx.png';
goto L2xxu;
L2xldMhxx:
L2xxu:
$tmp=$zts==0;
if($tmp)goto L2xeWjgxz;
goto L2xldMhxz;
goto L2xldMhxz;
L2xeWjgxz:
$tmp="select * from lcke where luser= '" . $user_zh;
$tmp4=$tmp . "' and lwz='";
$tmp2=$tmp4 . $tieid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
$row=mysqli_fetch_array($result);
$row=$row;
if($row){
    $val["code"]="201";
    $val["msg"]="您已经点过赞了";
    $arr[]=$val;
    $arr=$arr;
    $row=json_encode($arr, JSON_UNESCAPED_UNICODE);
    echo $row;
    exit();
}
$bdm="lcke";
$tmp="INSERT INTO " . $bdm;
$tmp4=$tmp . " (luser,lname,limg,lwz,ltime)
VALUES ('";
$tmp2=$tmp4 . $user_zh;
$tmp3=$tmp2 . "','";
$tmp5=$tmp3 . $user_name;
$tmp6=$tmp5 . "','";
$tmp7=$tmp6 . $user_img;
$tmp8=$tmp7 . "','";
$tmp9=$tmp8 . $tieid;
$tmp10=$tmp9 . "','";
$tmp11=$tmp10 . $sj;
$sql=$tmp11 . "')";
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp)goto L2xeWjgx14;
goto L2xldMhx14;
goto L2xldMhx14;
L2xeWjgx14:
$str3="select * from essay where cid='" . $tieid;
$str4=$str3 . "'";
$row=mysqli_query($conn, $str4);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data_row=$row;
$wzfszh=$data_row["ptpuser"];
$str3="select * from user where username='" . $wzfszh;
$str4=$str3 . "'";
$row=mysqli_query($conn, $str4);
$data_resultl=$row;
$row=mysqli_fetch_array($data_resultl);
$data_rowl=$row;
$wzfszh=$data_rowl["username"];
$wzfsnc=$data_rowl["name"];
$wzfstx=$data_rowl["img"];
$wzfseam=$data_rowl["img"];
$bdm2="message";
$btmnr=$user_name . "给你点赞啦!";
$tmp="INSERT INTO " . $bdm2;
$tmp4=$tmp . " (fuser,fimg,fname,suser,title,text,ftime,msg)
VALUES ('";
$tmp2=$tmp4 . $user_zh;
$tmp3=$tmp2 . "','";
$tmp5=$tmp3 . $user_img;
$tmp6=$tmp5 . "','";
$tmp7=$tmp6 . $user_name;
$tmp8=$tmp7 . "','";
$tmp9=$tmp8 . $wzfszh;
$tmp10=$tmp9 . "','新的点赞','";
$tmp11=$tmp10 . $btmnr;
$tmp12=$tmp11 . "','";
$tmp13=$tmp12 . $sj;
$sql2=$tmp13 . "','0')";
$result=$conn->query($sql2);
$tmp=$result===TRUE;
if(!($tmp)){
    $tmp="Error: " . $sql2;
    $tmp4=$tmp . "<br>";
    $tmp2=$tmp4 . $conn->error;
    echo $tmp2;
}else{
    $tmp="select * from lcke where lwz='" . $tieid;
    $sqly=$tmp . "'";
    $result=$conn->query($sqly);
    $resulty=$result;
    $dwys=0;
}
L2xx17:
while(true){
    $result=$resulty->fetch_assoc();
    $rowy=$result;
    if(!$str2)break;
    $ykdzm=$rowy["luser"];
    $row=strpos($ykdzm, 'vis#-[');
    $tmp=$row!==false;
    $tmp2=(bool)$tmp;
    $tmp3=!$tmp2;
    if($tmp3){
        $cookieResult=strpos($ykdzm, ']-#vis');
        $tmp4=$cookieResult!==false;
        $tmp2=(bool)$tmp4;
    }
if($tmp2)goto L2xeWjgx1c;
goto L2xx17;
goto L2xx17;
goto L2xx17;
L2xeWjgx1c:
    $obj3=$dwys;
    $dwys=$dwys+1;
}
L2xx1d:
$str=$dwys . "位访客";
$val["code"]="200";
$val["msg"]=$str;
$val["img"]=$user_img;
$arr[]=$val;
$arr=$arr;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
goto L2xxy;
L2xldMhx14:
$tmp="Error: " . $sql;
$tmp4=$tmp . "<br>";
$tmp2=$tmp4 . $conn->error;
echo $tmp2;
L2xldMhxz:
$tmp=$zts==-1;
if($tmp){
    $val["code"]="201";
    $val["msg"]="游客暂不支持取消点赞哦";
    $arr[]=$val;
    $arr=$arr;
    $row=json_encode($arr, JSON_UNESCAPED_UNICODE);
    echo $row;
}
L2xxy:
exit();
goto L2xx1k;
L2xldMhx1l:
L2xx1k:
$tmp=include '../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
$num=6869;
if($conn->connect_error){
    $num=$buf[2]*$buf[1];
}
switch($num){
    case 304:{
    die("连接失败: " . $conn->connect_error);
        break;
    }
}
$escaped=htmlspecialchars($user_zh);
$cookieResult=addslashes($escaped);
$user_zhsg=$cookieResult;
$tmp="select * from user where username='" . $user_zhsg;
$sqls=$tmp . "'";
$row=mysqli_query($conn, $sqls);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$data2s_row=$row;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$user_id=$user_zh;
$user_name=$user_name;
$user_img=$user_img;
$num2=6876;
$isArray=is_array($_POST);
if($isArray){
    $num2=$buf[0]*$buf[4];
}else{
    $num2=$buf[3]*$buf[4];
}
switch($num2){
    case 44:{
    $tieid=&$_POST['tieid'];
        break;
    }
    case 72:{
        $tieid=$_POST['tieid'];
        break;
    }
}
$escaped=htmlspecialchars($tieid);
unset($tieid);
$escaped2=addslashes($escaped);
$tieid=$escaped2;
$num3=6873;
$isArray=is_array($_POST);
if($isArray){
    $num3=$buf[2]*$buf[3];
}else{
    $num3=$buf[3]*$buf[0];
}
switch($num3){
    case 198:{
    $tieid=$_POST['zts'];
        break;
    }
    case 342:{
        $tieid=&$_POST['zts'];
        break;
    }
}
$escaped=htmlspecialchars($tieid);
unset($tieid);
$escaped2=addslashes($escaped);
$zts=$escaped2;
$num4=6874;
$tmp=$user_id=="";
$tmp2=(bool)$tmp;
$tmp13=!$tmp2;
if($tmp13){
    $tmp4=$user_name=="";
    $tmp2=(bool)$tmp4;
}
$tmp5=(bool)$tmp2;
$tmp12=!$tmp5;
if($tmp12){
    $tmp3=$user_img=="";
    $tmp5=(bool)$tmp3;
}
$tmp7=(bool)$tmp5;
$tmp11=!$tmp7;
if($tmp11){
    $tmp6=$tieid=="";
    $tmp7=(bool)$tmp6;
}
$tmp9=(bool)$tmp7;
$tmp10=!$tmp9;
if($tmp10){
    $tmp8=$zts=="";
    $tmp9=(bool)$tmp8;
}
if($tmp9){
    $num4=$buf[4]*$buf[4];
}
switch($num4){
    case 16:{
    $val["code"]="201";
    $val["msg"]="参数不完整!";
    $arr[]=$val;
    $arr=$arr;
    $row=json_encode($arr, JSON_UNESCAPED_UNICODE);
    echo $row;
    exit();
        break;
    }
}
$str3="select * from user where username='" . $user_zh;
$str4=$str3 . "'";
$row=mysqli_query($conn, $str4);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
$ban=$data2_row["ban"];
$bantime=$data2_row["bantime"];
$num5=6870;
$tmp=$user_passid!=$passid;
if($tmp){
    $num5=$buf[0]*$buf[3];
}
switch($num5){
    case 198:{
    $escaped=time();
    $str3=$escaped+ -1;
    $cookieResult=setcookie("username", "", $str3, "/");
    $escaped=time();
    $str3=$escaped+ -1;
    $cookieResult=setcookie("passid", "", $str3, "/");
    $val["code"]="201";
    $val["msg"]="账号信息异常,请重新登录!";
    $arr[]=$val;
    $arr=$arr;
    $row=json_encode($arr, JSON_UNESCAPED_UNICODE);
    echo $row;
    exit();
        break;
    }
}
$num6=6861;
$tmp=$ban!="0";
$tmp2=(bool)$tmp;
if($tmp2){
    $tmp4=$bantime!="false";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    $num6=$buf[4]*$buf[1];
}
$tmp=20;
$tmp4=64;
$tmp2=$num6==64;
if($tmp2)goto L2xeWjgx4z;
goto L2xldMhx4z;
L2xeWjgx4z:
$tmp=$bantime==="true";
if($tmp)goto L2xeWjgx3x;
goto L2xldMhx3x;
goto L2xldMhx3x;
L2xeWjgx3x:
$escaped=time();
$str3=$escaped+ -1;
$cookieResult=setcookie("username", "", $str3, "/");
$escaped=time();
$str3=$escaped+ -1;
$cookieResult=setcookie("passid", "", $str3, "/");
$val["code"]="201";
$val["msg"]="该账号涉嫌违规,已被永久封禁!";
$arr[]=$val;
$arr=$arr;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
exit();
goto L2xx3y;
L2xldMhx3x:
$escaped=time();
$str3=$escaped+ -1;
$cookieResult=setcookie("username", "", $str3, "/");
$escaped=time();
$str3=$escaped+ -1;
$cookieResult=setcookie("passid", "", $str3, "/");
$str="你的账号已被封禁！解封时间为:" . $bantime;
$val["code"]="201";
$val["msg"]=$str;
$arr[]=$val;
$arr=$arr;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
exit();
L2xldMhx4z:
L2xx3y:
$str2="Y";
$Y=$str2;
$str2="m";
$m=$str2;
$str2="d";
$d=$str2;
$str2="H";
$H=$str2;
$str2="i";
$i=$str2;
$str2="s";
$s=$str2;
$str3=$Y . "-";
$str4=$str3 . $m;
$str5=$str4 . "-";
$val2=$str5 . $d;
$str6=$val2 . " ";
$val3=$str6 . $H;
$str7=$val3 . ":";
$val4=$str7 . $i;
$str8=$val4 . ":";
$val5=$str8 . $s;
$row=date($val5);
$sj=$row;
$num7=6863;
if($HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"]){
    $num7=$buf[4]*$buf[1];
}else{
    if($HTTP_SERVER_VARS["HTTP_CLIENT_IP"]){
        $num7=$buf[0]*$buf[3];
    }else{
        if($HTTP_SERVER_VARS["REMOTE_ADDR"]){
            $num7=$buf[0]*$buf[4];
        }else{
            $row=getenv("HTTP_X_FORWARDED_FOR");
            if($row){
                $num7=$buf[1]*$buf[3];
            }else{
                $row=getenv("HTTP_CLIENT_IP");
                if($row){
                    $num7=$buf[1]*$buf[0];
                }else{
                    $row=getenv("REMOTE_ADDR");
                    if($row){
                        $num7=$buf[2]*$buf[0];
                    }else{
                        $num7=$buf[2]*$buf[3];
                    }
                }
            }
        }
    }
}
switch($num7){
    case 209:{
    $row=getenv("REMOTE_ADDR");
    $ip=$row;
        break;
    }
    case 288:{
        $row=getenv("HTTP_X_FORWARDED_FOR");
        $ip=$row;
        break;
    }
    case 64:{
            $ip=$HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"];
        break;
    }
    case 198:{
                $ip=$HTTP_SERVER_VARS["HTTP_CLIENT_IP"];
        break;
    }
    case 44:{
                    $ip=$HTTP_SERVER_VARS["REMOTE_ADDR"];
        break;
    }
    case 176:{
                        $row=getenv("HTTP_CLIENT_IP");
                        $ip=$row;
        break;
    }
    case 342:{
                            $ip="Unknown";
        break;
    }
}
$num8=6875;
$tmp=$zts==0;
if($tmp){
    $num8=$buf[4]*$buf[3];
}else{
    $tmp=$zts==-1;
    if($tmp){
        $num8=$buf[4]*$buf[3];
        $num8=1391+$num8;
    }
}
$tmp=30;
$tmp4=1463;
$tmp2=$num8==1463;
if($tmp2)goto L2xeWjgx4y;
goto L2xldMhx4y;
L2xeWjgx4y:
$tmp="select * from lcke where luser= '" . $zjzhq;
$tmp4=$tmp . "' and lwz='";
$tmp2=$tmp4 . $tieid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
$row=mysqli_fetch_array($result);
$row=$row;
if($row)goto L2xeWjgx4u;
goto L2xx4x;
goto L2xx4x;
L2xeWjgx4u:
$wida=$row['id'];
$tmp="delete from lcke where id='" . $wida;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx4w;
goto L2xldMhx4w;
goto L2xldMhx4w;
L2xeWjgx4w:
$val["code"]="200";
$val["msg"]=$zjnc;
$arr[]=$val;
$arr=$arr;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
goto L2xx4x;
L2xldMhx4w:
$row=mysql_errno();
echo $row;
L2xldMhx4y:
$tmp=210;
$tmp4=72;
$tmp2=$num8==72;
if($tmp2)goto L2xeWjgx54;
goto L2xldMhx54;
L2xeWjgx54:
$tmp="select * from lcke where luser= '" . $zjzhq;
$tmp4=$tmp . "' and lwz='";
$tmp2=$tmp4 . $tieid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
$row=mysqli_fetch_array($result);
$row=$row;
if($row){
    $val["code"]="201";
    $val["msg"]="您已经点过赞了";
    $arr[]=$val;
    $arr=$arr;
    $row=json_encode($arr, JSON_UNESCAPED_UNICODE);
    echo $row;
    exit();
}
$str3="select * from essay where cid='" . $tieid;
$str4=$str3 . "'";
$row=mysqli_query($conn, $str4);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data_row=$row;
$wzfszh=$data_row["ptpuser"];
$str3="select * from user where username='" . $wzfszh;
$str4=$str3 . "'";
$row=mysqli_query($conn, $str4);
$data_resultl=$row;
$row=mysqli_fetch_array($data_resultl);
$data_rowl=$row;
$wzfszh=$data_rowl["username"];
$wzfsnc=$data_rowl["name"];
$wzfstx=$data_rowl["img"];
$wzfseam=$data_rowl["img"];
$bdm="lcke";
$tmp="INSERT INTO " . $bdm;
$tmp4=$tmp . " (luser,lname,limg,lwz,ltime)
VALUES ('";
$tmp2=$tmp4 . $zjzhq;
$tmp3=$tmp2 . "','";
$tmp5=$tmp3 . $zjnc;
$tmp6=$tmp5 . "','";
$tmp7=$tmp6 . $zjimg;
$tmp8=$tmp7 . "','";
$tmp9=$tmp8 . $tieid;
$tmp10=$tmp9 . "','";
$tmp11=$tmp10 . $sj;
$sql=$tmp11 . "')";
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp){
    $val["code"]="200";
    $val["msg"]=$zjnc;
    $val["img"]=$zjimg;
    $arr[]=$val;
    $arr=$arr;
    $row=json_encode($arr, JSON_UNESCAPED_UNICODE);
    echo $row;
}else{
    $tmp="Error: " . $sql;
    $tmp4=$tmp . "<br>";
    $tmp2=$tmp4 . $conn->error;
    echo $tmp2;
}
$tmp=$wzfszh!=$user_zh;
if($tmp)goto L2xeWjgx4p;
goto L2xx4x;
goto L2xx4x;
L2xeWjgx4p:
$bdm2="message";
$btmnr=$zjnc . "给你点赞啦!";
$tmp="INSERT INTO " . $bdm2;
$tmp4=$tmp . " (fuser,fimg,fname,suser,title,text,ftime,msg)
VALUES ('";
$tmp2=$tmp4 . $zjzhq;
$tmp3=$tmp2 . "','";
$tmp5=$tmp3 . $zjimg;
$tmp6=$tmp5 . "','";
$tmp7=$tmp6 . $zjnc;
$tmp8=$tmp7 . "','";
$tmp9=$tmp8 . $wzfszh;
$tmp10=$tmp9 . "','新的点赞','";
$tmp11=$tmp10 . $btmnr;
$tmp12=$tmp11 . "','";
$tmp13=$tmp12 . $sj;
$sql2=$tmp13 . "','0')";
$result=$conn->query($sql2);
$tmp=$result===TRUE;
if($tmp)goto L2xx4x;
goto L2xldMhx4r;
L2xldMhx4r:
$tmp="Error: " . $sql2;
$tmp4=$tmp . "<br>";
$tmp2=$tmp4 . $conn->error;
echo $tmp2;
L2xldMhx54:
L2xx4x:
$result=$conn->close();