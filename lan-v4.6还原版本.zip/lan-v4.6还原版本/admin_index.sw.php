<?php
$iteace=1;
$curlOptResult=is_file('../config.php');
if($curlOptResult){
    $tmp=include '../config.php';
}
$tmp=include '../api/wz.php';
if($userdlzt==0){
    $curlOptResult=header('location: ./login.php');
    exit();
}
$num5=4916;
$tmp=$user_zh==$glyadmin;
if($tmp){
    $num5=15;
}else{
    $num5=85;
}
$tmp=34;
$tmp2=15;
$tmp3=$num5==15;
if($tmp3)goto L2xeWjgxe;
goto L2xldMhxe;
L2xeWjgxe:
$tmp=$user_passid!=$passid;
if($tmp)goto L2xeWjgxc;
goto L2xxd;
goto L2xxd;
L2xeWjgxc:
exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="./login.php";</script>;');
goto L2xxd;
L2xldMhxe:
switch($num5){
    case 85:{
    exit('<script language="JavaScript">;alert("没有权限!");location.href="../index.php";</script>;');
        break;
    }
}
L2xxd:
$str='Select count(*) as AllNum from user';
$Query=$str;
$curlOptResult=mysqli_query($conn, $Query);
$str=$curlOptResult;
$a=$str;
$curlOptResult=mysqli_fetch_assoc($a);
$str=$curlOptResult;
$b=$str;
$usercount=$b['AllNum'];
$str='Select count(*) as AllNum from essay';
$Query=$str;
$curlOptResult=mysqli_query($conn, $Query);
$str=$curlOptResult;
$a=$str;
$curlOptResult=mysqli_fetch_assoc($a);
$str=$curlOptResult;
$b=$str;
$essaycount=$b['AllNum'];
$str='Select count(*) as AllNum from comm';
$Query=$str;
$curlOptResult=mysqli_query($conn, $Query);
$str=$curlOptResult;
$a=$str;
$curlOptResult=mysqli_fetch_assoc($a);
$str=$curlOptResult;
$b=$str;
$commcount=$b['AllNum'];
echo "<!doctype html>";
echo "
<html lang=\"en\">";
echo "
<head>";
echo "
<meta charset=\"utf-8\">";
echo "
<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0\">";
echo "
<title>后台首页 - ";
echo $name;
echo "</title>";
echo "
<meta name=\"keywords\" content=\"";
echo $filterkeyw;
echo "\">";
echo "
<meta name=\"description\" content=\"";
echo $subtitle;
echo "\">";
echo "
<meta name=\"author\" content=\"";
echo $name;
echo "\">";
echo "
<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"";
$num6=4923;
$curlOptResult=strpos($icon, 'http');
$tmp=$curlOptResult!==false;
if($tmp){
    $num6=15;
}else{
    $num6=16;
}
switch($num6){
    case 16:{
    $tmp='.' . $icon;
    echo $tmp;
        break;
    }
    case 15:{
        echo $icon;
        break;
    }
}
echo "\">";
echo "
<link rel=\"stylesheet\" href=\"assets/css/css2.css\">";
echo "
<link rel=\"stylesheet\" id=\"css-main\" href=\"assets/css/oneui.min.css\">";
echo "
</head>";
echo "
<body>";
echo "
<div id=\"page-container\" class=\"sidebar-o sidebar-dark page-header-fixed main-content-narrow\">";
echo "
<nav id=\"sidebar\" aria-label=\"Main Navigation\">";
echo "
<!-- Side Header -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Logo -->";
echo "
<a class=\"fw-semibold text-dual\" href=\"index.php\">";
echo "
<span class=\"smini-visible\">";
echo "
<i class=\"fa fa-circle-notch text-primary\"></i>";
echo "
</span>";
echo "
<span class=\"smini-hide fs-5 tracking-wider\">后台管理</span>";
echo "
</a>";
echo "
<!-- END Logo -->";
echo "
";
echo "
<!-- Extra -->";
echo "
<div>";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" data-toggle=\"layout\" data-action=\"dark_mode_toggle\">";
echo "
<i class=\"far fa-moon\"></i>";
echo "
</button>";
echo "
<!-- END Dark Mode -->";
echo "
";
echo "
<!-- Options -->";
echo "
<div class=\"dropdown d-inline-block ms-1\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" id=\"sidebar-themes-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<i class=\"far fa-circle\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-end fs-sm smini-hide border-0\" aria-labelledby=\"sidebar-themes-dropdown\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"default\" href=\"#\">";
echo "
<span>默认</span>";
echo "
<i class=\"fa fa-circle text-default\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/amethyst.min.css\" href=\"#\">";
echo "
<span>紫色</span>";
echo "
<i class=\"fa fa-circle text-amethyst\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/city.min.css\" href=\"#\">";
echo "
<span>红色</span>";
echo "
<i class=\"fa fa-circle text-city\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/flat.min.css\" href=\"#\">";
echo "
<span>青色</span>";
echo "
<i class=\"fa fa-circle text-flat\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/modern.min.css\" href=\"#\">";
echo "
<span>蓝色</span>";
echo "
<i class=\"fa fa-circle text-modern\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/smooth.min.css\" href=\"#\">";
echo "
<span>粉色</span>";
echo "
<i class=\"fa fa-circle text-smooth\"></i>";
echo "
</a>";
echo "
<!-- END Color Themes -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_light\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 黑色</span>";
echo "
</a>";
echo "
<!-- END Sidebar Styles -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_light\" href=\"javascript:void(0)\">";
echo "
<span>导航 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>导航 黑色</span>";
echo "
</a>";
echo "
<!-- END Header Styles -->";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Options -->";
echo "
<a class=\"d-lg-none btn btn-sm btn-alt-secondary ms-1\" data-toggle=\"layout\" data-action=\"sidebar_close\" href=\"javascript:void(0)\">";
echo "
<i class=\"fa fa-fw fa-times\"></i>";
echo "
</a>";
echo "
<!-- END Close Sidebar -->";
echo "
</div>";
echo "
<!-- END Extra -->";
echo "
</div>";
echo "
<!-- END Side Header -->";
echo "
";
echo "
<!-- Sidebar Scrolling -->";
echo "
<div class=\"js-sidebar-scroll\">";
echo "
<!-- Side Navigation -->";
echo "
<div class=\"content-side\">";
echo "
<ul class=\"nav-main\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link active\" href=\"./index.php\">";
echo "
<i class=\"nav-main-link-icon si si-speedometer\"></i>";
echo "
<span class=\"nav-main-link-name\">后台首页</span>";
echo "
</a>";
echo "
</li>";
echo "
";
echo "
<li class=\"nav-main-heading\">设置</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-energy\"></i>";
echo "
<span class=\"nav-main-link-name\">网站设置</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./basic.php\">";
echo "
<span class=\"nav-main-link-name\">基础设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./authority.php\">";
echo "
<span class=\"nav-main-link-name\">权限设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./imgset.php\">";
echo "
<span class=\"nav-main-link-name\">图像设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./emailset.php\">";
echo "
<span class=\"nav-main-link-name\">邮箱设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./calis.php\">";
echo "
<span class=\"nav-main-link-name\">卡密管理</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-users\"></i>";
echo "
<span class=\"nav-main-link-name\">用户管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./userlist.php\">";
echo "
<span class=\"nav-main-link-name\">用户列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-book-open\"></i>";
echo "
<span class=\"nav-main-link-name\">文章管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditesli.php\">";
echo "
<span class=\"nav-main-link-name\">文章列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditessh.php\">";
echo "
<span class=\"nav-main-link-name\">审核文章</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-speech\"></i>";
echo "
<span class=\"nav-main-link-name\">评论管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditcoli.php\">";
echo "
<span class=\"nav-main-link-name\">评论列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditcosh.php\">";
echo "
<span class=\"nav-main-link-name\">审核评论</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-paper-clip\"></i>";
echo "
<span class=\"nav-main-link-name\">友链管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./linkset.php\">";
echo "
<span class=\"nav-main-link-name\">友链列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
</ul>";
echo "
</div>";
echo "
<!-- END Side Navigation -->";
echo "
</div>";
echo "
<!-- END Sidebar Scrolling -->";
echo "
</nav>";
echo "
<!-- END Sidebar -->";
echo "
";
echo "
<!-- Header -->";
echo "
<header id=\"page-header\">";
echo "
<!-- Header Content -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Left Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- Toggle Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-lg-none\" data-toggle=\"layout\" data-action=\"sidebar_toggle\">";
echo "
<i class=\"fa fa-fw fa-bars\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Sidebar -->";
echo "
";
echo "
<!-- Toggle Mini Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-none d-lg-inline-block\" data-toggle=\"layout\" data-action=\"sidebar_mini_toggle\">";
echo "
<i class=\"fa fa-fw fa-ellipsis-v\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Mini Sidebar -->";
echo "
";
echo "
<!-- Open Search Section (visible on smaller screens) -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
";
echo "
<!-- END Open Search Section -->";
echo "
";
echo "
<!-- Search Form (visible on larger screens) -->";
echo "
";
echo "
<!-- END Search Form -->";
echo "
</div>";
echo "
<!-- END Left Section -->";
echo "
";
echo "
<!-- Right Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- User Dropdown -->";
echo "
<div class=\"dropdown d-inline-block ms-2\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary d-flex align-items-center\" id=\"page-header-user-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<img class=\"rounded-circle\" src=\"";
$num=4931;
$curlOptResult=strpos($user_img, 'http');
$tmp=$curlOptResult!==false;
if($tmp){
    $num=20;
}else{
    $num=9;
}
switch($num){
    case 20:{
    echo $user_img;
        break;
    }
    case 9:{
        $tmp='.' . $user_img;
        echo $tmp;
        break;
    }
}
echo "\" alt=\"Header Avatar\" style=\"width: 21px;\">";
echo "
<span class=\"d-none d-sm-inline-block ms-2\">";
echo $user_name;
echo "</span>";
echo "
<i class=\"fa fa-fw fa-angle-down d-none d-sm-inline-block opacity-50 ms-1 mt-1\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-md dropdown-menu-end p-0 border-0\" aria-labelledby=\"page-header-user-dropdown\">";
echo "
<div class=\"p-3 text-center bg-body-light border-bottom rounded-top\">";
echo "
<img class=\"img-avatar img-avatar48 img-avatar-thumb\" src=\"";
$num2=4920;
$curlOptResult=strpos($user_img, 'http');
$tmp=$curlOptResult!==false;
if($tmp){
    $num2=25;
}else{
    $num2=12;
}
switch($num2){
    case 25:{
    echo $user_img;
        break;
    }
    case 12:{
        $tmp='.' . $user_img;
        echo $tmp;
        break;
    }
}
echo "\" alt=\"\">";
echo "
<p class=\"mt-2 mb-0 fw-medium\">";
echo $user_name;
echo "</p>";
echo "
<!--p class=\"mb-0 text-muted fs-sm fw-medium\">介绍</p-->";
echo "
</div>";
echo "
<div role=\"separator\" class=\"dropdown-divider m-0\"></div>";
echo "
<div class=\"p-2\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"../\">";
echo "
<span class=\"fs-sm fw-medium\">返回前台</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"JavaScript:;\" onclick=\"logut()\">";
echo "
<span class=\"fs-sm fw-medium\">退出登录</span>";
echo "
</a>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
<!-- END User Dropdown -->";
echo "
";
echo "
<!-- Notifications Dropdown -->";
echo "
";
echo "
<!-- END Notifications Dropdown -->";
echo "
";
echo "
<!-- Toggle Side Overlay -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
<!-- END Toggle Side Overlay -->";
echo "
</div>";
echo "
<!-- END Right Section -->";
echo "
</div>";
echo "
<!-- END Header Content -->";
echo "
";
echo "
<!-- Header Search -->";
echo "
";
echo "
<!-- END Header Search -->";
echo "
";
echo "
<!-- Header Loader -->";
echo "
<!-- Please check out the Loaders page under Components category to see examples of showing/hiding it -->";
echo "
<div id=\"page-header-loader\" class=\"overlay-header bg-body-extra-light\">";
echo "
<div class=\"content-header\">";
echo "
<div class=\"w-100 text-center\">";
echo "
<i class=\"fa fa-fw fa-circle-notch fa-spin\"></i>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Header Loader -->";
echo "
</header>";
echo "
<!-- END Header -->";
echo "
";
echo "
";
echo "
<!-- Main Container -->";
echo "
<main id=\"main-container\">";
echo "
";
echo "
<div class=\"content\">";
echo "
<div class=\"d-flex flex-column flex-md-row justify-content-md-between align-items-md-center py-2 text-center text-md-start\">";
echo "
<div class=\"flex-grow-1 mb-1 mb-md-0\">";
echo "
<h1 class=\"h3 fw-bold mb-2\">";
echo "
LAN - 后台管理";
echo "
</h1>";
echo "
<h2 class=\"h6 fw-medium fw-medium text-muted mb-0\">";
echo "
Welcome <a class=\"fw-semibold\" href=\"JavaScript:;\">";
echo $user_name;
echo "</a>, everything looks great.";
echo "
</h2>";
echo "
<h2 class=\"h6 fw-medium fw-medium text-muted mb-0\">";
echo "
授权有效期至：";
$curlOptResult=substr($auth_second);
$tmp=$curlOptResult . "-";
$substr=substr($auth_second);
$tmp2=$tmp . $substr;
$tmp3=$tmp2 . "-";
$substr2=substr($auth_second);
$formattedDate=$tmp3 . $substr2;
echo $formattedDate;
echo " 您可在到期前7天 <a class=\"fw-semibold\" href=\"./authver.php?condition=error\">重新授权</a>";
echo "
</h2>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
<!-- Page Content -->";
echo "
<div class=\"content\">";
echo "
";
$tmp=include "./api/updatever.php";
echo "";
echo "
<!-- Overview -->";
echo "
<div class=\"row items-push\">";
echo "
<div class=\"col-sm-6 col-xxl-3\">";
echo "
<!-- New Customers -->";
echo "
<div class=\"block block-rounded d-flex flex-column h-100 mb-0\">";
echo "
<div class=\"block-content block-content-full flex-grow-1 d-flex justify-content-between align-items-center\">";
echo "
<dl class=\"mb-0\">";
echo "
<dt class=\"fs-3 fw-bold\">";
echo $usercount;
echo "</dt>";
echo "
<dd class=\"fs-sm fw-medium fs-sm fw-medium text-muted mb-0\">用户总数</dd>";
echo "
</dl>";
echo "
<div class=\"item item-rounded-lg bg-body-light\">";
echo "
<i class=\"far fa-user-circle fs-3 text-primary\"></i>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"bg-body-light rounded-bottom\">";
echo "
<a class=\"block-content block-content-full block-content-sm fs-sm fw-medium d-flex align-items-center justify-content-between\" href=\"./userlist.php\">";
echo "
<span>查看详情</span>";
echo "
<i class=\"fa fa-arrow-alt-circle-right ms-1 opacity-25 fs-base\"></i>";
echo "
</a>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END New Customers -->";
echo "
</div>";
echo "
<div class=\"col-sm-6 col-xxl-3\">";
echo "
<!-- Pending Orders -->";
echo "
<div class=\"block block-rounded d-flex flex-column h-100 mb-0\">";
echo "
<div class=\"block-content block-content-full flex-grow-1 d-flex justify-content-between align-items-center\">";
echo "
<dl class=\"mb-0\">";
echo "
<dt class=\"fs-3 fw-bold\">";
echo $essaycount;
echo "</dt>";
echo "
<dd class=\"fs-sm fw-medium fs-sm fw-medium text-muted mb-0\">文章总数</dd>";
echo "
</dl>";
echo "
<div class=\"item item-rounded-lg bg-body-light\">";
echo "
<i class=\"fa fa-chart-bar fs-3 text-primary\"></i>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"bg-body-light rounded-bottom\">";
echo "
<a class=\"block-content block-content-full block-content-sm fs-sm fw-medium d-flex align-items-center justify-content-between\" href=\"./auditesli.php\">";
echo "
<span>查看详情</span>";
echo "
<i class=\"fa fa-arrow-alt-circle-right ms-1 opacity-25 fs-base\"></i>";
echo "
</a>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Pending Orders -->";
echo "
</div>";
echo "
<div class=\"col-sm-6 col-xxl-3\">";
echo "
<!-- Messages -->";
echo "
<div class=\"block block-rounded d-flex flex-column h-100 mb-0\">";
echo "
<div class=\"block-content block-content-full flex-grow-1 d-flex justify-content-between align-items-center\">";
echo "
<dl class=\"mb-0\">";
echo "
<dt class=\"fs-3 fw-bold\">";
echo $commcount;
echo "</dt>";
echo "
<dd class=\"fs-sm fw-medium fs-sm fw-medium text-muted mb-0\">评论总数</dd>";
echo "
</dl>";
echo "
<div class=\"item item-rounded-lg bg-body-light\">";
echo "
<i class=\"far fa-comment fs-3 text-primary\"></i>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"bg-body-light rounded-bottom\">";
echo "
<a class=\"block-content block-content-full block-content-sm fs-sm fw-medium d-flex align-items-center justify-content-between\" href=\"./auditcoli.php\">";
echo "
<span>查看详情</span>";
echo "
<i class=\"fa fa-arrow-alt-circle-right ms-1 opacity-25 fs-base\"></i>";
echo "
</a>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Messages -->";
echo "
</div>";
echo "
<div class=\"col-sm-6 col-xxl-3\">";
echo "
<!-- Conversion Rate -->";
echo "
<div class=\"block block-rounded d-flex flex-column h-100 mb-0\">";
echo "
<div class=\"block-content block-content-full flex-grow-1 d-flex justify-content-between align-items-center\">";
echo "
<dl class=\"mb-0\">";
echo "
<dt class=\"fs-3 fw-bold\">";
$num3=4930;
$tmp=sh_auth_state!="ok";
if($tmp){
    $num3=15;
}else{
    $num3=25;
}
switch($num3){
    case 15:{
    echo "未授权";
        break;
    }
    case 25:{
        echo "正常";
        break;
    }
}
echo "</dt>";
echo "
<dd class=\"fs-sm fw-medium fs-sm fw-medium text-muted mb-0\">授权状态</dd>";
echo "
</dl>";
echo "
<div class=\"item item-rounded-lg bg-body-light\">";
echo "
<i class=\"far fa-gem fs-3 text-primary\"></i>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"bg-body-light rounded-bottom\">";
echo "
<a class=\"block-content block-content-full block-content-sm fs-sm fw-medium d-flex align-items-center justify-content-between\" href=\"https://www.qemao.com\" target=\"_blank\">";
echo "
<span>授权中心</span>";
echo "
<i class=\"fa fa-arrow-alt-circle-right ms-1 opacity-25 fs-base\"></i>";
echo "
</a>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Conversion Rate-->";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Overview -->";
echo "
";
echo "
<!-- Statistics -->";
echo "
";
echo "          ";
echo "
";
echo "
";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\" role=\"tab\" id=\"faq1_h2\">";
echo "
<a class=\"text-muted collapsed\" data-bs-toggle=\"collapse\" data-bs-parent=\"#faq1\" href=\"#faq1_q2\" aria-expanded=\"false\" aria-controls=\"faq1_q2\">更新日志(";
$tmp="当前版本：" . $vernum;
echo $tmp;
echo ")</a>";
echo "
</div>";
echo "
<div id=\"faq1_q2\" class=\"collapse\" role=\"tabpanel\" aria-labelledby=\"faq1_h2\" data-bs-parent=\"#faq1\" style=\"height: 100%;max-height: 500px;overflow: hidden scroll;overscroll-behavior-y: contain;\">";
echo "
<div class=\"block-content\">";
echo "
<ul class=\"timeline timeline-alt py-0\">";
echo "
";
$url="https://www.qemao.com/files/lan/api/uplog.php";
$timeout=2;
$curlOptResult=curl_init();
$ch=$curlOptResult;
$curlOptResult=curl_setopt($ch, CURLOPT_URL, $url);
$curlOptResult=curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$curlOptResult=curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
$curlOptResult=curl_exec($ch);
$response=$curlOptResult;
$curlOptResult=curl_close($ch);
$num4=4932;
$tmp=$response===false;
if($tmp){
    $num4=20;
}else{
    $num4=20;
    $num4=9126;
}
$tmp=300;
$tmp2=20;
$tmp3=$num4==20;
if($tmp3)goto L2xeWjgx1f;
goto L2xldMhx1f;
L2xeWjgx1f:
$curlOptResult=curl_error($ch);
$error=$curlOptResult;
$tmp="Error: " . $error;
echo $tmp;
goto L2xx1e;
L2xldMhx1f:
$tmp=160;
$tmp2=4573;
$tmp3=$num4==4573;
if($tmp3)goto L2xeWjgx1g;
goto L2xldMhx1g;
L2xeWjgx1g:
$curlOptResult=json_decode($response, true);
$arrbblog=$curlOptResult;
$curlOptResult=is_array($arrbblog);
if($curlOptResult)goto L2xeWjgx16;
goto L2xx1e;
goto L2xx1e;
L2xeWjgx16:
$curlOptResult=array_reverse($arrbblog);
$arrbblog=$curlOptResult;
$tmp=$vernum<$vernumx;
if($tmp){
    $tisupxx=445;
}else{
    $tisupxx="";
}
$str=0;
$i=$str;
while(true){
    $curlOptResult=count($arrbblog);
    $tmp=$i<$curlOptResult;
    if(!$tmp)break;
    $tmp='<li class="timeline-event">
    <div class="timeline-event-icon bg-default">
    <i class="fa fa-1x fa-circle-arrow-up"></i>
    </div>
    <div class="timeline-event-block block">
    <div class="block-header">
    <h3 class="block-title">版本号：' . $arrbblog[$i]['bb'];
    $tmp2=$tmp . '</h3>
    <div class="block-options">
    <div class="timeline-event-time block-options-item fs-sm">
    时间：';
    $tmp3=4573 . $arrbblog[$i]['time'];
    $tmp4=$tmp3 . '
    </div>
    </div>
    </div>
    <div class="block-content">
    <p style="font-size: 14px;">
    ';
    $tmp5=$tmp4 . $arrbblog[$i]['text'];
    $tmp6=$tmp5 . '
    </p>
    </div>
    </div>
    </li>';
    echo $tmp6;
    $obj=$i;
    $obj2=$i+1;
    $str=$obj2;
    $i=$str;
}
goto L2xx1e;
L2xldMhx1g:
L2xx1e:
echo "                </ul>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Statistics -->";
echo "
";
echo "
<!-- Recent Orders -->";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\">站内通告</h3>";
echo "
";
echo "
</div>";
echo "
<div class=\"block-content\">";
echo "
<!-- If you put a checkbox in thead section, it will automatically toggle all tbody section checkboxes -->";
echo "
<table class=\"js-table-checkable table table-hover table-vcenter js-table-checkable-enabled\">";
echo "
<thead>";
echo "
<tr>";
echo "
<th>内容</th>";
echo "
<th class=\"d-none d-sm-table-cell\" style=\"width: 15%;\">标题</th>";
echo "
</tr>";
echo "
</thead>";
echo "
<tbody>";
echo "
";
echo "
";
$url="https://www.qemao.com/files/lan/api/admap.php";
$curlOptResult=curl_init();
$ch=$curlOptResult;
$curlOptResult=curl_setopt($ch, CURLOPT_URL, $url);
$curlOptResult=curl_setopt($ch, CURLOPT_RETURNTRANSFER);
$curlOptResult=curl_setopt($ch, CURLOPT_HEADER);
$curlOptResult=curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
$curlOptResult=curl_setopt($ch, CURLOPT_TIMEOUT);
$curlOptResult=curl_exec($ch);
$output=$curlOptResult;
$curlOptResult=curl_close($ch);
$curlOptResult=json_decode($output, true);
$arr=$curlOptResult;
$curlOptResult=is_array($arr);
if($curlOptResult){
$str=0;
$i=$str;
while(true){
    $curlOptResult=count($arr);
    $tmp=$i<$curlOptResult;
    if(!$tmp)break;
    $ggatitle=$arr[$i]['title'];
    $ggamsg=$arr[$i]['msg'];
    $ggadurl=$arr[$i]['url'];
    $ggadimg=$arr[$i]['img'];
    $tmp=$ggadurl=="JavaScript:;";
    if($tmp){
        $ggadurl='';
    }else{
        $tmp='target="_blank" href="' . $ggadurl;
        $ggadurl=$tmp . '"';
    }
    $tmp='<tr>
    <td class="fs-sm">
    <p class="fw-semibold mb-1">
    <a ' . $ggadurl;
    $tmp2=$tmp . '>';
    $tmp3=$tmp2 . $ggamsg;
    $tmp4=$tmp3 . '</a>
    </p>
    </td>
    <td class="d-none d-sm-table-cell">
    <span class="fs-xs fw-semibold d-inline-block py-1 px-3 rounded-pill bg-info-light text-info">';
    $tmp5=$tmp4 . $ggatitle;
    $tmp6=$tmp5 . '</span>
    </td>
    </tr>';
    echo $tmp6;
    $obj2=$i;
    $obj3=$i+1;
    $str=$obj3;
    $i=$str;
}
}else{
}
L2xx1y:
echo "                  ";
echo "
";
echo "
</tbody>";
echo "
</table>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Recent Orders -->";
echo "
</div>";
echo "
<!-- END Page Content -->";
echo "
</main>";
echo "
<!-- END Main Container -->";
echo "
";
echo "
<!-- Footer -->";
echo "
<footer id=\"page-footer\" class=\"bg-body-light\">";
echo "
<div class=\"content py-3\">";
echo "
<div class=\"row fs-sm\">";
echo "
<div class=\"col-sm-6 order-sm-2 py-1 text-center text-sm-end\">";
echo "
Crafted with <i class=\"fa fa-heart text-danger\"></i> by <a class=\"fw-semibold\" href=\"https://qemao.com\" target=\"_blank\">苏画</a>";
echo "
</div>";
echo "
<div class=\"col-sm-6 order-sm-1 py-1 text-center text-sm-start\">";
echo "
<a class=\"fw-semibold\" href=\"https://www.qemao.com\" target=\"_blank\">LAN</a> &copy; <span data-toggle=\"year-copy\"></span>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</footer>";
echo "
<!-- END Footer -->";
echo "
</div>";
echo "
<!-- END Page Container -->";
echo "
";
echo "
<!--";
echo "
OneUI JS";
echo "
";
echo "
Core libraries and functionality";
echo "
webpack is putting everything together at assets/_js/main/app.js";
echo "
-->";
echo "
<script src=\"assets/js/oneui.app.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Plugins -->";
echo "
<script src=\"assets/js/chart.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Code -->";
echo "
<script src=\"assets/js/be_pages_dashboard.min.js\"></script>";
echo "
</body>";
echo "
</html>";
echo "
";