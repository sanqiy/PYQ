<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val3["code"]="201";
    $val3["msg"]="非法请求";
    $arr2[]=$val3;
    $arr=$arr2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp2=$user_zh=="";
$tmp3=(bool)$tmp2;
$tmp4=!$tmp3;
if($tmp4){
    $tmp5=$user_passid=="";
    $tmp3=(bool)$tmp5;
}
if($tmp3){
    exit('<script language="JavaScript">;alert("请先登录!");location.href="../index.php";</script>');
}
$tmp2=include '../config.php';
$tmp2=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp2;
if($conn->connect_error){
    exit('<script language="JavaScript">;alert("连接数据库失败");location.href="../edit.php";</script>');
}
$escaped=htmlspecialchars($user_zh);
$cookieResult=addslashes($escaped);
$user_zhsg=$cookieResult;
$tmp2="select * from user where username='" . $user_zhsg;
$sqls=$tmp2 . "'";
$row=mysqli_query($conn, $sqls);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$data2s_row=$row;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($str))break;
    $name=$row["name"];
    $subtitle=$row["subtitle"];
    $icon=$row["icon"];
    $logo=$row["logo"];
    $zt=$row["zt"];
    $glyusername=$row["username"];
    $username=$row["username"];
    $glyadmin=$row["username"];
    $homimg=$row["homimg"];
    $sign=$row["sign"];
    $wzmusic=$row["music"];
    $essgs=$row["essgs"];
    $commgs=$row["commgs"];
    $lnkzt=$row["lnkzt"];
    $regqx=$row["regqx"];
    $kqsy=$row["kqsy"];
    $comaud=$row["comaud"];
    $ptpaud=$row["ptpaud"];
    $ptpfan=$row["ptpfan"];
    $loginkg=$row["loginkg"];
    $notname=$row["notname"];
    $imgpres=$row["imgpres"];
    $rosdomain=$row["rosdomain"];
    $daymode=$row["daymode"];
    $gotop=$row["gotop"];
    $search=$row["search"];
    $videoauplay=$row["videoauplay"];
    $regverify=$row["regverify"];
    $pagepass=$row["pagepass"];
    $emydz=$row["emydz"];
    $emssl=$row["emssl"];
    $emduk=$row["emduk"];
    $emkey=$row["emkey"];
    $emzh=$row["emzh"];
    $emfs=$row["emfs"];
    $emfszm=$row["emfszm"];
    $copyright=$row["copyright"];
    $beian=$row["beian"];
    $topes=$row["topes"];
    $scfont=$row["scfont"];
    $viscomm=$row["viscomm"];
    $musplay=$row["musplay"];
    $sigin=$row["sigin"];
    $rnking=$row["rnking"];
    $rnggy=$row["rnggy"];
    $dywptp=$row["dywptp"];
    $topwcz=$row["topwcz"];
    $imgyunc=$row["imgyunc"];
    $date=$row["date"];
}
L2xxj:
$str2="select * from user where username='" . $user_zh;
$str3=$str2 . "'";
$row=mysqli_query($conn, $str3);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjwallet=$data2_row["wallet"];
$zjussig=$data2_row["ussig"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
$ban=$data2_row["ban"];
$bantime=$data2_row["bantime"];
if($user_passid!=$passid){
    $escaped=time();
    $str2=$escaped+ -1;
    $cookieResult=setcookie("username", "", $str2, "/");
    $escaped=time();
    $str2=$escaped+ -1;
    $cookieResult=setcookie("passid", "", $str2, "/");
    exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="../index.php";</script>;');
}
$tmp2=$ban!="0";
$tmp3=(bool)$tmp2;
if($tmp3){
    $tmp5=$bantime!="false";
    $tmp3=(bool)$tmp5;
}
if($tmp3)goto L2xeWjgxw;
goto L2xldMhxw;
L2xeWjgxw:
$tmp2=$bantime==="true";
if($tmp2)goto L2xeWjgxu;
goto L2xldMhxu;
goto L2xldMhxu;
L2xeWjgxu:
$escaped=time();
$str2=$escaped+ -1;
$cookieResult=setcookie("username", "", $str2, "/");
$escaped=time();
$str2=$escaped+ -1;
$cookieResult=setcookie("passid", "", $str2, "/");
exit('<script language="JavaScript">;alert("该账号涉嫌违规,已被永久封禁!");location.href="../index.php";</script>');
goto L2xxv;
L2xldMhxu:
$escaped=time();
$str2=$escaped+ -1;
$cookieResult=setcookie("username", "", $str2, "/");
$escaped=time();
$str2=$escaped+ -1;
$cookieResult=setcookie("passid", "", $str2, "/");
$tmp2='<script language="JavaScript">;alert("你的账号已被封禁！解封时间为:' . $bantime;
exit($tmp2 . '");location.href="../index.php";</script>');
L2xldMhxw:
L2xxv:
$filtertext="";
$sql="SELECT text FROM configx WHERE title = 'filtertext'";
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0){
    $result=$result->fetch_assoc();
    $row=$result;
    $filtertext=$row['text'];
}
$num11=4100;
$isArray=is_array($_POST);
if($isArray){
    $num11=208;
}else{
    $num11=52;
}
switch($num11){
    case 52:{
    $allkey=$_POST["allkey"];
        break;
    }
    case 208:{
        $allkey=&$_POST["allkey"];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$allkey=$escaped3;
if($allkey==""){
    exit('<script language="JavaScript">;alert("请传入秘钥");location.href="../edit.php";</script>;');
}
$row=session_start();
$cloudallkey=$_SESSION['allkey'];
$serverVal=$_SERVER['HTTP_HOST'] . "aI4cG0nO3kT5mQ4mL4qL7eP6sL2oS5rS";
$escaped=md5($serverVal);
$cookieResult=md5($escaped);
$appintkey=$cookieResult;
if($allkey!=$cloudallkey)goto L2xeWjgx1i;
goto L2xldMhx1i;
L2xeWjgx1i:
$tmp2=$allkey==$appintkey;
if($tmp2)goto L2xx1h;
goto L2xldMhx1g;
L2xldMhx1g:
exit('<script language="JavaScript">;alert("秘钥错误");location.href="../edit.php";</script>;');
L2xldMhx1i:
L2xx1h:
$edwzadmin=$_POST['edwzadmin'];
$num12=4108;
$tmp2=$edwzadmin!="";
$tmp3=(bool)$tmp2;
if($tmp3){
    $escaped=md5($edwzadmin);
    $cookieResult=md5($escaped);
    $tmp5=$cookieResult=="b64ac4cd37291d7e180752e7c3e55ba3";
    $tmp3=(bool)$tmp5;
}
if($tmp3){
    $num12=60;
}else{
    $num12=64;
}
$tmp2=57;
$tmp5=64;
$tmp3=$num12==64;
if($tmp3)goto L2xeWjgx21;
goto L2xldMhx21;
L2xeWjgx21:
$tmp2=$kqsy==1;
if($tmp2)goto L2xeWjgx1q;
goto L2xldMhx1q;
goto L2xldMhx1q;
L2xeWjgx1q:
$tmp2=$zjfbqx==1;
$tmp3=(bool)$tmp2;
$tmp6=!$tmp3;
if($tmp6){
    $tmp5=$zjfbqx==2;
    $tmp3=(bool)$tmp5;
}
$tmp4=!$tmp3;
if($tmp4)goto L2xeWjgx1u;
goto L2xx2z;
goto L2xx2z;
L2xeWjgx1u:
exit('<script>alert("您没有发布权限!");location.href="../edit.php";</script>');
goto L2xx2z;
L2xldMhx1q:
$tmp2=$zjzhq!=$glyusername;
if($tmp2)goto L2xeWjgx1w;
goto L2xx2z;
goto L2xx2z;
L2xeWjgx1w:
$tmp2=$zjfbqx==2;
$tmp5=!$tmp2;
if($tmp5)goto L2xeWjgx1y;
goto L2xx2z;
goto L2xx2z;
L2xeWjgx1y:
exit('<script>alert("管理员未开启所有用户发布权限!");location.href="../edit.php";</script>');
goto L2xx2z;
L2xldMhx21:
$tmp2=27;
$tmp5=60;
$tmp3=$num12==60;
L2xx2z:
if(!($tmp3)){
}else{
    $str="Y";
    $Y=$str;
    $str="m";
    $m=$str;
    $str="d";
    $d=$str;
    $str="H";
    $H=$str;
    $str="i";
    $i=$str;
    $str="s";
    $s=$str;
    $str2=$Y . $m;
    $str3=$str2 . $d;
    $val64=$str3 . $H;
    $val65=$val64 . $i;
    $val66=$val65 . $s;
    $row=date($val66);
    $sj=$row;
    $num13=4106;
    if($HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"]){
        $num13=256;
    }else{
        if($HTTP_SERVER_VARS["HTTP_CLIENT_IP"]){
            $num13=100;
        }else{
            if($HTTP_SERVER_VARS["REMOTE_ADDR"]){
                $num13=60;
            }else{
                $row=getenv("HTTP_X_FORWARDED_FOR");
                if($row){
                    $num13=64;
                }else{
                    $row=getenv("HTTP_CLIENT_IP");
                    if($row){
                        $num13=24;
                    }else{
                        $row=getenv("REMOTE_ADDR");
                        if($row){
                            $num13=256;
                            $num13=4664;
                        }else{
                            $num13=96;
                        }
                    }
                }
            }
        }
    }
    switch($num13){
        case 96:{
        $ip="Unknown";
            break;
        }
        case 64:{
            $row=getenv("HTTP_X_FORWARDED_FOR");
            $ip=$row;
            break;
        }
        case 60:{
                $ip=$HTTP_SERVER_VARS["REMOTE_ADDR"];
            break;
        }
        case 100:{
                    $ip=$HTTP_SERVER_VARS["HTTP_CLIENT_IP"];
            break;
        }
        case 256:{
                        $ip=$HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"];
            break;
        }
        case 24:{
                            $row=getenv("HTTP_CLIENT_IP");
                            $ip=$row;
            break;
        }
        case 2460:{
                                $row=getenv("REMOTE_ADDR");
                                $ip=$row;
            break;
        }
    }
    $sql="SELECT ptptime FROM essay";
    $row=mysqli_query($conn, $sql);
    $result=$row;
}
L2xx2s:
while(true){
    $row=mysqli_fetch_assoc($result);
    $row=$row;
    if(!($str))break;
if($row['ptptime']==$sj)goto L2xeWjgx2x;
goto L2xx2s;
goto L2xx2s;
goto L2xx2s;
L2xeWjgx2x:
    exit('<script language="JavaScript">;alert("发布频率过快,请稍后再试!");location.href="../edit.php";</script>;');
}
L2xx35:
$escaped=microtime(true);
$cookieResult=str_replace('.', '', $escaped);
$microtime=$cookieResult;
$randomDigits='';
L2xx3b:
$i=0;
while(true){
    $tmp2=$i<5;
    if(!($tmp2))break;
    $row=rand();
    $randomDigits=$randomDigits . $row;
    $val67=$randomDigits;
    $obj=$i;
    $obj2=$i+1;
    $str=$obj2;
    $i=$str;
}
L2xx3j:
$row=strlen($randomDigits);
$tmp2=$row<5;
if($tmp2)goto L2xx3b;
goto L2xldMhx3o;
goto L2xx3n;
L2xldMhx3o:
L2xx3n:
$str=$microtime . $randomDigits;
$base64Arr=$_POST['image'];
$num14=4108;
$isArray=is_array($_POST);
if($isArray){
    $num14=160;
}else{
    $num14=208;
}
switch($num14){
    case 208:{
    $allkey=$_POST['imgul'];
        break;
    }
    case 160:{
        $allkey=&$_POST['imgul'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$imgul=$escaped3;
$num15=4114;
$isArray=is_array($_POST);
if($isArray){
    $num15=208;
}else{
    $num15=130;
}
switch($num15){
    case 130:{
    $allkey=$_POST['radio'];
        break;
    }
    case 208:{
        $allkey=&$_POST['radio'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$lx=$escaped3;
$num16=4114;
$isArray=is_array($_POST);
if($isArray){
    $num16=40;
}else{
    $num16=96;
}
switch($num16){
    case 96:{
    $text=$_POST['text'];
        break;
    }
    case 40:{
        $text=&$_POST['text'];
        break;
    }
}
$replaced=filterEmoji($text);
unset($text);
$escaped2=htmlspecialchars($replaced);
$writeResult=addslashes($escaped2);
$text=$writeResult;
$num17=4103;
$isArray=is_array($_POST);
if($isArray){
    $num17=96;
}else{
    $num17=78;
}
switch($num17){
    case 96:{
    $allkey=&$_POST['dw'];
        break;
    }
    case 78:{
        $allkey=$_POST['dw'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$dw=$escaped3;
$num18=4105;
$isArray=is_array($_POST);
if($isArray){
    $num18=36;
}else{
    $num18=64;
}
switch($num18){
    case 36:{
    $allkey=&$_POST['radiogg'];
        break;
    }
    case 64:{
        $allkey=$_POST['radiogg'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$gg=$escaped3;
$num19=4115;
$isArray=is_array($_POST);
if($isArray){
    $num19=24;
}else{
    $num19=24;
    $num19=3320;
}
switch($num19){
    case 24:{
    $allkey=&$_POST['yxplkg'];
        break;
    }
    case 1672:{
        $allkey=$_POST['yxplkg'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$yxplkg=$escaped3;
$num20=4100;
$isArray=is_array($_POST);
if($isArray){
    $num20=52;
}else{
    $num20=96;
}
switch($num20){
    case 52:{
    $allkey=&$_POST['nmkg'];
        break;
    }
    case 96:{
        $allkey=$_POST['nmkg'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$nmkg=$escaped3;
$num21=4115;
$isArray=is_array($_POST);
if($isArray){
    $num21=160;
}else{
    $num21=16;
}
switch($num21){
    case 160:{
    $allkey=&$_POST['gg'];
        break;
    }
    case 16:{
        $allkey=$_POST['gg'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$gglj=$escaped3;
$num22=4114;
$isArray=is_array($_POST);
if($isArray){
    $num22=40;
}else{
    $num22=60;
}
switch($num22){
    case 40:{
    $allkey=&$_POST['spp'];
        break;
    }
    case 60:{
        $allkey=$_POST['spp'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$spp=$escaped3;
$num23=4106;
$isArray=is_array($_POST);
if($isArray){
    $num23=208;
}else{
    $num23=40;
}
switch($num23){
    case 208:{
    $allkey=&$_POST['sppfm'];
        break;
    }
    case 40:{
        $allkey=$_POST['sppfm'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$sppfm=$escaped3;
$spfle=$_POST['file'];
$num24=4111;
$isArray=is_array($_POST);
if($isArray){
    $num24=40;
}else{
    $num24=52;
}
switch($num24){
    case 52:{
    $allkey=$_POST['music'];
        break;
    }
    case 40:{
        $allkey=&$_POST['music'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$music=$escaped3;
$num25=4106;
$isArray=is_array($_POST);
if($isArray){
    $num25=78;
}else{
    $num25=160;
}
switch($num25){
    case 160:{
    $allkey=$_POST['musicm'];
        break;
    }
    case 78:{
        $allkey=&$_POST['musicm'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$musicm=$escaped3;
$num26=4107;
$isArray=is_array($_POST);
if($isArray){
    $num26=60;
}else{
    $num26=60;
    $num26=6794;
}
switch($num26){
    case 60:{
    $allkey=&$_POST['musics'];
        break;
    }
    case 3427:{
        $allkey=$_POST['musics'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$musics=$escaped3;
$num27=4102;
$isArray=is_array($_POST);
if($isArray){
    $num27=78;
}else{
    $num27=96;
}
switch($num27){
    case 96:{
    $allkey=$_POST['musict'];
        break;
    }
    case 78:{
        $allkey=&$_POST['musict'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$musict=$escaped3;
$row=str_replace(PHP_EOL, "<br>", $text);
$text=$row;
$num28=4114;
$isArray=is_array($_POST);
if($isArray){
    $num28=52;
}else{
    $num28=40;
}
switch($num28){
    case 52:{
    $allkey=&$_POST['edlx'];
        break;
    }
    case 40:{
        $allkey=$_POST['edlx'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$edlx=$escaped3;
$num29=4110;
$isArray=is_array($_POST);
if($isArray){
    $num29=256;
}else{
    $num29=130;
}
switch($num29){
    case 256:{
    $allkey=&$_POST['fbtime'];
        break;
    }
    case 130:{
        $allkey=$_POST['fbtime'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$fbtime=$escaped3;
$num30=4097;
$isArray=is_array($_POST);
if($isArray){
    $num30=208;
}else{
    $num30=130;
}
switch($num30){
    case 130:{
    $allkey=$_POST['edwzcid'];
        break;
    }
    case 208:{
        $allkey=&$_POST['edwzcid'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$edwzcid=$escaped3;
$row=iconv_strlen($text, "UTF-8");
$tmp2=$row>50000;
if($tmp2){
    exit('<script language="JavaScript">;alert("字数超过最大限制!");location.href="../edit.php";</script>;');
}
if($filtertext!=""){
    $row=json_decode($filtertext, true);
    $arrayData=$row;
    $row=str_replace($arrayData, "*", $text);
    $text=$row;
}
$emwz=$text;
if($gg==1)goto L2xeWjgx6q;
goto L2xldMhx6q;
L2xeWjgx6q:
$tmp2=$zjzhq!=$glyusername;
if($tmp2)goto L2xeWjgx6g;
goto L2xldMhx6g;
goto L2xldMhx6g;
L2xeWjgx6g:
$tmp2=$zjfbqx==2;
$tmp5=!$tmp2;
if($tmp5)goto L2xeWjgx6i;
goto L2xx6f;
goto L2xx6f;
L2xeWjgx6i:
$tmp2=$rnggy>$zjwallet;
if($tmp2)goto L2xeWjgx6k;
goto L2xx6f;
goto L2xx6f;
L2xeWjgx6k:
$tmp2='<script language="JavaScript">;alert("发布广告需要:' . $rnggy;
exit($tmp2 . '余额,您的余额不足!");location.href="../edit.php";</script>;');
goto L2xx6f;
L2xldMhx6g:
L2xx6f:
$tmp2=$gglj=="";
if($tmp2){
    exit('<script language="JavaScript">;alert("请输入广告地址!");location.href="../edit.php";</script>;');
}
$row=preg_match("/^(http:\/\/|https:\/\/).*$/", $gglj);
$tmp2=!$row;
if($tmp2)goto L2xeWjgx6o;
goto L2xx6p;
goto L2xx6p;
L2xeWjgx6o:
exit('<script language="JavaScript">;alert("请输入正确的广告地址链接!");location.href="../edit.php";</script>;');
goto L2xx6p;
L2xldMhx6q:
L2xx6p:
if($notname==1)goto L2xeWjgx77;
goto L2xldMhx77;
L2xeWjgx77:
$tmp2=$nmkg==1;
if($tmp2)goto L2xeWjgx75;
goto L2xx76;
goto L2xx76;
L2xeWjgx75:
$zjnc="匿名用户";
$zjimg="./assets/img/anonymous.png";
goto L2xx76;
L2xldMhx77:
L2xx76:
$row=parseUrls($text);
$textes=$row;
$val3["title"]="::(呵呵)";
$val3["img"]="./assets/owo/paopao/E591B5E591B5_2x.png";
$val4["title"]="::(哈哈)";
$val4["img"]="./assets/owo/paopao/E59388E59388_2x.png";
$val5["title"]="::(吐舌)";
$val5["img"]="./assets/owo/paopao/E59090E8888C_2x.png";
$val6["title"]="::(太开心)";
$val6["img"]="./assets/owo/paopao/E5A4AAE5BC80E5BF83_2x.png";
$val7["title"]="::(笑眼)";
$val7["img"]="./assets/owo/paopao/E7AC91E79CBC_2x.png";
$val8["title"]="::(花心)";
$val8["img"]="./assets/owo/paopao/E88AB1E5BF83_2x.png";
$val9["title"]="::(小乖)";
$val9["img"]="./assets/owo/paopao/E5B08FE4B996_2x.png";
$val10["title"]="::(乖)";
$val10["img"]="./assets/owo/paopao/E4B996_2x.png";
$val11["title"]="::(捂嘴笑)";
$val11["img"]="./assets/owo/paopao/E68D82E598B4E7AC91_2x.png";
$val12["title"]="::(滑稽)";
$val12["img"]="./assets/owo/paopao/E6BB91E7A8BD_2x.png";
$val13["title"]="::(你懂的)";
$val13["img"]="./assets/owo/paopao/E4BDA0E68782E79A84_2x.png";
$val14["title"]="::(不高兴)";
$val14["img"]="./assets/owo/paopao/E4B88DE9AB98E585B4_2x.png";
$val15["title"]="::(怒)";
$val15["img"]="./assets/owo/paopao/E68092_2x.png";
$val16["title"]="::(汗)";
$val16["img"]="./assets/owo/paopao/E6B197_2x.png";
$val17["title"]="::(黑线)";
$val17["img"]="./assets/owo/paopao/E9BB91E7BABF_2x.png";
$val18["title"]="::(泪)";
$val18["img"]="./assets/owo/paopao/E6B3AA_2x.png";
$val19["title"]="::(真棒)";
$val19["img"]="./assets/owo/paopao/E79C9FE6A392_2x.png";
$val20["title"]="::(喷)";
$val20["img"]="./assets/owo/paopao/E596B7_2x.png";
$val21["title"]="::(惊哭)";
$val21["img"]="./assets/owo/paopao/E6838AE593AD_2x.png";
$val22["title"]="::(阴险)";
$val22["img"]="./assets/owo/paopao/E998B4E999A9_2x.png";
$val23["title"]="::(鄙视)";
$val23["img"]="./assets/owo/paopao/E98499E8A786_2x.png";
$val24["title"]="::(酷)";
$val24["img"]="./assets/owo/paopao/E985B7_2x.png";
$val25["title"]="::(啊)";
$val25["img"]="./assets/owo/paopao/E5958A_2x.png";
$val26["title"]="::(狂汗)";
$val26["img"]="./assets/owo/paopao/E78B82E6B197_2x.png";
$val27["title"]="::(what)";
$val27["img"]="./assets/owo/paopao/what_2x.png";
$val28["title"]="::(疑问)";
$val28["img"]="./assets/owo/paopao/E79691E997AE_2x.png";
$val29["title"]="::(酸爽)";
$val29["img"]="./assets/owo/paopao/E985B8E788BD_2x.png";
$val30["title"]="::(呀咩蹀)";
$val30["img"]="./assets/owo/paopao/E59180E592A9E788B9_2x.png";
$val31["title"]="::(委屈)";
$val31["img"]="./assets/owo/paopao/E5A794E5B188_2x.png";
$val32["title"]="::(惊讶)";
$val32["img"]="./assets/owo/paopao/E6838AE8AEB6_2x.png";
$val33["title"]="::(睡觉)";
$val33["img"]="./assets/owo/paopao/E79DA1E8A789_2x.png";
$val34["title"]="::(笑尿)";
$val34["img"]="./assets/owo/paopao/E7AC91E5B0BF_2x.png";
$val35["title"]="::(挖鼻)";
$val35["img"]="./assets/owo/paopao/E68C96E9BCBB_2x.png";
$val36["title"]="::(吐)";
$val36["img"]="./assets/owo/paopao/E59090_2x.png";
$val37["title"]="::(犀利)";
$val37["img"]="./assets/owo/paopao/E78A80E588A9_2x.png";
$val38["title"]="::(小红脸)";
$val38["img"]="./assets/owo/paopao/E5B08FE7BAA2E884B8_2x.png";
$val39["title"]="::(懒得理)";
$val39["img"]="./assets/owo/paopao/E68792E5BE97E79086_2x.png";
$val40["title"]="::(勉强)";
$val40["img"]="./assets/owo/paopao/E58B89E5BCBA_2x.png";
$val41["title"]="::(爱心)";
$val41["img"]="./assets/owo/paopao/E788B1E5BF83_2x.png";
$val42["title"]="::(心碎)";
$val42["img"]="./assets/owo/paopao/E5BF83E7A28E_2x.png";
$val43["title"]="::(玫瑰)";
$val43["img"]="./assets/owo/paopao/E78EABE791B0_2x.png";
$val44["title"]="::(礼物)";
$val44["img"]="./assets/owo/paopao/E7A4BCE789A9_2x.png";
$val45["title"]="::(彩虹)";
$val45["img"]="./assets/owo/paopao/E5BDA9E899B9_2x.png";
$val46["title"]="::(太阳)";
$val46["img"]="./assets/owo/paopao/E5A4AAE998B3_2x.png";
$val47["title"]="::(星星月亮)";
$val47["img"]="./assets/owo/paopao/E6989FE6989FE69C88E4BAAE_2x.png";
$val48["title"]="::(钱币)";
$val48["img"]="./assets/owo/paopao/E992B1E5B881_2x.png";
$val49["title"]="::(茶杯)";
$val49["img"]="./assets/owo/paopao/E88CB6E69DAF_2x.png";
$val50["title"]="::(蛋糕)";
$val50["img"]="./assets/owo/paopao/E89B8BE7B395_2x.png";
$val51["title"]="::(大拇指)";
$val51["img"]="./assets/owo/paopao/E5A4A7E68B87E68C87_2x.png";
$val52["title"]="::(胜利)";
$val52["img"]="./assets/owo/paopao/E8839CE588A9_2x.png";
$val53["title"]="::(haha)";
$val53["img"]="./assets/owo/paopao/haha_2x.png";
$val54["title"]="::(OK)";
$val54["img"]="./assets/owo/paopao/OK_2x.png";
$val55["title"]="::(沙发)";
$val55["img"]="./assets/owo/paopao/E6B299E58F91_2x.png";
$val56["title"]="::手纸";
$val56["img"]="./assets/owo/paopao/E6898BE7BAB8_2x.png";
$val57["title"]="::(香蕉)";
$val57["img"]="./assets/owo/paopao/E9A699E89589_2x.png";
$val58["title"]="::(便便)";
$val58["img"]="./assets/owo/paopao/E4BEBFE4BEBF_2x.png";
$val59["title"]="::(药丸)";
$val59["img"]="./assets/owo/paopao/E88DAFE4B8B8_2x.png";
$val60["title"]="::(红领巾)";
$val60["img"]="./assets/owo/paopao/E7BAA2E9A286E5B7BE_2x.png";
$val61["title"]="::(蜡烛)";
$val61["img"]="./assets/owo/paopao/E89CA1E7839B_2x.png";
$val62["title"]="::(音乐)";
$val62["img"]="./assets/owo/paopao/E99FB3E4B990_2x.png";
$val63["title"]="::(灯泡)";
$val63["img"]="./assets/owo/paopao/E781AFE6B3A1_2x.png";
$val68[]=$val3;
$val68[]=$val4;
$val68[]=$val5;
$val68[]=$val6;
$val68[]=$val7;
$val68[]=$val8;
$val68[]=$val9;
$val68[]=$val10;
$val68[]=$val11;
$val68[]=$val12;
$val68[]=$val13;
$val68[]=$val14;
$val68[]=$val15;
$val68[]=$val16;
$val68[]=$val17;
$val68[]=$val18;
$val68[]=$val19;
$val68[]=$val20;
$val68[]=$val21;
$val68[]=$val22;
$val68[]=$val23;
$val68[]=$val24;
$val68[]=$val25;
$val68[]=$val26;
$val68[]=$val27;
$val68[]=$val28;
$val68[]=$val29;
$val68[]=$val30;
$val68[]=$val31;
$val68[]=$val32;
$val68[]=$val33;
$val68[]=$val34;
$val68[]=$val35;
$val68[]=$val36;
$val68[]=$val37;
$val68[]=$val38;
$val68[]=$val39;
$val68[]=$val40;
$val68[]=$val41;
$val68[]=$val42;
$val68[]=$val43;
$val68[]=$val44;
$val68[]=$val45;
$val68[]=$val46;
$val68[]=$val47;
$val68[]=$val48;
$val68[]=$val49;
$val68[]=$val50;
$val68[]=$val51;
$val68[]=$val52;
$val68[]=$val53;
$val68[]=$val54;
$val68[]=$val55;
$val68[]=$val56;
$val68[]=$val57;
$val68[]=$val58;
$val68[]=$val59;
$val68[]=$val60;
$val68[]=$val61;
$val68[]=$val62;
$val68[]=$val63;
$arr=$val68;
$i=0;
while(true){
    $row=count($arr);
    $tmp2=$i<$row;
    if(!($tmp2))break;
    $danm=$arr[$i]["title"];
    $dang=$arr[$i]["img"];
    $tmp2='<span class="sh-nr-bq-img-wk"><img src="./assets/img/thumbnail.svg" data-src="' . $dang;
    $tmp5=$tmp2 . '" class="sh-nr-bq-img" alt="';
    $tmp3=$tmp5 . $danm;
    $aeimg=$tmp3 . '"></span>';
    $row=str_ireplace($danm, $aeimg, $textes);
    $textes=$row;
    $obj2=$i;
    $obj3=$i+1;
    $str=$obj3;
    $i=$str;
}
L2xx7f:
$text=$textes;
$num=4101;
$tmp2=$zjzhq==$glyusername;
if($tmp2){
    $num=24;
}else{
    $num=40;
}
$tmp2=176;
$tmp5=24;
$tmp3=$num==24;
if($tmp3)goto L2xeWjgx7q;
goto L2xldMhx7q;
L2xeWjgx7q:
$ptpaud=0;
$ptpaudzt=1;
goto L2xx7p;
L2xldMhx7q:
$tmp2=56;
$tmp5=40;
$tmp3=$num==40;
if($tmp3)goto L2xeWjgx7r;
goto L2xldMhx7r;
L2xeWjgx7r:
$tmp2=$edwzadmin!="";
$tmp3=(bool)$tmp2;
if($tmp3){
    $escaped=md5($edwzadmin);
    $cookieResult=md5($escaped);
    $tmp5=$cookieResult=="eb8a165d75ba24c35be2e73209fb7174";
    $tmp3=(bool)$tmp5;
}
if($tmp3)goto L2xx7p;
goto L2xldMhx7m;
L2xldMhx7m:
$tmp2=$ptpaud==0;
if($tmp2)goto L2xeWjgx7o;
goto L2xldMhx7o;
goto L2xldMhx7o;
L2xeWjgx7o:
$ptpaudzt=1;
goto L2xx7p;
L2xldMhx7o:
$ptpaudzt=0;
L2xldMhx7r:
L2xx7p:
$row=is_dir("../upload/");
$tmp2=!$row;
if($tmp2){
    $row=mkdir("../upload/");
}
if($edlx=='edites')goto L2xeWjgx8k;
goto L2xldMhx8k;
L2xeWjgx8k:
$tmp2=$edwzcid!="";
if($tmp2)goto L2xeWjgx86;
goto L2xldMhx86;
goto L2xldMhx86;
L2xeWjgx86:
$tmp2="select * from essay where cid = '" . $edwzcid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
$row=mysqli_num_rows($result);
$tmp2=$row>0;
if($tmp2)goto L2xeWjgx88;
goto L2xldMhx88;
goto L2xldMhx88;
L2xeWjgx88:
$row=mysqli_fetch_assoc($result);
$row=$row;
$edbjwzid=$row["id"];
$ptpimag=$row["ptpimag"];
goto L2xx85;
L2xldMhx88:
$referer=$_SERVER['HTTP_REFERER'];
$tmp2='<script language="JavaScript">;alert("文章不存在");location.href="' . $referer;
exit($tmp2 . '";</script>;');
L2xldMhx86:
$referer=$_SERVER['HTTP_REFERER'];
$tmp2='<script language="JavaScript">;alert("未传入文章数据");location.href="' . $referer;
exit($tmp2 . '";</script>;');
L2xx85:
$tmp2=$zjzhq==$glyadmin;
if($tmp2)goto L2xx89;
goto L2xldMhx8a;
L2xldMhx8a:
$tmp2="select * from essay where cid= '" . $edwzcid;
$sql=$tmp2 . "'";
$row=mysqli_query($conn, $sql);
$result=$row;
$row=mysqli_num_rows($result);
$tmp2=$row>0;
if($tmp2){
    $row=mysqli_fetch_assoc($result);
    $row=$row;
    $ptpuser=$row["ptpuser"];
}else{
    $referer=$_SERVER['HTTP_REFERER'];
    $tmp2='<script language="JavaScript">;alert("未获取到文章数据");location.href="' . $referer;
    exit($tmp2 . '";</script>;');
}
$tmp2=$zjzhq==$ptpuser;
if(!($tmp2)){
    $referer=$_SERVER['HTTP_REFERER'];
    $tmp2='<script language="JavaScript">;alert("您无权操作其他用户的文章");location.href="' . $referer;
    exit($tmp2 . '";</script>;');
}
L2xx89:
if(1){function isTimeString($str) {
    $format='Y-m-d H:i:s';
    $str=DateTime::createFromFormat($format,$str);
    $dateTime=$str;
    $tmp5=(bool)$dateTime;
    $tmp3=120;
    $tmp4=180;
    if($tmp5){
        $result=$dateTime->format($format);
        $tmp2=$result===$str;
        $tmp5=(bool)$tmp2;
    }
    return $tmp5;
}}$arr2=array();
$row=isTimeString($fbtime);
$isTime=$row;
if($isTime){
    $tmp2=",ptptime='" . $fbtime;
    $wftime=$tmp2 . "'";
}else{
    $wftime='';
}
$tmp2="UPDATE essay SET ptptext='" . $text;
$tmp5=$tmp2 . "',ptpdw='";
$tmp3=$tmp5 . $dw;
$tmp4=$tmp3 . "' ";
$tmp6=$tmp4 . $wftime;
$tmp7=$tmp6 . ",ptpgg='";
$tmp8=$tmp7 . $gg;
$tmp9=$tmp8 . "',ptpggurl='";
$tmp10=$tmp9 . $gglj;
$tmp11=$tmp10 . "',commauth='";
$tmp12=$tmp11 . $yxplkg;
$tmp13=$tmp12 . "' WHERE id='";
$tmp14=$tmp13 . $edbjwzid;
$sql=$tmp14 . "'";
$result=$conn->query($sql);
$result=$result;
if($result){
    unset($_SESSION['allkey']);
    $str2="location:../view.php?cid=" . $edwzcid;
    $row=header($str2);
}else{
    $referer=$_SERVER['HTTP_REFERER'];
    $tmp2='<script language="JavaScript">;alert("文章编辑出错,请重试");location.href="' . $referer;
    exit($tmp2 . '";</script>;');
}
exit();
goto L2xx8j;
L2xldMhx8k:
L2xx8j:
$num2=4107;
$tmp2=$lx==1;
if($tmp2){
    $num2=$buf[0]*$buf[3];
}
$tmp2=180;
$tmp5=24;
$tmp3=$num2==24;
if($tmp3)goto L2xeWjgxcs;
goto L2xldMhxcs;
L2xeWjgxcs:
$tmp2=$text=="";
if($tmp2){
    exit('<script language="JavaScript">;alert("请输入内容!");location.href="../edit.php";</script>;');
}
$tmp2=$imgul!="";
if($tmp2)goto L2xeWjgx95;
goto L2xldMhx95;
goto L2xldMhx95;
L2xeWjgx95:
$wzlx="img";
$row=explode(PHP_EOL, $imgul);
$arrwlt=$row;
$row=count($arrwlt);
$tmp2=$row>15;
if($tmp2){
    exit('<script language="JavaScript">;alert("不可超过15张图片!");location.href="../edit.php";</script>;');
}
$row=str_replace(PHP_EOL, '(+@+)', $imgul);
$tuplj=$row;
$str=0;
$i=$str;
while(true){
    $row=count($arrwlt);
    $tmp2=$i<$row;
    if(!$tmp2)break;
    $isArray=is_array($arrwlt);
    if($isArray){
        $file=&$arrwlt[$i];
    }else{
        $file=$arrwlt[$i];
    }
    $row=preg_match("/^(http:\/\/|https:\/\/).*$/", $file);
    unset($file);
    $tmp2=!$row;
    if($tmp2){
        exit('<script language="JavaScript">;alert("请输入正确的图片链接!");location.href="../edit.php";</script>;');
    }
    $obj3=$i;
    $obj4=$i+1;
    $str=$obj4;
    $i=$str;
}
goto L2xx94;
L2xldMhx95:
$tmp2=$base64Arr!="";
if($tmp2)goto L2xeWjgx9m;
goto L2xldMhx9m;
goto L2xldMhx9m;
L2xeWjgx9m:
$arr=$val69;
unset($tmp);
foreach($base64Arr as $key=>$base64){$tmp[$key]=$base64;
}
$tmp15=0;
while(true){
    $row=count($tmp);
    $tmp2=$tmp15<$row;
    if(!$tmp2)break;
    $row=array_keys($tmp);
    $key=$row;
    $key=$key[$tmp15];
    $base64=$tmp[$key];
    $row=str_replace(' ', '+', $base64);
    $base64Image=$row;
    $row=preg_match('/^(data:\s*image\/(\w+);base64,)/', $base64Image, $result);
if($row)goto L2xeWjgx9o;
goto L2xldMhx9o;
goto L2xldMhx9o;
goto L2xldMhx9o;
goto L2xldMhx9o;
L2xeWjgx9o:
    $substr2=is_array($result);
    if($substr2){
        $file=&$result[0];
    }else{
        $file=$result[0];
    }
    $row=strpos($file, '/php');
    unset($file);
    $tmp2=$row!==false;
    $tmp3=(bool)$tmp2;
    $tmp4=!$tmp3;
    if($tmp4){
        $isArray2=is_array($result);
        if($isArray2){
            $file2=&$result[2];
        }else{
            $file2=$result[2];
        }
        $isArray=strpos($file2, 'php');
        unset($file2);
        $tmp5=$isArray!==false;
        $tmp3=(bool)$tmp5;
    }
    if($tmp3){
        exit('<script language="JavaScript">;alert("文件有风险,请重试!");location.href="../edit.php";</script>;');
    }
    $type=$result[2];
    $filePath="../upload/";
    $row=file_exists($filePath);
    $tmp2=!$row;
    if($tmp2){
        $row=mkdir($filePath);
    }
    $escaped=microtime(true);
    $cookieResult=str_replace('.', '', $escaped);
    $rand=mt_rand();
    $tmp2=$cookieResult . $rand;
    $hash=md5($zjzhq);
    $substr2=substr($hash);
    $fileName=$tmp2 . $substr2;
    $tmp2=$filePath . $fileName;
    $tmp5=$tmp2 . ".";
    $newFile=$tmp5 . $type;
    $isArray=is_array($result);
    if($isArray){
        $text=&$result[1];
    }else{
        $text=$result[1];
    }
    $replaced=str_replace($text, '', $base64Image);
    unset($text);
    $escaped2=base64_decode($replaced);
    $writeResult=file_put_contents($newFile, $escaped2);
if($writeResult)goto L2xeWjgxa3;
goto L2xldMhxa3;
goto L2xldMhxa3;
goto L2xldMhxa3;
goto L2xldMhxa3;
L2xeWjgxa3:
    $tmp2=$fileName . ".";
    $upylu=$tmp2 . $type;
    $tmp2=$imgyunc=="0";
    $tmp3=(bool)$tmp2;
    $tmp4=!$tmp3;
    if($tmp4){
        $tmp5=$imgyunc=="";
        $tmp3=(bool)$tmp5;
    }
    if($tmp3){
        $upy=0;
    }else{
        $tmp2=$imgyunc=="upyun";
        if($tmp2){
            $tmp2=include "./upyun.php";
        }else{
            $tmp2=$imgyunc=="aliyun";
            if($tmp2){
                $tmp2=include "./aliyunosapi.php";
            }
        }
    }
    $tmp2=$upy=="0";
if($tmp2)goto L2xeWjgxab;
goto L2xx9n;
goto L2xx9n;
goto L2xx9n;
goto L2xx9n;
L2xeWjgxab:
    $str2="./upload/" . $fileName;
    $str3=$str2 . ".";
    $val64=$str3 . $type;
    $row=array_push($arr, $val64);
    $tmp2=$imgpres==1;
if($tmp2)goto L2xeWjgxad;
goto L2xx9n;
goto L2xx9n;
goto L2xx9n;
goto L2xx9n;
L2xeWjgxad:
    $row=compress($newFile, $newFile);
goto L2xx9n;
L2xldMhxa3:
    exit("<script>alert('写入文件失败,请检查服务器权限');location.href='../edit.php';</script>");
    die("error");
L2xldMhx9o:
    exit("<script>alert('未匹配到图片文件,请检查文件格式');location.href='../edit.php';</script>");
    die("error");
L2xx9n:
    $tmp15=$tmp15+1;
}
L2xxba:
$row=implode('(+@+)', $arr);
$tuplj=$row;
$wzlx="img";
goto L2xx9l;
L2xldMhx9m:
$wzlx="only";
L2xx9l:
L2xx94:
$tmp2=$zjzhq!=$glyusername;
if($tmp2)goto L2xeWjgxc6;
goto L2xldMhxc6;
goto L2xldMhxc6;
L2xeWjgxc6:
$tmp2=$zjfbqx==2;
$tmp5=!$tmp2;
if($tmp5)goto L2xeWjgxc8;
goto L2xxc5;
goto L2xxc5;
L2xeWjgxc8:
$tmp2=$gg==1;
if($tmp2)goto L2xeWjgxca;
goto L2xxc5;
goto L2xxc5;
L2xeWjgxca:
$tmp2=$rnggy>0;
if($tmp2)goto L2xeWjgxcc;
goto L2xxc5;
goto L2xxc5;
L2xeWjgxcc:
$tmp2=$zjwallet>$rnggy;
if($tmp2)goto L2xeWjgxce;
goto L2xldMhxce;
goto L2xldMhxce;
L2xeWjgxce:
$xwyae=$zjwallet-$rnggy;
$tmp2="UPDATE user SET wallet = '" . $xwyae;
$tmp5=$tmp2 . "' WHERE username = '";
$tmp3=$tmp5 . $zjzhq;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$tmp2=$result===TRUE;
if($tmp2)goto L2xxc5;
goto L2xldMhxcg;
L2xldMhxcg:
exit("<script>alert('扣除广告余额失败,请重试');location.href='../edit.php';</script>");
L2xldMhxce:
$tmp2='<script language="JavaScript">;alert("发布广告需要:' . $rnggy;
exit($tmp2 . '余额,您的余额不足!");location.href="../edit.php";</script>;');
L2xldMhxc6:
L2xxc5:
$tmp2=$dywptp>0;
if($tmp2)goto L2xeWjgxci;
goto L2xldMhxci;
goto L2xldMhxci;
L2xeWjgxci:
$row=date('Ymd');
$currentDate=$row;
$tmp2="SELECT ptptime FROM essay WHERE ptpuser = '" . $zjzhq;
$tmp5=$tmp2 . "' AND ptptime LIKE '%";
$tmp3=$tmp5 . $currentDate;
$sql=$tmp3 . "%'";
$result=$conn->query($sql);
$result=$result;
$tmp2=$result->num_rows>0;
if($tmp2)goto L2xxch;
goto L2xldMhxck;
L2xldMhxck:
$xwyaeg=$zjwallet+$dywptp;
$tmp2="UPDATE user SET wallet = '" . $xwyaeg;
$tmp5=$tmp2 . "' WHERE username = '";
$tmp3=$tmp5 . $zjzhq;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$tmp2=$result===TRUE;
goto L2xxch;
L2xldMhxci:
L2xxch:
$bdm="essay";
$tmp2="INSERT INTO " . $bdm;
$tmp5=$tmp2 . " (ptpuser,ptpimg,ptpname,ptptext,ptpimag,ptpvideo,ptpmusic,ptplx,ptpdw,ptptime,ptpgg,ptpggurl,ptpys,commauth,ptpaud,ip,cid)
VALUES ('";
$tmp3=$tmp5 . $zjzhq;
$tmp4=$tmp3 . "','";
$tmp6=$tmp4 . $zjimg;
$tmp7=$tmp6 . "','";
$tmp8=$tmp7 . $zjnc;
$tmp9=$tmp8 . "','";
$tmp10=$tmp9 . $text;
$tmp11=$tmp10 . "','";
$tmp12=$tmp11 . $tuplj;
$tmp13=$tmp12 . "','','','";
$tmp14=$tmp13 . $wzlx;
$tmp16=$tmp14 . "','";
$tmp17=$tmp16 . $dw;
$tmp18=$tmp17 . "','";
$tmp19=$tmp18 . $sj;
$tmp20=$tmp19 . "','";
$tmp21=$tmp20 . $gg;
$tmp22=$tmp21 . "','";
$tmp23=$tmp22 . $gglj;
$tmp24=$tmp23 . "','1','";
$tmp25=$tmp24 . $yxplkg;
$tmp26=$tmp25 . "','";
$tmp27=$tmp26 . $ptpaudzt;
$tmp28=$tmp27 . "','";
$tmp29=$tmp28 . $ip;
$tmp30=$tmp29 . "','";
$tmp31=$tmp30 . $str;
$sql=$tmp31 . "')";
$result=$conn->query($sql);
$tmp2=$result===TRUE;
if($tmp2)goto L2xeWjgxco;
goto L2xldMhxco;
goto L2xldMhxco;
L2xeWjgxco:
$tmp2=$ptpaud==0;
if($tmp2)goto L2xeWjgxcq;
goto L2xldMhxcq;
goto L2xldMhxcq;
L2xeWjgxcq:
$row=header("Location: ../index.php");
goto L2xxcr;
L2xldMhxcq:
$fsyjtzemail=1;
unset($_SESSION['allkey']);
echo "<script>alert('文章发布成功,审核通过后即可显示!');location.href='../index.php';</script>";
L2xldMhxco:
echo "<script>alert('文章发布失败,写入数据库出错');location.href='../edit.php';</script>";
L2xldMhxcs:
L2xxcr:
$num3=4113;
$tmp2=$lx==2;
if($tmp2){
    $num3=$buf[4]*$buf[4];
}
$tmp2=260;
$tmp5=256;
$tmp3=$num3==256;
if($tmp3)goto L2xeWjgxgi;
goto L2xldMhxgi;
L2xeWjgxgi:
$wzlx="video";
$tmp2=$text=="";
if($tmp2){
    exit('<script language="JavaScript">;alert("请输入内容!");location.href="../edit.php";</script>;');
}
$tmp2=$spp=="";
if($tmp2)goto L2xeWjgxeu;
goto L2xldMhxeu;
goto L2xldMhxeu;
L2xeWjgxeu:
$tmp2=$_FILES["file"]["name"]=="";
if($tmp2)goto L2xeWjgxew;
goto L2xxet;
goto L2xxet;
L2xeWjgxew:
exit('<script language="JavaScript">;alert("请上传视频!");location.href="../edit.php";</script>;');
goto L2xxet;
L2xldMhxeu:
L2xxet:
$tmp2=$spp!="";
if($tmp2)goto L2xeWjgxey;
goto L2xldMhxey;
goto L2xldMhxey;
L2xeWjgxey:
$tmp2=$spp . '|';
$spljd=$tmp2 . $sppfm;
$row=preg_match("/^(http:\/\/|https:\/\/).*$/", $spljd);
$tmp2=!$row;
if($tmp2)goto L2xeWjgxf1;
goto L2xxex;
goto L2xxex;
L2xeWjgxf1:
exit('<script language="JavaScript">;alert("请输入正确的视频链接!");location.href="../edit.php";</script>;');
goto L2xxex;
L2xldMhxey:
$isArray2=is_array($_FILES);
if($isArray2){
    $file2=&$_FILES["file"];
}else{
    $file2=$_FILES["file"];
}
$isArray=is_array($file2);
unset($file2);
if($isArray){
    $text=&$_FILES["file"]["name"];
}else{
    $text=$_FILES["file"]["name"];
}
$replaced=strrchr($text, ".");
unset($text);
$substr=substr($replaced);
$lowered=strtolower($substr);
$fileEx=$lowered;
$isArray3=is_array($_FILES);
if($isArray3){
    $file3=&$_FILES["file"];
}else{
    $file3=$_FILES["file"];
}
$isArray4=is_array($file3);
unset($file3);
if($isArray4){
    $file=&$_FILES["file"]["name"];
}else{
    $file=$_FILES["file"]["name"];
}
$row=strpos($file, "php");
unset($file);
$tmp2=$row!==false;
$tmp3=(bool)$tmp2;
$tmp8=!$tmp3;
if($tmp8){
    $isArray5=is_array($_FILES);
    if($isArray5){
        $file4=&$_FILES["file"];
    }else{
        $file4=$_FILES["file"];
    }
    $isArray6=is_array($file4);
    unset($file4);
    if($isArray6){
        $file2=&$_FILES["file"]["name"];
    }else{
        $file2=$_FILES["file"]["name"];
    }
    $isArray=strpos($file2, "js");
    unset($file2);
    $tmp5=$isArray!==false;
    $tmp3=(bool)$tmp5;
}
$tmp6=(bool)$tmp3;
$tmp7=!$tmp6;
if($tmp7){
    $isArray7=is_array($_FILES);
    if($isArray7){
        $file5=&$_FILES["file"];
    }else{
        $file5=$_FILES["file"];
    }
    $isArray8=is_array($file5);
    unset($file5);
    if($isArray8){
        $file6=&$_FILES["file"]["name"];
    }else{
        $file6=$_FILES["file"]["name"];
    }
    $isArray2=strpos($file6, "html");
    unset($file6);
    $tmp4=$isArray2!==false;
    $tmp6=(bool)$tmp4;
}
if($tmp6){
    exit('<script language="JavaScript">alert("文件有风险，请重试!");location.href="../edit.php";</script>');
}
$val69[]='video/mp4';
$val69[]='video/mpeg';
$val69[]='video/quicktime';
$val69[]='video/x-msvideo';
$val69[]='video/x-flv';
$allowedVideoTypes=$val69;
$uploadedFileType=$_FILES['file']['type'];
$row=in_array($uploadedFileType, $allowedVideoTypes);
if(!($row)){
    exit('<script language="JavaScript">alert("文件类型错误,请上传视频!");location.href="../edit.php";</script>');
}else{
    $escaped=microtime(true);
    $cookieResult=str_replace('.', '', $escaped);
    $rand=mt_rand();
    $tmp2=$cookieResult . $rand;
    $hash=md5($zjzhq);
    $substr2=substr($hash);
    $tmp5=$tmp2 . $substr2;
    $tmp3=$tmp5 . '.';
    $fileName=$tmp3 . $fileEx;
    $str2="../upload/" . $fileName;
    $isArray2=is_array($_FILES);
    if($isArray2){
        $file2=&$_FILES["file"];
    }else{
        $file2=$_FILES["file"];
    }
    $isArray=is_array($file2);
    unset($file2);
    if($isArray){
        $file=&$_FILES["file"]["tmp_name"];
    }else{
        $file=$_FILES["file"]["tmp_name"];
    }
    $row=move_uploaded_file($file, $str2);
    unset($file);
    $tmp2='/upload/' . $fileName;
    $tmp5=$tmp2 . '|';
    $spljd=$tmp5 . $sppfm;
}
L2xxex:
$tmp2=$zjzhq!=$glyusername;
if($tmp2)goto L2xeWjgxfv;
goto L2xldMhxfv;
goto L2xldMhxfv;
L2xeWjgxfv:
$tmp2=$zjfbqx==2;
$tmp5=!$tmp2;
if($tmp5)goto L2xeWjgxfx;
goto L2xxfu;
goto L2xxfu;
L2xeWjgxfx:
$tmp2=$gg==1;
if($tmp2)goto L2xeWjgxgz;
goto L2xxfu;
goto L2xxfu;
L2xeWjgxgz:
$tmp2=$rnggy>0;
if($tmp2)goto L2xeWjgxg2;
goto L2xxfu;
goto L2xxfu;
L2xeWjgxg2:
$tmp2=$zjwallet>$rnggy;
if($tmp2)goto L2xeWjgxg4;
goto L2xldMhxg4;
goto L2xldMhxg4;
L2xeWjgxg4:
$xwyae=$zjwallet-$rnggy;
$tmp2="UPDATE user SET wallet = '" . $xwyae;
$tmp5=$tmp2 . "' WHERE username = '";
$tmp3=$tmp5 . $zjzhq;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$tmp2=$result===TRUE;
if($tmp2)goto L2xxfu;
goto L2xldMhxg6;
L2xldMhxg6:
exit("<script>alert('扣除广告余额失败,请重试');location.href='../edit.php';</script>");
L2xldMhxg4:
$tmp2='<script language="JavaScript">;alert("发布广告需要:' . $rnggy;
exit($tmp2 . '余额,您的余额不足!");location.href="../edit.php";</script>;');
L2xldMhxfv:
L2xxfu:
$tmp2=$dywptp>0;
if($tmp2)goto L2xeWjgxg8;
goto L2xldMhxg8;
goto L2xldMhxg8;
L2xeWjgxg8:
$row=date('Ymd');
$currentDate=$row;
$tmp2="SELECT ptptime FROM essay WHERE ptpuser = '" . $zjzhq;
$tmp5=$tmp2 . "' AND ptptime LIKE '%";
$tmp3=$tmp5 . $currentDate;
$sql=$tmp3 . "%'";
$result=$conn->query($sql);
$result=$result;
$tmp2=$result->num_rows>0;
if($tmp2)goto L2xxg7;
goto L2xldMhxga;
L2xldMhxga:
$xwyaeg=$zjwallet+$dywptp;
$tmp2="UPDATE user SET wallet = '" . $xwyaeg;
$tmp5=$tmp2 . "' WHERE username = '";
$tmp3=$tmp5 . $zjzhq;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$tmp2=$result===TRUE;
goto L2xxg7;
L2xldMhxg8:
L2xxg7:
$bdm="essay";
$tmp2="INSERT INTO " . $bdm;
$tmp5=$tmp2 . " (ptpuser,ptpimg,ptpname,ptptext,ptpimag,ptpvideo,ptpmusic,ptplx,ptpdw,ptptime,ptpgg,ptpggurl,ptpys,commauth,ptpaud,ip,cid)
VALUES ('";
$tmp3=$tmp5 . $zjzhq;
$tmp4=$tmp3 . "','";
$tmp6=$tmp4 . $zjimg;
$tmp7=$tmp6 . "','";
$tmp8=$tmp7 . $zjnc;
$tmp9=$tmp8 . "','";
$tmp10=$tmp9 . $text;
$tmp11=$tmp10 . "','";
$tmp12=$tmp11 . $tuplj;
$tmp13=$tmp12 . "','";
$tmp14=$tmp13 . $spljd;
$tmp16=$tmp14 . "','','";
$tmp17=$tmp16 . $wzlx;
$tmp18=$tmp17 . "','";
$tmp19=$tmp18 . $dw;
$tmp20=$tmp19 . "','";
$tmp21=$tmp20 . $sj;
$tmp22=$tmp21 . "','";
$tmp23=$tmp22 . $gg;
$tmp24=$tmp23 . "','";
$tmp25=$tmp24 . $gglj;
$tmp26=$tmp25 . "','1','";
$tmp27=$tmp26 . $yxplkg;
$tmp28=$tmp27 . "','";
$tmp29=$tmp28 . $ptpaudzt;
$tmp30=$tmp29 . "','";
$tmp31=$tmp30 . $ip;
$tmp32=$tmp31 . "','";
$tmp33=$tmp32 . $str;
$sql=$tmp33 . "')";
$result=$conn->query($sql);
$tmp2=$result===TRUE;
if($tmp2)goto L2xeWjgxge;
goto L2xldMhxge;
goto L2xldMhxge;
L2xeWjgxge:
$tmp2=$ptpaud==0;
if($tmp2)goto L2xeWjgxgg;
goto L2xldMhxgg;
goto L2xldMhxgg;
L2xeWjgxgg:
$row=header("Location: ../index.php");
goto L2xxgh;
L2xldMhxgg:
$fsyjtzemail=1;
unset($_SESSION['allkey']);
echo "<script>alert('文章发布成功,审核通过后即可显示!');location.href='../index.php';</script>";
L2xldMhxge:
echo "<script>alert('文章发布失败,写入数据库出错');location.href='../edit.php';</script>";
L2xldMhxgi:
L2xxgh:
$num4=4101;
$tmp2=$lx==3;
if($tmp2){
    $num4=$buf[3]*$buf[4];
}
$tmp2=18;
$tmp5=64;
$tmp3=$num4==64;
if($tmp3)goto L2xeWjgxjd;
goto L2xldMhxjd;
L2xeWjgxjd:
$wzlx="music";
$tmp2=$text=="";
if($tmp2){
    exit('<script language="JavaScript">;alert("请输入内容!");location.href="../edit.php";</script>;');
}
$tmp2=$music=="";
if($tmp2){
    exit('<script language="JavaScript">;alert("请输入音乐链接!");location.href="../edit.php";</script>;');
}
$tmp2=$musicm=="";
if($tmp2){
    exit('<script language="JavaScript">;alert("请输入歌名!");location.href="../edit.php";</script>;');
}
$tmp2=$musics=="";
if($tmp2){
    exit('<script language="JavaScript">;alert("请输入歌手!");location.href="../edit.php";</script>;');
}
$tmp2=$musict!="";
if($tmp2)goto L2xeWjgxik;
goto L2xldMhxik;
goto L2xldMhxik;
L2xeWjgxik:
$pattern='/^(http|https):\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,}(\/\S*)?$/';
$row=preg_match($pattern, $musict);
$tmp2=!$row;
if($tmp2)goto L2xeWjgxim;
goto L2xxij;
goto L2xxij;
L2xeWjgxim:
$musict='./assets/img/musicba.jpg';
goto L2xxij;
L2xldMhxik:
L2xxij:
$row=is_numeric($music);
if($row){
    $tmp2='//music.163.com/song/media/outer/url?id=' . $music;
    $music=$tmp2 . '.mp3';
}
$tmp2=$music . "|";
$tmp5=$tmp2 . $musicm;
$tmp3=$tmp5 . "|";
$tmp4=$tmp3 . $musics;
$tmp6=$tmp4 . "|";
$music=$tmp6 . $musict;
$tmp2=$zjzhq!=$glyusername;
if($tmp2)goto L2xeWjgxiq;
goto L2xldMhxiq;
goto L2xldMhxiq;
L2xeWjgxiq:
$tmp2=$zjfbqx==2;
$tmp5=!$tmp2;
if($tmp5)goto L2xeWjgxis;
goto L2xxip;
goto L2xxip;
L2xeWjgxis:
$tmp2=$gg==1;
if($tmp2)goto L2xeWjgxiu;
goto L2xxip;
goto L2xxip;
L2xeWjgxiu:
$tmp2=$rnggy>0;
if($tmp2)goto L2xeWjgxiw;
goto L2xxip;
goto L2xxip;
L2xeWjgxiw:
$tmp2=$zjwallet>$rnggy;
if($tmp2)goto L2xeWjgxiy;
goto L2xldMhxiy;
goto L2xldMhxiy;
L2xeWjgxiy:
$xwyae=$zjwallet-$rnggy;
$tmp2="UPDATE user SET wallet = '" . $xwyae;
$tmp5=$tmp2 . "' WHERE username = '";
$tmp3=$tmp5 . $zjzhq;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$tmp2=$result===TRUE;
if($tmp2)goto L2xxip;
goto L2xldMhxj1;
L2xldMhxj1:
exit("<script>alert('扣除广告余额失败,请重试');location.href='../edit.php';</script>");
L2xldMhxiy:
$tmp2='<script language="JavaScript">;alert("发布广告需要:' . $rnggy;
exit($tmp2 . '余额,您的余额不足!");location.href="../edit.php";</script>;');
L2xldMhxiq:
L2xxip:
$tmp2=$dywptp>0;
if($tmp2)goto L2xeWjgxj3;
goto L2xldMhxj3;
goto L2xldMhxj3;
L2xeWjgxj3:
$row=date('Ymd');
$currentDate=$row;
$tmp2="SELECT ptptime FROM essay WHERE ptpuser = '" . $zjzhq;
$tmp5=$tmp2 . "' AND ptptime LIKE '%";
$tmp3=$tmp5 . $currentDate;
$sql=$tmp3 . "%'";
$result=$conn->query($sql);
$result=$result;
$tmp2=$result->num_rows>0;
if($tmp2)goto L2xxj2;
goto L2xldMhxj5;
L2xldMhxj5:
$xwyaeg=$zjwallet+$dywptp;
$tmp2="UPDATE user SET wallet = '" . $xwyaeg;
$tmp5=$tmp2 . "' WHERE username = '";
$tmp3=$tmp5 . $zjzhq;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$tmp2=$result===TRUE;
goto L2xxj2;
L2xldMhxj3:
L2xxj2:
$bdm="essay";
$tmp2="INSERT INTO " . $bdm;
$tmp5=$tmp2 . " (ptpuser,ptpimg,ptpname,ptptext,ptpimag,ptpvideo,ptpmusic,ptplx,ptpdw,ptptime,ptpgg,ptpggurl,ptpys,commauth,ptpaud,ip,cid)
VALUES ('";
$tmp3=$tmp5 . $zjzhq;
$tmp4=$tmp3 . "','";
$tmp6=$tmp4 . $zjimg;
$tmp7=$tmp6 . "','";
$tmp8=$tmp7 . $zjnc;
$tmp9=$tmp8 . "','";
$tmp10=$tmp9 . $text;
$tmp11=$tmp10 . "','";
$tmp12=$tmp11 . $tuplj;
$tmp13=$tmp12 . "','','";
$tmp14=$tmp13 . $music;
$tmp16=$tmp14 . "','";
$tmp17=$tmp16 . $wzlx;
$tmp18=$tmp17 . "','";
$tmp19=$tmp18 . $dw;
$tmp20=$tmp19 . "','";
$tmp21=$tmp20 . $sj;
$tmp22=$tmp21 . "','";
$tmp23=$tmp22 . $gg;
$tmp24=$tmp23 . "','";
$tmp25=$tmp24 . $gglj;
$tmp26=$tmp25 . "','1','";
$tmp27=$tmp26 . $yxplkg;
$tmp28=$tmp27 . "','";
$tmp29=$tmp28 . $ptpaudzt;
$tmp30=$tmp29 . "','";
$tmp31=$tmp30 . $ip;
$tmp32=$tmp31 . "','";
$tmp33=$tmp32 . $str;
$sql=$tmp33 . "')";
$result=$conn->query($sql);
$tmp2=$result===TRUE;
if($tmp2)goto L2xeWjgxj9;
goto L2xldMhxj9;
goto L2xldMhxj9;
L2xeWjgxj9:
$tmp2=$ptpaud==0;
if($tmp2)goto L2xeWjgxjb;
goto L2xldMhxjb;
goto L2xldMhxjb;
L2xeWjgxjb:
$row=header("Location: ../index.php");
goto L2xxjc;
L2xldMhxjb:
$fsyjtzemail=1;
unset($_SESSION['allkey']);
echo "<script>alert('文章发布成功,审核通过后即可显示!');location.href='../index.php';</script>";
L2xldMhxj9:
$tmp2="Error: " . $sql;
$tmp5=$tmp2 . "<br>";
$tmp3=$tmp5 . $conn->error;
echo $tmp3;
L2xldMhxjd:
L2xxjc:
$num5=4101;
$tmp2=$lx==4;
if($tmp2){
    $num5=$buf[1]*$buf[2];
}
$tmp2=12;
$tmp5=130;
$tmp3=$num5==130;
if($tmp3)goto L2xeWjgxln;
goto L2xldMhxln;
L2xeWjgxln:
$wzlx="mony";
$isArray=is_array($_POST);
if($isArray){
    $allkey=&$_POST['hbgs'];
}else{
    $allkey=$_POST['hbgs'];
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$hbgs=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $allkey=&$_POST['hbzje'];
}else{
    $allkey=$_POST['hbzje'];
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$hbzje=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $allkey=&$_POST['hbzf'];
}else{
    $allkey=$_POST['hbzf'];
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$hbzf=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $allkey=&$_POST['hbfimg'];
}else{
    $allkey=$_POST['hbfimg'];
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$hbfimg=$escaped3;
$isArray=is_array($_POST);
if($isArray){
    $allkey=&$_POST['hblx'];
}else{
    $allkey=$_POST['hblx'];
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped3=addslashes($escaped);
$hblx=$escaped3;
$tmp2=$text=="";
if($tmp2){
    exit('<script language="JavaScript">;alert("请输入内容!");location.href="../edit.php";</script>;');
}
$tmp2=$hbgs=="";
if($tmp2){
    exit('<script language="JavaScript">;alert("红包个数不可为空");location.href="../edit.php";</script>;');
}
$tmp2=$hbzje=="";
if($tmp2){
    exit('<script language="JavaScript">;alert("红包金额不可为空");location.href="../edit.php";</script>;');
}
$tmp2=$hbzf=="";
if($tmp2){
    $hbzf="大吉大利";
}
$tmp2=$hblx=="";
if($tmp2){
    exit('<script language="JavaScript">;alert("红包类型不可为空");location.href="../edit.php";</script>;');
}
$tmp2=$hbgs>1000;
if($tmp2){
    exit('<script language="JavaScript">;alert("红包个数不可大于1000个");location.href="../edit.php";</script>;');
}
$tmp2=$hbzje>1000;
if($tmp2){
    exit('<script language="JavaScript">;alert("红包金额不可大于1000元");location.href="../edit.php";</script>;');
}
$tmp2=$hbgs<1;
if($tmp2){
    exit('<script language="JavaScript">;alert("红包个数不可低于1个");location.href="../edit.php";</script>;');
}
$tmp2=$hbzje<1;
if($tmp2){
    exit('<script language="JavaScript">;alert("红包金额不可低于1元");location.href="../edit.php";</script>;');
}
$redPacketCount=$hbgs;
$totalAmount=$hbzje;
$minRedPacketAmount=0.01;
$calculatedTotalAmount=$redPacketCount*$minRedPacketAmount;
$tmp2=$totalAmount>=$calculatedTotalAmount;
if($tmp2)goto L2xxla;
goto L2xldMhxlb;
L2xldMhxlb:
$tmp2='<script language="JavaScript">;alert("您需要至少' . $calculatedTotalAmount;
$tmp5=$tmp2 . '元来发放';
$tmp3=$tmp5 . $redPacketCount;
exit($tmp3 . '个红包");location.href="../edit.php";</script>;');
L2xxla:
$tmp2=$hbzje>$zjwallet;
if($tmp2){
    $tmp2='<script language="JavaScript">;alert("您的余额不足以发放' . $hbzje;
    exit($tmp2 . '元的红包");location.href="../edit.php";</script>;');
}
$walletx=$zjwallet-$hbzje;
$tmp2="UPDATE user SET wallet='" . $walletx;
$tmp5=$tmp2 . "' WHERE username='";
$tmp3=$tmp5 . $zjzhq;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$tmp2=$result===TRUE;
if($tmp2)goto L2xxle;
goto L2xldMhxlf;
L2xldMhxlf:
exit('<script language="JavaScript">;alert("扣除余额失败");location.href="../edit.php";</script>;');
L2xxle:
$bdmh="money";
$tmp2="INSERT INTO " . $bdmh;
$tmp5=$tmp2 . " (muser,type,zsum,sum,total,recve,luser,montext,monimg,ptpmoncid)
VALUES ('";
$tmp3=$tmp5 . $zjzhq;
$tmp4=$tmp3 . "','";
$tmp6=$tmp4 . $hblx;
$tmp7=$tmp6 . "','";
$tmp8=$tmp7 . $hbzje;
$tmp9=$tmp8 . "','";
$tmp10=$tmp9 . $hbzje;
$tmp11=$tmp10 . "','";
$tmp12=$tmp11 . $hbgs;
$tmp13=$tmp12 . "','";
$tmp14=$tmp13 . $hbgs;
$tmp16=$tmp14 . "','','";
$tmp17=$tmp16 . $hbzf;
$tmp18=$tmp17 . "','";
$tmp19=$tmp18 . $hbfimg;
$tmp20=$tmp19 . "','";
$tmp21=$tmp20 . $str;
$sqlh=$tmp21 . "')";
$result=$conn->query($sqlh);
$tmp2=$result===TRUE;
if($tmp2)goto L2xxlg;
goto L2xldMhxlh;
L2xldMhxlh:
L2xxlg:
$bdm="essay";
$tmp2="INSERT INTO " . $bdm;
$tmp5=$tmp2 . " (ptpuser,ptpimg,ptpname,ptptext,ptpimag,ptpvideo,ptpmusic,ptplx,ptpdw,ptptime,ptpgg,ptpggurl,ptpys,commauth,ptpaud,ip,cid)
VALUES ('";
$tmp3=$tmp5 . $zjzhq;
$tmp4=$tmp3 . "','";
$tmp6=$tmp4 . $zjimg;
$tmp7=$tmp6 . "','";
$tmp8=$tmp7 . $zjnc;
$tmp9=$tmp8 . "','";
$tmp10=$tmp9 . $text;
$tmp11=$tmp10 . "','','','','";
$tmp12=$tmp11 . $wzlx;
$tmp13=$tmp12 . "','','";
$tmp14=$tmp13 . $sj;
$tmp16=$tmp14 . "','";
$tmp17=$tmp16 . $gg;
$tmp18=$tmp17 . "','";
$tmp19=$tmp18 . $gglj;
$tmp20=$tmp19 . "','1','";
$tmp21=$tmp20 . $yxplkg;
$tmp22=$tmp21 . "','";
$tmp23=$tmp22 . $ptpaudzt;
$tmp24=$tmp23 . "','";
$tmp25=$tmp24 . $ip;
$tmp26=$tmp25 . "','";
$tmp27=$tmp26 . $str;
$sql=$tmp27 . "')";
$result=$conn->query($sql);
$tmp2=$result===TRUE;
if($tmp2)goto L2xeWjgxlj;
goto L2xldMhxlj;
goto L2xldMhxlj;
L2xeWjgxlj:
$tmp2=$ptpaud==0;
if($tmp2)goto L2xeWjgxll;
goto L2xldMhxll;
goto L2xldMhxll;
L2xeWjgxll:
$row=header("Location: ../index.php");
goto L2xxlm;
L2xldMhxll:
$fsyjtzemail=1;
unset($_SESSION['allkey']);
echo "<script>alert('文章发布成功,审核通过后即可显示!');location.href='../index.php';</script>";
L2xldMhxlj:
$tmp2="Error: " . $sql;
$tmp5=$tmp2 . "<br>";
$tmp3=$tmp5 . $conn->error;
echo $tmp3;
L2xldMhxln:
L2xxlm:
$num6=4108;
$tmp2=$fsyjtzemail==1;
if($tmp2){
    $num6=$buf[2]*$buf[3];
}
switch($num6){
    case 40:{
    $str2="select * from user where username='" . $glyusername;
    $str3=$str2 . "'";
    $row=mysqli_query($conn, $str3);
    $data_resultgl=$row;
    $row=mysqli_fetch_array($data_resultgl);
    $data_rowgl=$row;
    $glydem=$data_rowgl["email"];
    $mailapfs='nopost';
    $tmp2='[' . $wzname;
    $tmp5=$tmp2 . ']';
    $mailtitle=$tmp5 . '您有新的待审核文章!';
    $title='待审核的文章 - 文章主题：';
    $text=$emwz;
    $mailbox=$glydem;
    $tmp2=include "./sendmail.php";
        break;
    }
}
$result=$conn->close();
unset($val70);function filterEmoji($str) {
    $str=preg_replace_callback('/./u',function(array $match){$arr=array();
    $arr[]=2;
    $arr[]=14;
    $arr[]=16;
    $arr[]=15;
    $arr[]=20;
    $num7=8016;
    $isArray=is_array($match);
    if($isArray){
        $num7=$arr[3]*$arr[4];
    }else{
        $num7=$arr[1]*$arr[1];
    }
    switch($num7){
        case 300:{
        $file=&$match[0];
            break;
        }
        case 196:{
            $file=$match[0];
            break;
        }
    }
    $row=strlen($file);
    unset($file);
    $tmp2=$row>=4;
    $num8=8007;
    if($tmp2){
        $num8=$arr[3]*$arr[3];
    }else{
        $num8=$arr[3]*$arr[3];
        $num8=$num8+6911;
    }
    switch($num8){
        case 7136:{
        $tmp5=$match[0];
            break;
        }
        case 225:{
            $tmp5='';
            break;
        }
    }
    return $tmp5;
},$str);
$str=$str;
return $str;
}function parseUrls($string) {
    $urls=$val69;
    $pattern='/\b(?:https?:\/\/|www\.)([a-z0-9.-]+\.[a-z]{2,4}(?:\/[^\s]*)?)/i';
    $row=preg_match_all($pattern, $string, $matches);
    unset($tmp);
    foreach($matches[0] as $url){$tmp[]=$url;
}
$tmp15=0;
while(true){
    $row=count($tmp);
    $tmp2=$tmp15<$row;
    if(!($tmp2))break;
    $keys=array_keys($tmp);
    $keys=$keys[$tmp15];
    $url=$tmp[$keys];
    $row=strpos($url, 'http://');
    $tmp2=$row!==0;
    $tmp3=(bool)$tmp2;
    if($tmp3){
        $cookieResult=strpos($url, 'https://');
        $tmp5=$cookieResult!==0;
        $tmp3=(bool)$tmp5;
    }
    if($tmp3){
        $url='http://' . $url;
    }
    $tmp2='<a href="' . $url;
    $tmp5=$tmp2 . '" target="_blank" class="sh-wz-nr-url">';
    $tmp3=$tmp5 . $url;
    $tmp4=$tmp3 . '</a>';
    $sentinel=$tmp4;
    $str=$sentinel;
    $urls[]=$str;
    $tmp15=$tmp15+1;
}
L2xxnv:
$num9=1017;
$isArray=is_array($matches);
if($isArray){
    $num9=56;
}else{
    $num9=63;
}
switch($num9){
    case 63:{
    $file=$matches[0];
        break;
    }
    case 56:{
        $file=&$matches[0];
        break;
    }
}
$row=str_replace($file, $urls, $string);
unset($file);
$string=$row;
return $string;
}function rotateAndSaveImage($source_image,$destination_image) {
    $row=exif_read_data($source_image);
    $exif=$row;
    $num10=4107;
    if(isset($exif['Orientation'])){
        $num10=42;
    }else{
        $num10=196;
    }
    $tmp3=119;
    $tmp4=196;
    $tmp6=$num10==196;
if($tmp6)goto L2xeWjgxoc;
goto L2xldMhxoc;
L2xeWjgxoc:
    $tmp2=null;
goto L2xxob;
L2xldMhxoc:
    $tmp7=187;
    $tmp8=42;
    $tmp9=$num10==42;
if($tmp9)goto L2xxob;
L2xxob:
    $orientation=$exif['Orientation'];
    $row=imagecreatefromjpeg($source_image);
    $image=$row;
    $val=$orientation;
    $tmp2=$val==3;
if($tmp2)goto L2xcgFhxof;
goto L2xldMhxon;
goto L2xxom;
L2xldMhxon:
L2xxom:
    $tmp2=$val==6;
if($tmp2)goto L2xcgFhxog;
goto L2xldMhxol;
goto L2xxok;
L2xldMhxol:
L2xxok:
    $tmp2=$val==8;
if($tmp2)goto L2xcgFhxoh;
goto L2xxoe;
goto L2xxoe;
L2xcgFhxof:
    $row=imagerotate($image);
    $image=$row;
goto L2xxoe;
L2xcgFhxog:
    $row=imagerotate($image);
    $image=$row;
goto L2xxoe;
L2xcgFhxoh:
    $row=imagerotate($image);
    $image=$row;
L2xxoe:
    $row=imagejpeg($image, $destination_image);
    $row=imagedestroy($image);
}function compress($source_image,$compressed_image) {
    $row=pathinfo($source_image, PATHINFO_EXTENSION);
    $extension=$row;
    $tmp2=$extension=='gif';
    $tmp3=(bool)$tmp2;
    $tmp4=!$tmp3;
    if($tmp4){
        $tmp5=$extension=='webp';
        $tmp3=(bool)$tmp5;
    }
    if($tmp3){
        return ;
    }
    $row=file_exists($source_image);
    $tmp2=!$row;
    if($tmp2){
        $str2="Source image not found: " . $source_image;
        $row=trigger_error($str2, E_USER_ERROR);
        return ;
    }
    $str=@getimagesize($source_image);
    $image_info=$str;
    $tmp2=$image_info===false;
    $tmp3=(bool)$tmp2;
    $tmp8=!$tmp3;
    if($tmp8){
        $tmp5=$image_info['mime']=='image/webp';
        $tmp3=(bool)$tmp5;
    }
    $tmp6=(bool)$tmp3;
    $tmp7=!$tmp6;
    if($tmp7){
        $tmp4=$image_info['mime']=='image/gif';
        $tmp6=(bool)$tmp4;
    }
    if($tmp3){
        return ;
    }
    $source_image=$source_image;
    $destination_image=$compressed_image;
    $source_image=$source_image;
    $compressed_image=$compressed_image;
    $compression_quality=75;
    $env=getimagesize($source_image);
    $str=$env;
    list($width,$height,$type)=$str;
    $val2=$type;
    $tmp2=$val2==IMAGETYPE_JPEG;
if($tmp2)goto L2xcgFhxp8;
goto L2xldMhxpj;
goto L2xxpi;
L2xldMhxpj:
L2xxpi:
    $tmp2=$val2==IMAGETYPE_PNG;
if($tmp2)goto L2xcgFhxp9;
goto L2xldMhxph;
goto L2xxpg;
L2xldMhxph:
L2xxpg:
    $tmp2=$val2==IMAGETYPE_GIF;
if($tmp2)goto L2xcgFhxpa;
goto L2xldMhxpf;
goto L2xxpe;
L2xldMhxpf:
L2xxpe:
    $tmp2=$val2==IMAGETYPE_JPG;
if($tmp2)goto L2xcgFhxpb;
goto L2xxp7;
goto L2xxp7;
L2xcgFhxp8:
    $row=imagecreatefromjpeg($source_image);
    $source=$row;
goto L2xxp7;
L2xcgFhxp9:
    $row=imagecreatefrompng($source_image);
    $source=$row;
goto L2xxp7;
L2xcgFhxpa:
    $row=imagecreatefromgif($source_image);
    $source=$row;
goto L2xxp7;
L2xcgFhxpb:
    $row=imagecreatefromgif($source_image);
    $source=$row;
L2xxp7:
    $new_width=$width/2;
    $new_height=$height/2;
    $row=imagecreatetruecolor($new_width, $new_height);
    $destination=$row;
    $row=imagecopyresampled($destination, $source, $new_width, $new_height, $width, $height);
    $row=imagejpeg($destination, $compressed_image, $compression_quality);
    $row=imagedestroy($source);
    $row=imagedestroy($destination);
}