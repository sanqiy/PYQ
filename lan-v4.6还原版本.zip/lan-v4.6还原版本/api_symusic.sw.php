<?php
$tmp=include '../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    $val["code"]="201";
    $val["msg"]="连接数据库失败";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$q=$_POST['q'];
$q=$q;
if($q==""){
    $val["code"]="201";
    $val["msg"]="空参数!";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($q))break;
    $name=$row["name"];
    $subtitle=$row["subtitle"];
    $icon=$row["icon"];
    $logo=$row["logo"];
    $zt=$row["zt"];
    $username=$row["username"];
    $homimg=$row["homimg"];
    $sign=$row["sign"];
    $wzmusic=$row["music"];
    $essgs=$row["essgs"];
    $commgs=$row["commgs"];
    $lnkzt=$row["lnkzt"];
    $regqx=$row["regqx"];
    $kqsy=$row["kqsy"];
}
L2xxd:
if($wzmusic==-1){
    $val["code"]="201";
    $val["mum"]=$mum;
    $val["muurl"]=$muurl;
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$parts=explode(PHP_EOL, $wzmusic);
$arr=$parts;
$q=array_filter($arr);
$arry=$q;
$parts=count($arry);
$ary=$parts;
$val3=$ary-1;
$parts=rand($val3);
$mu=$parts;
$yiny=$arry[$mu];
$parts=explode('|', $yiny);
$arys=$parts;
$mum=$arys[0];
$muurl=$arys[1];
$q=preg_replace('/[\s\r\n]+/','',$muurl);
$muurl=$q;
$tmp=$mum=="网易音乐";
$tmp2=(bool)$tmp;
if($tmp2){
    $parts=is_numeric($muurl);
    $tmp2=(bool)$parts;
}
if($tmp2){
    $mum=$arys[0];
    $tmp='//music.163.com/song/media/outer/url?id=' . $muurl;
    $muurl=$tmp . '.mp3';
}
$val["code"]="200";
$val["mum"]=$mum;
$val["muurl"]=$muurl;
$val2[]=$val;
$arr=$val2;
$parts=json_encode($arr);
echo $parts;
$result=$conn->close();