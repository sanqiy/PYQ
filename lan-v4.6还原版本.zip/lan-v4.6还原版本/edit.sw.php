<?php
if($_SERVER['REQUEST_METHOD']==='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val62[]=$val;
    $arr=$val62;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$fileExists=session_start();
$num9=6862;
$tmp=!isset($_SESSION['visits']);
if($tmp){
    $num9=133;
}else{
    $num9=225;
}
$tmp=17;
$tmp2=225;
$tmp3=$num9==225;
if($tmp3)goto L2xeWjgxa;
goto L2xldMhxa;
L2xeWjgxa:
$fileExists=time();
$time_diff=$fileExists-$_SESSION['start_time'];
$tmp=$time_diff>60;
if($tmp)goto L2xeWjgx8;
goto L2xldMhx8;
goto L2xldMhx8;
L2xeWjgx8:
$num12=1;
$_SESSION['visits']=$num12;
$fileExists=time();
$num12=$fileExists;
$_SESSION['start_time']=$num12;
goto L2xx9;
L2xldMhx8:
$visits=$_SESSION['visits'];
$visits2=$_SESSION['visits']+1;
$num12=$visits2;
$_SESSION['visits']=$num12;
L2xldMhxa:
switch($num9){
    case 133:{
    $num12=1;
    $_SESSION['visits']=$num12;
    $fileExists=time();
    $num12=$fileExists;
    $_SESSION['start_time']=$num12;
        break;
    }
}
L2xx9:
$num10=6871;
$tmp=$_SESSION['visits']<=5;
if($tmp){
    $num10=289;
}else{
    $num10=119;
}
$tmp=7;
$tmp2=119;
$tmp3=$num10==119;
if($tmp3)goto L2xeWjgxh;
goto L2xldMhxh;
L2xeWjgxh:
exit("请求频繁,请稍后再试!");
goto L2xxg;
L2xldMhxh:
$tmp=76;
$tmp2=289;
$tmp3=$num10==289;
if($tmp3)goto L2xxg;
L2xxg:
$num11=6870;
$isArray=is_array($_GET);
if($isArray){
    $num11=105;
}else{
    $num11=225;
}
switch($num11){
    case 225:{
    $cid=$_GET['cid'];
        break;
    }
    case 105:{
        $cid=&$_GET['cid'];
        break;
    }
}
$timestamp=htmlspecialchars($cid);
unset($cid);
$escaped=addslashes($timestamp);
$cid=$escaped;
$referer=$_SERVER['HTTP_REFERER'];
$num=6877;
$fileExists=strpos($referer, "view.php");
$tmp=$fileExists!==false;
if($tmp){
    $num=285;
}else{
    $num=75;
}
$tmp=152;
$tmp2=285;
$tmp3=$num==285;
if($tmp3)goto L2xeWjgxt;
goto L2xldMhxt;
L2xeWjgxt:
$tmp=$cid!="";
if($tmp)goto L2xeWjgxr;
goto L2xldMhxr;
goto L2xldMhxr;
L2xeWjgxr:
$tiaourl="./view.php?cid=" . $cid;
goto L2xxs;
L2xldMhxr:
$tiaourl="./view.php";
L2xldMhxt:
switch($num){
    case 75:{
    $tiaourl="./index.php";
        break;
    }
}
L2xxs:
$iteace=0;
$num2=6868;
$fileExists=is_file('./config.php');
if($fileExists){
    $num2=75;
}else{
    $num2=225;
}
switch($num2){
    case 75:{
    $tmp=require './config.php';
        break;
    }
    case 225:{
        exit('未检测到配置文件：<span style="color: red;">config.php</span>，若您是首次使用请先进行安装,删除文件夹 <span style="color: red;">[install/]</span> 下的 <span style="color: red;">[ins.bak]</span> 文件后进行安装。若已删除请<a href="./install/">【点击安装】</a>');
        break;
    }
}
$tmp=require './api/wz.php';
if($userdlzt==0){
    $fileExists=Header("Location:./index.php");
    exit();
}
if($cid!="")goto L2xeWjgx1t;
goto L2xldMhx1t;
L2xeWjgx1t:
$tmp="select * from essay where cid = '" . $cid;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
$fileExists=mysqli_num_rows($result);
$tmp=!$fileExists;
$tmp2=$tmp>0;
if($tmp2){
    $fileExists=strpos($referer, "view.php");
    $tmp=$fileExists!==false;
    if($tmp){
        $tiaourl="./home.php";
    }else{
        $tiaourl="./index.php";
    }
    $tmp='<script language="JavaScript">;alert("该文章不存在或已被删除!");location.href="' . $tiaourl;
    exit($tmp . '";</script>;');
}
$tmp=$zjzhq==$glyadmin;
if($tmp)goto L2xx1d;
goto L2xldMhx1e;
L2xldMhx1e:
$tmp="select * from essay where cid= '" . $cid;
$sql=$tmp . "'";
$fileExists=mysqli_query($conn, $sql);
$result=$fileExists;
$fileExists=mysqli_num_rows($result);
$tmp=$fileExists>0;
if($tmp){
    $fileExists=mysqli_fetch_assoc($result);
    $row=$fileExists;
    $ptpuser=$row["ptpuser"];
}else{
    $fileExists=strpos($referer, "view.php");
    $tmp=$fileExists!==false;
    if($tmp){
        $tiaourl="./home.php";
    }else{
        $tiaourl="./index.php";
    }
    $tmp='<script language="JavaScript">;alert("未获取到文章数据");location.href="' . $tiaourl;
    exit($tmp . '";</script>;');
}
$tmp=$zjzhq==$ptpuser;
if(!($tmp)){
    $fileExists=strpos($referer, "view.php");
    $tmp=$fileExists!==false;
    if($tmp){
        $tiaourl="./home.php";
    }else{
        $tiaourl="./index.php";
    }
    $tmp='<script language="JavaScript">;alert("您无权操作其他用户的文章");location.href="' . $tiaourl;
    exit($tmp . '";</script>;');
}
L2xx1d:
$str="select * from essay where cid='" . $cid;
$str2=$str . "'";
$fileExists=mysqli_query($conn, $str2);
$data_result=$fileExists;
$fileExists=mysqli_fetch_array($data_result);
$row=$fileExists;
$ptpuser=$row["ptpuser"];
$ptpimg=$row["ptpimg"];
$ptpname=$row["ptpname"];
$ptptext=$row["ptptext"];
$ptpimag=$row["ptpimag"];
$ptpvideo=$row["ptpvideo"];
$ptpmusic=$row["ptpmusic"];
$ptplx=$row["ptplx"];
$ptpdw=$row["ptpdw"];
$ptptime=$row["ptptime"];
$ptpgg=$row["ptpgg"];
$ptpggurl=$row["ptpggurl"];
$ptpys=$row["ptpys"];
$commauth=$row["commauth"];
$ptpaud=$row["ptpaud"];
$ptpip=$row["ip"];
$cid=$row["cid"];
$wid=$row["id"];
$timestamp=strtotime($ptptime);
$dateStr=date('Y', $timestamp);
$year=$dateStr;
$timestamp=strtotime($ptptime);
$dateStr=date('m', $timestamp);
$month=$dateStr;
$timestamp=strtotime($ptptime);
$dateStr=date('d', $timestamp);
$day=$dateStr;
$timestamp=strtotime($ptptime);
$dateStr=date('H', $timestamp);
$hour=$dateStr;
$timestamp=strtotime($ptptime);
$dateStr=date('i', $timestamp);
$minute=$dateStr;
$timestamp=strtotime($ptptime);
$dateStr=date('s', $timestamp);
$second=$dateStr;
$val["title"]="::(呵呵)";
$val["img"]="./assets/owo/paopao/E591B5E591B5_2x.png";
$val2["title"]="::(哈哈)";
$val2["img"]="./assets/owo/paopao/E59388E59388_2x.png";
$val3["title"]="::(吐舌)";
$val3["img"]="./assets/owo/paopao/E59090E8888C_2x.png";
$val4["title"]="::(太开心)";
$val4["img"]="./assets/owo/paopao/E5A4AAE5BC80E5BF83_2x.png";
$val5["title"]="::(笑眼)";
$val5["img"]="./assets/owo/paopao/E7AC91E79CBC_2x.png";
$val6["title"]="::(花心)";
$val6["img"]="./assets/owo/paopao/E88AB1E5BF83_2x.png";
$val7["title"]="::(小乖)";
$val7["img"]="./assets/owo/paopao/E5B08FE4B996_2x.png";
$val8["title"]="::(乖)";
$val8["img"]="./assets/owo/paopao/E4B996_2x.png";
$val9["title"]="::(捂嘴笑)";
$val9["img"]="./assets/owo/paopao/E68D82E598B4E7AC91_2x.png";
$val10["title"]="::(滑稽)";
$val10["img"]="./assets/owo/paopao/E6BB91E7A8BD_2x.png";
$val11["title"]="::(你懂的)";
$val11["img"]="./assets/owo/paopao/E4BDA0E68782E79A84_2x.png";
$val12["title"]="::(不高兴)";
$val12["img"]="./assets/owo/paopao/E4B88DE9AB98E585B4_2x.png";
$val13["title"]="::(怒)";
$val13["img"]="./assets/owo/paopao/E68092_2x.png";
$val14["title"]="::(汗)";
$val14["img"]="./assets/owo/paopao/E6B197_2x.png";
$val15["title"]="::(黑线)";
$val15["img"]="./assets/owo/paopao/E9BB91E7BABF_2x.png";
$val16["title"]="::(泪)";
$val16["img"]="./assets/owo/paopao/E6B3AA_2x.png";
$val17["title"]="::(真棒)";
$val17["img"]="./assets/owo/paopao/E79C9FE6A392_2x.png";
$val18["title"]="::(喷)";
$val18["img"]="./assets/owo/paopao/E596B7_2x.png";
$val19["title"]="::(惊哭)";
$val19["img"]="./assets/owo/paopao/E6838AE593AD_2x.png";
$val20["title"]="::(阴险)";
$val20["img"]="./assets/owo/paopao/E998B4E999A9_2x.png";
$val21["title"]="::(鄙视)";
$val21["img"]="./assets/owo/paopao/E98499E8A786_2x.png";
$val22["title"]="::(酷)";
$val22["img"]="./assets/owo/paopao/E985B7_2x.png";
$val23["title"]="::(啊)";
$val23["img"]="./assets/owo/paopao/E5958A_2x.png";
$val24["title"]="::(狂汗)";
$val24["img"]="./assets/owo/paopao/E78B82E6B197_2x.png";
$val25["title"]="::(what)";
$val25["img"]="./assets/owo/paopao/what_2x.png";
$val26["title"]="::(疑问)";
$val26["img"]="./assets/owo/paopao/E79691E997AE_2x.png";
$val27["title"]="::(酸爽)";
$val27["img"]="./assets/owo/paopao/E985B8E788BD_2x.png";
$val28["title"]="::(呀咩蹀)";
$val28["img"]="./assets/owo/paopao/E59180E592A9E788B9_2x.png";
$val29["title"]="::(委屈)";
$val29["img"]="./assets/owo/paopao/E5A794E5B188_2x.png";
$val30["title"]="::(惊讶)";
$val30["img"]="./assets/owo/paopao/E6838AE8AEB6_2x.png";
$val31["title"]="::(睡觉)";
$val31["img"]="./assets/owo/paopao/E79DA1E8A789_2x.png";
$val32["title"]="::(笑尿)";
$val32["img"]="./assets/owo/paopao/E7AC91E5B0BF_2x.png";
$val33["title"]="::(挖鼻)";
$val33["img"]="./assets/owo/paopao/E68C96E9BCBB_2x.png";
$val34["title"]="::(吐)";
$val34["img"]="./assets/owo/paopao/E59090_2x.png";
$val35["title"]="::(犀利)";
$val35["img"]="./assets/owo/paopao/E78A80E588A9_2x.png";
$val36["title"]="::(小红脸)";
$val36["img"]="./assets/owo/paopao/E5B08FE7BAA2E884B8_2x.png";
$val37["title"]="::(懒得理)";
$val37["img"]="./assets/owo/paopao/E68792E5BE97E79086_2x.png";
$val38["title"]="::(勉强)";
$val38["img"]="./assets/owo/paopao/E58B89E5BCBA_2x.png";
$val39["title"]="::(爱心)";
$val39["img"]="./assets/owo/paopao/E788B1E5BF83_2x.png";
$val40["title"]="::(心碎)";
$val40["img"]="./assets/owo/paopao/E5BF83E7A28E_2x.png";
$val41["title"]="::(玫瑰)";
$val41["img"]="./assets/owo/paopao/E78EABE791B0_2x.png";
$val42["title"]="::(礼物)";
$val42["img"]="./assets/owo/paopao/E7A4BCE789A9_2x.png";
$val43["title"]="::(彩虹)";
$val43["img"]="./assets/owo/paopao/E5BDA9E899B9_2x.png";
$val44["title"]="::(太阳)";
$val44["img"]="./assets/owo/paopao/E5A4AAE998B3_2x.png";
$val45["title"]="::(星星月亮)";
$val45["img"]="./assets/owo/paopao/E6989FE6989FE69C88E4BAAE_2x.png";
$val46["title"]="::(钱币)";
$val46["img"]="./assets/owo/paopao/E992B1E5B881_2x.png";
$val47["title"]="::(茶杯)";
$val47["img"]="./assets/owo/paopao/E88CB6E69DAF_2x.png";
$val48["title"]="::(蛋糕)";
$val48["img"]="./assets/owo/paopao/E89B8BE7B395_2x.png";
$val49["title"]="::(大拇指)";
$val49["img"]="./assets/owo/paopao/E5A4A7E68B87E68C87_2x.png";
$val50["title"]="::(胜利)";
$val50["img"]="./assets/owo/paopao/E8839CE588A9_2x.png";
$val51["title"]="::(haha)";
$val51["img"]="./assets/owo/paopao/haha_2x.png";
$val52["title"]="::(OK)";
$val52["img"]="./assets/owo/paopao/OK_2x.png";
$val53["title"]="::(沙发)";
$val53["img"]="./assets/owo/paopao/E6B299E58F91_2x.png";
$val54["title"]="::手纸";
$val54["img"]="./assets/owo/paopao/E6898BE7BAB8_2x.png";
$val55["title"]="::(香蕉)";
$val55["img"]="./assets/owo/paopao/E9A699E89589_2x.png";
$val56["title"]="::(便便)";
$val56["img"]="./assets/owo/paopao/E4BEBFE4BEBF_2x.png";
$val57["title"]="::(药丸)";
$val57["img"]="./assets/owo/paopao/E88DAFE4B8B8_2x.png";
$val58["title"]="::(红领巾)";
$val58["img"]="./assets/owo/paopao/E7BAA2E9A286E5B7BE_2x.png";
$val59["title"]="::(蜡烛)";
$val59["img"]="./assets/owo/paopao/E89CA1E7839B_2x.png";
$val60["title"]="::(音乐)";
$val60["img"]="./assets/owo/paopao/E99FB3E4B990_2x.png";
$val61["title"]="::(灯泡)";
$val61["img"]="./assets/owo/paopao/E781AFE6B3A1_2x.png";
$val63[]=$val;
$val63[]=$val2;
$val63[]=$val3;
$val63[]=$val4;
$val63[]=$val5;
$val63[]=$val6;
$val63[]=$val7;
$val63[]=$val8;
$val63[]=$val9;
$val63[]=$val10;
$val63[]=$val11;
$val63[]=$val12;
$val63[]=$val13;
$val63[]=$val14;
$val63[]=$val15;
$val63[]=$val16;
$val63[]=$val17;
$val63[]=$val18;
$val63[]=$val19;
$val63[]=$val20;
$val63[]=$val21;
$val63[]=$val22;
$val63[]=$val23;
$val63[]=$val24;
$val63[]=$val25;
$val63[]=$val26;
$val63[]=$val27;
$val63[]=$val28;
$val63[]=$val29;
$val63[]=$val30;
$val63[]=$val31;
$val63[]=$val32;
$val63[]=$val33;
$val63[]=$val34;
$val63[]=$val35;
$val63[]=$val36;
$val63[]=$val37;
$val63[]=$val38;
$val63[]=$val39;
$val63[]=$val40;
$val63[]=$val41;
$val63[]=$val42;
$val63[]=$val43;
$val63[]=$val44;
$val63[]=$val45;
$val63[]=$val46;
$val63[]=$val47;
$val63[]=$val48;
$val63[]=$val49;
$val63[]=$val50;
$val63[]=$val51;
$val63[]=$val52;
$val63[]=$val53;
$val63[]=$val54;
$val63[]=$val55;
$val63[]=$val56;
$val63[]=$val57;
$val63[]=$val58;
$val63[]=$val59;
$val63[]=$val60;
$val63[]=$val61;
$arr=$val63;
$num12=0;
$i=$num12;
while(true){
    $fileExists=count($arr);
    $tmp=$i<$fileExists;
    if(!$tmp)break;
    $danm=$arr[$i]["title"];
    $dang=$arr[$i]["img"];
    $tmp='<span class="sh-nr-bq-img-wk"><img src="./assets/img/thumbnail.svg" data-src="' . $dang;
    $tmp2=$tmp . '" class="sh-nr-bq-img" alt="';
    $tmp3=$tmp2 . $danm;
    $aeimg=$tmp3 . '"></span>';
    $fileExists=str_ireplace($aeimg, $danm, $ptptext);
    $ptptext=$fileExists;
    $tmp='<img src="./assets/img/thumbnail.svg" data-src="' . $dang;
    $aeimg=$tmp . '" class="sh-nr-bq-img">';
    $fileExists=str_ireplace($aeimg, $danm, $ptptext);
    $ptptext=$fileExists;
    $pattern='/<a\s+.*?\bhref=["\'](.*?)["\'].*.*?<\/a>/i';
    $replacement=' $1 ';
    $num12=preg_replace($pattern,$replacement,$ptptext);
    $ptptext=$num12;
    $fileExists=str_replace("<br>", "", $ptptext);
    $ptptext=$fileExists;
    $visits2=$i;
    $obj=$i+1;
    $num12=$obj;
    $i=$num12;
}
goto L2xx1s;
L2xldMhx1t:
L2xx1s:
echo "<!DOCTYPE html>";
echo "
<html lang=\"zh-CN\">";
echo "
<head>";
echo "
<meta charset=\"UTF-8\">";
echo "
<title>发布 - ";
echo $name;
echo "</title>";
echo "
<!--为搜索引擎定义关键词-->";
echo "
<meta name=\"keywords\" content=\"";
echo $filterkeyw;
echo "\">";
echo "
<!--为网页定义描述内容 用于告诉搜索引擎，你网站的主要内容-->";
echo "
<meta name=\"description\" content=\"";
echo $subtitle;
echo "\">";
echo "
<meta name=\"author\" content=\"";
echo $name;
echo "\">";
echo "
<meta name=\"copyright\" content=\"";
echo $name;
echo "\">";
echo "
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" />";
echo "
<meta http-equiv=\"cache-control\" content=\"no-cache\">";
echo "
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0,minimum-scale=1.0, user-scalable=no minimal-ui\">";
echo "
<link rel=\"apple-touch-icon\" sizes=\"57x57\" href=\"";
echo $icon;
echo "\" /><!-- Standard iPhone -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"114x114\" href=\"";
echo $icon;
echo "\" /><!-- Retina iPhone -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"72x72\" href=\"";
echo $icon;
echo "\" /><!-- Standard iPad -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"144x144\" href=\"";
echo $icon;
echo "\" /><!-- Retina iPad -->";
echo "
<link rel=\"icon\" href=\"";
echo $icon;
echo "\" type=\"image/x-icon\" />";
echo "
<meta name=\"robots\" content=\"index,follow\">";
echo "
<meta name=\"format-detection\" content=\"telephone=no\">";
echo "
<meta http-equiv=\"x-rim-auto-match\" content=\"none\">";
echo "
";
if($rosdomain==1){
    echo '<meta name="referrer" content="no-referrer">';
}
echo "    <link rel=\"stylesheet\" href=\"";
echo $iconurl_url;
echo "\">";
echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"./assets/css/style.css\">";
echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"./assets/mesg/dist/css/style.css\"><!--引入弹窗对话框-->";
echo "
";
echo $scfontzt;
echo "    ";
$folderPath='./user/bobg/';
$fileExists=file_exists($folderPath);
$tmp=!$fileExists;
if($tmp){
    $fileExists=mkdir($folderPath, true);
}
$num3=6877;
$fileExists=file_exists("./user/bobg/bobg.jpg");
if($fileExists){
    $num3=255;
}else{
    $fileExists=file_exists("./user/bobg/bobg.png");
    if($fileExists){
        $num3=85;
    }else{
        $fileExists=file_exists("./user/bobg/bobg.jpeg");
        if($fileExists){
            $num3=119;
        }else{
            $fileExists=file_exists("./user/bobg/bobg.gif");
            if($fileExists){
                $num3=35;
            }
        }
    }
}
switch($num3){
    case 35:{
    echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.gif);}</style>';
        break;
    }
    case 85:{
        echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.png);}</style>';
        break;
    }
    case 255:{
            echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.jpg);}</style>';
        break;
    }
    case 119:{
                echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.jpeg);}</style>';
        break;
    }
}
echo "    ";
$tmp='<style>' . $filtercucss;
$tmp2=$tmp . '</style>';
echo $tmp2;
echo "</head>";
echo "
<body class=\"";
$num4=6870;
if(isset($_COOKIE['dark_theme'])){
    $num4=49;
}else{
    $num4=105;
}
$tmp=11;
$tmp2=49;
$tmp3=$num4==49;
if($tmp3)goto L2xeWjgx2y;
goto L2xldMhx2y;
L2xeWjgx2y:
$tmp=$_COOKIE["dark_theme"]=="dark-theme";
if($tmp)goto L2xeWjgx2w;
goto L2xx2x;
goto L2xx2x;
L2xeWjgx2w:
echo 'dark-theme';
goto L2xx2x;
L2xldMhx2y:
$tmp=3;
$tmp2=105;
$tmp3=$num4==105;
if($tmp3)goto L2xx2x;
L2xx2x:
echo "\">";
echo "
";
if($pagepass!="")goto L2xeWjgx3a;
goto L2xldMhx3a;
L2xeWjgx3a:
if(isset($_COOKIE['pagepass']))goto L2xeWjgx36;
goto L2xldMhx36;
goto L2xldMhx36;
L2xeWjgx36:
$timestamp=md5($pagepass);
$dateStr=md5($timestamp);
$tmp=$_COOKIE['pagepass']!=$dateStr;
if($tmp)goto L2xeWjgx38;
goto L2xx39;
goto L2xx39;
L2xeWjgx38:
$tmp=include './site/pagepass.php';
goto L2xx39;
L2xldMhx36:
$tmp=include './site/pagepass.php';
L2xldMhx3a:
L2xx39:
echo "    <div class=\"centent\">";
echo "
<div class=\"sh-main setup-main edit-main\" >";
echo "
<form method=\"post\" action=\"./api/form.php\" enctype=\"multipart/form-data\" onsubmit=\"return dosubmit()\" autocomplete=\"off\">";
echo "
";
$num5=6878;
$tmp=$cid!="";
if($tmp){
    $num5=105;
}else{
    $num5=35;
}
switch($num5){
    case 105:{
    $tmp='<input type="text" name="edlx" value="edites" checked id="editeslx" style="display: none;"/>
    <input type="text" name="edwzcid" value="' . $cid;
    $tmp2=190;
    echo $tmp2;
        break;
    }
    case 35:{
        echo '<input type="text" name="edlx" value="prees" checked id="editeslx" style="display: none;"/>';
        break;
    }
}
echo "            <div class=\"sh-main-head setup-main-head\">";
echo "
<!-- 顶部菜单 -->";
echo "
<div class=\"sh-main-head-top setup-main-top\" id=\"sh-main-head-top\">";
echo "
<!-- 左边 -->";
echo "
<div class=\"sh-main-head-top-left\">";
echo "
<div class=\"sh-main-head-top-left-s\" onclick=\"location.href='";
echo $tiaourl;
echo "'\">";
echo "
<i class=\"iconfont icon-weibiaoti al-sxbh\" id=\"top-left-1\"></i>";
echo "
</div>";
echo "
<div class=\"sh-main-head-top-left-s setup-main-head-top-left-s\">";
echo "
<span class=\"setup-main-title\">发布</span>";
echo "
</div>";
echo "
</div>";
echo "
<!-- 右边 -->";
echo "
<div class=\"sh-main-head-top-right\">";
echo "
<div class=\"sh-main-head-top-right-s-fas\">";
echo "
<button type=\"submit\" id=\"submit\">发布</button>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
<div class=\"sh-cont-nr\">";
echo "
<div class=\"sh-cont-nr-tzh\">";
echo "
<textarea name=\"text\" id=\"bletext\" class=\"form-controll\" placeholder=\"说点什么..\" required=\"\" maxlength=\"50000\" spellcheck=\"false\">";
if($ptptext!=""){
    echo $ptptext;
}
echo "</textarea>";
echo "
</div>";
echo "
";
echo "
<!--各种开关控制-->";
echo "
<div class=\"sh-cont-nr-kg\">";
echo "
";
echo "
<!--表情开关按钮-->";
echo "
<div class=\"sh-cont-nr-kg-bqkg\" onclick=\"shkgbqkg()\" title=\"表情\" id=\"bqkg\"><i class=\"iconfont icon-biaoqing ri-sxfbbq\" id=\"bqkgimg\"></i></div>";
echo "
<!--红包-->";
echo "
";
if($cid==""){
    echo '<div class="sh-cont-nr-kg-ggkg" onclick="hbkg()" title="发红包" id="hbkg" lang="0"><i class="iconfont icon-hongbao ri-sxfbbq" id="hbkgimg"></i>
    </div>';
}
echo "                    ";
echo "
<!--广告开关按钮-->";
echo "
";
$num6=6866;
$tmp=$ptpgg=="1";
if($tmp){
    $num6=35;
}else{
    $num6=119;
}
switch($num6){
    case 35:{
    echo '<div class="sh-cont-nr-kg-ggkg" onclick="ggkg()" title="取消广告" id="ggkg" lang="1" style="background: var(--themetm);"><i class="iconfont icon-ljgg ri-sxfbbqls" id="ggkgimg"></i>
    <input type="radio" name="radiogg" value="1" checked="" id="ggmk" style="display: none;">
    </div>';
        break;
    }
    case 119:{
        echo '<div class="sh-cont-nr-kg-ggkg" onclick="ggkg()" title="设为广告" id="ggkg" lang="0"><i class="iconfont icon-ljgg ri-sxfbbq" id="ggkgimg"></i>
        <input type="radio" name="radiogg" value="0" checked id="ggmk" style="display: none;"/>
        </div>';
        break;
    }
}
echo "                    ";
echo "
";
echo "
";
if($notname=="1")goto L2xeWjgx43;
goto L2xldMhx43;
L2xeWjgx43:
$tmp=$cid=="";
if($tmp)goto L2xeWjgx41;
goto L2xx42;
goto L2xx42;
L2xeWjgx41:
echo '<!--匿名开关按钮-->
<div class="sh-cont-nr-kg-yxplkg" onclick="nmkgz()" title="匿名发布" id="nmkgz" lang="0"><i class="iconfont icon-anonymous ri-sxfbbq" id="nmkgimg"></i>
<input type="radio" name="nmkg" value="0" checked id="nmmkz" style="display: none;"/>
</div>';
goto L2xx42;
L2xldMhx43:
L2xx42:
echo "                    ";
echo "
<!--评论开关按钮-->";
echo "
";
$num7=6867;
$tmp=$commauth!="0";
if($tmp){
    $num7=133;
}else{
    $num7=25;
}
switch($num7){
    case 25:{
    echo '<div class="sh-cont-nr-kg-yxplkg" onclick="yxplkgz()" title="禁止评论" id="yxplkgz" lang="0" style="background: var(--fgxys);"><i class="iconfont icon-pinglun-yx ri-sxfbbq" id="yxplkgimg"></i>
    <input type="radio" name="yxplkg" value="0" checked="" id="yxplmkz" style="display: none;">
    </div>';
        break;
    }
    case 133:{
        echo '<div class="sh-cont-nr-kg-yxplkg" onclick="yxplkgz()" title="允许评论" id="yxplkgz" lang="1" style="background: var(--themetm);"><i class="iconfont icon-pinglun-yx ri-sxfbbqls" id="yxplkgimg"></i>
        <input type="radio" name="yxplkg" value="1" checked id="yxplmkz" style="display: none;"/>
        </div>';
        break;
    }
}
echo "                    ";
echo "
";
echo "
<!--文章类型切换按钮-->";
echo "
";
if($cid==""){
    echo '<div class="sh-cont-nr-kg-lxqh" onclick="lxqhkg()" title="文章类型:图文" id="lxqh"><i class="iconfont icon-tupian ri-sxfbbqls" id="lxqhimg"></i>
    <input type="radio" name="radio" value="1" checked id="lxmk" style="display: none;"/>
    </div>
    <!--图片链接与上传切换按钮-->
    <div class="sh-cont-nr-kg-twl" onclick="tpscfs()" title="切换外链图片" id="tpscfs" lang="0"><i class="iconfont icon-qiehuan ri-sxfbbq" id="twlimg"></i>
    </div>';
}
echo "                    ";
echo "
";
echo "
</div>";
echo "
<!--各种开关控制 end-->";
echo "
";
echo "
<div class=\"sh-pinglun-biao\" id=\"biaoqing\" style=\"display: none;\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E591B5E591B5_2x.png\" alt=\"::(呵呵)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E59388E59388_2x.png\" alt=\"::(哈哈)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E59090E8888C_2x.png\" alt=\"::(吐舌)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5A4AAE5BC80E5BF83_2x.png\" alt=\"::(太开心)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E7AC91E79CBC_2x.png\" alt=\"::(笑眼)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E88AB1E5BF83_2x.png\" alt=\"::(花心)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5B08FE4B996_2x.png\" alt=\"::(小乖)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E4B996_2x.png\" alt=\"::(乖)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E68D82E598B4E7AC91_2x.png\" alt=\"::(捂嘴笑)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6BB91E7A8BD_2x.png\" alt=\"::(滑稽)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E4BDA0E68782E79A84_2x.png\" alt=\"::(你懂的)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E4B88DE9AB98E585B4_2x.png\" alt=\"::(不高兴)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E68092_2x.png\" alt=\"::(怒)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6B197_2x.png\" alt=\"::(汗)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E9BB91E7BABF_2x.png\" alt=\"::(黑线)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6B3AA_2x.png\" alt=\"::(泪)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E79C9FE6A392_2x.png\" alt=\"::(真棒)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E596B7_2x.png\" alt=\"::(喷)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6838AE593AD_2x.png\" alt=\"::(惊哭)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E998B4E999A9_2x.png\" alt=\"::(阴险)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E98499E8A786_2x.png\" alt=\"::(鄙视)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E985B7_2x.png\" alt=\"::(酷)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5958A_2x.png\" alt=\"::(啊)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E78B82E6B197_2x.png\" alt=\"::(狂汗)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/what_2x.png\" alt=\"::(what)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E79691E997AE_2x.png\" alt=\"::(疑问)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E985B8E788BD_2x.png\" alt=\"::(酸爽)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E59180E592A9E788B9_2x.png\" alt=\"::(呀咩蹀)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5A794E5B188_2x.png\" alt=\"::(委屈)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6838AE8AEB6_2x.png\" alt=\"::(惊讶)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E79DA1E8A789_2x.png\" alt=\"::(睡觉)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E7AC91E5B0BF_2x.png\" alt=\"::(笑尿)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E68C96E9BCBB_2x.png\" alt=\"::(挖鼻)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E59090_2x.png\" alt=\"::(吐)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E78A80E588A9_2x.png\" alt=\"::(犀利)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5B08FE7BAA2E884B8_2x.png\" alt=\"::(小红脸)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E68792E5BE97E79086_2x.png\" alt=\"::(懒得理)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E58B89E5BCBA_2x.png\" alt=\"::(勉强)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E788B1E5BF83_2x.png\" alt=\"::(爱心)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5BF83E7A28E_2x.png\" alt=\"::(心碎)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E78EABE791B0_2x.png\" alt=\"::(玫瑰)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E7A4BCE789A9_2x.png\" alt=\"::(礼物)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5BDA9E899B9_2x.png\" alt=\"::(彩虹)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5A4AAE998B3_2x.png\" alt=\"::(太阳)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6989FE6989FE69C88E4BAAE_2x.png\" alt=\"::(星星月亮)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E992B1E5B881_2x.png\" alt=\"::(钱币)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E88CB6E69DAF_2x.png\" alt=\"::(茶杯)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E89B8BE7B395_2x.png\" alt=\"::(蛋糕)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5A4A7E68B87E68C87_2x.png\" alt=\"::(大拇指)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E8839CE588A9_2x.png\" alt=\"::(胜利)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/haha_2x.png\" alt=\"::(haha)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/OK_2x.png\" alt=\"::(OK)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6B299E58F91_2x.png\" alt=\"::(沙发)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6898BE7BAB8_2x.png\" alt=\"::手纸\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E9A699E89589_2x.png\" alt=\"::(香蕉)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E4BEBFE4BEBF_2x.png\" alt=\"::(便便)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E88DAFE4B8B8_2x.png\" alt=\"::(药丸)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E7BAA2E9A286E5B7BE_2x.png\" alt=\"::(红领巾)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E89CA1E7839B_2x.png\" alt=\"::(蜡烛)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E99FB3E4B990_2x.png\" alt=\"::(音乐)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E781AFE6B3A1_2x.png\" alt=\"::(灯泡)\" onclick=\"biaoqzj()\">";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
<!--红包-->";
echo "
";
if($cid==""){
    echo '<div id="sh-cont-hongbao" class="sh-cont-hongbao">
    <div class="sh-cont-hongbao-fl">
    <span class="sh-cont-hongbao-fl-pt" id="sh-cont-hongbao-fl-pt">普通</span>
    <span class="sh-cont-hongbao-fl-sq" id="sh-cont-hongbao-fl-sq">拼手气</span>
    <input type="hidden" name="hblx" id="hblx" value="0">
    </div>
    <div class="sh-cont-hongbz">
    <div class="sh-cont-hongbz-gs">
    <div class="sh-cont-hongbz-gs-z">
    <span class="sh-cont-hongbz-gs-z-bs">个数</span>
    </div>
    <div class="sh-cont-hongbz-gs-y">
    <input type="number" name="hbgs" id="hbgs" value="" placeholder="填写个数" minlength="1" maxlength="200" spellcheck="false">
    <span>个</span>
    </div>
    </div>
    <div class="sh-cont-hongbz-ed">
    <div class="sh-cont-hongbz-gs-z">
    <span class="sh-cont-hongbz-gs-z-psq" id="sh-cont-hongbz-gs-z-psq">拼</span>
    <span class="sh-cont-hongbz-gs-z-bs">总金额</span>
    </div>
    <div class="sh-cont-hongbz-gs-y">
    <input type="number" name="hbzje" id="hbzje" value="" placeholder="0.00" minlength="1" maxlength="200" spellcheck="false">
    <span>元</span>
    </div>
    </div>
    <div class="sh-cont-hongbz-ed">
    <div class="sh-cont-hongbz-gs-z">
    <input type="text" name="hbzf" id="hbzf" value="大吉大利" placeholder="大吉大利" minlength="1" maxlength="10" spellcheck="false">
    </div>
    </div>
    <div class="sh-cont-hongbz-fmxz">
    <div class="sh-cont-hongbz-fmxz-z">
    <p>红包封面</p>
    <span>默认</span>
    <input type="hidden" name="hbfimg" id="hbfimg" value="" minlength="1" maxlength="1" spellcheck="false">
    </div>
    <div class="sh-cont-hongbz-fmxz-y">
    <i class="iconfont icon-weibiaotiy ri-sxfbbq"></i>
    </div>
    </div>
    <div class="sh-cont-hongbz-jine">
    <div class="sh-cont-hongbz-jine-z">
    <span>￥</span>
    </div>
    <div class="sh-cont-hongbz-jine-y">
    <span id="sh-cont-hongbz-jine-y-je">0.00</span>
    </div>
    </div>
    </div>
    </div>';
}
echo "            ";
echo "
";
echo "
<!--定位-->";
echo "
<div class=\"sh-cont-dw\">";
echo "
<div class=\"sh-cont-dw-tu\" onclick=\"hqdqip()\" title=\"获取当前位置\">";
echo "
<i class=\"iconfont icon-31dingwei ri-sxgps\" id=\"sh-cont-dw\"></i></div>";
echo "
<input type=\"text\" name=\"dw\" id=\"dwxx\" value=\"";
if($ptpdw!=""){
    echo $ptpdw;
}
echo "\" placeholder=\"当前位置\" minlength=\"1\" maxlength=\"100\" spellcheck=\"false\">";
echo "
</div>";
echo "
";
echo "
<!--发布时间-->";
echo "
";
if($cid!=""){
    $tmp='<div class="sh-cont-dw">
    <div class="sh-cont-dw-tu" onclick="hqdqip()" title="发布时间">
    <i class="iconfont icon-shijian31 ri-sxgps" id="sh-cont-dw"></i></div>
    <input type="text" name="fbtime" id="fbtimexx" value="' . $year;
    $tmp2=$tmp . '-';
    $tmp3=$tmp2 . $month;
    $tmp4=$tmp3 . '-';
    $tmp5=$tmp4 . $day;
    $tmp6=$tmp5 . ' ';
    $tmp7=$tmp6 . $hour;
    $tmp8=$tmp7 . ':';
    $tmp9=$tmp8 . $minute;
    $tmp10=$tmp9 . ':';
    $tmp11=$tmp10 . $second;
    $tmp12=$tmp11 . '" placeholder="发布时间" minlength="1" maxlength="20" spellcheck="false" required>
    </div>';
    echo $tmp12;
}
echo "";
echo "
<!--广告跳转链接-->";
echo "
";
$num8=6875;
$tmp=$ptpgg=="1";
if($tmp){
    $num8=85;
}else{
    $num8=35;
}
switch($num8){
    case 35:{
    echo '<div class="sh-cont-gg" id="sh-cont-gg">
    <input type="url" name="gg" id="gglj" value="" placeholder="广告跳转链接" minlength="1" maxlength="2000" spellcheck="false">
    </div>';
        break;
    }
    case 85:{
        $tmp='<div class="sh-cont-gg" id="sh-cont-gg" style="display: flex;">
        <input type="url" name="gg" id="gglj" value="' . $ptpggurl;
        $tmp2=$tmp . '" placeholder="广告跳转链接" minlength="1" maxlength="2000" spellcheck="false">
        </div>';
        echo $tmp2;
        break;
    }
}
echo "            ";
echo "
";
echo "
<!--音乐-->";
echo "
<div class=\"sh-cont-yy\" id=\"sh-cont-yy\" ";
if($cid!=""){
    echo 'style="display:none"';
}
echo ">";
echo "
<span>";
echo "
<input type=\"text\" name=\"music\" id=\"music\" value=\"\" placeholder=\"ID/音乐链接*\" minlength=\"1\" maxlength=\"2000\" spellcheck=\"false\" style=\"border-radius: 4px 0 0 0;\">";
echo "
<p></p>";
echo "
<input type=\"text\" name=\"musicm\" id=\"musicm\" value=\"\" placeholder=\"歌名*\" minlength=\"1\" maxlength=\"2000\" spellcheck=\"false\" style=\"border-radius: 0 4px 0 0;\">";
echo "
</span>";
echo "
<div class=\"sh-cont-yy-fg\"></div>";
echo "
<span>";
echo "
<input type=\"text\" name=\"musics\" id=\"musics\" value=\"\" placeholder=\"歌手*\" minlength=\"1\" maxlength=\"2000\" spellcheck=\"false\" style=\"border-radius: 0 0 0 4px;\">";
echo "
<p></p>";
echo "
<input type=\"text\" name=\"musict\" id=\"musict\" value=\"\" placeholder=\"封面链接\" minlength=\"1\" maxlength=\"2000\" pattern=\"^(http|https)://[\\w\\-]+(\\.[\\w\\-]+)+([\\w\\-\\.,@?^=%&:/~\\+#]*[\\w\\-@?^=%&/~\\+#])?\$\" spellcheck=\"false\" style=\"border-radius: 0 0 4px 0;\">";
echo "
</span>";
echo "
<!--p>注:网易云音乐可直接填写音乐id</p-->";
echo "
</div>";
echo "
";
echo "
<!--视频-->";
echo "
<div class=\"sh-cont-sp\" id=\"sh-cont-sp\" ";
if($cid!=""){
    echo 'style="display:none"';
}
echo ">";
echo "
<input type=\"url\" name=\"spp\" id=\"spp\" value=\"\" placeholder=\"视频链接\" minlength=\"1\" maxlength=\"2000\" oninput=\"myScript()\" spellcheck=\"false\">";
echo "
</div>";
echo "
<div class=\"sh-cont-sp\" id=\"sh-cont-spfm\" style=\"display: none;margin-top: 2px;\">";
echo "
<input type=\"url\" name=\"sppfm\" id=\"sppfm\" value=\"\" placeholder=\"视频封面\" minlength=\"1\" maxlength=\"2000\" spellcheck=\"false\">";
echo "
</div>";
echo "
<video src=\"\" controls=\"controls\" controlslist=\"nodownload noplaybackrate noremoteplayback\" poster=\"\" oncontextmenu=\"return false\" class=\"sh-content-video sh-cont-video\" id=\"sh-content-video\" muted=\"true\" playsinline webkit-playsinline preload=\"metadata\" autoplay muted loop ";
if($cid==""){
    echo 'style="display:none"';
}
echo "></video>";
echo "
<div class=\"filsp\" id=\"filsp\" ";
if($cid!=""){
    echo 'style="display:none"';
}
echo ">";
echo "
<span class=\"cupload-upload-btn\">+</span>";
echo "
<input type=\"file\" accept=\"video/*\" name=\"file\" id=\"files\"><br>";
echo "
</div>";
echo "
";
echo "
<!--图片-->";
echo "
<div class=\"sh-cont-img\" id=\"sh-cont-img\" ";
if($cid!=""){
    echo 'style="display:none"';
}
echo ">";
echo "
<div class=\"sh-cont-imgul\" id=\"sh-cont-imgul\">";
echo "
<textarea name=\"imgul\" class=\"form-controllul\" placeholder=\"图片外链(一行一条,最多15条)\"></textarea>";
echo "
</div>";
echo "
<div class=\"cupload-image-list-wk\"><div id=\"cupload-7\"></div></div>";
echo "
</div>";
echo "
<input type=\"hidden\" name=\"allkey\" id=\"allkey\" value=\"";
echo $allkey;
echo "\">";
echo "
</form>";
echo "
<!--div class=\"edit-detu\" id=\"edit-detu\">";
echo "
<div class=\"edit-detu-wk\">";
echo "
<div class=\"edit-detu-wk-xx\"><i class=\"iconfont icon-shanchu3\"></i><span>删除</span></div>";
echo "
</div>";
echo "
</div-->";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo auth_ts;
echo "<div class=\"sh-copyright\">";
echo "
<span class=\"sh-copyright-banquan\" id=\"sh-copyright-banquan\">";
echo $copyright;
echo "</span>&nbsp;";
echo "
";
if($beian!=""){
    $fileExists=html_entity_decode($beian);
    $tmp='<span class="sh-copyright-banquan">' . $fileExists;
    $tmp2=$tmp . '</span>';
    echo $tmp2;
}
echo "</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<script type=\"text/javascript\" src=\"./assets/js/edit.js\"></script>";
echo "
<script src=\"./assets/js/cupload.js\"></script><!-- 引用多图上传js文件-->";
echo "
<script type=\"text/javascript\" src=\"./assets/mesg/dist/js/sh-noytf.js\"></script>";
echo "
<script type=\"text/javascript\">";
echo "
var cupload7 = new Cupload ({";
echo "
ele	: '#cupload-7',";
echo "
name: 'image',";
echo "
num	: 15,//限制图片上传最多15张";
echo "
});";
echo "
</script>";
echo "
";
$tmp='<script type="text/javascript">' . $filtercujs;
$tmp2=$tmp . '</script>';
echo $tmp2;
echo "</body>";
echo "
</html>";