<?php
$num2=5847;
$queryResult=file_exists("./config.php");
if($queryResult){
    $num2=72;
}else{
    $num2=96;
}
switch($num2){
    case 72:{
    $tmp2=include './config.php';
        break;
    }
    case 96:{
        $queryResult=header("Location:../index.php");
        break;
    }
}
$tmp2=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp2;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$sqly="SELECT * FROM admin";
$result=$conn->query($sqly);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($str))break;
if($row['topes']=="")goto L2xeWjgxf;
goto L2xldMhxf;
goto L2xldMhxf;
goto L2xldMhxf;
L2xeWjgxf:
    $snk=-403;
goto L2xxb;
goto L2xxe;
L2xldMhxf:
L2xxe:
    $ars=$row['topes'];
}
L2xxm:
L2xxb:
$filterpiccir="";
$sql="SELECT text FROM configx WHERE title = 'piccir'";
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0){
    $result=$result->fetch_assoc();
    $row=$result;
    $filterpiccir=$row['text'];
}
$num=5835;
$tmp2=$snk=='-201-201-1';
if($tmp2){
    $num=72;
}else{
    $num=16;
}
$tmp2=171;
$tmp3=16;
$tmp4=$num==16;
if($tmp4)goto L2xeWjgxby;
goto L2xldMhxby;
L2xeWjgxby:
$parts=explode(PHP_EOL, $ars);
$hash=array_reverse($parts);
$ars=$hash;
$iars=0;
while(true){
    $queryResult=count($ars);
    $tmp2=$iars<$queryResult;
    if(!$tmp2)break;
    $cdid=$ars[$iars];
    $tmp2="select * from essay where id= '" . $cdid;
    $sqly=$tmp2 . "'";
    $queryResult=mysqli_query($conn, $sqly);
    $result=$queryResult;
    $queryResult=mysqli_num_rows($result);
    $tmp2=$queryResult>0;
if($tmp2)goto L2xeWjgx13;
goto L2xldMhx13;
goto L2xldMhx13;
goto L2xldMhx13;
L2xeWjgx13:
L2xx14:
    while(true){
        $queryResult=mysqli_fetch_assoc($result);
        $row=$queryResult;
        if(!$str)break;
        $ptpuser=$row["ptpuser"];
        $ptpimg=$row["ptpimg"];
        $ptpname=$row["ptpname"];
        $ptptext=$row["ptptext"];
        $ptpimag=$row["ptpimag"];
        $ptpvideo=$row["ptpvideo"];
        $ptpmusic=$row["ptpmusic"];
        $ptplx=$row["ptplx"];
        $ptpdw=$row["ptpdw"];
        $ptptime=$row["ptptime"];
        $ptpgg=$row["ptpgg"];
        $ptpggurl=$row["ptpggurl"];
        $ptpys=$row["ptpys"];
        $commauth=$row["commauth"];
        $ptpaud=$row["ptpaud"];
        $ptpip=$row["ip"];
        $cid=$row["cid"];
        $wid=$row["id"];
        $queryResult=explode("|", $ptpvideo);
        $partssp=$queryResult;
        $ptpvideo=$partssp[0];
        $ptpvideofm=$partssp[1];
        $queryResult=explode('(+@+)', $ptpimag);
        $imgar=$queryResult;
        $queryResult=count($imgar);
        $coun=$queryResult;
        $tmp2=$coun==1;
        if($tmp2){
            $tusty=155;
        }else{
            $tmp2=$coun==4;
            $tmp4=(bool)$tmp2;
            $tmp5=!$tmp4;
            if($tmp5){
                $tmp3=$coun==2;
                $tmp4=(bool)$tmp3;
            }
            if($tmp4){
                $tusty=1155;
            }else{
                $tusty=111;
            }
        }
        $tmp2=$ptpgg==1;
        if($tmp2){
            $ggdiv='display: flex;';
            $tmp2='<div class="sh-content-right-ggurl"><i class="iconfont icon-lianjie1 ri-sxwzgg"></i><a href="' . $ptpggurl;
            $ggurl=$tmp2 . '" target="_blank">进一步了解</a></div>';
            $gps="";
            $zdes=-5;
        }else{
            $ggdiv='display: none;';
            $ggurl="";
            $tmp2='<div class="sh-content-right-gps"><a href="javascript:;">' . $ptpdw;
            $gps=$tmp2 . '</a></div>';
            $zdes="";
        }
        $queryResult=strtotime($ptptime);
        $time=$queryResult;
        $queryResult=ReckonTime($time);
        $wzfbsj=$queryResult;
        $tmp2=$ptpys==1;
        $tmp4=(bool)$tmp2;
        if($tmp4){
            $tmp3=$ptpaud==1;
            $tmp4=(bool)$tmp3;
        }
if($tmp4)goto L2xeWjgx1g;
goto L2xx14;
goto L2xx14;
goto L2xx14;
goto L2xx14;
L2xeWjgx1g:
        $str=preg_replace("/<img[^>]+>/i","",$ptptext);
        $contenttext0=$str;
        $str=preg_replace("/<span[^>]+>/i","",$contenttext0);
        $contenttext1=$str;
        $str=preg_replace("/<a href=[^>]+>/i","",$contenttext1);
        $contenttext=$str;
        $queryResult=iconv_strlen($contenttext, "UTF-8");
        $tmp2=$queryResult>100;
        if($tmp2){
            $tmp2='<span class="wzndhycyc" id="sh-content-qwdid-' . $cid;
            $tmp3=$tmp2 . '">';
            $tmp4=$tmp3 . $ptptext;
            $tmp5=$tmp4 . '</span><a href="JavaScript:;" class="sh-content-quanwenan" id="sh-content-quanwenan-';
            $tmp6=$tmp5 . $cid;
            $tmp7=$tmp6 . '" lang="0" onclick="quanwenan()">全文</a>';
            $ptptext=$tmp7;
        }else{
            $tmp2='<span>' . $ptptext;
            $ptptext=$tmp2 . '</span>';
        }
        $tmp2=$ptpname=="匿名用户";
        if($tmp2){
            $arcuserurl='';
        }else{
            $parts=md5($ptpuser);
            $hash=md5($parts);
            $tmp2='onclick="location.href=\'./archives.php?user=' . $hash;
            $arcuserurl=$tmp2 . '\'"';
        }
        $tmp2='
        <div class="sh-content"  id="sh-content-' . $cid;
        $tmp3=$tmp2 . '">
        <!-- 左边 -->
        <div class="sh-content-left">
        <!-- 头像 -->
        <img src="./assets/img/thumbnail.svg" data-src="';
        $tmp4=$tmp3 . $ptpimg;
        $tmp5=$tmp4 . '" alt="头像" ';
        $tmp6=$tmp5 . $arcuserurl;
        $tmp7=$tmp6 . '>
        </div>
        <!-- 右边 -->
        <div class="sh-content-right">
        <!-- 昵称与内容 -->
        <div class="sh-content-right-head">
        <!-- 昵称 -->
        <div class="sh-content-right-head-title">
        <p>';
        $tmp8=$tmp7 . $ptpname;
        $tmp9=$tmp8 . '</p>
        <div style="display: flex;align-content: center;">
        <div class="sh-content-right-head-title-ad" style="background: var(--themetm);';
        $tmp10=$tmp9 . $zdes;
        $tmp11=$tmp10 . '">
        <p style="color: var(--theme);">置顶</p>
        </div>
        <div class="sh-content-right-head-title-ad" style="';
        $tmp12=$tmp11 . $ggdiv;
        $tmp13=$tmp12 . '">
        <p>广告</p>
        </div></div>
        </div>
        <!-- 内容 -->
        ';
        $tmp14=$tmp13 . $ptptext;
        echo $tmp14;
        $tmp2=$ptplx=="only";
if($tmp2)goto L2xeWjgx1m;
goto L2xldMhx1m;
goto L2xldMhx1m;
goto L2xldMhx1m;
goto L2xldMhx1m;
L2xeWjgx1m:
        echo '<!-- 图片 -->';
goto L2xx1l;
L2xldMhx1m:
        $tmp2=$ptplx=="img";
if($tmp2)goto L2xeWjgx1n;
goto L2xldMhx1n;
goto L2xldMhx1n;
goto L2xldMhx1n;
goto L2xldMhx1n;
L2xeWjgx1n:
        $tmp2=$coun>"1";
        if($tmp2){
            $picimg=100;
        }else{
            $picimg='';
        }
        $tmp2='<!-- 图片 -->
        <div class="sh-content-right-img" id="imglib-' . $cid;
        $tmp3=$tmp2 . '" style="';
        $tmp4=$tmp3 . $tusty;
        $tmp5=$tmp4 . '">';
        echo $tmp5;
        $str=0;
        $i=$str;
        while(true){
            $tmp2=$i<$coun;
            if(!$tmp2)break;
            $tuimg=$imgar[$i];
            $tmp2=$i>7;
if($tmp2)goto L2xeWjgx1u;
goto L2xldMhx1u;
goto L2xldMhx1u;
goto L2xldMhx1u;
goto L2xldMhx1u;
goto L2xldMhx1u;
L2xeWjgx1u:
            $tmp2=$coun-$i;
            $duoimg=$tmp2-1;
            $tmp2=$coun>9;
if($tmp2)goto L2xeWjgx1w;
goto L2xldMhx1w;
goto L2xldMhx1w;
goto L2xldMhx1w;
goto L2xldMhx1w;
goto L2xldMhx1w;
L2xeWjgx1w:
            $tmp2=$i==8;
if($tmp2)goto L2xeWjgx1y;
goto L2xldMhx1y;
goto L2xldMhx1y;
goto L2xldMhx1y;
goto L2xldMhx1y;
goto L2xldMhx1y;
L2xeWjgx1y:
            $tmp2='<a href="' . $tuimg;
            $tmp3=$tmp2 . '" class="sh-content-right-img-pic" data-fancybox="gallery';
            $tmp4=$tmp3 . $cid;
            $tmp5=$tmp4 . '" data-caption="">
            <span class="sh-content-right-img-pic-mask">+';
            $tmp6=$tmp5 . $duoimg;
            $tmp7=$tmp6 . '</span>
            <img src="./assets/img/thumbnail.svg" data-src="';
            $tmp8=$tmp7 . $tuimg;
            $tmp9=$tmp8 . '" alt="" ';
            $tmp10=$tmp9 . $picimg;
            $tmp11=$tmp10 . '>
            </a>';
            echo $tmp11;
goto L2xx1t;
L2xldMhx1y:
            $tmp2='<a href="' . $tuimg;
            $tmp3=$tmp2 . '" class="sh-content-right-img-pic" data-fancybox="gallery';
            $tmp4=$tmp3 . $cid;
            $tmp5=$tmp4 . '" data-caption=""  style="display:none;">
            <img src="';
            $tmp6=$tmp5 . $tuimg;
            $tmp7=$tmp6 . '" data-src="';
            $tmp8=$tmp7 . $tuimg;
            $tmp9=$tmp8 . '" alt="" ';
            $tmp10=$tmp9 . $picimg;
            $tmp11=$tmp10 . '>
            </a>';
            echo $tmp11;
L2xldMhx1w:
            $tmp2='<a href="' . $tuimg;
            $tmp3=$tmp2 . '" class="sh-content-right-img-pic" data-fancybox="gallery';
            $tmp4=$tmp3 . $cid;
            $tmp5=$tmp4 . '" data-caption="">
            <img src="./assets/img/thumbnail.svg" data-src="';
            $tmp6=$tmp5 . $tuimg;
            $tmp7=$tmp6 . '" alt="" ';
            $tmp8=$tmp7 . $picimg;
            $tmp9=$tmp8 . '>
            </a>';
            echo $tmp9;
L2xldMhx1u:
            $tmp2='<a href="' . $tuimg;
            $tmp3=$tmp2 . '" class="sh-content-right-img-pic" data-fancybox="gallery';
            $tmp4=$tmp3 . $cid;
            $tmp5=$tmp4 . '" data-caption="">
            <img src="./assets/img/thumbnail.svg" data-src="';
            $tmp6=$tmp5 . $tuimg;
            $tmp7=$tmp6 . '" alt="" ';
            $tmp8=$tmp7 . $picimg;
            $tmp9=$tmp8 . '>
            </a>';
            echo $tmp9;
L2xx1t:
            $obj=$i;
            $obj2=$i+1;
            $str=$obj2;
            $i=$str;
        }
        echo '</div>';
goto L2xx1l;
L2xldMhx1n:
        $tmp2=$ptplx=="video";
if($tmp2)goto L2xeWjgx28;
goto L2xldMhx28;
goto L2xldMhx28;
goto L2xldMhx28;
goto L2xldMhx28;
L2xeWjgx28:
        $tmp2=$videoauplay==1;
        if($tmp2){
            $videobf='autoplay';
            $videobfplas='';
        }else{
            $videobf='';
            $tmp2='<i class="iconfont icon-sa4f56" id="sh-content-video-videobfb-' . $cid;
            $tmp3=$tmp2 . '" style="width: fit-content;height: fit-content;grid-column: 1;grid-row: 1;z-index: 5;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);font-size: 40px;color: #ffffff;display: flex;cursor: pointer;padding: 15px;pointer-events: none;"></i>';
            $videobfplas=$tmp3;
        }
        $tmp2=$filterpiccir==1;
        if($tmp2){
            $vidoyuan=1;
        }else{
            $vidoyuan=0;
        }
        $tmp2='
        <!-- 视频 -->
        <div class="sh-video" id="sh-content-video-' . $cid;
        $tmp3=$tmp2 . '" onclick="videofdgb()" lang="0">
        <video class="sh-content-video" data-ybs="';
        $tmp4=$tmp3 . $vidoyuan;
        $tmp5=$tmp4 . '" poster="';
        $tmp6=$tmp5 . $ptpvideofm;
        $tmp7=$tmp6 . '" id="sh-content-videok-';
        $tmp8=$tmp7 . $cid;
        $tmp9=$tmp8 . '" src="';
        $tmp10=$tmp9 . $ptpvideo;
        $tmp11=$tmp10 . '" playsinline webkit-playsinline preload="metadata" ';
        $tmp12=$tmp11 . $videobf;
        $tmp13=$tmp12 . ' muted loop onclick="videofd()" lang="0"></video>
        <!--iframe src="../site/library/player.php?url=';
        $tmp14=$tmp13 . $ptpvideo;
        $tmp15=$tmp14 . '" allowfullscreen="allowfullscreen" mozallowfullscreen="mozallowfullscreen" msallowfullscreen="msallowfullscreen" oallowfullscreen="oallowfullscreen" webkitallowfullscreen="webkitallowfullscreen" frameborder=""></iframe-->
        ';
        $tmp16=$tmp15 . $videobfplas;
        $tmp17=$tmp16 . '
        <i class="iconfont icon-quxiao" id="sh-content-videog-';
        $tmp18=$tmp17 . $cid;
        $tmp19=$tmp18 . '" onclick="videofdgb()" lang="0"></i>
        <span class="sh-video-span" id="sh-video-span-';
        $tmp20=$tmp19 . $cid;
        $tmp21=$tmp20 . '">MP4</span>
        </div>
        ';
        echo $tmp21;
goto L2xx1l;
L2xldMhx28:
        $tmp2=$ptplx=="music";
if($tmp2)goto L2xeWjgx2d;
goto L2xldMhx2d;
goto L2xldMhx2d;
goto L2xldMhx2d;
goto L2xldMhx2d;
L2xeWjgx2d:
        echo '<!-- 音乐 -->';
        $queryResult=is_numeric($ptpmusic);
if($queryResult)goto L2xx1l;
goto L2xldMhx2f;
L2xldMhx2f:
        $queryResult=explode('|', $ptpmusic);
        $mus=$queryResult;
        $tmp2=include "./site/musicplay.php";
L2xldMhx2d:
        $tmp2=$ptplx=="mony";
if($tmp2)goto L2xeWjgx2g;
goto L2xldMhx2g;
goto L2xldMhx2g;
goto L2xldMhx2g;
goto L2xldMhx2g;
L2xeWjgx2g:
        $tmp2="SELECT * FROM money WHERE ptpmoncid = '" . $cid;
        $sql01=$tmp2 . "'";
        $result=$conn->query($sql01);
        $result01=$result;
        $tmp2=$result01->num_rows>0;
if($tmp2)goto L2xeWjgx2i;
goto L2xx1l;
goto L2xx1l;
goto L2xx1l;
goto L2xx1l;
L2xeWjgx2i:
        while(true){
            $result=$result01->fetch_assoc();
            $row01=$result;
            if(!$str)break;
            $muser=$row01["muser"];
            $type=$row01["type"];
            $zsum=$row01["zsum"];
            $sum=$row01["sum"];
            $total=$row01["total"];
            $recve=$row01["recve"];
            $luser=$row01["luser"];
            $montext=$row01["montext"];
            $monimg=$row01["monimg"];
            $ptpmoncid=$row01["ptpmoncid"];
        }
        $tmp2=$monimg=="";
        if($tmp2){
            $monimg='';
        }else{
            $tmp2='background-image: url(' . $monimg;
            $monimg=$tmp2 . ');';
        }
        $tmp2=$recve<1;
        $tmp4=(bool)$tmp2;
        $tmp5=!$tmp4;
        if($tmp5){
            $tmp3=$sum<0.01;
            $tmp4=(bool)$tmp3;
        }
        if($tmp4){
            $hongbtm="opacity: 0.6;";
            $str='onclick="monyk()"';
            $hongbshij=$str;
            $ptpmoncid='';
        }else{
            $hongbtm="";
            $str='onclick="monyk()"';
            $hongbshij=$str;
        }
        $queryResult=explode(PHP_EOL, $luser);
        $lines=$queryResult;
        unset($tmp);
        foreach($lines as $line){$tmp[]=$line;
    }
    $tmp22=0;
    while(true){
        $queryResult=count($tmp);
        $tmp2=$tmp22<$queryResult;
        if(!$tmp2)break;
        $keys=array_keys($tmp);
        $keys=$keys[$tmp22];
        $line=$tmp[$keys];
        $queryResult=explode("|", $line);
        $parts=$queryResult;
        $before_pipe=$parts[0];
        $after_pipe=$parts[1];
        $tmp2=$before_pipe==$user_zh;
        if($tmp2){
            $hongbtm="opacity: 0.6;";
            $str='onclick="monyk()"';
            $hongbshij=$str;
            $ptpmoncid=-1;
        }
        $tmp22=$tmp22+1;
    }
    $tmp2=$zjzhq=="";
    $tmp4=(bool)$tmp2;
    $tmp5=!$tmp4;
    if($tmp5){
        $tmp3=$passid=="";
        $tmp4=(bool)$tmp3;
    }
if($tmp4)goto L2xeWjgx38;
goto L2xldMhx38;
goto L2xldMhx38;
goto L2xldMhx38;
goto L2xldMhx38;
L2xeWjgx38:
    $tmp2=$recve<1;
    $tmp4=(bool)$tmp2;
    $tmp5=!$tmp4;
    if($tmp5){
        $tmp3=$sum<0.01;
        $tmp4=(bool)$tmp3;
    }
if($tmp4)goto L2xeWjgx3c;
goto L2xldMhx3c;
goto L2xldMhx3c;
goto L2xldMhx3c;
goto L2xldMhx3c;
L2xeWjgx3c:
    $hongbtm="opacity: 0.6;";
    $str='onclick="monyk()"';
    $hongbshij=$str;
    $ptpmoncid=-1;
goto L2xx35;
L2xldMhx3c:
    $hongbtm="";
    $str='onclick="monyk()"';
    $hongbshij=$str;
    $ptpmoncid=-1;
L2xldMhx38:
L2xx35:
    $tmp2='<div id="sh-redpacket-content" class="sh-redpacket-content" style="' . $hongbtm;
    $tmp3=$tmp2 . '">
    <div class="sh-redpacket-content-space">
    <div class="sh-space-up">
    <!-- 上部分圆角框架 背景-->
    <div class="sh-space-up-space" style="';
    $tmp4=$tmp3 . $monimg;
    $tmp5=$tmp4 . '">
    <div class="sh-space-up-space-logo"><img src="./assets/img/logogolden.svg" data-src="./assets/img/logogolden.svg"></div>
    <div class="sh-space-up-space-title"><span>';
    $tmp6=$tmp5 . $montext;
    $tmp7=$tmp6 . '</span></div>
    </div>
    </div>
    <div class="sh-space-dw">
    <div class="sh-space-dw-btnk"><span class="sh-space-dw-btn" id="sh-space-dw-btn-';
    $tmp8=$tmp7 . $cid;
    $tmp9=$tmp8 . '" lang="';
    $tmp10=$tmp9 . $ptpmoncid;
    $tmp11=$tmp10 . '" ';
    $tmp12=$tmp11 . $hongbshij;
    $tmp13=$tmp12 . '>领</span></div>
    </div>
    </div>
    </div>';
    echo $tmp13;
goto L2xx1l;
L2xldMhx2g:
L2xx1l:
    echo '
    </div>
    <!-- 地址 -->';
    $tmp2=$ptpdw!="";
    if($tmp2){
        echo $gps;
    }
    echo '<!--广告-->';
    echo $ggurl;
    $tmp2="select * from lcke where lwz= '" . $cid;
    $sql2b=$tmp2 . "'";
    $queryResult=mysqli_query($conn, $sql2b);
    $result2b=$queryResult;
    $queryResult=mysqli_num_rows($result2b);
    $tmp2=$queryResult>0;
if($tmp2)goto L2xeWjgx3g;
goto L2xldMhx3g;
goto L2xldMhx3g;
goto L2xldMhx3g;
goto L2xldMhx3g;
L2xeWjgx3g:
    $sql2a="SELECT * FROM lcke";
    $result=$conn->query($sql2a);
    $result2a=$result;
    while(true){
        while(true){
            $result=$result2a->fetch_assoc();
            $row2a=$result;
            if(!$str)break;
            $tmp2=$row2a['lwz']==$cid;
            if(!$tmp2)break;
            $dianzmlnr=$row2a['luser'];
            $tmp2=$user_zh=="";
            $tmp4=(bool)$tmp2;
            $tmp5=!$tmp4;
            if($tmp5){
                $tmp3=$user_passid=="";
                $tmp4=(bool)$tmp3;
            }
if($tmp4)goto L2xeWjgx3o;
goto L2xldMhx3o;
goto L2xldMhx3o;
goto L2xldMhx3o;
goto L2xldMhx3o;
goto L2xldMhx3o;
L2xeWjgx3o:
            $tmp2=$dianzmlnr==$_SESSION['visykmz_userip'];
if($tmp2)goto L2xeWjgx3q;
goto L2xldMhx3q;
goto L2xldMhx3q;
goto L2xldMhx3q;
goto L2xldMhx3q;
goto L2xldMhx3q;
L2xeWjgx3q:
            $dianzmlnr="取消";
            $dianzmlimg="iconfont icon-aixin2 ri-sxdzlikehs";
goto L2xx3f;
        }
L2xldMhx3q:
        $dianzmlnr="赞";
        $dianzmlimg="iconfont icon-aixin ri-sxdzlike";
L2xldMhx3o:
        $tmp2=$dianzmlnr==$user_zh;
if($tmp2)goto L2xeWjgx3s;
goto L2xldMhx3s;
goto L2xldMhx3s;
goto L2xldMhx3s;
goto L2xldMhx3s;
goto L2xldMhx3s;
L2xeWjgx3s:
        $dianzmlnr="取消";
        $dianzmlimg="iconfont icon-aixin2 ri-sxdzlikehs";
goto L2xx3f;
    }
L2xldMhx3s:
    $dianzmlnr="赞";
    $dianzmlimg="iconfont icon-aixin ri-sxdzlike";
goto L2xx3f;
L2xldMhx3g:
    $dianzmlnr="赞";
    $dianzmlimg="iconfont icon-aixin ri-sxdzlike";
L2xx3f:
    $tmp2=$commauth==1;
    if($tmp2){
        $tmp2='
        <div class="sh-content-right-time-right-left-y" id="' . $cid;
        $tmp3=$tmp2 . '" onclick="plkkg()">
        <i class="iconfont icon-pinglun2 ri-sxdzcomm"></i>
        <span>评论</span>
        </div>
        ';
        $gwzkplzt=$tmp3;
    }else{
        $tmp2='
        <div class="sh-content-right-time-right-left-y" id="' . $cid;
        $tmp3=$tmp2 . '">
        <i class="iconfont icon-pinglun2 ri-sxdzcomm"></i>
        <span>评论关闭</span>
        </div>
        ';
        $gwzkplzt=$tmp3;
    }
    $tmp2='
    <!-- 时间与点赞 -->
    <div class="sh-content-right-time">
    <!-- 时间 -->
    <a class="sh-content-right-time-left" href="./view.php?cid=' . $cid;
    $tmp3=$tmp2 . '" target="_blank"><span>';
    $tmp4=$tmp3 . $wzfbsj;
    $tmp5=$tmp4 . '</span></a>
    <!-- 点赞 -->
    <div class="sh-content-right-time-right">
    <!-- 左边合集 -->
    <div class="sh-content-right-time-right-left" id="pl-';
    $tmp6=$tmp5 . $cid;
    $tmp7=$tmp6 . '" name="pl">
    <div class="sh-content-right-time-right-left-z" onclick="dinazan()">
    <i class="';
    $tmp8=$tmp7 . $dianzmlimg;
    $tmp9=$tmp8 . '" id="tiezimg-';
    $tmp10=$tmp9 . $cid;
    $tmp11=$tmp10 . '"></i>
    <span id="tiezdz-';
    $tmp12=$tmp11 . $cid;
    $tmp13=$tmp12 . '">';
    $tmp14=$tmp13 . $dianzmlnr;
    $tmp15=$tmp14 . '</span>
    </div>
    <p></p>
    ';
    $tmp16=$tmp15 . $gwzkplzt;
    $tmp17=$tmp16 . '
    </div>
    <!-- 右边点赞控制按钮 -->
    <div class="sh-content-right-time-right-right" id="';
    $tmp18=$tmp17 . $cid;
    $tmp19=$tmp18 . '" onclick="plk()">
    <p class="zp1"></p>
    <p></p>
    </div>
    </div>
    </div>
    <!-- 点赞列表与评论 -->
    <div class="sh-zanp" id="zanss-';
    $tmp20=$tmp19 . $cid;
    $tmp21=$tmp20 . '">
    ';
    echo $tmp21;
    $tmp2="select * from lcke where lwz= '" . $cid;
    $sql2=$tmp2 . "'";
    $queryResult=mysqli_query($conn, $sql2);
    $result2=$queryResult;
    $queryResult=mysqli_num_rows($result2);
    $tmp2=$queryResult>0;
if($tmp2)goto L2xeWjgx49;
goto L2xldMhx49;
goto L2xldMhx49;
goto L2xldMhx49;
goto L2xldMhx49;
L2xeWjgx49:
    $tmp2='
    <!-- 点赞列表 -->
    <div class="sh-zanp-zan" id="zans-' . $cid;
    $tmp3=$tmp2 . '">
    <!-- 左侧点赞图标 -->
    <div class="sh-zanp-zan-left"><!--img src="./assets/img/likel.svg" alt=""--><i class="iconfont icon-aixin ri-sxwzlike"></i></div>
    <!-- 右边点赞名列表 -->
    <ul class="sh-zanp-zan-right" id="zlbeh-';
    $tmp4=$tmp3 . $cid;
    $tmp5=$tmp4 . '">
    ';
    echo $tmp5;
    $iw=0;
    $dwys=0;
    while(true){
        while(true){
            $queryResult=mysqli_fetch_assoc($result2);
            $row2=$queryResult;
            if(!$str)break;
            $dianzmys=$row2["luser"];
            $queryResult=strpos($dianzmys, 'vis#-[');
            $tmp2=$queryResult!==false;
            $tmp4=(bool)$tmp2;
            $tmp5=!$tmp4;
            if($tmp5){
                $hash=strpos($dianzmys, ']-#vis');
                $tmp3=$hash!==false;
                $tmp4=(bool)$tmp3;
            }
            if(!$tmp4)break;
            $obj2=$dwys;
            $dwys=$dwys+1;
        }
        $obj3=$iw;
        $iw=$iw+1;
        $dianzms=$row2["lname"];
        $tmp2='<li id="zan-' . $cid;
        $tmp3=$tmp2 . '" lang="';
        $tmp4=$tmp3 . $dianzms;
        $tmp5=$tmp4 . '">';
        $tmp6=$tmp5 . $dianzms;
        $tmp7=$tmp6 . '</li>';
        echo $tmp7;
    }
    $tmp2=$dwys!=0;
    if($tmp2){
        $tmp2='<li id="fkzan-' . $cid;
        $tmp3=$tmp2 . '">';
        $tmp4=$tmp3 . $dwys;
        $tmp5=$tmp4 . '位访客</li>';
        echo $tmp5;
    }
    echo '
    </ul>
    </div>
    ';
goto L2xx48;
L2xldMhx49:
    $tmp2='
    <!-- 点赞列表 -->
    <div class="sh-zanp-zan" id="zans-' . $cid;
    $tmp3=$tmp2 . '" style="display:none;">
    <!-- 左侧点赞图标 -->
    <div class="sh-zanp-zan-left"><i class="iconfont icon-aixin ri-sxwzlike"></i></div>
    <!-- 右边点赞名列表 -->
    <ul class="sh-zanp-zan-right" id="zlbeh-';
    $tmp4=$tmp3 . $cid;
    $tmp5=$tmp4 . '">
    </ul>
    </div>
    ';
    echo $tmp5;
L2xx48:
    echo '
    <!-- 评论列表 -->';
    $tmp2="select * from comm where wzcid= '" . $cid;
    $sql3=$tmp2 . "' and comaud<>'0' and comaud<>'-1'";
    $queryResult=mysqli_query($conn, $sql3);
    $result3=$queryResult;
    $pls=0;
    $queryResult=mysqli_num_rows($result3);
    $tmp2=$queryResult>0;
if($tmp2)goto L2xeWjgx4p;
goto L2xldMhx4p;
goto L2xldMhx4p;
goto L2xldMhx4p;
goto L2xldMhx4p;
L2xeWjgx4p:
    $tmp2='<ul class="sh-zanp-pl" id="sh-zanp-pl-' . $cid;
    $tmp3=$tmp2 . '">';
    echo $tmp3;
    while(true){
        $queryResult=mysqli_fetch_assoc($result3);
        $row3=$queryResult;
        if(!$str)break;
        $pls=$pls+1;
        $tmp2=$pls>$commgs;
if($tmp2)goto L2xeWjgx4t;
goto L2xldMhx4t;
goto L2xldMhx4t;
goto L2xldMhx4t;
goto L2xldMhx4t;
goto L2xldMhx4t;
L2xeWjgx4t:
        $pls=$pls-1;
        $plgd="display:flex";
goto L2xx4r;
goto L2xx4s;
L2xldMhx4t:
        $plgd="display:none";
L2xx4s:
        $couser=$row3["couser"];
        $coname=$row3["coname"];
        $courl=$row3["courl"];
        $cotext=$row3["cotext"];
        $bcouser=$row3["bcouser"];
        $bconame=$row3["bconame"];
        $comaud=$row3["comaud"];
        $tmp2=$comaud!=1;
        if($tmp2){
            $cotext="该条评论未通过审核!";
        }
        $tmp2=$courl=="";
        if($tmp2){
            $plzwze='';
        }else{
            $tmp2='href="' . $courl;
            $plzwze=$tmp2 . '" style="pointer-events: all;"';
        }
        $tmp2=$commauth==1;
        if($tmp2){
            $str='onclick="plhuifu()"';
            $pldjhf=$str;
        }else{
            $pldjhf='';
        }
        $tmp2=$bcouser=="false";
        $tmp4=(bool)$tmp2;
        $tmp5=!$tmp4;
        if($tmp5){
            $tmp3=$bconame=="false";
            $tmp4=(bool)$tmp3;
        }
if($tmp4)goto L2xeWjgx54;
goto L2xldMhx54;
goto L2xldMhx54;
goto L2xldMhx54;
goto L2xldMhx54;
goto L2xldMhx54;
L2xeWjgx54:
        $tmp2='
        <li lang="' . $coname;
        $tmp3=$tmp2 . '" ';
        $tmp4=$tmp3 . $pldjhf;
        $tmp5=$tmp4 . ' id="';
        $tmp6=$tmp5 . $cid;
        $tmp7=$tmp6 . '" value="';
        $tmp8=$tmp7 . $couser;
        $tmp9=$tmp8 . '" data-comkzt="0">
        <div class="sh-zanp-pl-n">
        <a ';
        $tmp10=$tmp9 . $plzwze;
        $tmp11=$tmp10 . ' class="sh-zanp-pl-n-nc" onclick="hfljurl()" target="_blank">';
        $tmp12=$tmp11 . $coname;
        $tmp13=$tmp12 . '</a>：
        <span class="sh-zanp-pl-n-nr">';
        $tmp14=$tmp13 . $cotext;
        $tmp15=$tmp14 . '</span>
        </div>
        </li>
        ';
        echo $tmp15;
    }
L2xldMhx54:
    $tmp2='
    <li lang="' . $coname;
    $tmp3=$tmp2 . '" ';
    $tmp4=$tmp3 . $pldjhf;
    $tmp5=$tmp4 . ' id="';
    $tmp6=$tmp5 . $cid;
    $tmp7=$tmp6 . '" value="';
    $tmp8=$tmp7 . $couser;
    $tmp9=$tmp8 . '" data-comkzt="0">
    <div class="sh-zanp-pl-n">
    <a ';
    $tmp10=$tmp9 . $plzwze;
    $tmp11=$tmp10 . ' class="sh-zanp-pl-n-nc" onclick="hfljurl()" target="_blank">';
    $tmp12=$tmp11 . $coname;
    $tmp13=$tmp12 . '</a>
    <span>回复</span>
    <span class="sh-zanp-pl-n-nc">';
    $tmp14=$tmp13 . $bconame;
    $tmp15=$tmp14 . '</span>：
    <span class="sh-zanp-pl-n-nr">';
    $tmp16=$tmp15 . $cotext;
    $tmp17=$tmp16 . '</span>
    </div>
    </li>
    ';
    echo $tmp17;
L2xx4r:
    echo '</ul>';
goto L2xx4o;
L2xldMhx4p:
    $plgd="display:none";
    $tmp2='<ul class="sh-zanp-pl" id="sh-zanp-pl-' . $cid;
    $tmp3=$tmp2 . '" style="display:none;"></ul>';
    echo $tmp3;
L2xx4o:
    $tmp2='
    <!-- 显示更多评论 -->
    <div class="sh-zanp-pl-ku">
    <a href="./view.php?cid=' . $cid;
    $tmp3=$tmp2 . '" target="_blank" class="sh-zanp-pl-gd" style="';
    $tmp4=$tmp3 . $plgd;
    $tmp5=$tmp4 . '">
    <p class="zp1"></p>
    <p class="zp1"></p>
    <p></p>
    </a>
    </div>
    </div>
    </div>
    </div>
    ';
    echo $tmp5;
}
goto L2xx12;
L2xldMhx13:
L2xx12:
$obj4=$iars;
$iars=$iars+1;
}
goto L2xxbx;
L2xldMhxby:
$tmp2=14;
$tmp3=72;
$tmp4=$num==72;
if($tmp4)goto L2xxbx;
L2xxbx: