<?php
$iteace='adminapi';
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp=$user_zh=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$user_passid=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit('<script language="JavaScript">;alert("请先登录!");location.href="../login.php";</script>');
}
$tmp=include '../../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$escaped=htmlspecialchars($user_zh);
$cookieResult=addslashes($escaped);
$user_zhsg=$cookieResult;
$tmp="select * from user where username='" . $user_zhsg;
$sqls=$tmp . "'";
$row=mysqli_query($conn, $sqls);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$data2s_row=$row;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($sentinel))break;
    $glyzhuser=$row["username"];
}
L2xxf:
$str="select * from user where username='" . $user_zh;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
$zid=$data2_row["id"];
$zjpassword=$data2_row["password"];
if($user_passid!=$passid){
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("username", "", $str, "/");
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("passid", "", $str, "/");
    exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="../login.php";</script>');
}
if($zjzhq!=$glyzhuser){
    exit('<script language="JavaScript">;alert("没有权限!");history.go(-1);</script>');
}
$auth_keylocation='../../api/key.php';
$auth_keyauth='../../api/auth.php';
$num=1746;
$row=file_exists($auth_keyauth);
if($row){
    $num=28;
}else{
    $num=28;
    $num=2732;
}
$tmp=90;
$tmp4=28;
$tmp2=$num==28;
if($tmp2)goto L2xeWjgxw;
goto L2xldMhxw;
L2xeWjgxw:
$tmp=require $auth_keyauth;
$tmp=!defined("sh_auth_state");
if($tmp){
    exit('<script language="JavaScript">;alert("授权验证失败,请确保文件完整且未篡改!");history.go(-1);</script>');
}
$tmp=sh_auth_state!="ok";
if($tmp)goto L2xeWjgxu;
goto L2xxv;
goto L2xxv;
L2xeWjgxu:
exit('<script language="JavaScript">;alert("程序未授权,您的请求已被拒绝,请授权后使用!");history.go(-1);</script>');
goto L2xxv;
L2xldMhxw:
switch($num){
    case 1380:{
    exit('<script language="JavaScript">;alert("授权验证文件不存在或被篡改,请确保文件完整且未篡改!");history.go(-1);</script>');
        break;
    }
}
L2xxv:
$num2=1739;
$isArray=is_array($_POST);
if($isArray){
    $num2=84;
}else{
    $num2=8;
}
switch($num2){
    case 8:{
    $linmz=$_POST['lx'];
        break;
    }
    case 84:{
        $linmz=&$_POST['lx'];
        break;
    }
}
$escaped=htmlspecialchars($linmz);
unset($linmz);
$escaped2=addslashes($escaped);
$lx=$escaped2;
if($lx=="ylgl")goto L2xeWjgx1y;
goto L2xldMhx1y;
L2xeWjgx1y:
$isArray=is_array($_POST);
if($isArray){
    $linmz=&$_POST['linkid'];
}else{
    $linmz=$_POST['linkid'];
}
$escaped=htmlspecialchars($linmz);
unset($linmz);
$escaped2=addslashes($escaped);
$linkid=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $linmz=&$_POST['linmz'];
}else{
    $linmz=$_POST['linmz'];
}
$escaped=htmlspecialchars($linmz);
unset($linmz);
$escaped2=addslashes($escaped);
$linmz=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $linmz=&$_POST['linimg'];
}else{
    $linmz=$_POST['linimg'];
}
$escaped=htmlspecialchars($linmz);
unset($linmz);
$escaped2=addslashes($escaped);
$linimg=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $linmz=&$_POST['linurl'];
}else{
    $linmz=$_POST['linurl'];
}
$escaped=htmlspecialchars($linmz);
unset($linmz);
$escaped2=addslashes($escaped);
$linurl=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $linmz=&$_POST['delyl'];
}else{
    $linmz=$_POST['delyl'];
}
$escaped=htmlspecialchars($linmz);
unset($linmz);
$escaped2=addslashes($escaped);
$delyl=$escaped2;
$tmp=$linkid!=-1;
if($tmp)goto L2xeWjgx1l;
goto L2xldMhx1l;
goto L2xldMhx1l;
L2xeWjgx1l:
$tmp=$linkid!="";
$tmp2=(bool)$tmp;
if($tmp2){
    $tmp4=$delyl==-1;
    $tmp2=(bool)$tmp4;
}
if($tmp2)goto L2xeWjgx1p;
goto L2xldMhx1p;
goto L2xldMhx1p;
L2xeWjgx1p:
$tmp="delete from link where id='" . $linkid;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
exit('<script language="JavaScript">;alert("友链已删除");location.href="../linkset.php";</script>;');
goto L2xx1x;
L2xldMhx1p:
$tmp=$delyl==0;
if($tmp)goto L2xeWjgx1q;
goto L2xx1x;
goto L2xx1x;
L2xeWjgx1q:
$tmp=$linmz!="";
if($tmp){
    $tmp="UPDATE link SET urls='" . $linmz;
    $tmp4=$tmp . "' WHERE id='";
    $tmp2=$tmp4 . $linkid;
    $sql=$tmp2 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$linimg!="";
if($tmp){
    $tmp="UPDATE link SET urlimg='" . $linimg;
    $tmp4=$tmp . "' WHERE id='";
    $tmp2=$tmp4 . $linkid;
    $sql=$tmp2 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$linurl!="";
if($tmp){
    $tmp="UPDATE link SET url='" . $linurl;
    $tmp4=$tmp . "' WHERE id='";
    $tmp2=$tmp4 . $linkid;
    $sql=$tmp2 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
exit('<script language="JavaScript">;alert("更新友链成功");location.href="../linkset.php";</script>;');
goto L2xx1x;
L2xldMhx1l:
exit('<script language="JavaScript">;alert("未选择友链");location.href="../linkset.php";</script>;');
L2xldMhx1y:
L2xx1x:
if($lx=="ylnew")goto L2xeWjgx36;
goto L2xldMhx36;
L2xeWjgx36:
$isArray=is_array($_POST);
if($isArray){
    $linmz=&$_POST['linmz'];
}else{
    $linmz=$_POST['linmz'];
}
$escaped=htmlspecialchars($linmz);
unset($linmz);
$escaped2=addslashes($escaped);
$linmz=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $linmz=&$_POST['linimg'];
}else{
    $linmz=$_POST['linimg'];
}
$escaped=htmlspecialchars($linmz);
unset($linmz);
$escaped2=addslashes($escaped);
$linimg=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $linmz=&$_POST['linurl'];
}else{
    $linmz=$_POST['linurl'];
}
$escaped=htmlspecialchars($linmz);
unset($linmz);
$escaped2=addslashes($escaped);
$linurl=$escaped2;
$tmp=$linmz!="";
$tmp2=(bool)$tmp;
if($tmp2){
    $tmp4=$linimg!="";
    $tmp2=(bool)$tmp4;
}
$tmp5=(bool)$tmp2;
if($tmp5){
    $tmp3=$linurl!="";
    $tmp5=(bool)$tmp3;
}
if($tmp5)goto L2xeWjgx32;
goto L2xldMhx32;
goto L2xldMhx32;
L2xeWjgx32:
$tmp="INSERT INTO link (url,urls,urlimg)
VALUES ('" . $linurl;
$tmp4=$tmp . "','";
$tmp2=$tmp4 . $linmz;
$tmp3=$tmp2 . "','";
$tmp5=$tmp3 . $linimg;
$sql=$tmp5 . "')";
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp)goto L2xeWjgx34;
goto L2xldMhx34;
goto L2xldMhx34;
L2xeWjgx34:
exit('<script language="JavaScript">;alert("添加友链成功");location.href="../linkset.php";</script>;');
goto L2xx35;
L2xldMhx34:
$tmp="Error: " . $sql;
$tmp4=$tmp . "<br>";
$tmp2=$tmp4 . $conn->error;
echo $tmp2;
L2xldMhx32:
exit('<script language="JavaScript">;alert("参数不完整");location.href="../linkset.php";</script>;');
L2xldMhx36:
L2xx35:
if($lx=="poln")goto L2xeWjgx3u;
goto L2xldMhx3u;
L2xeWjgx3u:
$isArray=is_array($_POST);
if($isArray){
    $linmz=&$_POST['likid'];
}else{
    $linmz=$_POST['likid'];
}
$escaped=htmlspecialchars($linmz);
unset($linmz);
$escaped2=addslashes($escaped);
$likid=$escaped2;
$tmp=$likid!=-1;
$tmp2=(bool)$tmp;
if($tmp2){
    $tmp4=$likid!="";
    $tmp2=(bool)$tmp4;
}
if($tmp2)goto L2xeWjgx3s;
goto L2xx3t;
goto L2xx3t;
L2xeWjgx3s:
$str="select * from link where id='" . $likid;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data_row=$row;
$val['url']=$data_row['url'];
$val['urlbt']=$data_row['urls'];
$val['urlimg']=$data_row['urlimg'];
$val2[]=$val;
$arr=$val2;
$str=JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT;
$str2=$str|JSON_UNESCAPED_SLASHES;
$row=json_encode($arr, $str2);
echo $row;
goto L2xx3t;
L2xldMhx3u:
L2xx3t:
$result=$conn->close();