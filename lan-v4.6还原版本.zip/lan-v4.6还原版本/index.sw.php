<?php
$iteace=0;
$num12=5845;
$row=is_file('./config.php');
if($row){
    $num12=128;
}else{
    $num12=45;
}
switch($num12){
    case 45:{
    exit('未检测到配置文件：<span style="color: red;">config.php</span>，若您是首次使用请先进行安装,删除文件夹 <span style="color: red;">[install/]</span> 下的 <span style="color: red;">[ins.bak]</span> 文件后进行安装。若已删除请<a href="./install/">【点击安装】</a>');
        break;
    }
    case 128:{
        $tmp2=require './config.php';
        break;
    }
}
$tmp2=require './api/wz.php';
echo "<!DOCTYPE html>";
echo "
<html lang=\"zh-CN\">";
echo "
<head>";
echo "
<meta charset=\"UTF-8\">";
echo "
<title>";
echo $name;
echo "</title>";
echo "
<!--为搜索引擎定义关键词-->";
echo "
<meta name=\"keywords\" content=\"";
echo $filterkeyw;
echo "\">";
echo "
<!--为网页定义描述内容 用于告诉搜索引擎，你网站的主要内容-->";
echo "
<meta name=\"description\" content=\"";
echo $subtitle;
echo "\">";
echo "
<meta name=\"author\" content=\"";
echo $name;
echo "\">";
echo "
<meta name=\"copyright\" content=\"";
echo $name;
echo "\">";
echo "
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" />";
echo "
<meta http-equiv=\"cache-control\" content=\"no-cache\">";
echo "
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0,minimum-scale=1.0, user-scalable=no minimal-ui\">";
echo "
<link rel=\"apple-touch-icon\" sizes=\"57x57\" href=\"";
echo $icon;
echo "\" /><!-- Standard iPhone -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"114x114\" href=\"";
echo $icon;
echo "\" /><!-- Retina iPhone -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"72x72\" href=\"";
echo $icon;
echo "\" /><!-- Standard iPad -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"144x144\" href=\"";
echo $icon;
echo "\" /><!-- Retina iPad -->";
echo "
<link rel=\"icon\" href=\"";
echo $icon;
echo "\" type=\"image/x-icon\" />";
echo "
<meta name=\"robots\" content=\"index,follow\">";
echo "
<meta name=\"format-detection\" content=\"telephone=no\">";
echo "
<meta http-equiv=\"x-rim-auto-match\" content=\"none\">";
echo "
";
if($rosdomain==1){
    echo '<meta name="referrer" content="no-referrer">';
}
echo "    <link rel=\"stylesheet\" href=\"";
echo $iconurl_url;
echo "\">";
echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"./assets/css/style.css\">";
echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"./assets/mesg/dist/css/style.css\"><!--引入弹窗对话框-->";
echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"./assets/css/jquery.fancybox.min.css\">";
echo "
";
echo $scfontzt;
echo "    ";
$folderPath='./user/bobg/';
$row=file_exists($folderPath);
$tmp2=!$row;
if($tmp2){
    $row=mkdir($folderPath, true);
}
$num13=5841;
$row=file_exists("./user/bobg/bobg.jpg");
if($row){
    $num13=144;
}else{
    $row=file_exists("./user/bobg/bobg.png");
    if($row){
        $num13=144;
        $num13=2764;
    }else{
        $row=file_exists("./user/bobg/bobg.jpeg");
        if($row){
            $num13=144;
            $num13=10052;
        }else{
            $row=file_exists("./user/bobg/bobg.gif");
            if($row){
                $num13=162;
            }
        }
    }
}
switch($num13){
    case 162:{
    echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.gif);}</style>';
        break;
    }
    case 144:{
        echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.jpg);}</style>';
        break;
    }
    case 1454:{
            echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.png);}</style>';
        break;
    }
    case 5098:{
                echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.jpeg);}</style>';
        break;
    }
}
echo "    ";
$tmp2='<style>' . $filtercucss;
$tmp3=$tmp2 . '</style>';
echo $tmp3;
echo "</head>";
echo "
<body class=\"";
$num3=5842;
if(isset($_COOKIE['dark_theme'])){
    $num3=324;
}else{
    $num3=144;
}
$tmp2=300;
$tmp3=144;
$tmp4=$num3==144;
if($tmp4)goto L2xxs;
$tmp2=140;
$tmp3=324;
$tmp4=$num3==324;
if($tmp4)goto L2xeWjgxu;
goto L2xldMhxu;
L2xeWjgxu:
$tmp2=$_COOKIE["dark_theme"]=="dark-theme";
if($tmp2)goto L2xeWjgxr;
goto L2xxs;
goto L2xxs;
L2xeWjgxr:
echo 'dark-theme';
goto L2xxs;
L2xldMhxu:
L2xxs:
echo "\">";
echo "
";
if($pagepass!="")goto L2xeWjgx15;
goto L2xldMhx15;
L2xeWjgx15:
if(isset($_COOKIE['pagepass']))goto L2xeWjgx11;
goto L2xldMhx11;
goto L2xldMhx11;
L2xeWjgx11:
$hash=md5($pagepass);
$hash2=md5($hash);
$tmp2=$_COOKIE['pagepass']!=$hash2;
if($tmp2)goto L2xeWjgx13;
goto L2xx14;
goto L2xx14;
L2xeWjgx13:
$tmp2=include './site/pagepass.php';
goto L2xx14;
L2xldMhx11:
$tmp2=include './site/pagepass.php';
L2xldMhx15:
L2xx14:
echo "    <div class=\"centent\">";
echo "
<div class=\"sh-main\">";
echo "
<div class=\"sh-main-head\">";
echo "
<div class=\"sh-main-head-top\" id=\"sh-main-head-top\">";
echo "
<!-- 左边 -->";
echo "
<div class=\"sh-main-head-top-left\">";
echo "
";
echo "
";
$num4=5847;
$isArray=is_array($_GET);
if($isArray){
    $num4=144;
}else{
    $num4=40;
}
switch($num4){
    case 144:{
    $so=&$_GET['so'];
        break;
    }
    case 40:{
        $so=$_GET['so'];
        break;
    }
}
$hash=htmlspecialchars($so);
unset($so);
$escaped=addslashes($hash);
$so=$escaped;
if($so!=""){
    echo '<div class="sh-main-head-top-left-s" onclick="location.href=\'./index.php\'">
    <i class="iconfont icon-weibiaoti al-sxb" id="top-left-xx"></i>
    </div>';
}
if($userdlzt==0)goto L2xeWjgx1o;
goto L2xldMhx1o;
L2xeWjgx1o:
$tmp2=$loginkg==1;
if($tmp2)goto L2xeWjgx1m;
goto L2xx1n;
goto L2xx1n;
L2xeWjgx1m:
echo '
<div class="sh-main-head-top-left-s" onclick="kqlogin()">
<!--img src="./assets/img/wo.svg" alt="" id="top-left-1"-->
<i class="iconfont icon-account-circle-fill ri-sxzytx" id="top-left-1"></i>
</div>';
goto L2xx1n;
L2xldMhx1o:
L2xx1n:
echo "                        <!--音乐-->";
echo "
";
$num5=5849;
$tmp2=$wzmusic==-1;
if($tmp2){
    $num5=64;
}else{
    $num5=144;
}
$tmp2=18;
$tmp3=144;
$tmp4=$num5==144;
if($tmp4)goto L2xeWjgx1y;
goto L2xldMhx1y;
L2xeWjgx1y:
$row=explode(PHP_EOL, $wzmusic);
$arr=$row;
$str=array_filter($arr);
$arry=$str;
$row=count($arry);
$ary=$row;
$num14=$ary-1;
$row=rand($num14);
$mu=$row;
$yiny=$arry[$mu];
$row=explode('|', $yiny);
$arys=$row;
$mum=$arys[0];
$muurl=$arys[1];
$str=preg_replace('/[\s\r\n]+/','',$muurl);
$muurl=$str;
$tmp2=$mum=="网易音乐";
$tmp3=(bool)$tmp2;
if($tmp3){
    $row=is_numeric($muurl);
    $tmp3=(bool)$row;
}
if($tmp3){
    $mum=$arys[0];
    $tmp2='//music.163.com/song/media/outer/url?id=' . $muurl;
    $muurl=$tmp2 . '.mp3';
}
$tmp2='
<div class="sh-main-head-top-left-mu">
<div class="sh-main-top-mu" lang="0" onclick="syaudbf()"><i class="iconfont icon-jixu ri-z-sx" id="sh-main-top-mu" lang="0" data-bfzt="bb"></i></div>
<div id="sh-main-top-g-m" class="sh-main-top-g-container" lang="' . $mum;
$tmp3=$tmp2 . '">
<div id="sh-main-top-mucisjd" lang="0" style="display:none">
<!--音乐动画-->
<div class="shaft-load2">
<div class="shaft1"></div>
<div class="shaft2"></div>
<div class="shaft3"></div>
<div class="shaft4"></div>
<div class="shaft5"></div>
<div class="shaft6"></div>
<div class="shaft7"></div>
<div class="shaft8"></div>
<div class="shaft9"></div>
<!--div class="shaft10"></div-->
</div>
</div>
</div>
<div class="sh-main-top-mu-bgmq" onclick="sjsyyy()"><i class="iconfont icon-yinle_2 ri-z-sx" id="sh-main-top-mu-bgmq"></i></div>
<audio id="sh-main-top-musicplay-b" src="';
$tmp4=$tmp3 . $muurl;
$tmp5=$tmp4 . '" type="audio/mp3" controls="controls" style="display: none;">
您的浏览器不支持音频元素。
</audio>
</div>
';
echo $tmp5;
goto L2xx1x;
L2xldMhx1y:
$tmp2=143;
$tmp3=64;
$tmp4=$num5==64;
if($tmp4)goto L2xx1x;
L2xx1x:
echo "                        ";
echo "
";
echo "
";
echo "
</div>";
echo "
<!-- 右边 -->";
echo "
<div class=\"sh-main-head-top-right\">";
echo "
";
echo "
";
$rnkingyc=0;
$tmp2=$rnking==1;
$tmp4=(bool)$tmp2;
if($tmp4){
    $tmp3=False;
    $tmp4=(bool)False;
}
if($tmp4){
    echo '<div class="sh-main-head-top-right-s" onclick="paihk()">
    <i class="iconfont icon-paihangbang ri-sx" id="top-right-4"></i>
    </div>';
}
echo "";
echo "
";
if($userdlzt==1)goto L2xeWjgx2q;
goto L2xldMhx2q;
L2xeWjgx2q:
$tmp2=$ptpfan==1;
if($tmp2){
    echo '
    <div class="sh-main-head-top-right-s" onclick="fby()">
    <i class="iconfont icon-xiangji2 ri-sx" id="top-right-3"></i>
    </div>';
}
echo '<div class="sh-main-head-top-right-s" onclick="kqnews()">';
$tmp2=include './config.php';
$tmp2=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp2;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$tmp2="SELECT * FROM message WHERE suser = '" . $user_zh;
$sqlxx=$tmp2 . "' AND msg != '-1' ORDER BY id DESC";
$result=$conn->query($sqlxx);
$resultxx=$result;
$xmsgxx='';
L2xx2h:
while(true){
    $result=$resultxx->fetch_assoc();
    $rowxx=$result;
    if(!$str)break;
    $tmp2=$rowxx['msg']==0;
if($tmp2)goto L2xeWjgx2k;
goto L2xx2h;
goto L2xx2h;
goto L2xx2h;
L2xeWjgx2k:
    $xmsgxx='<p id="xiaoxhd" class="xiaoxhd"></p>';
goto L2xx2i;
}
L2xx2l:
L2xx2i:
echo $xmsgxx;
echo '<i class="xxtbcl iconfont icon-lingdang ri-sx" id="top-right-1"></i>
</div>';
goto L2xx2p;
L2xldMhx2q:
L2xx2p:
echo "";
echo "
";
if($lnkzt==0){
    echo '
    <div class="sh-main-head-top-right-s" onclick="kqlink()">
    <i class="iconfont icon-tongxunlu-copy ri-sx" id="top-right-2"></i>
    </div>';
}
echo "                        ";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
$num6=5847;
$tmp2=$userdlzt==0;
if($tmp2){
    $num6=144;
}else{
    $num6=162;
}
switch($num6){
    case 144:{
    $wymz=$glyname;
    $wylj='JavaScript:;';
    $wyimg=$glyimg;
    $wyqm=$sign;
    $wyhomeimg=$homimg;
        break;
    }
    case 162:{
        $wymz=$zjnc;
        $wylj='./home.php';
        $wyimg=$zjimg;
        $wyqm=$zjsign;
        $wyhomeimg=$homimg;
        break;
    }
}
echo "";
echo "
<div class=\"sh-main-head-img\"";
echo "
style=\"background-image:url(";
echo $wyhomeimg;
echo ")\">";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
<div class=\"sh-main-head-headimg\">";
echo "
<div class=\"sh-main-head-headimg-tx\">";
echo "
<h4>";
echo $wymz;
echo "</h4>";
echo "
";
echo "
<a href=\"";
echo $wylj;
echo "\"><img src=\"./assets/img/thumbnail.svg\" data-src=\"";
echo $wyimg;
echo "\" alt=\"头像\"></a>";
echo "
</div>";
echo "
<div class=\"sh-main-head-headimg-qm\">";
echo "
<p>";
echo $wyqm;
echo "</p>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div style=\"display:none;position: absolute;top: -100%;\" id=\"pinglunkfk\">";
echo "
<div class=\"sh-pinglunkuang\" id=\"pinglunkuang\">";
echo "
";
echo "
";
echo "
<div class=\"sh-pinglun\" id=\"sh-pinglun\">";
echo "
<!--游客模式-->";
echo "
";
if($userdlzt==0)goto L2xeWjgx3e;
goto L2xldMhx3e;
L2xeWjgx3e:
$tmp2=$viscomm==0;
if($tmp2)goto L2xeWjgx3c;
goto L2xx3d;
goto L2xx3d;
L2xeWjgx3c:
echo '
<div class="sh-plk-yk" id="sh-plk-yk">
<div class="sh-plk-yk-z" style="margin-left: 8px;"><input id="vis_name" type="text" value="" maxlength="10" minlength="1" placeholder="昵称*" autocomplete="off"></div>
<div class="sh-plk-yk-zz"><input id="vis_email" type="text" value="" maxlength="100" minlength="1" placeholder="邮箱*" autocomplete="off"></div>
<div class="sh-plk-yk-z" style="margin-right: 8px;"><input id="vis_url" type="text" value="" maxlength="500" minlength="1" placeholder="网站" autocomplete="off"></div>
</div>
';
goto L2xx3d;
L2xldMhx3e:
L2xx3d:
echo "                        <div class=\"sh-pinglun-s\">";
echo "
<textarea name=\"text\" id=\"bletext\" class=\"form-controll\" placeholder=\"评论\" required=\"\" spellcheck=\"false\" maxlength=\"500\" onchange=\"this.value=this.value.substring(0, 500)\" onkeydown=\"this.value=this.value.substring(0, 500)\" onkeyup=\"this.value=this.value.substring(0, 500)\" oninput=\"myjtbl()\"></textarea>";
echo "
</div>";
echo "
<!-- 表情 -->";
echo "
<div class=\"sh-pinglun-biao\" id=\"biaoqing\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E591B5E591B5_2x.png\" alt=\"::(呵呵)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E59388E59388_2x.png\" alt=\"::(哈哈)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E59090E8888C_2x.png\" alt=\"::(吐舌)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5A4AAE5BC80E5BF83_2x.png\" alt=\"::(太开心)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E7AC91E79CBC_2x.png\" alt=\"::(笑眼)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E88AB1E5BF83_2x.png\" alt=\"::(花心)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5B08FE4B996_2x.png\" alt=\"::(小乖)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E4B996_2x.png\" alt=\"::(乖)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E68D82E598B4E7AC91_2x.png\" alt=\"::(捂嘴笑)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6BB91E7A8BD_2x.png\" alt=\"::(滑稽)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E4BDA0E68782E79A84_2x.png\" alt=\"::(你懂的)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E4B88DE9AB98E585B4_2x.png\" alt=\"::(不高兴)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E68092_2x.png\" alt=\"::(怒)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6B197_2x.png\" alt=\"::(汗)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E9BB91E7BABF_2x.png\" alt=\"::(黑线)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6B3AA_2x.png\" alt=\"::(泪)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E79C9FE6A392_2x.png\" alt=\"::(真棒)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E596B7_2x.png\" alt=\"::(喷)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6838AE593AD_2x.png\" alt=\"::(惊哭)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E998B4E999A9_2x.png\" alt=\"::(阴险)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E98499E8A786_2x.png\" alt=\"::(鄙视)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E985B7_2x.png\" alt=\"::(酷)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5958A_2x.png\" alt=\"::(啊)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E78B82E6B197_2x.png\" alt=\"::(狂汗)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/what_2x.png\" alt=\"::(what)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E79691E997AE_2x.png\" alt=\"::(疑问)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E985B8E788BD_2x.png\" alt=\"::(酸爽)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E59180E592A9E788B9_2x.png\" alt=\"::(呀咩蹀)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5A794E5B188_2x.png\" alt=\"::(委屈)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6838AE8AEB6_2x.png\" alt=\"::(惊讶)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E79DA1E8A789_2x.png\" alt=\"::(睡觉)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E7AC91E5B0BF_2x.png\" alt=\"::(笑尿)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E68C96E9BCBB_2x.png\" alt=\"::(挖鼻)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E59090_2x.png\" alt=\"::(吐)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E78A80E588A9_2x.png\" alt=\"::(犀利)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5B08FE7BAA2E884B8_2x.png\" alt=\"::(小红脸)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E68792E5BE97E79086_2x.png\" alt=\"::(懒得理)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E58B89E5BCBA_2x.png\" alt=\"::(勉强)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E788B1E5BF83_2x.png\" alt=\"::(爱心)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5BF83E7A28E_2x.png\" alt=\"::(心碎)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E78EABE791B0_2x.png\" alt=\"::(玫瑰)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E7A4BCE789A9_2x.png\" alt=\"::(礼物)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5BDA9E899B9_2x.png\" alt=\"::(彩虹)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5A4AAE998B3_2x.png\" alt=\"::(太阳)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6989FE6989FE69C88E4BAAE_2x.png\" alt=\"::(星星月亮)\"";
echo "
onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E992B1E5B881_2x.png\" alt=\"::(钱币)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E88CB6E69DAF_2x.png\" alt=\"::(茶杯)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E89B8BE7B395_2x.png\" alt=\"::(蛋糕)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5A4A7E68B87E68C87_2x.png\" alt=\"::(大拇指)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E8839CE588A9_2x.png\" alt=\"::(胜利)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/haha_2x.png\" alt=\"::(haha)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/OK_2x.png\" alt=\"::(OK)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6B299E58F91_2x.png\" alt=\"::(沙发)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6898BE7BAB8_2x.png\" alt=\"::手纸\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E9A699E89589_2x.png\" alt=\"::(香蕉)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E4BEBFE4BEBF_2x.png\" alt=\"::(便便)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E88DAFE4B8B8_2x.png\" alt=\"::(药丸)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E7BAA2E9A286E5B7BE_2x.png\" alt=\"::(红领巾)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E89CA1E7839B_2x.png\" alt=\"::(蜡烛)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E99FB3E4B990_2x.png\" alt=\"::(音乐)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E781AFE6B3A1_2x.png\" alt=\"::(灯泡)\" onclick=\"biaoqzj()\">";
echo "
</div>";
echo "
<!-- 表情 end-->";
echo "
";
echo "
<!-- 表情开关与评论发送 -->";
echo "
<div class=\"sh-pinglun-fs\">";
echo "
<div class=\"sh-pinglun-fs-right\">";
echo "
<!-- 游客开关 -->";
echo "
";
if($userdlzt==0)goto L2xeWjgx3m;
goto L2xldMhx3m;
L2xeWjgx3m:
$tmp2=$viscomm==0;
if($tmp2)goto L2xeWjgx3k;
goto L2xx3l;
goto L2xx3l;
L2xeWjgx3k:
echo '
<div class="sh-pinglun-fs-right-bqimg" id="ykkg" onclick="ykkg()">
<i class="iconfont icon-yonghu1 ri-sxbqxz" id="sh-pinglun-fs-right-ykkgb" title="游客模式"></i>
</div>';
goto L2xx3l;
L2xldMhx3m:
L2xx3l:
echo "                                <!-- 表情开关 -->";
echo "
<div class=\"sh-pinglun-fs-right-bqimg\" id=\"bqkg\" onclick=\"bqkg()\">";
echo "
<i class=\"iconfont icon-biaoqing ri-sxbqxz\" id=\"sh-pinglun-fs-right-bqimg\"></i>";
echo "
</div>";
echo "
<!-- 发送按钮 -->";
echo "
<div class=\"sh-pinglun-fs-right-fs\" id=\"sh-pinglun-fs-right-fs\" onclick=\"fasong()\">";
echo "
<span>发送</span>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
</div>";
echo "
<!-- cs -->";
echo "
<div class=\"huifucanshu\">";
echo "
<p id=\"sh-tieid\">-</p>";
echo "
<p id=\"sh-tiehf\">-</p>";
echo "
<p id=\"sh-tieea\">-</p>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"sh-nrbk\" id=\"sh-nrbk\" style=\"width:100%\">";
echo "
";
echo "
";
$tmp2=include "./api/topes.php";
$wzsl=0;
$num7=5849;
$isArray=is_array($_GET);
if($isArray){
    $num7=162;
}else{
    $num7=128;
}
switch($num7){
    case 162:{
    $so=&$_GET['so'];
        break;
    }
    case 128:{
        $so=$_GET['so'];
        break;
    }
}
$hash=htmlspecialchars($so);
unset($so);
$escaped=addslashes($hash);
$so=$escaped;
$num8=5849;
$tmp2=$so!="";
$tmp4=(bool)$tmp2;
if($tmp4){
    $tmp3=$so!="null";
    $tmp4=(bool)$tmp3;
}
if($tmp4){
    $num8=128;
}else{
    $num8=90;
}
switch($num8){
    case 128:{
    $tmp2="SELECT * FROM essay where ptpaud<>'0' and ptpaud<>'-1' and ptpys<>'0' and ptptext LIKE '%" . $so;
    $tmp3=$tmp2 . "%' order by id desc limit ";
    $sql=$tmp3 . $essgs;
        break;
    }
    case 90:{
        $sql="SELECT * FROM essay where ptpaud<>'0' and ptpaud<>'-1' and ptpys<>'0' order by id desc limit " . $essgs;
        break;
    }
}
$result=$conn->query($sql);
$result=$result;
L2xx42:
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($str))break;
    $wzsl=$wzsl+1;
    $ptpuser=$row["ptpuser"];
    $ptpimg=$row["ptpimg"];
    $ptpname=$row["ptpname"];
    $ptptext=$row["ptptext"];
    $ptpimag=$row["ptpimag"];
    $ptpvideo=$row["ptpvideo"];
    $ptpmusic=$row["ptpmusic"];
    $ptplx=$row["ptplx"];
    $ptpdw=$row["ptpdw"];
    $ptptime=$row["ptptime"];
    $ptpgg=$row["ptpgg"];
    $ptpggurl=$row["ptpggurl"];
    $ptpys=$row["ptpys"];
    $commauth=$row["commauth"];
    $ptpaud=$row["ptpaud"];
    $ptpip=$row["ip"];
    $cid=$row["cid"];
    $wid=$row["id"];
    $row=explode("|", $ptpvideo);
    $partssp=$row;
    $ptpvideo=$partssp[0];
    $ptpvideofm=$partssp[1];
    $num9=5849;
    $tmp2=$snk=='-201-201-1';
    if($tmp2){
        $num9=144;
    }else{
        $num9=162;
    }
    $tmp2=170;
    $tmp3=144;
    $tmp4=$num9==144;
if($tmp4)goto L2xx48;
goto L2xldMhx49;
L2xldMhx49:
    $tmp2=165;
    $tmp3=162;
    $tmp4=$num9==162;
if($tmp4)goto L2xeWjgx4a;
goto L2xldMhx4a;
goto L2xldMhx4a;
goto L2xldMhx4a;
L2xeWjgx4a:
    $row=in_array($wid, $ars);
if($row)goto L2xx42;
goto L2xx48;
goto L2xx48;
goto L2xx48;
goto L2xx48;
goto L2xx48;
L2xldMhx4a:
L2xx48:
    $row=explode('(+@+)', $ptpimag);
    $imgar=$row;
    $row=count($imgar);
    $coun=$row;
    $num10=5848;
    $tmp2=$coun==1;
    if($tmp2){
        $num10=144;
    }else{
        $tmp2=$coun==4;
        $tmp4=(bool)$tmp2;
        $tmp5=!$tmp4;
        if($tmp5){
            $tmp3=$coun==2;
            $tmp4=(bool)$tmp3;
        }
        if($tmp4){
            $num10=90;
        }else{
            $num10=128;
        }
    }
    switch($num10){
        case 128:{
        $tusty=111;
            break;
        }
        case 144:{
            $tusty=155;
            break;
        }
        case 90:{
                $tusty=1155;
            break;
        }
    }
    $num11=5837;
    $tmp2=$ptpgg==1;
    if($tmp2){
        $num11=80;
    }else{
        $num11=25;
    }
    switch($num11){
        case 25:{
        $ggdiv='display: none;';
        $ggurl="";
        $tmp2='<div class="sh-content-right-gps"><a href="javascript:;">' . $ptpdw;
        $gps=$tmp2 . '</a></div>';
            break;
        }
        case 80:{
            $ggdiv='display: flex;';
            $tmp2='<div class="sh-content-right-ggurl"><i class="iconfont icon-lianjie1 ri-sxwzgg"></i><a href="' . $ptpggurl;
            $ggurl=$tmp2 . '" target="_blank">进一步了解</a></div>';
            $gps="";
            break;
        }
    }
    $row=strtotime($ptptime);
    $time=$row;
    $row=ReckonTime($time);
    $wzfbsj=$row;
    $tmp2=$ptpys==1;
    $tmp4=(bool)$tmp2;
    if($tmp4){
        $tmp3=$ptpaud==1;
        $tmp4=(bool)$tmp3;
    }
if($tmp4)goto L2xeWjgx97;
goto L2xx42;
goto L2xx42;
goto L2xx42;
L2xeWjgx97:
    $str=preg_replace("/<img[^>]+>/i","",$ptptext);
    $contenttext0=$str;
    $str=preg_replace("/<span[^>]+>/i","",$contenttext0);
    $contenttext1=$str;
    $str=preg_replace("/<a href=[^>]+>/i","",$contenttext1);
    $contenttext=$str;
    $row=str_replace(" ", "", $contenttext);
    $contenttext=$row;
    $row=iconv_strlen($contenttext, "UTF-8");
    $tmp2=$row>100;
    if($tmp2){
        $tmp2='<span class="wzndhycyc" id="sh-content-qwdid-' . $cid;
        $tmp3=$tmp2 . '">';
        $tmp4=$tmp3 . $ptptext;
        $tmp5=$tmp4 . '</span><a href="JavaScript:;" class="sh-content-quanwenan" id="sh-content-quanwenan-';
        $tmp6=$tmp5 . $cid;
        $tmp7=$tmp6 . '" lang="0" onclick="quanwenan()">全文</a>';
        $ptptext=$tmp7;
    }else{
        $tmp2='<span>' . $ptptext;
        $ptptext=$tmp2 . '</span>';
    }
    $tmp2=$ptpname=="匿名用户";
    if($tmp2){
        $arcuserurl='';
    }else{
        $hash=md5($ptpuser);
        $hash2=md5($hash);
        $tmp2='onclick="location.href=\'./archives.php?user=' . $hash2;
        $arcuserurl=$tmp2 . '\'"';
    }
    $tmp2='
    <div class="sh-content" id="sh-content-' . $cid;
    $tmp3=$tmp2 . '">
    <!-- 左边 -->
    <div class="sh-content-left">
    <!-- 头像 -->
    <img src="./assets/img/thumbnail.svg" data-src="';
    $tmp4=$tmp3 . $ptpimg;
    $tmp5=$tmp4 . '" alt="头像" ';
    $tmp6=$tmp5 . $arcuserurl;
    $tmp7=$tmp6 . '>
    </div>
    <!-- 右边 -->
    <div class="sh-content-right">
    <!-- 昵称与内容 -->
    <div class="sh-content-right-head">
    <!-- 昵称 -->
    <div class="sh-content-right-head-title">
    <p>';
    $tmp8=$tmp7 . $ptpname;
    $tmp9=$tmp8 . '</p>
    <div class="sh-content-right-head-title-ad" style="';
    $tmp10=$tmp9 . $ggdiv;
    $tmp11=$tmp10 . '">
    <p>广告</p>
    </div>
    </div>
    <!-- 内容 -->
    ';
    $tmp12=$tmp11 . $ptptext;
    echo $tmp12;
    $tmp2=$ptplx=="only";
if($tmp2)goto L2xeWjgx51;
goto L2xldMhx51;
goto L2xldMhx51;
goto L2xldMhx51;
goto L2xldMhx51;
L2xeWjgx51:
    echo '<!-- 图片 -->';
goto L2xx5z;
L2xldMhx51:
    $tmp2=$ptplx=="img";
if($tmp2)goto L2xeWjgx52;
goto L2xldMhx52;
goto L2xldMhx52;
goto L2xldMhx52;
goto L2xldMhx52;
L2xeWjgx52:
    $tmp2=$coun>"1";
    if($tmp2){
        $picimg=100;
    }else{
        $picimg='';
    }
    $tmp2='<!-- 图片 -->
    <div class="sh-content-right-img" id="imglib-' . $cid;
    $tmp3=$tmp2 . '" style="';
    $tmp4=$tmp3 . $tusty;
    $tmp5=$tmp4 . '">';
    echo $tmp5;
    $str=0;
    $i=$str;
    while(true){
        $tmp2=$i<$coun;
        if(!$tmp2)break;
        $tuimg=$imgar[$i];
        $tmp2=$i>7;
if($tmp2)goto L2xeWjgx59;
goto L2xldMhx59;
goto L2xldMhx59;
goto L2xldMhx59;
goto L2xldMhx59;
goto L2xldMhx59;
L2xeWjgx59:
        $tmp2=$coun-$i;
        $duoimg=$tmp2-1;
        $tmp2=$coun>9;
if($tmp2)goto L2xeWjgx5b;
goto L2xldMhx5b;
goto L2xldMhx5b;
goto L2xldMhx5b;
goto L2xldMhx5b;
goto L2xldMhx5b;
L2xeWjgx5b:
        $tmp2=$i==8;
if($tmp2)goto L2xeWjgx5d;
goto L2xldMhx5d;
goto L2xldMhx5d;
goto L2xldMhx5d;
goto L2xldMhx5d;
goto L2xldMhx5d;
L2xeWjgx5d:
        $tmp2='<a href="' . $tuimg;
        $tmp3=$tmp2 . '" class="sh-content-right-img-pic" data-fancybox="gallery';
        $tmp4=$tmp3 . $cid;
        $tmp5=$tmp4 . '" data-caption="">
        <span class="sh-content-right-img-pic-mask">+';
        $tmp6=$tmp5 . $duoimg;
        $tmp7=$tmp6 . '</span>
        <img src="./assets/img/thumbnail.svg" data-src="';
        $tmp8=$tmp7 . $tuimg;
        $tmp9=$tmp8 . '" alt="" ';
        $tmp10=$tmp9 . $picimg;
        $tmp11=$tmp10 . '>
        </a>';
        echo $tmp11;
goto L2xx58;
L2xldMhx5d:
        $tmp2='<a href="' . $tuimg;
        $tmp3=$tmp2 . '" class="sh-content-right-img-pic" data-fancybox="gallery';
        $tmp4=$tmp3 . $cid;
        $tmp5=$tmp4 . '" data-caption=""  style="display:none;">
        <img src="';
        $tmp6=$tmp5 . $tuimg;
        $tmp7=$tmp6 . '" data-src="';
        $tmp8=$tmp7 . $tuimg;
        $tmp9=$tmp8 . '" alt="" ';
        $tmp10=$tmp9 . $picimg;
        $tmp11=$tmp10 . '>
        </a>';
        echo $tmp11;
L2xldMhx5b:
        $tmp2='<a href="' . $tuimg;
        $tmp3=$tmp2 . '" class="sh-content-right-img-pic" data-fancybox="gallery';
        $tmp4=$tmp3 . $cid;
        $tmp5=$tmp4 . '" data-caption="">
        <img src="./assets/img/thumbnail.svg" data-src="';
        $tmp6=$tmp5 . $tuimg;
        $tmp7=$tmp6 . '" alt="" ';
        $tmp8=$tmp7 . $picimg;
        $tmp9=$tmp8 . '>
        </a>';
        echo $tmp9;
L2xldMhx59:
        $tmp2='<a href="' . $tuimg;
        $tmp3=$tmp2 . '" class="sh-content-right-img-pic" data-fancybox="gallery';
        $tmp4=$tmp3 . $cid;
        $tmp5=$tmp4 . '" data-caption="">
        <img src="./assets/img/thumbnail.svg" data-src="';
        $tmp6=$tmp5 . $tuimg;
        $tmp7=$tmp6 . '" alt="" ';
        $tmp8=$tmp7 . $picimg;
        $tmp9=$tmp8 . '>
        </a>';
        echo $tmp9;
L2xx58:
        $obj=$i;
        $obj2=$i+1;
        $str=$obj2;
        $i=$str;
    }
    echo '</div>';
goto L2xx5z;
L2xldMhx52:
    $tmp2=$ptplx=="video";
if($tmp2)goto L2xeWjgx5m;
goto L2xldMhx5m;
goto L2xldMhx5m;
goto L2xldMhx5m;
goto L2xldMhx5m;
L2xeWjgx5m:
    $tmp2=$videoauplay==1;
    if($tmp2){
        $videobf='autoplay';
        $videobfplas='';
    }else{
        $videobf='';
        $tmp2='<i class="iconfont icon-sa4f56" id="sh-content-video-videobfb-' . $cid;
        $tmp3=$tmp2 . '" style="width: fit-content;height: fit-content;grid-column: 1;grid-row: 1;z-index: 5;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);font-size: 40px;color: #ffffff;display: flex;cursor: pointer;padding: 15px;pointer-events: none;"></i>';
        $videobfplas=$tmp3;
    }
    $tmp2=$filterpiccir==1;
    if($tmp2){
        $vidoyuan=1;
    }else{
        $vidoyuan=0;
    }
    $tmp2='
    <!-- 视频 -->
    <div class="sh-video" id="sh-content-video-' . $cid;
    $tmp3=$tmp2 . '" onclick="videofdgb()" lang="0">
    <video name="sh-videokid" class="sh-content-video" data-ybs="';
    $tmp4=$tmp3 . $vidoyuan;
    $tmp5=$tmp4 . '" poster="';
    $tmp6=$tmp5 . $ptpvideofm;
    $tmp7=$tmp6 . '" id="sh-content-videok-';
    $tmp8=$tmp7 . $cid;
    $tmp9=$tmp8 . '" src="';
    $tmp10=$tmp9 . $ptpvideo;
    $tmp11=$tmp10 . '" playsinline webkit-playsinline preload="metadata" ';
    $tmp12=$tmp11 . $videobf;
    $tmp13=$tmp12 . ' muted loop onclick="videofd()" lang="0" disablePictureInPicture="true" controlslist="nodownload nofullscreen noremoteplayback"></video>
    ';
    $tmp14=$tmp13 . $videobfplas;
    $tmp15=$tmp14 . '
    <i class="iconfont icon-quxiao" id="sh-content-videog-';
    $tmp16=$tmp15 . $cid;
    $tmp17=$tmp16 . '" lang="0"></i>
    <span class="sh-video-span" id="sh-video-span-';
    $tmp18=$tmp17 . $cid;
    $tmp19=$tmp18 . '">MP4</span>
    </div>
    ';
    echo $tmp19;
goto L2xx5z;
L2xldMhx5m:
    $tmp2=$ptplx=="music";
if($tmp2)goto L2xeWjgx5r;
goto L2xldMhx5r;
goto L2xldMhx5r;
goto L2xldMhx5r;
goto L2xldMhx5r;
L2xeWjgx5r:
    echo '<!-- 音乐 -->';
    $row=is_numeric($ptpmusic);
if($row)goto L2xx5z;
goto L2xldMhx5t;
goto L2xldMhx5t;
L2xldMhx5t:
    $row=explode('|', $ptpmusic);
    $mus=$row;
    $tmp2=include "./site/musicplay.php";
L2xldMhx5r:
    $tmp2=$ptplx=="mony";
if($tmp2)goto L2xeWjgx5u;
goto L2xldMhx5u;
goto L2xldMhx5u;
goto L2xldMhx5u;
goto L2xldMhx5u;
L2xeWjgx5u:
    $tmp2="SELECT * FROM money WHERE ptpmoncid = '" . $cid;
    $sql01=$tmp2 . "'";
    $result=$conn->query($sql01);
    $result01=$result;
    $tmp2=$result01->num_rows>0;
if($tmp2)goto L2xeWjgx5w;
goto L2xx5z;
goto L2xx5z;
goto L2xx5z;
goto L2xx5z;
L2xeWjgx5w:
    while(true){
        $result=$result01->fetch_assoc();
        $row01=$result;
        if(!$str)break;
        $muser=$row01["muser"];
        $type=$row01["type"];
        $zsum=$row01["zsum"];
        $sum=$row01["sum"];
        $total=$row01["total"];
        $recve=$row01["recve"];
        $luser=$row01["luser"];
        $montext=$row01["montext"];
        $monimg=$row01["monimg"];
        $ptpmoncid=$row01["ptpmoncid"];
    }
    $tmp2=$monimg=="";
    if($tmp2){
        $monimg='';
    }else{
        $tmp2='background-image: url(' . $monimg;
        $monimg=$tmp2 . ');';
    }
    $tmp2=$recve<1;
    $tmp4=(bool)$tmp2;
    $tmp5=!$tmp4;
    if($tmp5){
        $tmp3=$sum<0.01;
        $tmp4=(bool)$tmp3;
    }
    if($tmp4){
        $hongbtm="opacity: 0.6;";
        $str='onclick="monyk()"';
        $hongbshij=$str;
        $ptpmoncid='';
    }else{
        $hongbtm="";
        $str='onclick="monyk()"';
        $hongbshij=$str;
    }
    $row=explode(PHP_EOL, $luser);
    $lines=$row;
    unset($tmp);
    foreach($lines as $line){$tmp[]=$line;
}
$tmp20=0;
while(true){
    $row=count($tmp);
    $tmp2=$tmp20<$row;
    if(!$tmp2)break;
    $keys=array_keys($tmp);
    $keys=$keys[$tmp20];
    $line=$tmp[$keys];
    $row=explode("|", $line);
    $parts=$row;
    $before_pipe=$parts[0];
    $after_pipe=$parts[1];
    $tmp2=$before_pipe==$user_zh;
    if($tmp2){
        $hongbtm="opacity: 0.6;";
        $str='onclick="monyk()"';
        $hongbshij=$str;
        $ptpmoncid=-1;
    }
    $tmp20=$tmp20+1;
}
L2xx6f:
$tmp2=$zjzhq=="";
$tmp4=(bool)$tmp2;
$tmp5=!$tmp4;
if($tmp5){
    $tmp3=$passid=="";
    $tmp4=(bool)$tmp3;
}
if($tmp4)goto L2xeWjgx6m;
goto L2xldMhx6m;
goto L2xldMhx6m;
goto L2xldMhx6m;
goto L2xldMhx6m;
L2xeWjgx6m:
$tmp2=$recve<1;
$tmp4=(bool)$tmp2;
$tmp5=!$tmp4;
if($tmp5){
    $tmp3=$sum<0.01;
    $tmp4=(bool)$tmp3;
}
if($tmp4)goto L2xeWjgx6q;
goto L2xldMhx6q;
goto L2xldMhx6q;
goto L2xldMhx6q;
goto L2xldMhx6q;
L2xeWjgx6q:
$hongbtm="opacity: 0.6;";
$str='onclick="monyk()"';
$hongbshij=$str;
$ptpmoncid=-1;
goto L2xx6j;
L2xldMhx6q:
$hongbtm="";
$str='onclick="monyk()"';
$hongbshij=$str;
$ptpmoncid=-1;
L2xldMhx6m:
L2xx6j:
$tmp2='<div id="sh-redpacket-content" class="sh-redpacket-content" style="' . $hongbtm;
$tmp3=$tmp2 . '">
<div class="sh-redpacket-content-space">
<div class="sh-space-up">
<!-- 上部分圆角框架 背景-->
<div class="sh-space-up-space" style="';
$tmp4=$tmp3 . $monimg;
$tmp5=$tmp4 . '">
<div class="sh-space-up-space-logo"><img src="./assets/img/logogolden.svg" data-src="./assets/img/logogolden.svg"></div>
<div class="sh-space-up-space-title"><span>';
$tmp6=$tmp5 . $montext;
$tmp7=$tmp6 . '</span></div>
</div>
</div>
<div class="sh-space-dw">
<div class="sh-space-dw-btnk"><span class="sh-space-dw-btn" id="sh-space-dw-btn-';
$tmp8=$tmp7 . $cid;
$tmp9=$tmp8 . '" lang="';
$tmp10=$tmp9 . $ptpmoncid;
$tmp11=$tmp10 . '" ';
$tmp12=$tmp11 . $hongbshij;
$tmp13=$tmp12 . '>领</span></div>
</div>
</div>
</div>';
echo $tmp13;
goto L2xx5z;
L2xldMhx5u:
L2xx5z:
echo '
</div>
<!-- 地址 -->';
$tmp2=$ptpdw!="";
if($tmp2){
    echo $gps;
}
echo '<!--广告-->';
echo $ggurl;
$tmp2="select * from lcke where lwz= '" . $cid;
$sql2b=$tmp2 . "'";
$row=mysqli_query($conn, $sql2b);
$result2b=$row;
$row=mysqli_num_rows($result2b);
$tmp2=$row>0;
if($tmp2)goto L2xeWjgx6u;
goto L2xldMhx6u;
goto L2xldMhx6u;
goto L2xldMhx6u;
goto L2xldMhx6u;
L2xeWjgx6u:
$sql2a="SELECT * FROM lcke";
$result=$conn->query($sql2a);
$result2a=$result;
while(true){
    while(true){
        $result=$result2a->fetch_assoc();
        $row2a=$result;
        if(!$str)break;
        $tmp2=$row2a['lwz']==$cid;
        if(!$tmp2)break;
        $dianzmlnr=$row2a['luser'];
        $tmp2=$user_zh=="";
        $tmp4=(bool)$tmp2;
        $tmp11=!$tmp4;
        if($tmp11){
            $tmp3=$user_name=="";
            $tmp4=(bool)$tmp3;
        }
        $tmp6=(bool)$tmp4;
        $tmp10=!$tmp6;
        if($tmp10){
            $tmp5=$user_img=="";
            $tmp6=(bool)$tmp5;
        }
        $tmp8=(bool)$tmp6;
        $tmp9=!$tmp8;
        if($tmp9){
            $tmp7=$user_passid=="";
            $tmp8=(bool)$tmp7;
        }
if($tmp8)goto L2xeWjgx77;
goto L2xldMhx77;
goto L2xldMhx77;
goto L2xldMhx77;
goto L2xldMhx77;
goto L2xldMhx77;
L2xeWjgx77:
        $tmp2=$dianzmlnr==$_SESSION['visykmz_userip'];
if($tmp2)goto L2xeWjgx79;
goto L2xldMhx79;
goto L2xldMhx79;
goto L2xldMhx79;
goto L2xldMhx79;
goto L2xldMhx79;
L2xeWjgx79:
        $dianzmlnr="取消";
        $dianzmlimg="iconfont icon-aixin2 ri-sxdzlikehs";
goto L2xx6t;
    }
L2xldMhx79:
    $dianzmlnr="赞";
    $dianzmlimg="iconfont icon-aixin ri-sxdzlike";
L2xldMhx77:
    $tmp2=$dianzmlnr==$user_zh;
if($tmp2)goto L2xeWjgx7b;
goto L2xldMhx7b;
goto L2xldMhx7b;
goto L2xldMhx7b;
goto L2xldMhx7b;
goto L2xldMhx7b;
L2xeWjgx7b:
    $dianzmlnr="取消";
    $dianzmlimg="iconfont icon-aixin2 ri-sxdzlikehs";
goto L2xx6t;
}
L2xldMhx7b:
$dianzmlnr="赞";
$dianzmlimg="iconfont icon-aixin ri-sxdzlike";
goto L2xx6t;
L2xldMhx6u:
$dianzmlnr="赞";
$dianzmlimg="iconfont icon-aixin ri-sxdzlike";
L2xx6t:
$tmp2=$commauth==1;
if($tmp2){
    $tmp2='
    <div class="sh-content-right-time-right-left-y" id="' . $cid;
    $tmp3=$tmp2 . '" onclick="plkkg()">
    <i class="iconfont icon-pinglun2 ri-sxdzcomm"></i>
    <span>评论</span>
    </div>
    ';
    $gwzkplzt=$tmp3;
}else{
    $tmp2='
    <div class="sh-content-right-time-right-left-y" id="' . $cid;
    $tmp3=$tmp2 . '">
    <i class="iconfont icon-pinglun2 ri-sxdzcomm"></i>
    <span>评论关闭</span>
    </div>
    ';
    $gwzkplzt=$tmp3;
}
$tmp2='
<!-- 时间与点赞 -->
<div class="sh-content-right-time">
<!-- 时间 -->
<a class="sh-content-right-time-left" href="./view.php?cid=' . $cid;
$tmp3=$tmp2 . '" target="_blank"><span>';
$tmp4=$tmp3 . $wzfbsj;
$tmp5=$tmp4 . '</span></a>
<!-- 点赞 -->
<div class="sh-content-right-time-right">
<!-- 左边合集 -->
<div class="sh-content-right-time-right-left" id="pl-';
$tmp6=$tmp5 . $cid;
$tmp7=$tmp6 . '" name="pl">
<div class="sh-content-right-time-right-left-z" onclick="dinazan()">
<i class="';
$tmp8=$tmp7 . $dianzmlimg;
$tmp9=$tmp8 . '" id="tiezimg-';
$tmp10=$tmp9 . $cid;
$tmp11=$tmp10 . '"></i>
<span id="tiezdz-';
$tmp12=$tmp11 . $cid;
$tmp13=$tmp12 . '">';
$tmp14=$tmp13 . $dianzmlnr;
$tmp15=$tmp14 . '</span>
</div>
<p></p>
';
$tmp16=$tmp15 . $gwzkplzt;
$tmp17=$tmp16 . '
</div>
<!-- 右边点赞控制按钮 -->
<div class="sh-content-right-time-right-right" id="';
$tmp18=$tmp17 . $cid;
$tmp19=$tmp18 . '" onclick="plk()">
<p class="zp1"></p>
<p></p>
</div>
</div>
</div>
<!-- 点赞列表与评论 -->
<div class="sh-zanp" id="zanss-';
$tmp21=$tmp19 . $cid;
$tmp22=$tmp21 . '">
';
echo $tmp22;
$tmp2="select * from lcke where lwz= '" . $cid;
$sql2=$tmp2 . "'";
$row=mysqli_query($conn, $sql2);
$result2=$row;
$row=mysqli_num_rows($result2);
$tmp2=$row>0;
if($tmp2)goto L2xeWjgx7v;
goto L2xldMhx7v;
goto L2xldMhx7v;
goto L2xldMhx7v;
goto L2xldMhx7v;
L2xeWjgx7v:
$tmp2='
<!-- 点赞列表 -->
<div class="sh-zanp-zan" id="zans-' . $cid;
$tmp3=$tmp2 . '">
<!-- 左侧点赞图标 -->
<div class="sh-zanp-zan-left"><!--img src="./assets/img/likel.svg" alt=""--><i class="iconfont icon-aixin ri-sxwzlike"></i></div>
<!-- 右边点赞名列表 -->
<ul class="sh-zanp-zan-right" id="zlbeh-';
$tmp4=$tmp3 . $cid;
$tmp5=$tmp4 . '">
';
echo $tmp5;
$iw=0;
$dwys=0;
while(true){
    while(true){
        $row=mysqli_fetch_assoc($result2);
        $row2=$row;
        if(!$str)break;
        $dianzmys=$row2["luser"];
        $row=strpos($dianzmys, 'vis#-[');
        $tmp2=$row!==false;
        $tmp4=(bool)$tmp2;
        $tmp5=!$tmp4;
        if($tmp5){
            $hash2=strpos($dianzmys, ']-#vis');
            $tmp3=$hash2!==false;
            $tmp4=(bool)$tmp3;
        }
        if(!$tmp4)break;
        $obj2=$dwys;
        $dwys=$dwys+1;
    }
    $obj3=$iw;
    $iw=$iw+1;
    $dianzms=$row2["lname"];
    $tmp2='<li id="zan-' . $cid;
    $tmp3=$tmp2 . '" lang="';
    $tmp4=$tmp3 . $dianzms;
    $tmp5=$tmp4 . '">';
    $tmp6=$tmp5 . $dianzms;
    $tmp7=$tmp6 . '</li>';
    echo $tmp7;
}
L2xx83:
$tmp2=$dwys!=0;
if($tmp2){
    $tmp2='<li id="fkzan-' . $cid;
    $tmp3=$tmp2 . '">';
    $tmp4=$tmp3 . $dwys;
    $tmp5=$tmp4 . '位访客</li>';
    echo $tmp5;
}
echo '
</ul>
</div>
';
goto L2xx7u;
L2xldMhx7v:
$tmp2='
<!-- 点赞列表 -->
<div class="sh-zanp-zan" id="zans-' . $cid;
$tmp3=$tmp2 . '" style="display:none;">
<!-- 左侧点赞图标 -->
<div class="sh-zanp-zan-left"><i class="iconfont icon-aixin ri-sxwzlike"></i></div>
<!-- 右边点赞名列表 -->
<ul class="sh-zanp-zan-right" id="zlbeh-';
$tmp4=$tmp3 . $cid;
$tmp5=$tmp4 . '">
</ul>
</div>
';
echo $tmp5;
L2xx7u:
echo '
<!-- 评论列表 -->';
$tmp2="select * from comm where wzcid= '" . $cid;
$sql3=$tmp2 . "' and comaud<>'0' and comaud<>'-1'";
$row=mysqli_query($conn, $sql3);
$result3=$row;
$pls=0;
$row=mysqli_num_rows($result3);
$tmp2=$row>0;
if($tmp2)goto L2xeWjgx8c;
goto L2xldMhx8c;
goto L2xldMhx8c;
goto L2xldMhx8c;
goto L2xldMhx8c;
L2xeWjgx8c:
$tmp2='<ul class="sh-zanp-pl" id="sh-zanp-pl-' . $cid;
$tmp3=$tmp2 . '">';
echo $tmp3;
while(true){
    $row=mysqli_fetch_assoc($result3);
    $row3=$row;
    if(!$str)break;
    $pls=$pls+1;
    $tmp2=$pls>$commgs;
if($tmp2)goto L2xeWjgx8g;
goto L2xldMhx8g;
goto L2xldMhx8g;
goto L2xldMhx8g;
goto L2xldMhx8g;
goto L2xldMhx8g;
L2xeWjgx8g:
    $plgd="display:flex";
goto L2xx8e;
goto L2xx8f;
L2xldMhx8g:
    $plgd="display:none";
L2xx8f:
    $couser=$row3["couser"];
    $coname=$row3["coname"];
    $courl=$row3["courl"];
    $cotext=$row3["cotext"];
    $bcouser=$row3["bcouser"];
    $bconame=$row3["bconame"];
    $comaud=$row3["comaud"];
    $tmp2=$comaud!=1;
    if($tmp2){
        $cotext="该条评论未通过审核!";
    }
    $tmp2=$courl=="";
    if($tmp2){
        $plzwze='';
    }else{
        $tmp2='href="' . $courl;
        $plzwze=$tmp2 . '" style="pointer-events: all;"';
    }
    $tmp2=$commauth==1;
    if($tmp2){
        $str='onclick="plhuifu()"';
        $pldjhf=$str;
    }else{
        $pldjhf='';
    }
    $tmp2=$bcouser=="false";
    $tmp4=(bool)$tmp2;
    $tmp5=!$tmp4;
    if($tmp5){
        $tmp3=$bconame=="false";
        $tmp4=(bool)$tmp3;
    }
if($tmp4)goto L2xeWjgx8q;
goto L2xldMhx8q;
goto L2xldMhx8q;
goto L2xldMhx8q;
goto L2xldMhx8q;
goto L2xldMhx8q;
L2xeWjgx8q:
    $tmp2='
    <li lang="' . $coname;
    $tmp3=$tmp2 . '" ';
    $tmp4=$tmp3 . $pldjhf;
    $tmp5=$tmp4 . ' id="';
    $tmp6=$tmp5 . $cid;
    $tmp7=$tmp6 . '" value="';
    $tmp8=$tmp7 . $couser;
    $tmp9=$tmp8 . '" data-comkzt="0">
    <div class="sh-zanp-pl-n">
    <a ';
    $tmp10=$tmp9 . $plzwze;
    $tmp11=$tmp10 . ' class="sh-zanp-pl-n-nc" onclick="hfljurl()" target="_blank">';
    $tmp12=$tmp11 . $coname;
    $tmp13=$tmp12 . '</a>：
    <span class="sh-zanp-pl-n-nr">';
    $tmp14=$tmp13 . $cotext;
    $tmp15=$tmp14 . '</span>
    </div>
    </li>
    ';
    echo $tmp15;
}
L2xldMhx8q:
$tmp2='
<li lang="' . $coname;
$tmp3=$tmp2 . '" ';
$tmp4=$tmp3 . $pldjhf;
$tmp5=$tmp4 . ' id="';
$tmp6=$tmp5 . $cid;
$tmp7=$tmp6 . '" value="';
$tmp8=$tmp7 . $couser;
$tmp9=$tmp8 . '" data-comkzt="0">
<div class="sh-zanp-pl-n">
<a ';
$tmp10=$tmp9 . $plzwze;
$tmp11=$tmp10 . ' class="sh-zanp-pl-n-nc" onclick="hfljurl()" target="_blank">';
$tmp12=$tmp11 . $coname;
$tmp13=$tmp12 . '</a>
<span>回复</span>
<span class="sh-zanp-pl-n-nc">';
$tmp14=$tmp13 . $bconame;
$tmp15=$tmp14 . '</span>：
<span class="sh-zanp-pl-n-nr">';
$tmp16=$tmp15 . $cotext;
$tmp17=$tmp16 . '</span>
</div>
</li>
';
echo $tmp17;
L2xx8e:
echo '</ul>';
goto L2xx8b;
L2xldMhx8c:
$plgd="display:none";
$tmp2='<ul class="sh-zanp-pl" id="sh-zanp-pl-' . $cid;
$tmp3=$tmp2 . '" style="display:none;"></ul>';
echo $tmp3;
L2xx8b:
$tmp2='
<!-- 显示更多评论 -->
<div class="sh-zanp-pl-ku">
<a href="./view.php?cid=' . $cid;
$tmp3=$tmp2 . '" target="_blank" class="sh-zanp-pl-gd" style="';
$tmp4=$tmp3 . $plgd;
$tmp5=$tmp4 . '">
<p class="zp1"></p>
<p class="zp1"></p>
<p></p>
</a>
</div>
</div>
</div>
</div>
';
echo $tmp5;
}
L2xxfw:
echo "            ";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
if($userdlzt==0)goto L2xeWjgxkz;
goto L2xldMhxkz;
L2xeWjgxkz:
$tmp2=$loginkg==1;
if($tmp2)goto L2xeWjgxjt;
goto L2xxjy;
goto L2xxjy;
L2xeWjgxjt:
$tmp2='<div class="sh-login" id="sh-login" onclick="gblogin()">
<form class="sh-login-main" onsubmit="return false;" autocomplete="off" onclick="hfljurl()">
<!-- 顶部 -->
<div class="sh-login-main-top">
<div class="sh-news-main-top-div" onclick="gblogin()"><i class="iconfont icon-quxiao al-sxb2h"></i></div>
</div>
<div class="sh-login-main-kko">
<div class="sh-login-main-kko-kok">
<p class="sh-login-main-kko-kok-p" id="zhdzsx">账号登录</p>
<!-- 中间 -->
<div class="sh-login-main-con">
<div class="sh-login-main-con-anu">
<p>账号</p>
<input type="text" name="zh" id="login-zh" spellcheck="false" value="" placeholder="账号" onKeyUp="value=value.replace(/[\W]/g,\'\')">
</div>
<div class="sh-login-main-con-anu" id="sh-login-main-con-anu" style="display:none;">
<p>邮箱</p>
<input type="email" name="email" id="login-email" spellcheck="false" value="" placeholder="邮箱" pattern="^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$" title="请输入正确的邮箱格式">
</div>
<div class="sh-login-main-con-anu">
<input type="hidden" name="allkey" id="allkey" value="' . $allkey;
$tmp3=$tmp2 . '">
<p>密码</p>
<input type="password" name="pwd" id="login-pass" spellcheck="false" value="" placeholder="密码">
</div>';
echo $tmp3;
$tmp2=$regverify=="1";
if($tmp2){
    echo '<div class="sh-login-main-con-anu" id="sh-login-main-con-yzmwk" style="display:none;">
    <p>验证码</p>
    <input type="password" name="yzm" id="login-yzm" spellcheck="false" minlength="3" maxlength="16" value="" placeholder="验证码" style="margin-right: 5px;">
    <p style="color: var(--thetitle);margin: 0 30px 0 0;font-size: 14px;cursor: pointer;" id="yzm">发送</p>
    </div>';
}
echo '
<!--div class="sh-login-main-con-anu">
<a href="JavaScript:;" onclick="zhmm()">忘记密码</a>
</div-->
</div>
<!-- 底部 -->
<div class="sh-login-main-bot">
<input type="submit" value="登录" class="sh-right" id="sh-left-dlzc" onclick="logy()">
</div>
</div>
<div class="sh-login-main-bottom">
<a href="JavaScript:;" onclick="zhmm()" onkeydown="return checkKeyDown(event)">忘记密码</a>';
$tmp2=$regqx==0;
if($tmp2){
    echo '<p></p>
    <a href="JavaScript:;" id="sh-zck-an" onclick="zcanxy()" onkeydown="return checkKeyDown(event)">注册账号</a>';
}
echo '
</div>
</div>
</form>
</div>';
goto L2xxjy;
L2xldMhxkz:
L2xxjy:
echo "";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
if($userdlzt==1)goto L2xeWjgxln;
goto L2xldMhxln;
L2xeWjgxln:
echo '<div class="sh-news" id="sh-news" onclick="gbnews()">
<div class="sh-news-main" id="sh-news-main" onclick="hfljurl()">
<!-- 顶部 -->
<div class="sh-news-main-top">
<div class="sh-news-main-top-xiaoxih"><span>消息盒子</span></div>
<div class="sh-news-main-top-div" style="display:none;" id="xxscztqbk" class="sh-news-main-top-img" onclick="xxscztqb()"><i class="iconfont icon-shanchuwenjian ri-sxhsh ri-sxhs" id="xxscztqb"></i></div>
<div class="sh-news-main-top-div sh-news-main-top-div2" onclick="js_menu()">
<i class="iconfont icon-xialajiantouxiao ri-sxhqx"></i>
<div id="js_menu" class="sh-news-main-top-div-menu" style="display: none;">
<a href="JavaScript:;" onclick="xxscyd()" class="iconfont icon-icon-09 ri-sxhs">全部已读</a>
<a href="JavaScript:;" onclick="xxsczt()" class="iconfont icon-xuanze ri-sxhs" id="xxsczt" lang="0">选择消息</a>
<a href="JavaScript:;" onclick="xxscztqb()" class="iconfont icon-shanchu ri-sxhs">删除所有</a>
</div>
</div>
<div class="sh-news-main-top-div" onclick="gbnews()"><i class="iconfont icon-quxiao ri-sxhqx"></i></div>
</div>
<!-- 内容 -->
<div class="sh-news-con" id="sh-news-con">';
$tmp2=include './config.php';
$tmp2=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp2;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$sqlxx="SELECT * FROM message order by id desc";
$result=$conn->query($sqlxx);
$resultxx=$result;
$xxsl=0;
L2xxkb:
while(true){
    while(true){
        $result=$resultxx->fetch_assoc();
        $rowxx=$result;
        if(!$str)break;
        $obj4=$xxsl;
        $xxsl=$xxsl+1;
        $fuserxx=$rowxx['fuser'];
        $fimgxx=$rowxx['fimg'];
        $fnamexx=$rowxx['fname'];
        $suserxx=$rowxx['suser'];
        $titlexx=$rowxx['title'];
        $textxx=$rowxx['text'];
        $ftimexx=$rowxx['ftime'];
        $msgxx=$rowxx['msg'];
        $xxid=$rowxx['id'];
        $tmp2=$titlexx=="新的点赞";
        if(!$tmp2)break;
        $tmp2="select * from lcke where luser= '" . $fuserxx;
        $tmp3=$tmp2 . "' and ltime='";
        $tmp4=$tmp3 . $ftimexx;
        $sql=$tmp4 . "'";
        $result=$conn->query($sql);
        $result=$result;
        $row=mysqli_fetch_array($result);
        $row=$row;
if($row)goto L2xeWjgxkg;
goto L2xldMhxkg;
goto L2xldMhxkg;
goto L2xldMhxkg;
L2xeWjgxkg:
        $wzssid=$row['lwz'];
goto L2xxkd;
L2xldMhxkg:
        $wzssid=-1;
        $tmp2="select * from comm where couser= '" . $fuserxx;
        $tmp3=$tmp2 . "' and cotime='";
        $tmp4=$tmp3 . $ftimexx;
        $sql=$tmp4 . "'";
        $result=$conn->query($sql);
        $result=$result;
        $row=mysqli_fetch_array($result);
        $row=$row;
        if($row){
            $wzssid=$row['wzcid'];
        }else{
            $wzssid=-1;
        }
L2xxkd:
        $num14="select * from essay where cid='" . $wzssid;
        $str2=$num14 . "'";
        $row=mysqli_query($conn, $str2);
        $data_result=$row;
        $row=mysqli_fetch_array($data_result);
        $data_row=$row;
        $wzdlx=$data_row["ptplx"];
        $wzdtp=$data_row["ptpimag"];
        $wzdnr=$data_row["ptptext"];
        $tmp2=$wzdlx=="img";
        if($tmp2){
            $tmp2=$wzdtp!="";
            if($tmp2){
                $row=explode('(+@+)', $wzdtp);
                $imgar=$row;
                $row=count($imgar);
                $coun=$row;
                $wzdtp=$imgar[0];
            }else{
                $wzdtp="./assets/img/thumbnailbg.svg";
            }
            $tmp2='<img src="./assets/img/thumbnailbg.svg" data-src="' . $wzdtp;
            $wzfmd=$tmp2 . '" alt="动态封面">';
        }else{
            $tmp2=$wzdlx=="only";
            if($tmp2){
                $tmp2='<div class="sh-xxliebwb"><span>' . $wzdnr;
                $wzfmd=$tmp2 . '</span></div>';
            }else{
                $wzdtp="./assets/img/thumbnailbg.svg";
                $tmp2='<img src="./assets/img/thumbnailbg.svg" data-src="' . $wzdtp;
                $wzfmd=$tmp2 . '" alt="动态封面">';
            }
        }
        $row=strtotime($ftimexx);
        $time=$row;
        $row=ReckonTime($time);
        $ftimexx=$row;
        $tmp2=$suserxx==$user_zh;
if($tmp2)goto L2xeWjgxkp;
goto L2xldMhxkp;
goto L2xldMhxkp;
goto L2xldMhxkp;
L2xeWjgxkp:
        $tmp2=$msgxx!="-1";
if($tmp2)goto L2xeWjgxkr;
goto L2xldMhxkr;
goto L2xldMhxkr;
goto L2xldMhxkr;
L2xeWjgxkr:
        $tmp2=$msgxx==0;
if($tmp2)goto L2xeWjgxkt;
goto L2xldMhxkt;
goto L2xldMhxkt;
goto L2xldMhxkt;
L2xeWjgxkt:
        $tmp2='<div id="' . $xxid;
        $tmp3=$tmp2 . '" class="sh-news-con-lie" lang="';
        $tmp4=$tmp3 . $wzssid;
        $tmp5=$tmp4 . '" onclick="mesgxq()">
        <!-- 左 -->
        <div class="sh-news-con-lie-left">
        <p id="xxztx-';
        $tmp6=$tmp5 . $xxid;
        $tmp7=$tmp6 . '"></p>
        <div class="sh-news-con-lie-left-imgt">
        <img src="./assets/img/thumbnail.svg" data-src="';
        $tmp8=$tmp7 . $fimgxx;
        $tmp9=$tmp8 . '" alt="头像" class="sh-news-con-lie-left-img"></div>
        </div>
        <!-- 右 -->
        <div class="sh-news-con-lie-right">
        <p id="xxtzidtitle-';
        $tmp10=$tmp9 . $xxid;
        $tmp11=$tmp10 . '" class="sh-news-con-lie-right-title">';
        $tmp12=$tmp11 . $fnamexx;
        $tmp13=$tmp12 . '<span class="sh-news-con-lie-right-time">';
        $tmp14=$tmp13 . $ftimexx;
        $tmp15=$tmp14 . '</span>';
        $tmp16=$tmp15 . '</p>
        <p id="xxtzidtext-';
        $tmp17=$tmp16 . $xxid;
        $tmp18=$tmp17 . '" class="sh-news-con-lie-right-text" lang="';
        $tmp19=$tmp18 . $titlexx;
        $tmp21=$tmp19 . '">';
        $tmp22=$tmp21 . $textxx;
        $tmp23=$tmp22 . '</p>
        </div>
        <div class="sh-xxliebfm">';
        $tmp24=$tmp23 . $wzfmd;
        $tmp25=$tmp24 . '<div class="delmes" id="';
        $tmp26=$tmp25 . $xxid;
        $tmp27=$tmp26 . '" onclick="demes()">删除</div></div>
        </div>
        ';
        echo $tmp27;
goto L2xxkq;
L2xldMhxkt:
        $tmp2=$msgxx==1;
if($tmp2)goto L2xeWjgxku;
goto L2xxkq;
goto L2xxkq;
goto L2xxkq;
L2xeWjgxku:
        $tmp2='<div id="' . $xxid;
        $tmp3=$tmp2 . '" class="sh-news-con-lie" lang="';
        $tmp4=$tmp3 . $wzssid;
        $tmp5=$tmp4 . '" onclick="mesgxq()">
        <!-- 左 -->
        <div class="sh-news-con-lie-left">
        <p id="xxztx-';
        $tmp6=$tmp5 . $xxid;
        $tmp7=$tmp6 . '" style="display:none"></p>
        <div class="sh-news-con-lie-left-imgt">
        <img src="./assets/img/thumbnail.svg" data-src="';
        $tmp8=$tmp7 . $fimgxx;
        $tmp9=$tmp8 . '" alt="头像" class="sh-news-con-lie-left-img"></div>
        </div>
        <!-- 右 -->
        <div class="sh-news-con-lie-right">
        <p id="xxtzidtitle-';
        $tmp10=$tmp9 . $xxid;
        $tmp11=$tmp10 . '" class="sh-news-con-lie-right-title">';
        $tmp12=$tmp11 . $fnamexx;
        $tmp13=$tmp12 . '<span class="sh-news-con-lie-right-time">';
        $tmp14=$tmp13 . $ftimexx;
        $tmp15=$tmp14 . '</span>';
        $tmp16=$tmp15 . '</p>
        <p id="xxtzidtext-';
        $tmp17=$tmp16 . $xxid;
        $tmp18=$tmp17 . '" class="sh-news-con-lie-right-text" lang="';
        $tmp19=$tmp18 . $titlexx;
        $tmp21=$tmp19 . '">';
        $tmp22=$tmp21 . $textxx;
        $tmp23=$tmp22 . '</p>
        </div>
        <div class="sh-xxliebfm">';
        $tmp24=$tmp23 . $wzfmd;
        $tmp25=$tmp24 . '<div class="delmes" id="';
        $tmp26=$tmp25 . $xxid;
        $tmp27=$tmp26 . '" onclick="demes()">删除</div></div>
        </div>
        ';
        echo $tmp27;
goto L2xxkq;
L2xldMhxkr:
        $obj5=$xxsl;
        $xxsl=$xxsl-1;
L2xxkq:
        $tmp2=$xxsl>199;
if($tmp2)goto L2xxkc;
goto L2xxkb;
goto L2xxkb;
    }
}
L2xldMhxkp:
$obj6=$xxsl;
$xxsl=$xxsl-1;
L2xxkc:
$tmp2='</div>
<!-- 内容 end -->
<!-- 提示 -->
<div class="sh-news-tishi">
<P>共<span id="xxtzsul">' . $xxsl;
$tmp3=$tmp2 . '</span>条消息</P>
</div>
</div>
</div>';
echo $tmp3;
goto L2xxlm;
L2xldMhxln:
L2xxlm:
echo "";
echo "
";
echo "
";
if($lnkzt==0)goto L2xeWjgxmo;
goto L2xldMhxmo;
L2xeWjgxmo:
echo '<div class="sh-link" id="sh-link" onclick="gblink()">
<div class="sh-link-main" id="sh-link-main" onclick="hfljurl()">
<!-- 顶部 -->
<div class="sh-link-main-top">
<div class="sh-news-main-top-xiaoxih"><span>联系人</span></div>
<!--img src="./assets/img/light.svg" alt="" class="sh-link-main-top-img" onclick="gblink()"-->
<div class="sh-news-main-top-div" onclick="gblink()"><i class="iconfont icon-quxiao ri-sxhqx"></i></div>
</div>
<!-- 内容 -->
<div class="sh-link-con">';
$tmp2=include './config.php';
$tmp2=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp2;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$iy=0;
$sqllink="SELECT * FROM link";
$result=$conn->query($sqllink);
$resultlink=$result;
while(true){
    $result=$resultlink->fetch_assoc();
    $rowlink=$result;
    if(!$str)break;
    $obj7=$iy;
    $iy=$iy+1;
    $linkurl=$rowlink['url'];
    $linkurls=$rowlink['urls'];
    $linkurlimg=$rowlink['urlimg'];
    $tmp2='<a href="' . $linkurl;
    $tmp3=$tmp2 . '" class="sh-link-con-lie" target="_blank">
    <!-- 左 -->
    <div class="sh-link-con-lie-left">
    <img src="./assets/img/thumbnail.svg" data-src="';
    $tmp4=$tmp3 . $linkurlimg;
    $tmp5=$tmp4 . '" alt="" class="sh-link-con-lie-left-img">
    </div>
    <!-- 右 -->
    <div class="sh-link-con-lie-right">
    <p class="sh-link-con-lie-right-title">';
    $tmp6=$tmp5 . $linkurls;
    $tmp7=$tmp6 . '</p>
    </div>
    </a>';
    echo $tmp7;
}
L2xxml:
$tmp2='</div>
<!-- 内容 end -->
<!-- 提示 -->
<div class="sh-link-tishi">
<P>共' . $iy;
$tmp3=$tmp2 . '个朋友</P>
</div>
</div>
</div>';
echo $tmp3;
goto L2xxmn;
L2xldMhxmo:
L2xxmn:
echo "";
echo "
";
echo "
";
echo "
";
echo "
";
$tmp2=$rnking==1;
$tmp4=(bool)$tmp2;
if($tmp4){
    $tmp3=$rnkingyc==1;
    $tmp4=(bool)$tmp3;
}
if($tmp4)goto L2xeWjgxnh;
goto L2xldMhxnh;
L2xeWjgxnh:
echo '<div class="sh-link" id="sh-paih" onclick="gbpaih()" style="display: none;">
<div class="sh-link-main" id="sh-link-main" onclick="hfljurl()">
<!-- 顶部 -->
<div class="sh-link-main-top">
<div class="sh-news-main-top-xiaoxih"><span>排行榜</span></div>
<div class="sh-news-main-top-div" onclick="gbpaih()"><i class="iconfont icon-quxiao ri-sxhqx"></i></div>
</div><div class="sh-link-con">';
$str="SELECT * FROM user ORDER BY CAST(wallet AS SIGNED) DESC";
$sql=$str;
$result=$conn->query($sql);
$result=$result;
$im=0;
$tmp2=$result->num_rows>0;
if($tmp2)goto L2xeWjgxmy;
goto L2xldMhxmy;
goto L2xldMhxmy;
L2xeWjgxmy:
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!$str)break;
    $obj8=$im;
    $im=$im+1;
    $tmp2=$im>200;
if($tmp2)goto L2xxmx;
goto L2xldMhxn3;
goto L2xldMhxn3;
goto L2xldMhxn3;
goto L2xxn2;
L2xldMhxn3:
L2xxn2:
    $phwallet=$row["wallet"];
    $phname=$row["name"];
    $phimg=$row["img"];
    $phurl=$row["url"];
    $phsign=$row["sign"];
    $urltk='target="_blank"';
    $tmp2=$phurl=="";
    $tmp4=(bool)$tmp2;
    $tmp5=!$tmp4;
    if($tmp5){
        $tmp3=$phurl==null;
        $tmp4=(bool)$tmp3;
    }
    if($tmp4){
        $phurl="JavaScript:;";
        $urltk='';
    }
    $tmp2='<!-- 内容 -->
    <a href="' . $phurl;
    $tmp3=$tmp2 . '" class="sh-link-con-lie2" ';
    $tmp4=$tmp3 . $urltk;
    $tmp5=$tmp4 . '>
    <!-- 左 -->
    <div class="sh-link-con-lie-left">
    <img src="./assets/img/thumbnail.svg" data-src="';
    $tmp6=$tmp5 . $phimg;
    $tmp7=$tmp6 . '" alt="" class="sh-link-con-lie-left-img">
    </div>
    <!-- 右 -->
    <div class="sh-link-con-lie-right">
    <p class="sh-link-con-lie-right-title sh-link-con-lie-right-title2"><span style="background: var(--protextbg);color: var(--protext);">';
    $tmp8=$tmp7 . $im;
    $tmp9=$tmp8 . '</span>';
    $tmp10=$tmp9 . $phname;
    $tmp11=$tmp10 . '<span class="sh-link-con-lie-right-title-f">';
    $tmp12=$tmp11 . $phwallet;
    $tmp13=$tmp12 . '</span></p>
    <p class="sh-link-con-lie-right-title sh-link-con-lie-right-title3">';
    $tmp14=$tmp13 . $phsign;
    $tmp15=$tmp14 . '</p>
    </div>
    </a>';
    echo $tmp15;
}
goto L2xxmx;
L2xldMhxmy:
L2xxmx:
echo '</div><!-- 内容 end -->
<!-- 提示 -->
<div class="sh-link-tishi">
<p>仅显示前200名</p>
</div>
</div>
</div>';
goto L2xxng;
L2xldMhxnh:
L2xxng:
$result=$conn->close();
echo "";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"footer\">";
echo "
<div class=\"footer-text\" id=\"footer-text-zt\" onclick=\"hqgd()\">加载更多..</div>";
echo "
<p style=\"display:none\" id=\"footer-text-hqgd\">";
echo $wzsl;
echo "</p>";
echo "
</div>";
echo "
";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
if($search=="1"){
    echo '<div class="so" id="so" onclick="gbso()">
    <form class="sobd" method="get" action="./index.php?so=" onclick="hfljurl()">
    <input class="sobd-in" maxlength="50" autocomplete="off" placeholder="请输入关键字.." name="so" value="" type="text" required>
    <button class="sobd-bu" type="submit">搜一搜</button>
    </form>
    </div>';
}
echo "";
echo "
";
echo "
";
echo "
<!--右下角悬浮菜单-->";
echo "
<div class=\"sh-menu\" id=\"sh-menu\">";
echo "
";
if($search=="1"){
    echo '<div class="sh-menu-k" id="scrtop" onclick="kqso()"><i class="iconfont icon-sousuoxiao"></i></div>';
}
if($daymode=="1")goto L2xeWjgxo6;
goto L2xldMhxo6;
L2xeWjgxo6:
$darktheme=$_COOKIE["dark_theme"];
$tmp2=$darktheme=="dark-theme";
if($tmp2)goto L2xeWjgxo4;
goto L2xldMhxo4;
goto L2xldMhxo4;
L2xeWjgxo4:
echo '<div class="sh-menu-k" id="day" lang="0"><i class="iconfont icon-yueliang" id="day-i"></i></div>';
goto L2xxo5;
L2xldMhxo4:
echo '<div class="sh-menu-k" id="day" lang="1"><i class="iconfont icon-ai250" id="day-i"></i></div>';
L2xldMhxo6:
L2xxo5:
if($gotop=="1"){
    echo '<div class="sh-menu-k" id="scrtop" onclick="scrollToTop()"><i class="iconfont icon-weibiaoti-x-copy"></i></div>';
}
echo "</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
$num=5849;
$tmp2=$musplay==0;
if($tmp2){
    $num=80;
}else{
    $tmp2=$musplay==1;
    if($tmp2){
        $num=80;
        $num=11500;
    }
}
switch($num){
    case 5790:{
    $tmp2=include './site/musicbkcla.php';
        break;
    }
    case 80:{
        $tmp2=include './site/musicbk.php';
        break;
    }
}
echo "";
echo "
";
echo "
";
echo auth_ts;
echo "<div class=\"sh-copyright\">";
echo "
<span class=\"sh-copyright-banquan\" id=\"sh-copyright-banquan\">";
echo $copyright;
echo "</span>&nbsp;";
echo "
";
if($beian!=""){
    $row=html_entity_decode($beian);
    $tmp2='<span class="sh-copyright-banquan">' . $row;
    $tmp3=$tmp2 . '</span>';
    echo $tmp3;
}
echo "</div>";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
<script type=\"text/javascript\" src=\"./assets/js/index.js\"></script>";
echo "
<script type=\"text/javascript\" src=\"./assets/js/jquery.min.js\"></script>";
echo "
<script type=\"text/javascript\" src=\"./assets/mesg/dist/js/sh-noytf.js\"></script>";
echo "
<script type=\"text/javascript\" src=\"./assets/js/jquery.fancybox.min.js\"></script>";
echo "
";
$tmp2='<script type="text/javascript">' . $filtercujs;
$tmp3=$tmp2 . '</script>';
echo $tmp3;
echo "    ";
echo "
</body>";
echo "
</html>";function ReckonTime($time) {
    $row=time();
    $NowTime=$row;
    if($time>$NowTime){
        return false;
    }
    $TimePoor=$NowTime-$time;
    $num2=6871;
    $tmp2=$TimePoor==0;
    if($tmp2){
        $num2=247;
    }else{
        $tmp2=$TimePoor<60;
        $tmp4=(bool)$tmp2;
        if($tmp4){
            $tmp3=$TimePoor>0;
            $tmp4=(bool)$tmp3;
        }
        if($tmp4){
            $num2=361;
        }else{
            $tmp2=$TimePoor>=60;
            $tmp5=(bool)$tmp2;
            if($tmp5){
                $tmp3=3600;
                $tmp4=$TimePoor<=3600;
                $tmp5=(bool)$tmp4;
            }
            if($tmp5){
                $num2=38;
            }else{
                $tmp2=3600;
                $tmp3=$TimePoor>3600;
                $tmp6=(bool)$tmp3;
                if($tmp6){
                    $tmp4=86400;
                    $tmp5=$TimePoor<=86400;
                    $tmp6=(bool)$tmp5;
                }
                if($tmp6){
                    $num2=221;
                }else{
                    $tmp2=86400;
                    $tmp3=$TimePoor>86400;
                    $tmp7=(bool)$tmp3;
                    if($tmp7){
                        $tmp4=86400;
                        $tmp5=604800;
                        $tmp6=$TimePoor<=604800;
                        $tmp7=(bool)$tmp6;
                    }
                    if($tmp7){
                        $num2=34;
                    }else{
                        $tmp2=86400;
                        $tmp3=604800;
                        $tmp4=$TimePoor>604800;
                        if($tmp4){
                            $num2=323;
                        }
                    }
                }
            }
        }
    }
    $tmp2=280;
    $tmp3=38;
    $tmp4=$num2==38;
if($tmp4)goto L2xeWjgxpb;
goto L2xldMhxpb;
L2xeWjgxpb:
    $num14=$TimePoor/60;
    $row=floor($num14);
    $str=$row . '分钟前';
goto L2xxpa;
L2xldMhxpb:
    $tmp2=234;
    $tmp3=247;
    $tmp4=$num2==247;
if($tmp4)goto L2xeWjgxpc;
goto L2xldMhxpc;
L2xeWjgxpc:
    $str='一眨眼之间';
goto L2xxpa;
L2xldMhxpc:
    $tmp2=16;
    $tmp3=361;
    $tmp4=$num2==361;
if($tmp4)goto L2xeWjgxpd;
goto L2xldMhxpd;
L2xeWjgxpd:
    $str=$TimePoor . '秒之前';
goto L2xxpa;
L2xldMhxpd:
    $tmp2=105;
    $tmp3=221;
    $tmp4=$num2==221;
if($tmp4)goto L2xeWjgxpe;
goto L2xldMhxpe;
L2xeWjgxpe:
    $num14=$TimePoor/3600;
    $row=floor($num14);
    $str=$row . '小时前';
goto L2xxpa;
L2xldMhxpe:
    $tmp2=380;
    $tmp3=34;
    $tmp4=$num2==34;
if($tmp4)goto L2xeWjgxpf;
goto L2xldMhxpf;
L2xeWjgxpf:
    $num14=86400;
    $str2=$TimePoor/86400;
    $row=floor($str2);
    $tmp4=$row==1;
if($tmp4)goto L2xeWjgxp7;
goto L2xldMhxp7;
goto L2xldMhxp7;
L2xeWjgxp7:
    $str="昨天";
goto L2xxpa;
L2xldMhxp7:
    $num14=86400;
    $str2=$TimePoor/86400;
    $row=floor($str2);
    $tmp4=$row==2;
if($tmp4)goto L2xeWjgxp8;
goto L2xldMhxp8;
goto L2xldMhxp8;
L2xeWjgxp8:
    $str="前天";
goto L2xxpa;
L2xldMhxp8:
    $num14=86400;
    $str2=$TimePoor/86400;
    $row=floor($str2);
    $str=$row . '天前';
L2xldMhxpf:
    switch($num2){
        case 323:{
        $row=date("Y-m-d", $time);
        $str=$row;
            break;
        }
    }
L2xxpa:
    return $str;
}