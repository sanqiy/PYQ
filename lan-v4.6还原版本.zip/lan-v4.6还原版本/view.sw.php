<?php
if($_SERVER['REQUEST_METHOD']==='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$num19=8002;
if(isset($_SERVER['HTTP_REFERER'])){
    $num19=36;
}else{
    $num19=20;
}
$tmp2=228;
$tmp3=36;
$tmp4=$num19==36;
if($tmp4)goto L2xeWjgxd;
goto L2xldMhxd;
L2xeWjgxd:
$previousPage=$_SERVER['HTTP_REFERER'];
$row=strpos($previousPage, "home.php");
$tmp2=$row!==false;
if($tmp2)goto L2xeWjgx8;
goto L2xldMhx8;
goto L2xldMhx8;
L2xeWjgx8:
$tiaourl="./home.php";
goto L2xxc;
L2xldMhx8:
$row=strpos($previousPage, "edit.php");
$tmp2=$row!==false;
if($tmp2)goto L2xeWjgx9;
goto L2xldMhx9;
goto L2xldMhx9;
L2xeWjgx9:
$tiaourl="./home.php";
goto L2xxc;
L2xldMhx9:
$row=strpos($previousPage, "index.php");
$tmp2=$row!==false;
if($tmp2)goto L2xeWjgxa;
goto L2xldMhxa;
goto L2xldMhxa;
L2xeWjgxa:
$tiaourl="./index.php";
goto L2xxc;
L2xldMhxa:
$row=strpos($previousPage, "archives.php");
$tmp2=$row!==false;
if($tmp2)goto L2xeWjgxb;
goto L2xxc;
goto L2xxc;
L2xeWjgxb:
$tiaourl=$previousPage;
goto L2xxc;
L2xldMhxd:
switch($num19){
    case 20:{
    $tiaourl="./index.php";
        break;
    }
}
L2xxc:
$iteace=0;
$num9=8011;
$row=is_file('./config.php');
if($row){
    $num9=324;
}else{
    $num9=40;
}
switch($num9){
    case 324:{
    $tmp2=require './config.php';
        break;
    }
    case 40:{
        exit('未检测到配置文件：<span style="color: red;">config.php</span>，若您是首次使用请先进行安装,删除文件夹 <span style="color: red;">[install/]</span> 下的 <span style="color: red;">[ins.bak]</span> 文件后进行安装。若已删除请<a href="./install/">【点击安装】</a>');
        break;
    }
}
$tmp2=require './api/wz.php';
$num10=8000;
$isArray=is_array($_GET);
if($isArray){
    $num10=36;
}else{
    $num10=324;
}
switch($num10){
    case 36:{
    $cid=&$_GET['cid'];
        break;
    }
    case 324:{
        $cid=$_GET['cid'];
        break;
    }
}
$escaped=htmlspecialchars($cid);
unset($cid);
$escaped2=addslashes($escaped);
$cid=$escaped2;
if($cid==""){
    $tmp2='<script language="JavaScript">;alert("未传入ID!");location.href="' . $tiaourl;
    exit($tmp2 . '";</script>');
}
$tmp2="select * from essay where cid = '" . $cid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
$row=mysqli_num_rows($result);
$tmp2=!$row;
$tmp3=$tmp2>0;
if($tmp3){
    $tmp2='<script language="JavaScript">;alert("该文章不存在或已被删除!");location.href="' . $tiaourl;
    exit($tmp2 . '";</script>;');
}
$str="select * from essay where cid='" . $cid;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data_row=$row;
$num11=8014;
$tmp2=$data_row["ptpys"]==1;
$tmp4=(bool)$tmp2;
if($tmp4){
    $tmp3=$data_row["ptpaud"]==1;
    $tmp4=(bool)$tmp3;
}
$tmp5=(bool)$tmp4;
$tmp6=!$tmp5;
if($tmp6){
    $tmp7=$user_zh==$glyadmin;
    $tmp5=(bool)$tmp7;
}
if($tmp5){
    $num11=90;
}else{
    $num11=100;
}
$tmp2=96;
$tmp3=100;
$tmp4=$num11==100;
if($tmp4)goto L2xeWjgx1j;
goto L2xldMhx1j;
L2xeWjgx1j:
$tmp2=$userdlzt==1;
if($tmp2)goto L2xeWjgx1d;
goto L2xldMhx1d;
goto L2xldMhx1d;
L2xeWjgx1d:
$tmp2="SELECT ptpuser FROM essay WHERE cid = '" . $cid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
$tmp2=$result->num_rows>0;
if($tmp2)goto L2xeWjgx1f;
goto L2xx1i;
goto L2xx1i;
L2xeWjgx1f:
$result=$result->fetch_assoc();
$row=$result;
$ptpuser=$row["ptpuser"];
$tmp2=$ptpuser==$user_zh;
if($tmp2)goto L2xx1i;
goto L2xldMhx1h;
L2xldMhx1h:
$tmp2='<script language="JavaScript">;alert("该文章未通过审核或已被隐藏,暂时不可查看!");location.href="' . $tiaourl;
exit($tmp2 . '";</script>;');
L2xldMhx1d:
$tmp2='<script language="JavaScript">;alert("该文章未通过审核或已被隐藏,暂时不可查看!");location.href="' . $tiaourl;
exit($tmp2 . '";</script>;');
L2xldMhx1j:
$tmp2=22;
$tmp3=90;
$tmp4=$num11==90;
if($tmp4)goto L2xx1i;
L2xx1i:
$num12=8005;
$tmp2=$userdlzt==1;
if($tmp2){
    $num12=4;
}else{
    $num12=25;
}
$tmp2=200;
$tmp3=25;
$tmp4=$num12==25;
if($tmp4)goto L2xeWjgx21;
goto L2xldMhx21;
L2xeWjgx21:
$dewzbs='';
$headrigft1='';
$dewzplz=0;
goto L2xx2z;
L2xldMhx21:
$tmp2=144;
$tmp3=4;
$tmp4=$num12==4;
if($tmp4)goto L2xeWjgx22;
goto L2xldMhx22;
L2xeWjgx22:
$tmp2="SELECT ptpuser FROM essay WHERE cid = '" . $cid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
$tmp2=$result->num_rows>0;
if($tmp2)goto L2xeWjgx1u;
goto L2xldMhx1u;
goto L2xldMhx1u;
L2xeWjgx1u:
$result=$result->fetch_assoc();
$row=$result;
$ptpuser=$row["ptpuser"];
$tmp2=$ptpuser==$user_zh;
if($tmp2)goto L2xeWjgx1w;
goto L2xldMhx1w;
goto L2xldMhx1w;
L2xeWjgx1w:
$tmp2='<i class="iconfont icon-shanchu" id="sh-delewza-' . $cid;
$tmp3=$tmp2 . '" title="点击删除此内容" onclick="delewenz()"></i>';
$dewzbs=$tmp3;
$str3='<div class="sh-main-head-top-right-s" onclick="viewsetk()">
<i class="iconfont icon-gengduo al-sxb" id="top-right-1"></i>
</div>';
$headrigft1=$str3;
$dewzplz=1;
goto L2xx1t;
L2xldMhx1w:
$dewzbs='';
$headrigft1='';
$dewzplz=0;
L2xldMhx1u:
L2xx1t:
$tmp2=$user_zh==$glyadmin;
if($tmp2)goto L2xeWjgx1y;
goto L2xldMhx1y;
goto L2xldMhx1y;
L2xeWjgx1y:
$tmp2='<i class="iconfont icon-shanchu" id="sh-delewza-' . $cid;
$tmp3=$tmp2 . '" title="点击删除此内容" onclick="delewenz()"></i>';
$dewzbs=$tmp3;
$str3='<div class="sh-main-head-top-right-s" onclick="viewsetk()">
<i class="iconfont icon-gengduo al-sxb" id="top-right-1"></i>
</div>';
$headrigft1=$str3;
$dewzplz=1;
$glyszd="terewsq";
goto L2xx2z;
L2xldMhx1y:
$glyszd="";
L2xldMhx22:
L2xx2z:
$result=$conn->close();
echo "<!DOCTYPE html>";
echo "
<html lang=\"zh-CN\">";
echo "
<head>";
echo "
<meta charset=\"UTF-8\">";
echo "
<title>详情 - ";
echo $name;
echo "</title>";
echo "
<!--为搜索引擎定义关键词-->";
echo "
<meta name=\"keywords\" content=\"";
echo $filterkeyw;
echo "\">";
echo "
<!--为网页定义描述内容 用于告诉搜索引擎，你网站的主要内容-->";
echo "
<meta name=\"description\" content=\"";
echo $subtitle;
echo "\">";
echo "
<meta name=\"author\" content=\"";
echo $name;
echo "\">";
echo "
<meta name=\"copyright\" content=\"";
echo $name;
echo "\">";
echo "
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" />";
echo "
<meta http-equiv=\"cache-control\" content=\"no-cache\">";
echo "
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0,minimum-scale=1.0, user-scalable=no minimal-ui\">";
echo "
<link rel=\"apple-touch-icon\" sizes=\"57x57\" href=\"";
echo $icon;
echo "\" /><!-- Standard iPhone -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"114x114\" href=\"";
echo $icon;
echo "\" /><!-- Retina iPhone -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"72x72\" href=\"";
echo $icon;
echo "\" /><!-- Standard iPad -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"144x144\" href=\"";
echo $icon;
echo "\" /><!-- Retina iPad -->";
echo "
<link rel=\"icon\" href=\"";
echo $icon;
echo "\" type=\"image/x-icon\" />";
echo "
<meta name=\"robots\" content=\"index,follow\">";
echo "
<meta name=\"format-detection\" content=\"telephone=no\">";
echo "
<meta http-equiv=\"x-rim-auto-match\" content=\"none\">";
echo "
";
if($rosdomain==1){
    echo '<meta name="referrer" content="no-referrer">';
}
echo "    <link rel=\"stylesheet\" href=\"";
echo $iconurl_url;
echo "\">";
echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"./assets/css/style.css\">";
echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"./assets/mesg/dist/css/style.css\"><!--引入弹窗对话框-->";
echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"./assets/css/jquery.fancybox.min.css\">";
echo "
<style>";
echo "
.sh-zanp{";
echo "
width: auto;";
echo "
margin-left: -55px;";
echo "
}";
echo "
</style>";
echo "
";
echo $scfontzt;
echo "    ";
$folderPath='./user/bobg/';
$row=file_exists($folderPath);
$tmp2=!$row;
if($tmp2){
    $row=mkdir($folderPath, true);
}
$num13=8007;
$row=file_exists("./user/bobg/bobg.jpg");
if($row){
    $num13=90;
}else{
    $row=file_exists("./user/bobg/bobg.png");
    if($row){
        $num13=4;
    }else{
        $row=file_exists("./user/bobg/bobg.jpeg");
        if($row){
            $num13=40;
        }else{
            $row=file_exists("./user/bobg/bobg.gif");
            if($row){
                $num13=40;
                $num13=11796;
            }
        }
    }
}
switch($num13){
    case 5918:{
    echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.gif);}</style>';
        break;
    }
    case 4:{
        echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.png);}</style>';
        break;
    }
    case 90:{
            echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.jpg);}</style>';
        break;
    }
    case 40:{
                echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.jpeg);}</style>';
        break;
    }
}
echo "    ";
$tmp2='<style>' . $filtercucss;
$tmp3=$tmp2 . '</style>';
echo $tmp3;
echo "</head>";
echo "
<body class=\"";
$num14=8010;
if(isset($_COOKIE['dark_theme'])){
    $num14=10;
}else{
    $num14=360;
}
$tmp2=98;
$tmp3=10;
$tmp4=$num14==10;
if($tmp4)goto L2xeWjgx2w;
goto L2xldMhx2w;
L2xeWjgx2w:
$tmp2=$_COOKIE["dark_theme"]=="dark-theme";
if($tmp2)goto L2xeWjgx2u;
goto L2xx2v;
goto L2xx2v;
L2xeWjgx2u:
echo 'dark-theme';
goto L2xx2v;
L2xldMhx2w:
$tmp2=15;
$tmp3=360;
$tmp4=$num14==360;
if($tmp4)goto L2xx2v;
L2xx2v:
echo "\">";
echo "
";
if($pagepass!="")goto L2xeWjgx38;
goto L2xldMhx38;
L2xeWjgx38:
if(isset($_COOKIE['pagepass']))goto L2xeWjgx34;
goto L2xldMhx34;
goto L2xldMhx34;
L2xeWjgx34:
$escaped=md5($pagepass);
$hash=md5($escaped);
$tmp2=$_COOKIE['pagepass']!=$hash;
if($tmp2)goto L2xeWjgx36;
goto L2xx37;
goto L2xx37;
L2xeWjgx36:
$tmp2=include './site/pagepass.php';
goto L2xx37;
L2xldMhx34:
$tmp2=include './site/pagepass.php';
L2xldMhx38:
L2xx37:
echo "    <div class=\"centent\">";
echo "
<div class=\"sh-main\">";
echo "
<div class=\"sh-main-head\">";
echo "
<div class=\"sh-main-head-top\" id=\"sh-main-head-top\">";
echo "
<!-- 左边 -->";
echo "
<div class=\"sh-main-head-top-left\">";
echo "
<div class=\"sh-main-head-top-left-s\" onclick=\"location.href='";
echo $tiaourl;
echo "'\">";
echo "
<i class=\"iconfont icon-weibiaoti al-sxb\" id=\"top-left-1\"></i>";
echo "
</div>";
echo "
<div class=\"sh-view-head-top-left-s\">";
echo "
<span class=\"setup-view-title\" id=\"setup-view-title\">详情</span>";
echo "
</div>";
echo "
</div>";
echo "
<!-- 右边 -->";
echo "
<div class=\"sh-main-head-top-right\">";
echo "
";
echo $headrigft1;
echo "                    </div>";
echo "
</div>";
echo "
";
echo "
";
$num15=8007;
$tmp2=$userdlzt==0;
if($tmp2){
    $num15=50;
}else{
    $num15=100;
}
switch($num15){
    case 50:{
    $wymz=$glyname;
    $wylj='JavaScript:;';
    $wyimg=$glyimg;
    $wyqm=$sign;
    $wyhomeimg=$homimg;
        break;
    }
    case 100:{
        $wymz=$zjnc;
        $wylj='./home.php';
        $wyimg=$zjimg;
        $wyqm=$zjsign;
        $wyhomeimg=$homimg;
        break;
    }
}
echo "";
echo "
<div class=\"sh-main-head-img\"";
echo "
style=\"background-image:url(";
echo $wyhomeimg;
echo ")\">";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
<div class=\"sh-main-head-headimg\">";
echo "
<div class=\"sh-main-head-headimg-tx\">";
echo "
<h4>";
echo $wymz;
echo "</h4>";
echo "
";
echo "
<a href=\"";
echo $wylj;
echo "\"><img src=\"./assets/img/thumbnail.svg\" data-src=\"";
echo $wyimg;
echo "\" alt=\"头像\"></a>";
echo "
</div>";
echo "
<div class=\"sh-main-head-headimg-qm\">";
echo "
<p>";
echo $wyqm;
echo "</p>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div style=\"display:none;position: absolute;top: -100%;\" id=\"pinglunkfk\">";
echo "
<div class=\"sh-pinglunkuang\" id=\"pinglunkuang\">";
echo "
";
echo "
";
echo "
<div class=\"sh-pinglun\" id=\"sh-pinglun\">";
echo "
<!--游客模式-->";
echo "
";
if($userdlzt==0)goto L2xeWjgx3n;
goto L2xldMhx3n;
L2xeWjgx3n:
$tmp2=$viscomm==0;
if($tmp2)goto L2xeWjgx3l;
goto L2xx3m;
goto L2xx3m;
L2xeWjgx3l:
echo '
<div class="sh-plk-yk" id="sh-plk-yk">
<div class="sh-plk-yk-z" style="margin-left: 8px;"><input id="vis_name" type="text" value="" maxlength="10" minlength="1" placeholder="昵称*" autocomplete="off"></div>
<div class="sh-plk-yk-zz"><input id="vis_email" type="text" value="" maxlength="100" minlength="1" placeholder="邮箱*" autocomplete="off"></div>
<div class="sh-plk-yk-z" style="margin-right: 8px;"><input id="vis_url" type="text" value="" maxlength="500" minlength="1" placeholder="网站" autocomplete="off"></div>
</div>
';
goto L2xx3m;
L2xldMhx3n:
L2xx3m:
echo "                        <!-- 输入框 -->";
echo "
<div class=\"sh-pinglun-s\">";
echo "
<textarea name=\"text\" id=\"bletext\" class=\"form-controll\" placeholder=\"评论\" required=\"\" spellcheck=\"false\" maxlength=\"500\" onchange=\"this.value=this.value.substring(0, 500)\" onkeydown=\"this.value=this.value.substring(0, 500)\" onkeyup=\"this.value=this.value.substring(0, 500)\" oninput=\"myjtbl()\"></textarea>";
echo "
</div>";
echo "
<!-- 表情 -->";
echo "
<div class=\"sh-pinglun-biao\" id=\"biaoqing\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E591B5E591B5_2x.png\" alt=\"::(呵呵)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E59388E59388_2x.png\" alt=\"::(哈哈)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E59090E8888C_2x.png\" alt=\"::(吐舌)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5A4AAE5BC80E5BF83_2x.png\" alt=\"::(太开心)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E7AC91E79CBC_2x.png\" alt=\"::(笑眼)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E88AB1E5BF83_2x.png\" alt=\"::(花心)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5B08FE4B996_2x.png\" alt=\"::(小乖)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E4B996_2x.png\" alt=\"::(乖)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E68D82E598B4E7AC91_2x.png\" alt=\"::(捂嘴笑)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6BB91E7A8BD_2x.png\" alt=\"::(滑稽)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E4BDA0E68782E79A84_2x.png\" alt=\"::(你懂的)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E4B88DE9AB98E585B4_2x.png\" alt=\"::(不高兴)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E68092_2x.png\" alt=\"::(怒)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6B197_2x.png\" alt=\"::(汗)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E9BB91E7BABF_2x.png\" alt=\"::(黑线)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6B3AA_2x.png\" alt=\"::(泪)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E79C9FE6A392_2x.png\" alt=\"::(真棒)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E596B7_2x.png\" alt=\"::(喷)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6838AE593AD_2x.png\" alt=\"::(惊哭)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E998B4E999A9_2x.png\" alt=\"::(阴险)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E98499E8A786_2x.png\" alt=\"::(鄙视)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E985B7_2x.png\" alt=\"::(酷)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5958A_2x.png\" alt=\"::(啊)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E78B82E6B197_2x.png\" alt=\"::(狂汗)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/what_2x.png\" alt=\"::(what)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E79691E997AE_2x.png\" alt=\"::(疑问)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E985B8E788BD_2x.png\" alt=\"::(酸爽)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E59180E592A9E788B9_2x.png\" alt=\"::(呀咩蹀)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5A794E5B188_2x.png\" alt=\"::(委屈)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6838AE8AEB6_2x.png\" alt=\"::(惊讶)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E79DA1E8A789_2x.png\" alt=\"::(睡觉)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E7AC91E5B0BF_2x.png\" alt=\"::(笑尿)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E68C96E9BCBB_2x.png\" alt=\"::(挖鼻)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E59090_2x.png\" alt=\"::(吐)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E78A80E588A9_2x.png\" alt=\"::(犀利)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5B08FE7BAA2E884B8_2x.png\" alt=\"::(小红脸)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E68792E5BE97E79086_2x.png\" alt=\"::(懒得理)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E58B89E5BCBA_2x.png\" alt=\"::(勉强)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E788B1E5BF83_2x.png\" alt=\"::(爱心)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5BF83E7A28E_2x.png\" alt=\"::(心碎)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E78EABE791B0_2x.png\" alt=\"::(玫瑰)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E7A4BCE789A9_2x.png\" alt=\"::(礼物)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5BDA9E899B9_2x.png\" alt=\"::(彩虹)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5A4AAE998B3_2x.png\" alt=\"::(太阳)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6989FE6989FE69C88E4BAAE_2x.png\" alt=\"::(星星月亮)\"";
echo "
onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E992B1E5B881_2x.png\" alt=\"::(钱币)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E88CB6E69DAF_2x.png\" alt=\"::(茶杯)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E89B8BE7B395_2x.png\" alt=\"::(蛋糕)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E5A4A7E68B87E68C87_2x.png\" alt=\"::(大拇指)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E8839CE588A9_2x.png\" alt=\"::(胜利)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/haha_2x.png\" alt=\"::(haha)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/OK_2x.png\" alt=\"::(OK)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6B299E58F91_2x.png\" alt=\"::(沙发)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E6898BE7BAB8_2x.png\" alt=\"::手纸\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E9A699E89589_2x.png\" alt=\"::(香蕉)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E4BEBFE4BEBF_2x.png\" alt=\"::(便便)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E88DAFE4B8B8_2x.png\" alt=\"::(药丸)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E7BAA2E9A286E5B7BE_2x.png\" alt=\"::(红领巾)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E89CA1E7839B_2x.png\" alt=\"::(蜡烛)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E99FB3E4B990_2x.png\" alt=\"::(音乐)\" onclick=\"biaoqzj()\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"./assets/owo/paopao/E781AFE6B3A1_2x.png\" alt=\"::(灯泡)\" onclick=\"biaoqzj()\">";
echo "
</div>";
echo "
<!-- 表情 end-->";
echo "
";
echo "
<!-- 表情开关与评论发送 -->";
echo "
<div class=\"sh-pinglun-fs\">";
echo "
<div class=\"sh-pinglun-fs-right\">";
echo "
<!-- 游客开关 -->";
echo "
";
if($userdlzt==0)goto L2xeWjgx3v;
goto L2xldMhx3v;
L2xeWjgx3v:
$tmp2=$viscomm==0;
if($tmp2)goto L2xeWjgx3t;
goto L2xx3u;
goto L2xx3u;
L2xeWjgx3t:
echo '
<div class="sh-pinglun-fs-right-bqimg" id="ykkg" onclick="ykkg()">
<i class="iconfont icon-yonghu1 ri-sxbqxz" id="sh-pinglun-fs-right-ykkgb" title="游客模式"></i>
</div>
';
goto L2xx3u;
L2xldMhx3v:
L2xx3u:
echo "                                <!-- 表情开关 -->";
echo "
<div class=\"sh-pinglun-fs-right-bqimg\" id=\"bqkg\" onclick=\"bqkg()\">";
echo "
<i class=\"iconfont icon-biaoqing ri-sxbqxz\" id=\"sh-pinglun-fs-right-bqimg\"></i>";
echo "
</div>";
echo "
<!-- 发送按钮 -->";
echo "
<div class=\"sh-pinglun-fs-right-fs\" id=\"sh-pinglun-fs-right-fs\" onclick=\"fasongv()\">";
echo "
<span>发送</span>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
</div>";
echo "
<!-- cs -->";
echo "
<div class=\"huifucanshu\">";
echo "
<p id=\"sh-tieid\">-</p>";
echo "
<p id=\"sh-tiehf\">-</p>";
echo "
<p id=\"sh-tieea\">-</p>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"sh-nrbk\" id=\"sh-nrbk\" style=\"width:100%\">";
echo "
";
$tmp2=require './config.php';
$tmp2=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp2;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$str="select * from essay where cid='" . $cid;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$row=$row;
$ptpuser=$row["ptpuser"];
$ptpimg=$row["ptpimg"];
$ptpname=$row["ptpname"];
$ptptext=$row["ptptext"];
$ptpimag=$row["ptpimag"];
$ptpvideo=$row["ptpvideo"];
$ptpmusic=$row["ptpmusic"];
$ptplx=$row["ptplx"];
$ptpdw=$row["ptpdw"];
$ptptime=$row["ptptime"];
$ptpgg=$row["ptpgg"];
$ptpggurl=$row["ptpggurl"];
$ptpys=$row["ptpys"];
$commauth=$row["commauth"];
$ptpaud=$row["ptpaud"];
$ptpip=$row["ip"];
$cid=$row["cid"];
$wid=$row["id"];
$row=explode("|", $ptpvideo);
$partssp=$row;
$ptpvideo=$partssp[0];
$ptpvideofm=$partssp[1];
$row=explode('(+@+)', $ptpimag);
$imgar=$row;
$row=count($imgar);
$coun=$row;
$num16=8007;
$tmp2=$coun==1;
if($tmp2){
    $num16=180;
}else{
    $tmp2=$coun==4;
    $tmp4=(bool)$tmp2;
    $tmp7=!$tmp4;
    if($tmp7){
        $tmp3=$coun==2;
        $tmp4=(bool)$tmp3;
    }
    if($tmp4){
        $num16=100;
    }else{
        $num16=50;
    }
}
switch($num16){
    case 180:{
    $tusty=155;
        break;
    }
    case 100:{
        $tusty=1155;
        break;
    }
    case 50:{
            $tusty=111;
        break;
    }
}
$num17=8016;
$tmp2=$ptpgg==1;
if($tmp2){
    $num17=200;
}else{
    $num17=324;
}
switch($num17){
    case 324:{
    $ggdiv='display: none;';
    $ggurl="";
    $tmp2='<div class="sh-content-right-gps"><a href="javascript:;">' . $ptpdw;
    $gps=$tmp2 . '</a></div>';
        break;
    }
    case 200:{
        $ggdiv='display: flex;';
        $tmp2='<div class="sh-content-right-ggurl"><i class="iconfont icon-lianjie1 ri-sxwzgg"></i><a href="' . $ptpggurl;
        $ggurl=$tmp2 . '" target="_blank">进一步了解</a></div>';
        $gps="";
        break;
    }
}
$row=strtotime($ptptime);
$time=$row;
$row=ReckonTime($time);
$wzfbsj=$row;
echo "                <div class=\"sh-content sh-content2\" id=\"sh-content-";
echo $cid;
echo "\">";
echo "
<!-- 左边 -->";
echo "
<div class=\"sh-content-left\">";
echo "
<!-- 头像 -->";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"";
echo $ptpimg;
echo "\" alt=\"头像\">";
echo "
</div>";
echo "
<!-- 右边 -->";
echo "
<div class=\"sh-content-right\">";
echo "
<!-- 昵称与内容 -->";
echo "
<div class=\"sh-content-right-head\">";
echo "
<!-- 昵称 -->";
echo "
<div class=\"sh-content-right-head-title\">";
echo "
<p>";
echo $ptpname;
echo "</p>";
echo "
<div class=\"sh-content-right-head-title-ad\" style=\"";
echo $ggdiv;
echo "\">";
echo "
<p>广告</p>";
echo "
</div>";
echo "
</div>";
echo "
<!-- 内容 -->";
echo "
";
$str3=preg_replace("/<img[^>]+>/i","",$ptptext);
$contenttext0=$str3;
$str3=preg_replace("/<span[^>]+>/i","",$contenttext0);
$contenttext1=$str3;
$str3=preg_replace("/<a href=[^>]+>/i","",$contenttext1);
$contenttext=$str3;
$row=str_replace(" ", "", $contenttext);
$contenttext=$row;
$num18=8010;
$row=iconv_strlen($contenttext, "UTF-8");
$tmp2=$row>100;
if($tmp2){
    $num18=10;
}else{
    $num18=36;
}
switch($num18){
    case 36:{
    $tmp2='<span>' . $ptptext;
    $ptptext=$tmp2 . '</span>';
        break;
    }
    case 10:{
        $tmp2='<span class="wzndhycyc" id="sh-content-qwdid-' . $cid;
        $tmp3=$tmp2 . '">';
        $tmp4=$tmp3 . $ptptext;
        $tmp7=$tmp4 . '</span><a href="JavaScript:;" class="sh-content-quanwenan" id="sh-content-quanwenan-';
        $tmp5=$tmp7 . $cid;
        $tmp6=$tmp5 . '" lang="0" onclick="quanwenan()">全文</a>';
        $ptptext=$tmp6;
        break;
    }
}
echo $ptptext;
echo "                        <!--span><!--?php echo \$ptptext;</span--><!-- 图片 -->";
echo "
";
$num=8009;
$tmp2=$ptplx=="only";
if($tmp2){
    $num=200;
}else{
    $tmp2=$ptplx=="img";
    if($tmp2){
        $num=36;
    }else{
        $tmp2=$ptplx=="video";
        if($tmp2){
            $num=100;
        }else{
            $tmp2=$ptplx=="music";
            if($tmp2){
                $num=100;
                $num=8226;
            }else{
                $tmp2=$ptplx=="mony";
                if($tmp2){
                    $num=200;
                    $num=10682;
                }
            }
        }
    }
}
$tmp2=30;
$tmp3=5441;
$tmp4=$num==5441;
if($tmp4)goto L2xeWjgx6f;
goto L2xldMhx6f;
L2xeWjgx6f:
$tmp2="SELECT * FROM money WHERE ptpmoncid = '" . $cid;
$sql01=$tmp2 . "'";
$result=$conn->query($sql01);
$result01=$result;
$tmp2=$result01->num_rows>0;
if($tmp2)goto L2xeWjgx5j;
goto L2xx6e;
goto L2xx6e;
L2xeWjgx5j:
while(true){
    $result=$result01->fetch_assoc();
    $row01=$result;
    if(!$str3)break;
    $muser=$row01["muser"];
    $type=$row01["type"];
    $zsum=$row01["zsum"];
    $sum=$row01["sum"];
    $total=$row01["total"];
    $recve=$row01["recve"];
    $luser=$row01["luser"];
    $montext=$row01["montext"];
    $monimg=$row01["monimg"];
    $ptpmoncid=$row01["ptpmoncid"];
}
L2xx5m:
$tmp2=$monimg=="";
if($tmp2){
    $monimg='';
}else{
    $tmp2='background-image: url(' . $monimg;
    $monimg=$tmp2 . ');';
}
$tmp2=$recve<1;
$tmp4=(bool)$tmp2;
$tmp7=!$tmp4;
if($tmp7){
    $tmp3=$sum<0.01;
    $tmp4=(bool)$tmp3;
}
if($tmp4){
    $hongbtm="opacity: 0.6;";
    $str3='onclick="monyk()"';
    $hongbshij=$str3;
    $ptpmoncid='';
}else{
    $hongbtm="";
    $str3='onclick="monyk()"';
    $hongbshij=$str3;
}
$row=explode(PHP_EOL, $luser);
$lines=$row;
unset($tmp);
foreach($lines as $line){$tmp[]=$line;
}
$tmp8=0;
while(true){
    $row=count($tmp);
    $tmp2=$tmp8<$row;
    if(!$tmp2)break;
    $keys=array_keys($tmp);
    $keys=$keys[$tmp8];
    $line=$tmp[$keys];
    $row=explode("|", $line);
    $parts=$row;
    $before_pipe=$parts[0];
    $after_pipe=$parts[1];
    $tmp2=$before_pipe==$user_zh;
    if($tmp2){
        $hongbtm="opacity: 0.6;";
        $str3='onclick="monyk()"';
        $hongbshij=$str3;
        $ptpmoncid=-1;
    }
    $tmp8=$tmp8+1;
}
L2xx62:
$tmp2=$zjzhq=="";
$tmp4=(bool)$tmp2;
$tmp7=!$tmp4;
if($tmp7){
    $tmp3=$passid=="";
    $tmp4=(bool)$tmp3;
}
if($tmp4)goto L2xeWjgx69;
goto L2xldMhx69;
goto L2xldMhx69;
L2xeWjgx69:
$tmp2=$recve<1;
$tmp4=(bool)$tmp2;
$tmp7=!$tmp4;
if($tmp7){
    $tmp3=$sum<0.01;
    $tmp4=(bool)$tmp3;
}
if($tmp4)goto L2xeWjgx6d;
goto L2xldMhx6d;
goto L2xldMhx6d;
L2xeWjgx6d:
$hongbtm="opacity: 0.6;";
$str3='onclick="monyk()"';
$hongbshij=$str3;
$ptpmoncid=-1;
goto L2xx66;
L2xldMhx6d:
$hongbtm="";
$str3='onclick="monyk()"';
$hongbshij=$str3;
$ptpmoncid=-1;
L2xldMhx69:
L2xx66:
$tmp2='<div id="sh-redpacket-content" class="sh-redpacket-content" style="' . $hongbtm;
$tmp3=$tmp2 . '">
<div class="sh-redpacket-content-space">
<div class="sh-space-up">
<!-- 上部分圆角框架 背景-->
<div class="sh-space-up-space" style="';
$tmp4=$tmp3 . $monimg;
$tmp7=$tmp4 . '">
<div class="sh-space-up-space-logo"><img src="./assets/img/logogolden.svg" data-src="./assets/img/logogolden.svg"></div>
<div class="sh-space-up-space-title"><span>';
$tmp5=$tmp7 . $montext;
$tmp6=$tmp5 . '</span></div>
</div>
</div>
<div class="sh-space-dw">
<div class="sh-space-dw-btnk"><span class="sh-space-dw-btn" id="sh-space-dw-btn-';
$tmp9=$tmp6 . $cid;
$tmp10=$tmp9 . '" lang="';
$tmp11=$tmp10 . $ptpmoncid;
$tmp12=$tmp11 . '" ';
$tmp13=$tmp12 . $hongbshij;
$tmp14=$tmp13 . '>领</span></div>
</div>
</div>
</div>';
echo $tmp14;
goto L2xx6e;
L2xldMhx6f:
$tmp2=3;
$tmp3=4163;
$tmp4=$num==4163;
if($tmp4)goto L2xeWjgx73;
goto L2xldMhx73;
L2xeWjgx73:
echo '<!-- 音乐 -->';
$row=is_numeric($ptpmusic);
if($row)goto L2xx6e;
goto L2xldMhx5g;
L2xldMhx5g:
$row=explode('|', $ptpmusic);
$mus=$row;
$tmp2=include "./site/musicplay.php";
L2xldMhx73:
$tmp2=156;
$tmp3=200;
$tmp4=$num==200;
if($tmp4)goto L2xeWjgx76;
goto L2xldMhx76;
L2xeWjgx76:
echo '<!-- 图片 -->';
goto L2xx6e;
L2xldMhx76:
$tmp2=126;
$tmp3=36;
$tmp4=$num==36;
if($tmp4)goto L2xeWjgx77;
goto L2xldMhx77;
L2xeWjgx77:
$tmp2=$coun>"1";
if($tmp2){
    $picimg=100;
}else{
    $picimg='';
}
$tmp2='<!-- 图片 -->
<div class="sh-content-right-img" id="imglib-' . $cid;
$tmp3=$tmp2 . '" style="';
$tmp4=$tmp3 . $tusty;
$tmp7=$tmp4 . '">';
echo $tmp7;
$str3=0;
$i=$str3;
while(true){
    $tmp2=$i<$coun;
    if(!$tmp2)break;
    $tuimg=$imgar[$i];
    $tmp2=$i>7;
if($tmp2)goto L2xeWjgx4v;
goto L2xldMhx4v;
goto L2xldMhx4v;
goto L2xldMhx4v;
L2xeWjgx4v:
    $tmp2=$coun-$i;
    $duoimg=$tmp2-1;
    $tmp2=$coun>9;
if($tmp2)goto L2xeWjgx4x;
goto L2xldMhx4x;
goto L2xldMhx4x;
goto L2xldMhx4x;
L2xeWjgx4x:
    $tmp2=$i==8;
if($tmp2)goto L2xeWjgx5z;
goto L2xldMhx5z;
goto L2xldMhx5z;
goto L2xldMhx5z;
L2xeWjgx5z:
    $tmp2='<a href="' . $tuimg;
    $tmp3=$tmp2 . '" class="sh-content-right-img-pic" data-fancybox="gallery';
    $tmp4=$tmp3 . $cid;
    $tmp7=$tmp4 . '" data-caption="">
    <span class="sh-content-right-img-pic-mask">+';
    $tmp5=$tmp7 . $duoimg;
    $tmp6=$tmp5 . '</span>
    <img src="./assets/img/thumbnail.svg" data-src="';
    $tmp9=$tmp6 . $tuimg;
    $tmp10=$tmp9 . '" alt="" ';
    $tmp11=$tmp10 . $picimg;
    $tmp12=$tmp11 . '>
    </a>';
    echo $tmp12;
goto L2xx4u;
L2xldMhx5z:
    $tmp2='<a href="' . $tuimg;
    $tmp3=$tmp2 . '" class="sh-content-right-img-pic" data-fancybox="gallery';
    $tmp4=$tmp3 . $cid;
    $tmp7=$tmp4 . '" data-caption=""  style="display:none;">
    <img src="';
    $tmp5=$tmp7 . $tuimg;
    $tmp6=$tmp5 . '" data-src="';
    $tmp9=$tmp6 . $tuimg;
    $tmp10=$tmp9 . '" alt="" ';
    $tmp11=$tmp10 . $picimg;
    $tmp12=$tmp11 . '>
    </a>';
    echo $tmp12;
L2xldMhx4x:
    $tmp2='<a href="' . $tuimg;
    $tmp3=$tmp2 . '" class="sh-content-right-img-pic" data-fancybox="gallery';
    $tmp4=$tmp3 . $cid;
    $tmp7=$tmp4 . '" data-caption="">
    <img src="./assets/img/thumbnail.svg" data-src="';
    $tmp5=$tmp7 . $tuimg;
    $tmp6=$tmp5 . '" alt="" ';
    $tmp9=$tmp6 . $picimg;
    $tmp10=$tmp9 . '>
    </a>';
    echo $tmp10;
L2xldMhx4v:
    $tmp2='<a href="' . $tuimg;
    $tmp3=$tmp2 . '" class="sh-content-right-img-pic" data-fancybox="gallery';
    $tmp4=$tmp3 . $cid;
    $tmp7=$tmp4 . '" data-caption="">
    <img src="./assets/img/thumbnail.svg" data-src="';
    $tmp5=$tmp7 . $tuimg;
    $tmp6=$tmp5 . '" alt="" ';
    $tmp9=$tmp6 . $picimg;
    $tmp10=$tmp9 . '>
    </a>';
    echo $tmp10;
L2xx4u:
    $obj=$i;
    $obj2=$i+1;
    $str3=$obj2;
    $i=$str3;
}
L2xx51:
echo '</div>';
goto L2xx6e;
L2xldMhx77:
switch($num){
    case 100:{
    $tmp2=$videoauplay==1;
    if($tmp2){
        $videobf='autoplay';
        $videobfplas='';
    }else{
        $videobf='';
        $tmp2='<i class="iconfont icon-sa4f56" id="sh-content-video-videobfb-' . $cid;
        $tmp3=$tmp2 . '" style="width: fit-content;height: fit-content;grid-column: 1;grid-row: 1;z-index: 5;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);font-size: 40px;color: #ffffff;display: flex;cursor: pointer;padding: 15px;pointer-events: none;"></i>';
        $videobfplas=$tmp3;
    }
    $tmp2=$filterpiccir==1;
    if($tmp2){
        $vidoyuan=1;
    }else{
        $vidoyuan=0;
    }
    $tmp2='
    <!-- 视频 -->
    <div class="sh-video" id="sh-content-video-' . $cid;
    $tmp3=$tmp2 . '" onclick="videofdgb()" lang="0">
    <video name="sh-videokid" class="sh-content-video" data-ybs="';
    $tmp4=$tmp3 . $vidoyuan;
    $tmp7=$tmp4 . '" poster="';
    $tmp5=$tmp7 . $ptpvideofm;
    $tmp6=$tmp5 . '" id="sh-content-videok-';
    $tmp9=$tmp6 . $cid;
    $tmp10=$tmp9 . '" src="';
    $tmp11=$tmp10 . $ptpvideo;
    $tmp12=$tmp11 . '" playsinline webkit-playsinline preload="metadata" ';
    $tmp13=$tmp12 . $videobf;
    $tmp14=$tmp13 . ' muted loop onclick="videofd()" lang="0" disablePictureInPicture="true" controlslist="nodownload nofullscreen noremoteplayback"></video>
    ';
    $tmp15=$tmp14 . $videobfplas;
    $tmp16=$tmp15 . '
    <i class="iconfont icon-quxiao" id="sh-content-videog-';
    $tmp17=$tmp16 . $cid;
    $tmp18=$tmp17 . '" lang="0"></i>
    <span class="sh-video-span" id="sh-video-span-';
    $tmp19=$tmp18 . $cid;
    $tmp20=$tmp19 . '">MP4</span>
    </div>
    ';
    echo $tmp20;
        break;
    }
}
L2xx6e:
echo "                    </div>";
echo "
<!-- 地址 -->";
echo "
";
if($ptpdw!=""){
    echo $gps;
}
echo "                    <!--广告-->";
echo "
";
echo $ggurl;
echo "";
echo "
";
$tmp2="select * from lcke where lwz= '" . $cid;
$sql2b=$tmp2 . "'";
$row=mysqli_query($conn, $sql2b);
$result2b=$row;
$num2=8017;
$row=mysqli_num_rows($result2b);
$tmp2=$row>0;
if($tmp2){
    $num2=100;
}else{
    $num2=40;
}
$tmp2=342;
$tmp3=100;
$tmp4=$num2==100;
if($tmp4)goto L2xeWjgx8r;
goto L2xldMhx8r;
L2xeWjgx8r:
$sql2a="SELECT * FROM lcke";
$result=$conn->query($sql2a);
$result2a=$result;
while(true){
    while(true){
        $result=$result2a->fetch_assoc();
        $row2a=$result;
        if(!$str3)break;
        $tmp2=$row2a['lwz']==$cid;
        if(!$tmp2)break;
        $dianzmlnr=$row2a['luser'];
        $tmp2=$user_zh=="";
        $tmp4=(bool)$tmp2;
        $tmp12=!$tmp4;
        if($tmp12){
            $tmp3=$user_name=="";
            $tmp4=(bool)$tmp3;
        }
        $tmp5=(bool)$tmp4;
        $tmp11=!$tmp5;
        if($tmp11){
            $tmp7=$user_img=="";
            $tmp5=(bool)$tmp7;
        }
        $tmp9=(bool)$tmp5;
        $tmp10=!$tmp9;
        if($tmp10){
            $tmp6=$user_passid=="";
            $tmp9=(bool)$tmp6;
        }
if($tmp9)goto L2xeWjgx85;
goto L2xldMhx85;
goto L2xldMhx85;
goto L2xldMhx85;
L2xeWjgx85:
        $tmp2=$dianzmlnr==$_SESSION['visykmz_userip'];
if($tmp2)goto L2xeWjgx87;
goto L2xldMhx87;
goto L2xldMhx87;
goto L2xldMhx87;
L2xeWjgx87:
        $dianzmlnr="取消";
        $dianzmlimg="iconfont icon-aixin2 ri-sxdzlikehs";
goto L2xx7u;
    }
L2xldMhx87:
    $dianzmlnr="赞";
    $dianzmlimg="iconfont icon-aixin ri-sxdzlike";
L2xldMhx85:
    $tmp2=$dianzmlnr==$user_zh;
if($tmp2)goto L2xeWjgx89;
goto L2xldMhx89;
goto L2xldMhx89;
goto L2xldMhx89;
L2xeWjgx89:
    $dianzmlnr="取消";
    $dianzmlimg="iconfont icon-aixin2 ri-sxdzlikehs";
goto L2xx7u;
}
L2xldMhx89:
$dianzmlnr="赞";
$dianzmlimg="iconfont icon-aixin ri-sxdzlike";
L2xx7u:
$dzzha="display:flex";
goto L2xx8q;
L2xldMhx8r:
switch($num2){
    case 40:{
    $dianzmlnr="赞";
    $dianzmlimg="iconfont icon-aixin ri-sxdzlike";
    $dzzha="display:none";
        break;
    }
}
L2xx8q:
$num3=8005;
$tmp2=$commauth==1;
if($tmp2){
    $num3=90;
}else{
    $num3=36;
}
switch($num3){
    case 90:{
    $tmp2='
    <div class="sh-content-right-time-right-left-y" id="' . $cid;
    $tmp3=$tmp2 . '" onclick="plkkg()">
    <i class="iconfont icon-pinglun2 ri-sxdzcomm"></i>
    <span>评论</span>
    </div>
    ';
    $gwzkplzt=$tmp3;
        break;
    }
    case 36:{
        $tmp2='
        <div class="sh-content-right-time-right-left-y" id="' . $cid;
        $tmp3=$tmp2 . '">
        <i class="iconfont icon-pinglun2 ri-sxdzcomm"></i>
        <span>评论关闭</span>
        </div>';
        $num20=36;
        $gwzkplzt=36;
        break;
    }
}
$tmp2='
<!-- 时间与点赞 -->
<div class="sh-content-right-time">
<!-- 时间 -->
<div class="sh-content-right-time-left"><span>' . $wzfbsj;
$tmp3=$tmp2 . '</span>';
$tmp4=$tmp3 . $dewzbs;
$tmp7=$tmp4 . '</div>
<!-- 点赞 -->
<div class="sh-content-right-time-right">
<!-- 左边合集 -->
<div class="sh-content-right-time-right-left" id="pl-';
$tmp5=$tmp7 . $cid;
$tmp6=$tmp5 . '" name="pl">
<div class="sh-content-right-time-right-left-z" onclick="dinazanv()">
<i class="';
$tmp9=$tmp6 . $dianzmlimg;
$tmp10=$tmp9 . '" id="tiezimg-';
$tmp11=$tmp10 . $cid;
$tmp12=$tmp11 . '"></i>
<span id="tiezdz-';
$tmp13=$tmp12 . $cid;
$tmp14=$tmp13 . '">';
$tmp15=$tmp14 . $dianzmlnr;
$tmp16=$tmp15 . '</span>
</div>
<p></p>
';
$tmp17=$tmp16 . $gwzkplzt;
$tmp18=$tmp17 . '
</div>
<!-- 右边点赞控制按钮 -->
<div class="sh-content-right-time-right-right" id="';
$tmp19=$tmp18 . $cid;
$tmp20=$tmp19 . '" onclick="plk()">
<p class="zp1"></p>
<p></p>
</div>
</div>
</div>
<!-- 点赞列表与评论 -->
<div class="sh-zanp" id="zanss-';
$tmp21=$tmp20 . $cid;
$tmp22=$tmp21 . '">';
echo $tmp22;
echo "";
echo "
";
echo "
";
echo "
";
echo "
";
$tmp2='
<!-- 点赞列表 -->
<div class="sh-zanp-zan zan2" id="zans-' . $cid;
$tmp3=$tmp2 . '" style="';
$tmp4=$tmp3 . $dzzha;
$tmp7=$tmp4 . '">
<!-- 左侧点赞图标 -->
<div class="sh-zanp-zan-left sh-zanp-zan-left2"><i class="iconfont icon-aixin ri-sxwzlike"></i></div>
<!-- 右边点赞名列表 -->
<ul class="sh-zanp-zan-right sh-zanp-zan-right2" id="sh-zanp-ul">
';
echo $tmp7;
$tmp2="select * from lcke where lwz= '" . $cid;
$sql2=$tmp2 . "'";
$row=mysqli_query($conn, $sql2);
$result2=$row;
$vissul=0;
$num4=8018;
$row=mysqli_num_rows($result2);
$tmp2=$row>0;
if($tmp2){
    $num4=25;
}else{
    $num4=90;
}
$tmp2=4;
$tmp3=90;
$tmp4=$num4==90;
if($tmp4)goto L2xeWjgx9w;
goto L2xldMhx9w;
L2xeWjgx9w:
echo '</ul></div>';
goto L2xx9v;
L2xldMhx9w:
$tmp2=195;
$tmp3=25;
$tmp4=$num4==25;
if($tmp4)goto L2xeWjgx9x;
goto L2xldMhx9x;
L2xeWjgx9x:
while(true){
    $row=mysqli_fetch_assoc($result2);
    $row2=$row;
    if(!$str3)break;
    $dzzzh=$row2["luser"];
    $str="select * from user where username='" . $dzzzh;
    $str2=$str . "'";
    $row=mysqli_query($conn, $str2);
    $data_result=$row;
    $row=mysqli_fetch_array($data_result);
    $data_row=$row;
    $zhtximg=$data_row["img"];
    $dzdzh=$data_row["username"];
    $tmp2=$zhtximg=="";
    if($tmp2){
        $zhtximg="./assets/img/tx.png";
    }
    $tmp2=$dzdzh!="";
if($tmp2)goto L2xeWjgx9m;
goto L2xldMhx9m;
goto L2xldMhx9m;
goto L2xldMhx9m;
L2xeWjgx9m:
    $tmp2='<li id="zan-' . $dzdzh;
    $tmp3=$tmp2 . '">
    <img src="./assets/img/thumbnail.svg" data-src="';
    $tmp4=25 . $zhtximg;
    $tmp7=$tmp4 . '" alt="头像">
    </li>';
    echo $tmp7;
}
L2xldMhx9m:
$obj2=$vissul;
$vissul=$vissul+1;
$tmp2=$vissul!="0";
if($tmp2){
    $tmp2='<li id="fkzan-zan" style="width: fit-content;height: 30px;margin-right: 5px;margin-bottom: 5px;display: flex;align-items: center;"><span style="font-size: 12px;color: var(--adgg);max-width: 100px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">' . $vissul;
    $tmp3=$tmp2 . '位访客</span></li>';
    echo $tmp3;
}
echo '</ul></div>';
goto L2xx9v;
L2xldMhx9x:
L2xx9v:
echo "                    ";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
$tmp2="select * from comm where wzcid= '" . $cid;
$sql3=$tmp2 . "' and comaud<>'0' and comaud<>'-1'";
$row=mysqli_query($conn, $sql3);
$result3=$row;
$num5=8004;
$row=mysqli_num_rows($result3);
$tmp2=$row>0;
if($tmp2){
    $num5=90;
}else{
    $num5=400;
}
$tmp2=96;
$tmp3=400;
$tmp4=$num5==400;
if($tmp4)goto L2xeWjgxb3;
goto L2xldMhxb3;
L2xeWjgxb3:
$plgd="display:none";
$tmp2='
<!-- 评论列表 -->
<div class="sh-dz-z" style="display:none;" id="sh-dz-z-' . $cid;
$tmp3=$tmp2 . '">
<!-- 左侧评论图标 -->
<div class="sh-zanp-zan-left sh-zanp-zan-left2"><i class="iconfont icon-pinglun2 ri-sxdzcommls"></i></div>
<ul class="sh-zanp-pl sh-zanp-pl2 sh-zanp-pl3" id="sh-zanp-pl-';
$tmp4=400 . $cid;
$tmp7=$tmp4 . '" style="display:none;">
</ul>
</div>';
echo $tmp7;
goto L2xxb2;
L2xldMhxb3:
$tmp2=126;
$tmp3=90;
$tmp4=$num5==90;
if($tmp4)goto L2xeWjgxb4;
goto L2xldMhxb4;
L2xeWjgxb4:
$tmp2='
<!-- 评论列表 -->
<div class="sh-dz-z" id="sh-dz-z-' . $cid;
$tmp3=$tmp2 . '">
<!-- 左侧评论图标 -->
<div class="sh-zanp-zan-left sh-zanp-zan-left2"><i class="iconfont icon-pinglun2 ri-sxdzcommls"></i></div>
<ul class="sh-zanp-pl sh-zanp-pl2 sh-zanp-pl3" id="sh-zanp-pl-';
$tmp4=90 . $cid;
$tmp7=$tmp4 . '">
';
echo $tmp7;
while(true){
    $row=mysqli_fetch_assoc($result3);
    $row3=$row;
    if(!$str3)break;
    $couser=$row3["couser"];
    $coname=$row3["coname"];
    $coecid=$row3["ecid"];
    $coimg=$row3["coimg"];
    $courl=$row3["courl"];
    $cotext=$row3["cotext"];
    $cotime=$row3["cotime"];
    $bcouser=$row3["bcouser"];
    $bconame=$row3["bconame"];
    $row=strtotime($cotime);
    $timee=$row;
    $row=ReckonTime($timee);
    $cotime=$row;
    $comaud=$row3["comaud"];
    $tmp2=$comaud!=1;
    if($tmp2){
        $cotext="该条评论未通过审核!";
    }
    $tmp2=$dewzplz=="1";
    if($tmp2){
        $tmp2='<a href="JavaScript:;" class="sh-zanp-pl-del" onclick="pldels(this)" id="' . $coecid;
        $tmp3=$tmp2 . '" lang="yswid-';
        $tmp4=$tmp3 . $cid;
        $dewzpl=$tmp4 . '">删除</a>';
    }else{
        $dewzpl='';
    }
    $tmp2=$courl=="";
    if($tmp2){
        $plzwze='';
    }else{
        $tmp2='href="' . $courl;
        $plzwze=$tmp2 . '" style="pointer-events: all;"';
    }
    $tmp2=$commauth==1;
    if($tmp2){
        $str3='onclick="plhuifu()"';
        $pldjhf=$str3;
    }else{
        $pldjhf='';
    }
    $tmp2=$bcouser=="false";
    $tmp4=(bool)$tmp2;
    $tmp7=!$tmp4;
    if($tmp7){
        $tmp3=$bconame=="false";
        $tmp4=(bool)$tmp3;
    }
if($tmp4)goto L2xeWjgxam;
goto L2xldMhxam;
goto L2xldMhxam;
goto L2xldMhxam;
L2xeWjgxam:
    $tmp2='
    <li lang="' . $coname;
    $tmp3=$tmp2 . '" ';
    $tmp4=$tmp3 . $pldjhf;
    $tmp7=$tmp4 . ' id="';
    $tmp5=$tmp7 . $cid;
    $tmp6=$tmp5 . '" value="';
    $tmp9=$tmp6 . $couser;
    $tmp10=$tmp9 . '" data-comkzt="0">
    <div class="sh-zanp-pl-tx"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp11=$tmp10 . $coimg;
    $tmp12=$tmp11 . '" alt="头像"></div>
    <div class="sh-zanp-pl-n sh-zanp-pl-n2">
    <div class="sh-zanp-pl-n-mz"><a ';
    $tmp13=$tmp12 . $plzwze;
    $tmp14=$tmp13 . ' class="sh-zanp-pl-n-nc" onclick="hfljurl()" target="_blank">';
    $tmp15=$tmp14 . $coname;
    $tmp16=$tmp15 . '</a> <span>· ';
    $tmp17=$tmp16 . $cotime;
    $tmp18=$tmp17 . '</span></div>
    <span class="sh-zanp-pl-n-nr">';
    $tmp19=$tmp18 . $cotext;
    $tmp20=$tmp19 . '</span>
    </div>
    ';
    $tmp21=$tmp20 . $dewzpl;
    $tmp22=$tmp21 . '
    </li>';
    echo $tmp22;
}
L2xldMhxam:
$tmp2='
<li lang="' . $coname;
$tmp3=$tmp2 . '" ';
$tmp4=$tmp3 . $pldjhf;
$tmp7=$tmp4 . ' id="';
$tmp5=$tmp7 . $cid;
$tmp6=$tmp5 . '" value="';
$tmp9=$tmp6 . $couser;
$tmp10=$tmp9 . '" data-comkzt="0">
<div class="sh-zanp-pl-tx"><img src="./assets/img/thumbnail.svg" data-src="';
$tmp11=$tmp10 . $coimg;
$tmp12=$tmp11 . '" alt="头像"></div>
<div class="sh-zanp-pl-n sh-zanp-pl-n2">
<div class="sh-zanp-pl-n-mz"><a ';
$tmp13=$tmp12 . $plzwze;
$tmp14=$tmp13 . ' class="sh-zanp-pl-n-nc" onclick="hfljurl()" target="_blank">';
$tmp15=$tmp14 . $coname;
$tmp16=$tmp15 . '</a> <span>· ';
$tmp17=$tmp16 . $cotime;
$tmp18=$tmp17 . '</span></div>
<span>回复</span>
<span class="sh-zanp-pl-n-nc">';
$tmp19=$tmp18 . $bconame;
$tmp20=$tmp19 . '</span>：
<span class="sh-zanp-pl-n-nr">';
$tmp21=$tmp20 . $cotext;
$tmp22=$tmp21 . '</span>
</div>
';
$tmp23=$tmp22 . $dewzpl;
$tmp24=$tmp23 . '
</li>';
echo $tmp24;
echo '</ul></div>';
goto L2xxb2;
L2xldMhxb4:
L2xxb2:
echo "";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<!-- 设置弹窗层-->";
echo "
";
if($userdlzt==1)goto L2xeWjgxcz;
goto L2xldMhxcz;
L2xeWjgxcz:
$tmp2="SELECT ptpuser FROM essay WHERE cid = '" . $cid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
$tmp2=$result->num_rows>0;
if($tmp2)goto L2xeWjgxbm;
goto L2xldMhxbm;
goto L2xldMhxbm;
L2xeWjgxbm:
$result=$result->fetch_assoc();
$row=$result;
$ptpuser=$row["ptpuser"];
$tmp2=$ptpuser==$user_zh;
if($tmp2)goto L2xeWjgxbo;
goto L2xldMhxbo;
goto L2xldMhxbo;
L2xeWjgxbo:
$xstcbs=1;
goto L2xxbl;
L2xldMhxbo:
$tmp2=$user_zh==$glyadmin;
if($tmp2)goto L2xeWjgxbp;
goto L2xldMhxbp;
goto L2xldMhxbp;
L2xeWjgxbp:
$xstcbs=1;
goto L2xxbl;
L2xldMhxbp:
$xstcbs=0;
L2xldMhxbm:
L2xxbl:
$tmp2=$xstcbs==1;
if($tmp2)goto L2xeWjgxbr;
goto L2xxby;
goto L2xxby;
L2xeWjgxbr:
echo '<div class="sh-view-set" id="sh-view-set">
<div class="sh-view-set-wk" id="sh-view-set-wk" onclick="viewsetg()">
<div class="sh-view-set-wk-con" id="sh-view-set-wk-con">';
$row=explode(PHP_EOL, $topes);
$arsj=$row;
$row=in_array($wid, $arsj);
if($row){
    $tmp2='<div class="sh-view-set-wk-con-title" style="margin-bottom: 1px;" id="sh-wzzdyqx-' . $wid;
    $tmp3=$tmp2 . '" lang="qx" onclick="wzszd()">
    <span>取消置顶</span>
    </div>';
    echo $tmp3;
}else{
    $tmp2='<div class="sh-view-set-wk-con-title" style="margin-bottom: 1px;" id="sh-wzzdyqx-' . $wid;
    $tmp3=$tmp2 . '" lang="sw" onclick="wzszd()">
    <span>置顶</span>
    </div>';
    echo $tmp3;
}
$tmp2=$xstcbs==1;
if($tmp2){
    $tmp2='<div class="sh-view-set-wk-con-title" style="margin-bottom: 1px;" id="sh-wzzdyqx-' . $wid;
    $tmp3=$tmp2 . '" lang="qx" onclick="location.href=\'./edit.php?cid=';
    $tmp4=$tmp3 . $cid;
    $tmp7=$tmp4 . '\'">
    <span>编辑</span>
    </div>';
    echo $tmp7;
}
$tmp2=$ptpys==1;
if($tmp2){
    $tmp2='<div class="sh-view-set-wk-con-title" id="sh-wzdsdzt-' . $cid;
    $tmp3=$tmp2 . '" lang="1" onclick="wzsdyj()">
    <span>设为私密</span>
    </div>';
    echo $tmp3;
}else{
    $tmp2='<div class="sh-view-set-wk-con-title" id="sh-wzdsdzt-' . $cid;
    $tmp3=$tmp2 . '" lang="0" onclick="wzsdyj()">
    <span>取消私密</span>
    </div>';
    echo $tmp3;
}
echo '<div class="sh-view-set-wk-con-title" style="margin-top: 5px;padding-bottom: 10px;" onclick="viewsetg()">
<span>取消</span>
</div>
</div>
</div>
</div>';
goto L2xxby;
L2xldMhxcz:
L2xxby:
echo "";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"sh-menu\" id=\"sh-menu\">";
echo "
";
$darktheme=$_COOKIE["dark_theme"];
$num6=8017;
$tmp2=$darktheme=="dark-theme";
if($tmp2){
    $num6=200;
}else{
    $num6=36;
}
switch($num6){
    case 36:{
    echo '<div class="sh-menu-k" id="day" lang="1"><i class="iconfont icon-ai250" id="day-i"></i></div>';
        break;
    }
    case 200:{
        echo '<div class="sh-menu-k" id="day" lang="0"><i class="iconfont icon-yueliang" id="day-i"></i></div>';
        break;
    }
}
echo "    <div class=\"sh-menu-k\" id=\"scrtop\" onclick=\"scrollToTop()\"><i class=\"iconfont icon-weibiaoti-x-copy\"></i></div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
$num7=8012;
$tmp2=$musplay==0;
if($tmp2){
    $num7=200;
}else{
    $tmp2=$musplay==1;
    if($tmp2){
        $num7=36;
    }
}
switch($num7){
    case 36:{
    $tmp2=include './site/musicbkcla.php';
        break;
    }
    case 200:{
        $tmp2=include './site/musicbk.php';
        break;
    }
}
echo "";
echo "
";
echo "
";
echo auth_ts;
echo "<div class=\"sh-copyright\">";
echo "
<span class=\"sh-copyright-banquan\" id=\"sh-copyright-banquan\">";
echo $copyright;
echo "</span>&nbsp;";
echo "
";
if($beian!=""){
    $row=html_entity_decode($beian);
    $tmp2='<span class="sh-copyright-banquan">' . $row;
    $tmp3=$tmp2 . '</span>';
    echo $tmp3;
}
echo "</div>";
echo "
";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
$result=$conn->close();
echo "";
echo "
<script type=\"text/javascript\" src=\"./assets/js/index.js\"></script>";
echo "
<script type=\"text/javascript\" src=\"./assets/js/view.js\"></script>";
echo "
<script type=\"text/javascript\" src=\"./assets/js/jquery.min.js\"></script>";
echo "
<script type=\"text/javascript\" src=\"./assets/mesg/dist/js/sh-noytf.js\"></script>";
echo "
<script type=\"text/javascript\" src=\"./assets/js/jquery.fancybox.min.js\"></script>";
echo "
";
$tmp2='<script type="text/javascript">' . $filtercujs;
$tmp3=$tmp2 . '</script>';
echo $tmp3;
echo "</body>";
echo "
</html>";function ReckonTime($time) {
    $row=time();
    $NowTime=$row;
    if($time>$NowTime){
        return false;
    }
    $TimePoor=$NowTime-$time;
    $num8=3375;
    $tmp2=$TimePoor==0;
    if($tmp2){
        $num8=30;
    }else{
        $tmp2=$TimePoor<60;
        $tmp4=(bool)$tmp2;
        if($tmp4){
            $tmp3=$TimePoor>0;
            $tmp4=(bool)$tmp3;
        }
        if($tmp4){
            $num8=75;
        }else{
            $tmp2=$TimePoor>=60;
            $tmp7=(bool)$tmp2;
            if($tmp7){
                $tmp3=3600;
                $tmp4=$TimePoor<=3600;
                $tmp7=(bool)$tmp4;
            }
            if($tmp7){
                $num8=45;
            }else{
                $tmp2=3600;
                $tmp3=$TimePoor>3600;
                $tmp5=(bool)$tmp3;
                if($tmp5){
                    $tmp4=86400;
                    $tmp7=$TimePoor<=86400;
                    $tmp5=(bool)$tmp7;
                }
                if($tmp5){
                    $num8=135;
                }else{
                    $tmp2=86400;
                    $tmp3=$TimePoor>86400;
                    $tmp6=(bool)$tmp3;
                    if($tmp6){
                        $tmp4=86400;
                        $tmp7=604800;
                        $tmp5=$TimePoor<=604800;
                        $tmp6=(bool)$tmp5;
                    }
                    if($tmp6){
                        $num8=18;
                    }else{
                        $tmp2=86400;
                        $tmp3=604800;
                        $tmp4=$TimePoor>604800;
                        if($tmp4){
                            $num8=225;
                        }
                    }
                }
            }
        }
    }
    $tmp2=198;
    $tmp3=135;
    $tmp4=$num8==135;
if($tmp4)goto L2xeWjgxdi;
goto L2xldMhxdi;
L2xeWjgxdi:
    $str=$TimePoor/3600;
    $row=floor($str);
    $str=$row . '小时前';
goto L2xxdh;
L2xldMhxdi:
    $tmp2=150;
    $tmp3=45;
    $tmp4=$num8==45;
if($tmp4)goto L2xeWjgxdj;
goto L2xldMhxdj;
L2xeWjgxdj:
    $str=$TimePoor/60;
    $row=floor($str);
    $str=$row . '分钟前';
goto L2xxdh;
L2xldMhxdj:
    $tmp2=36;
    $tmp3=30;
    $tmp4=$num8==30;
if($tmp4)goto L2xeWjgxdk;
goto L2xldMhxdk;
L2xeWjgxdk:
    $str='一眨眼之间';
goto L2xxdh;
L2xldMhxdk:
    $tmp2=48;
    $tmp3=75;
    $tmp4=$num8==75;
if($tmp4)goto L2xeWjgxdl;
goto L2xldMhxdl;
L2xeWjgxdl:
    $str=$TimePoor . '秒之前';
goto L2xxdh;
L2xldMhxdl:
    $tmp2=204;
    $tmp3=18;
    $tmp4=$num8==18;
if($tmp4)goto L2xeWjgxdm;
goto L2xldMhxdm;
L2xeWjgxdm:
    $str=86400;
    $str2=$TimePoor/86400;
    $row=floor($str2);
    $tmp4=$row==1;
if($tmp4)goto L2xeWjgxde;
goto L2xldMhxde;
goto L2xldMhxde;
L2xeWjgxde:
    $str="昨天";
goto L2xxdh;
L2xldMhxde:
    $str=86400;
    $str2=$TimePoor/86400;
    $row=floor($str2);
    $tmp4=$row==2;
if($tmp4)goto L2xeWjgxdf;
goto L2xldMhxdf;
goto L2xldMhxdf;
L2xeWjgxdf:
    $str="前天";
goto L2xxdh;
L2xldMhxdf:
    $str=86400;
    $str2=$TimePoor/86400;
    $row=floor($str2);
    $str=$row . '天前';
L2xldMhxdm:
    switch($num8){
        case 225:{
        $row=date("Y-m-d", $time);
        $str=$row;
            break;
        }
    }
L2xxdh:
    return $str;
}