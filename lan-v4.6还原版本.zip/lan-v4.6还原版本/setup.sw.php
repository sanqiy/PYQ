<?php
if($_SERVER['REQUEST_METHOD']==='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$iteace=0;
$num5=4110;
$fileExists=is_file('./config.php');
if($fileExists){
    $num5=75;
}else{
    $num5=25;
}
switch($num5){
    case 75:{
    $tmp=require './config.php';
        break;
    }
    case 25:{
        exit('未检测到配置文件：<span style="color: red;">config.php</span>，若您是首次使用请先进行安装,删除文件夹 <span style="color: red;">[install/]</span> 下的 <span style="color: red;">[ins.bak]</span> 文件后进行安装。若已删除请<a href="./install/">【点击安装】</a>');
        break;
    }
}
$tmp=require './api/wz.php';
if($userdlzt==0){
    $fileExists=Header("Location:./index.php");
    exit();
}
echo "<!DOCTYPE html>";
echo "
<html lang=\"zh-CN\">";
echo "
<head>";
echo "
<meta charset=\"UTF-8\">";
echo "
<title>设置 - ";
echo $name;
echo "</title>";
echo "
<!--为搜索引擎定义关键词-->";
echo "
<meta name=\"keywords\" content=\"";
echo $filterkeyw;
echo "\">";
echo "
<!--为网页定义描述内容 用于告诉搜索引擎，你网站的主要内容-->";
echo "
<meta name=\"description\" content=\"";
echo $subtitle;
echo "\">";
echo "
<meta name=\"author\" content=\"";
echo $name;
echo "\">";
echo "
<meta name=\"copyright\" content=\"";
echo $name;
echo "\">";
echo "
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" />";
echo "
<meta http-equiv=\"cache-control\" content=\"no-cache\">";
echo "
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0,minimum-scale=1.0, user-scalable=no minimal-ui\">";
echo "
<link rel=\"apple-touch-icon\" sizes=\"57x57\" href=\"";
echo $icon;
echo "\" /><!-- Standard iPhone -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"114x114\" href=\"";
echo $icon;
echo "\" /><!-- Retina iPhone -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"72x72\" href=\"";
echo $icon;
echo "\" /><!-- Standard iPad -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"144x144\" href=\"";
echo $icon;
echo "\" /><!-- Retina iPad -->";
echo "
<link rel=\"icon\" href=\"";
echo $icon;
echo "\" type=\"image/x-icon\" />";
echo "
<meta name=\"robots\" content=\"index,follow\">";
echo "
<meta name=\"format-detection\" content=\"telephone=no\">";
echo "
<meta http-equiv=\"x-rim-auto-match\" content=\"none\">";
echo "
";
if($rosdomain==1){
    echo '<meta name="referrer" content="no-referrer">';
}
echo "    <link rel=\"stylesheet\" href=\"";
echo $iconurl_url;
echo "\">";
echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"./assets/css/style.css\">";
echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"./assets/mesg/dist/css/style.css\"><!--引入弹窗对话框-->";
echo "
";
echo $scfontzt;
echo "    ";
$folderPath='./user/bobg/';
$fileExists=file_exists($folderPath);
$tmp=!$fileExists;
if($tmp){
    $fileExists=mkdir($folderPath, true);
}
$num=4109;
$fileExists=file_exists("./user/bobg/bobg.jpg");
if($fileExists){
    $num=45;
}else{
    $fileExists=file_exists("./user/bobg/bobg.png");
    if($fileExists){
        $num=72;
    }else{
        $fileExists=file_exists("./user/bobg/bobg.jpeg");
        if($fileExists){
            $num=81;
        }else{
            $fileExists=file_exists("./user/bobg/bobg.gif");
            if($fileExists){
                $num=120;
            }
        }
    }
}
switch($num){
    case 120:{
    echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.gif);}</style>';
        break;
    }
    case 81:{
        echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.jpeg);}</style>';
        break;
    }
    case 72:{
            echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.png);}</style>';
        break;
    }
    case 45:{
                echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.jpg);}</style>';
        break;
    }
}
echo "    ";
$tmp='<style>' . $filtercucss;
$tmp2=$tmp . '</style>';
echo $tmp2;
echo "</head>";
echo "
<body class=\"";
$num2=4115;
if(isset($_COOKIE['dark_theme'])){
    $num2=120;
}else{
    $num2=120;
    $num2=4950;
}
$tmp=221;
$tmp2=120;
$tmp3=$num2==120;
if($tmp3)goto L2xeWjgx12;
goto L2xldMhx12;
L2xeWjgx12:
$tmp=$_COOKIE["dark_theme"]=="dark-theme";
if($tmp)goto L2xeWjgxz;
goto L2xx11;
goto L2xx11;
L2xeWjgxz:
echo 'dark-theme';
goto L2xx11;
L2xldMhx12:
$tmp=50;
$tmp2=2535;
$tmp3=$num2==2535;
if($tmp3)goto L2xx11;
L2xx11:
echo "\">";
echo "
";
if($pagepass!="")goto L2xeWjgx1d;
goto L2xldMhx1d;
L2xeWjgx1d:
if(isset($_COOKIE['pagepass']))goto L2xeWjgx19;
goto L2xldMhx19;
goto L2xldMhx19;
L2xeWjgx19:
$hash=md5($pagepass);
$hash2=md5($hash);
$tmp=$_COOKIE['pagepass']!=$hash2;
if($tmp)goto L2xeWjgx1b;
goto L2xx1c;
goto L2xx1c;
L2xeWjgx1b:
$tmp=include './site/pagepass.php';
goto L2xx1c;
L2xldMhx19:
$tmp=include './site/pagepass.php';
L2xldMhx1d:
L2xx1c:
echo "    <div class=\"centent\">";
echo "
<div class=\"sh-main setup-main\">";
echo "
<div class=\"sh-main-head setup-main-head\">";
echo "
<!-- 顶部菜单 -->";
echo "
<div class=\"sh-main-head-top setup-main-top\" id=\"sh-main-head-top\">";
echo "
<!-- 左边 -->";
echo "
<div class=\"sh-main-head-top-left\">";
echo "
<div class=\"sh-main-head-top-left-s\" onclick=\"location.href='./home.php'\">";
echo "
<i class=\"iconfont icon-weibiaoti al-sxbh\" id=\"top-left-1\"></i>";
echo "
</div>";
echo "
<div class=\"sh-main-head-top-left-s setup-main-head-top-left-s\">";
echo "
<span class=\"setup-main-title\">设置</span>";
echo "
</div>";
echo "
</div>";
echo "
<!-- 右边 -->";
echo "
<!--div class=\"sh-main-head-top-right\">";
echo "
</div-->";
echo "
</div>";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
<div class=\"sh-setup-main-xbb\" id=\"setuptx\" lang=\"60\">";
echo "
<!--新版UI-头像-->";
echo "
<div class=\"setup-main-lieb-xtitle\" onclick=\"setuptx()\">";
echo "
<span>头像</span>";
echo "
<div class=\"setup-main-lieb-title-y\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"";
echo $zjimg;
echo "\" id=\"setup-main-lieb-qx-imgt\" class=\"setup-main-lieb-title-y-imgt\" alt=\"\">";
echo "
<i class=\"iconfont icon-weibiaotiy al-sxbh-setup1\" id=\"setup-main-lieb-qtx-img\"></i>";
echo "
</div>";
echo "
</div>";
echo "
<!-- 嵌入内容 -->";
echo "
<form action=\"./api/uploadavatar.php\" method=\"post\" enctype=\"multipart/form-data\" class=\"setup-main-lieb-xcontent\">";
echo "
<!--内容标题-->";
echo "
<div class=\"sh-setup-formup\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"\" id=\"setup-formup-img\" alt=\"\">";
echo "
<span class=\"cupload-upload-btn\" id=\"cupload-upload-btn\">+</span>";
echo "
<input type=\"file\" name=\"file\" accept=\"image/*\" id=\"files\" required>";
echo "
</div>";
echo "
";
echo "
<div id=\"sctxs\"><input type=\"submit\" class=\"setup-main-tj\" name=\"submit\" value=\"上传\" onclick=\"sctxs()\"></div>";
echo "
";
echo "
</form>";
echo "
</div>";
echo "
";
echo "
<div class=\"sh-setup-main-xb\" id=\"setupnc\" lang=\"45\">";
echo "
<!--新版UI-昵称-->";
echo "
<div class=\"setup-main-lieb-xtitlee\" onclick=\"setupnc()\">";
echo "
<span>昵称</span>";
echo "
<div class=\"setup-main-lieb-title-y\">";
echo "
<p id=\"setup-main-lieb-title-y-usernc\">";
echo $zjnc;
echo "</p>";
echo "
<i class=\"iconfont icon-weibiaotiy al-sxbh-setup1\" id=\"setup-main-lieb-qnc-img\"></i>";
echo "
</div>";
echo "
</div>";
echo "
<!-- 嵌入内容 -->";
echo "
<div class=\"setup-main-lieb-xcontent\">";
echo "
<!--内容标题-->";
echo "
<input type=\"text\" name=\"\" id=\"usernc\" value=\"";
echo $zjnc;
echo "\" placeholder=\"设置昵称\"minlength=\"1\" maxlength=\"10\" spellcheck=\"false\"/>";
echo "
<div class=\"setup-main-lieb-xgxan\" id=\"zhnc\" onclick=\"zhnc()\">";
echo "
<span>更新</span>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
<div class=\"sh-setup-main-xb\" id=\"setupqm\" lang=\"45\">";
echo "
<!--新版UI-签名-->";
echo "
<div class=\"setup-main-lieb-xtitlee\" onclick=\"setupqm()\">";
echo "
<span>签名</span>";
echo "
<div class=\"setup-main-lieb-title-y\">";
echo "
<p id=\"setup-main-lieb-title-y-userqm\">";
echo $zjsign;
echo "</p>";
echo "
<i class=\"iconfont icon-weibiaotiy al-sxbh-setup1\" id=\"setup-main-lieb-qqm-img\"></i>";
echo "
</div>";
echo "
</div>";
echo "
<!-- 嵌入内容 -->";
echo "
<div class=\"setup-main-lieb-xcontent\">";
echo "
<!--内容标题-->";
echo "
<input type=\"text\" name=\"\" id=\"userqm\" value=\"";
echo $zjsign;
echo "\" placeholder=\"设置签名\" minlength=\"1\" maxlength=\"50\" spellcheck=\"false\"/>";
echo "
<div class=\"setup-main-lieb-xgxan\" id=\"zhqm\" onclick=\"zhqm()\">";
echo "
<span>更新</span>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
<div class=\"sh-setup-main-xb\" id=\"setupwz\" lang=\"45\">";
echo "
<!--新版UI-网址-->";
echo "
<div class=\"setup-main-lieb-xtitlee\" onclick=\"setupwz()\">";
echo "
<span>网址</span>";
echo "
<div class=\"setup-main-lieb-title-y\">";
echo "
<p id=\"setup-main-lieb-title-y-userurl\">";
echo $zjurl;
echo "</p>";
echo "
<i class=\"iconfont icon-weibiaotiy al-sxbh-setup1\" id=\"setup-main-lieb-qwz-img\"></i>";
echo "
</div>";
echo "
</div>";
echo "
<!-- 嵌入内容 -->";
echo "
<div class=\"setup-main-lieb-xcontent\">";
echo "
<!--内容标题-->";
echo "
<input type=\"url\" name=\"\" id=\"userurl\" value=\"";
echo $zjurl;
echo "\" placeholder=\"填写您的网站\" minlength=\"1\" spellcheck=\"false\"/>";
echo "
<div class=\"setup-main-lieb-xgxan\" id=\"zhwz\" onclick=\"zhwz()\">";
echo "
<span>更新</span>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<!-- 账号与安全 -->";
echo "
<div class=\"setup-main-lieb\" id=\"setup-main-lieb-aq\" lang=\"45\">";
echo "
<!-- 标题 -->";
echo "
<div class=\"setup-main-lieb-title\" onclick=\"anquan()\">";
echo "
<span>安全中心</span>";
echo "
<i class=\"iconfont icon-weibiaotiy al-sxbh-setup\" id=\"setup-main-lieb-aq-img\"></i>";
echo "
</div>";
echo "
<!-- 嵌入内容 -->";
echo "
<div class=\"setup-main-lieb-content\">";
echo "
<!--内容标题-->";
echo "
<span>账号</span>";
echo "
<input type=\"text\" name=\"\" id=\"userzh\" value=\"";
echo $zjzhq;
echo "\" placeholder=\"账号不可更改\" readonly=\"readonly\" disabled/>";
echo "
</div>";
echo "
<div class=\"setup-main-lieb-content\">";
echo "
<!--内容标题-->";
echo "
<span>旧密码</span>";
echo "
<input type=\"password\" name=\"\" id=\"usermm\" value=\"\" placeholder=\"输入旧密码\" spellcheck=\"false\"/>";
echo "
</div>";
echo "
<div class=\"setup-main-lieb-content\">";
echo "
<!--内容标题-->";
echo "
<span>新密码</span>";
echo "
<input type=\"text\" name=\"\" id=\"userxmm\" value=\"\" placeholder=\"输入新密码\" spellcheck=\"false\"/>";
echo "
</div>";
echo "
<div class=\"setup-main-lieb-content\">";
echo "
<!--内容标题-->";
echo "
<span>邮箱</span>";
echo "
<input type=\"email\" name=\"\" id=\"userem\" value=\"";
echo $zjemail;
echo "\" placeholder=\"设置您的邮箱\" spellcheck=\"false\"/>";
echo "
</div>";
echo "
";
echo "
<!--按钮-->";
echo "
<div class=\"setup-main-lieb-gxan\" id=\"zhyanxg\" onclick=\"zhyanxg()\">";
echo "
<span>更新</span>";
echo "
</div>";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"setup-main-lieb\" id=\"setup-main-lieb-wa\" lang=\"45\" style=\"height: 45px;\">";
echo "
<!-- 标题 -->";
echo "
<div class=\"setup-main-lieb-title\" onclick=\"walletb()\">";
echo "
<span>我的钱包</span>";
echo "
<div class=\"setup-main-lieb-title-y\">";
echo "
<p id=\"setup-main-lieb-title-y-userurl-wallet\">";
echo $zjwallet;
echo "</p>";
echo "
<i class=\"iconfont icon-weibiaotiy al-sxbh-setup1\" id=\"setup-main-lieb-wa-img\"></i>";
echo "
</div>";
echo "
</div>";
echo "
<!-- 嵌入内容 -->";
echo "
<div class=\"setup-main-lieb-content\">";
echo "
<!--内容标题-->";
echo "
<span>积分余额</span>";
echo "
<input type=\"text\" name=\"\" id=\"wallet\" value=\"";
echo $zjwallet;
echo "\" readonly=\"readonly\" disabled=\"\">";
echo "
</div>";
echo "
<div class=\"setup-main-lieb-content\">";
echo "
<!--内容标题-->";
echo "
<span>卡密充值</span>";
echo "
<input type=\"text\" class=\"form-control\" placeholder=\"请输入卡密\" id=\"kmkh\" name=\"kmkh\" maxlength=\"32\" required=\"\">";
echo "
<input type=\"hidden\" name=\"lx\" value=\"kmcz\">";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
<!--按钮-->";
echo "
<div class=\"setup-main-lieb-gxan\" id=\"yuecz\" onclick=\"yuecz()\">";
echo "
<span>充值</span>";
echo "
</div>";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<!-- 权限与状态 -->";
echo "
<div class=\"setup-main-lieb\" id=\"setup-main-lieb-qx\" lang=\"45\">";
echo "
<!-- 标题 -->";
echo "
<div class=\"setup-main-lieb-title\" onclick=\"quanxian()\">";
echo "
<span>权限管理</span>";
echo "
<i class=\"iconfont icon-weibiaotiy al-sxbh-setup\" id=\"setup-main-lieb-qx-img\"></i>";
echo "
</div>";
echo "
<!-- 嵌入内容 -->";
echo "
<div class=\"setup-main-lieb-content-kg\">";
echo "
<!--开关-->";
echo "
<span>文章发布权限</span>";
echo "
<div class=\"setup-main-lieb-content-kg-an\">";
echo "
";
$num3=4098;
$tmp=$zjfbqx==0;
if($tmp){
    $num3=120;
}else{
    $tmp=$zjfbqx==1;
    if($tmp){
        $num3=144;
    }
}
switch($num3){
    case 144:{
    $str="background: var(--theme);justify-content: flex-end";
    $fbsty=$str;
        break;
    }
    case 120:{
        $str="background: rgb(238 238 238);justify-content: flex-start";
        $fbsty=$str;
        break;
    }
}
echo "                        <div class=\"setup-main-lieb-content-kg-an-xin\" style=\"";
echo $fbsty;
echo ";cursor: not-allowed;\"><p></p></div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"setup-main-lieb-content-kg\">";
echo "
<!--开关-->";
echo "
<span>接收邮件通知</span>";
echo "
<div class=\"setup-main-lieb-content-kg-an\">";
echo "
";
$num4=4111;
$tmp=$zjemtz==0;
if($tmp){
    $num4=256;
}else{
    $tmp=$zjemtz==1;
    if($tmp){
        $num4=25;
    }
}
switch($num4){
    case 25:{
    $str="background: var(--theme);justify-content: flex-end";
    $fbstyy=$str;
    $ztema=1;
        break;
    }
    case 256:{
        $str="background: rgb(238 238 238);justify-content: flex-start";
        $fbstyy=$str;
        $ztema=0;
        break;
    }
}
echo "                        <div id=\"emaitz\"  onclick=\"emailkq()\" class=\"setup-main-lieb-content-kg-an-xin\" style=\"";
echo $fbstyy;
echo "\" lang=\"";
echo $ztema;
echo "\"><p></p></div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"setup-main-lieb-logout\" onclick=\"logut()\">";
echo "
<p>退出登录</p>";
echo "
</div>";
echo "
";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo auth_ts;
echo "<div class=\"sh-copyright\">";
echo "
<span class=\"sh-copyright-banquan\" id=\"sh-copyright-banquan\">";
echo $copyright;
echo "</span>&nbsp;";
echo "
";
if($beian!=""){
    $fileExists=html_entity_decode($beian);
    $tmp='<span class="sh-copyright-banquan">' . $fileExists;
    $tmp2=$tmp . '</span>';
    echo $tmp2;
}
echo "</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
</div>";
echo "
";
echo "
<script type=\"text/javascript\" src=\"./assets/js/setup.js\"></script>";
echo "
<script type=\"text/javascript\" src=\"./assets/mesg/dist/js/sh-noytf.js\"></script>";
echo "
";
$tmp='<script type="text/javascript">' . $filtercujs;
$tmp2=$tmp . '</script>';
echo $tmp2;
echo "</body>";
echo "
</html>";