<?php
$iteace='adminapi';
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp=$user_zh=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$user_passid=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit('<script language="JavaScript">;alert("请先登录!");location.href="../login.php";</script>');
}
$tmp=include '../../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$escaped=htmlspecialchars($user_zh);
$cookieResult=addslashes($escaped);
$user_zhsg=$cookieResult;
$tmp="select * from user where username='" . $user_zhsg;
$sqls=$tmp . "'";
$row=mysqli_query($conn, $sqls);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$data2s_row=$row;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($num4))break;
    $glyzhuser=$row["username"];
}
L2xxf:
$str="select * from user where username='" . $user_zh;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
$zid=$data2_row["id"];
$zjpassword=$data2_row["password"];
if($user_passid!=$passid){
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("username", "", $str, "/");
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("passid", "", $str, "/");
    exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="../login.php";</script>');
}
if($zjzhq!=$glyzhuser){
    exit('<script language="JavaScript">;alert("没有权限!");history.go(-1);</script>');
}
$auth_keylocation='../../api/key.php';
$auth_keyauth='../../api/auth.php';
$num=8002;
$row=file_exists($auth_keyauth);
if($row){
    $num=320;
}else{
    $num=100;
}
$tmp=8;
$tmp4=100;
$tmp2=$num==100;
if($tmp2)goto L2xeWjgxw;
goto L2xldMhxw;
L2xeWjgxw:
exit('<script language="JavaScript">;alert("授权验证文件不存在或被篡改,请确保文件完整且未篡改!");history.go(-1);</script>');
goto L2xxv;
L2xldMhxw:
$tmp=140;
$tmp4=320;
$tmp2=$num==320;
if($tmp2)goto L2xeWjgxx;
goto L2xldMhxx;
L2xeWjgxx:
$tmp=require $auth_keyauth;
$tmp=!defined("sh_auth_state");
if($tmp){
    exit('<script language="JavaScript">;alert("授权验证失败,请确保文件完整且未篡改!");history.go(-1);</script>');
}
$tmp=sh_auth_state!="ok";
if($tmp)goto L2xeWjgxu;
goto L2xxv;
goto L2xxv;
L2xeWjgxu:
exit('<script language="JavaScript">;alert("程序未授权,您的请求已被拒绝,请授权后使用!");history.go(-1);</script>');
goto L2xxv;
L2xldMhxx:
L2xxv:
$num2=8011;
$isArray=is_array($_POST);
if($isArray){
    $num2=35;
}else{
    $num2=25;
}
switch($num2){
    case 35:{
    $ztm=&$_POST['ztm'];
        break;
    }
    case 25:{
        $ztm=$_POST['ztm'];
        break;
    }
}
$escaped=htmlspecialchars($ztm);
unset($ztm);
$escaped2=addslashes($escaped);
$ztm=$escaped2;
$num3=8007;
$isArray=is_array($_POST);
if($isArray){
    $num3=80;
}else{
    $num3=119;
}
switch($num3){
    case 80:{
    $ztm=&$_POST['cs'];
        break;
    }
    case 119:{
        $ztm=$_POST['cs'];
        break;
    }
}
$escaped=htmlspecialchars($ztm);
unset($ztm);
$escaped2=addslashes($escaped);
$cs=$escaped2;
$tmp=$ztm=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$cs=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit("参数不完整!");
}
if($ztm=="shwz")goto L2xeWjgx1o;
goto L2xldMhx1o;
L2xeWjgx1o:
$tmp="UPDATE essay SET ptpaud='1' WHERE cid='" . $cs;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx1m;
goto L2xldMhx1m;
goto L2xldMhx1m;
L2xeWjgx1m:
echo "200";
goto L2xx1n;
L2xldMhx1m:
$row=mysql_errno();
echo $row;
L2xldMhx1o:
L2xx1n:
if($ztm=="bhwz")goto L2xeWjgx39;
goto L2xldMhx39;
L2xeWjgx39:
$tmp="SELECT ptpimag, ptpvideo, ptpmusic FROM essay WHERE cid = '" . $cs;
$sql=$tmp . "'";
$row=mysqli_query($conn, $sql);
$result=$row;
if($result){
    $row=mysqli_fetch_assoc($result);
    $row=$row;
    $id=$row['id'];
    $ptpimag=$row['ptpimag'];
    $ptpvideo=$row['ptpvideo'];
    $ptpmusic=$row['ptpmusic'];
}
$tmp="delete from essay where cid='" . $cs;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
if($result){
    echo "200";
}else{
    $row=mysql_errno();
    echo $row;
}
$sql="SELECT * FROM comm";
$result=$conn->query($sql);
$result=$result;
L2xx1x:
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!$num4)break;
    $wcid=$row['wzcid'];
    $tmp=$wcid==$wzdid;
if($tmp)goto L2xeWjgx21;
goto L2xx1x;
goto L2xx1x;
}
L2xeWjgx21:
$id=$row['id'];
$tmp="delete from comm where id='" . $id;
$sqlq=$tmp . "'";
$result=$conn->query($sqlq);
$resultq=$result;
if($resultq)goto L2xx1x;
goto L2xldMhx23;
goto L2xldMhx23;
L2xldMhx23:
$row=mysql_errno();
echo $row;
$sql="SELECT * FROM lcke";
$result=$conn->query($sql);
$result=$result;
L2xx2a:
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!$num4)break;
    $wcid=$row['lwz'];
    $tmp=$wcid==$wzdid;
if($tmp)goto L2xeWjgx2d;
goto L2xx2a;
goto L2xx2a;
}
L2xeWjgx2d:
$id=$row['id'];
$tmp="delete from lcke where id='" . $id;
$sqlq=$tmp . "'";
$result=$conn->query($sqlq);
$resultq=$result;
if($resultq)goto L2xx2a;
goto L2xldMhx2f;
goto L2xldMhx2f;
L2xldMhx2f:
$row=mysql_errno();
echo $row;
$tmp=$ptpimag!="";
if($tmp)goto L2xeWjgx2n;
goto L2xldMhx2n;
goto L2xldMhx2n;
L2xeWjgx2n:
$row=explode('(+@+)', $ptpimag);
$imgar=$row;
$row=count($imgar);
$coun=$row;
$num4=0;
$i=$num4;
while(true){
    $tmp=$i<$coun;
    if(!$tmp)break;
    $tuimg=$imgar[$i];
    $row=strpos($tuimg, '/upload/');
    $tmp=$row!==false;
if($tmp)goto L2xeWjgx2s;
goto L2xldMhx2s;
goto L2xldMhx2s;
goto L2xldMhx2s;
L2xeWjgx2s:
    $str='../.' . $tuimg;
    $row=is_file($str);
    $tmp4=!$row;
    if(!($tmp4)){
        $str='../.' . $tuimg;
        $row=unlink($str);
L2xldMhx2s:
    }
    $obj=$i;
    $obj2=$i+1;
    $num4=$obj2;
    $i=$num4;
}
goto L2xx2m;
L2xldMhx2n:
L2xx2m:
$tmp=$ptpvideo!="";
if($tmp)goto L2xeWjgx33;
goto L2xx38;
goto L2xx38;
L2xeWjgx33:
$row=strpos($ptpvideo, '/upload/');
$tmp=$row!==false;
if($tmp)goto L2xeWjgx35;
goto L2xx38;
goto L2xx38;
L2xeWjgx35:
$str='../..' . $ptpvideo;
$row=is_file($str);
$tmp4=!$row;
if($tmp4)goto L2xx38;
goto L2xldMhx37;
L2xldMhx37:
$str='../..' . $ptpvideo;
$row=unlink($str);
L2xldMhx39:
L2xx38:
if($ztm=="shpl")goto L2xeWjgx4a;
goto L2xldMhx4a;
L2xeWjgx4a:
$tmp="UPDATE comm SET comaud='1' WHERE ecid='" . $cs;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx48;
goto L2xldMhx48;
goto L2xldMhx48;
L2xeWjgx48:
echo "200";
goto L2xx49;
L2xldMhx48:
$row=mysql_errno();
echo $row;
L2xldMhx4a:
L2xx49:
if($ztm=="bhpl")goto L2xeWjgx4i;
goto L2xldMhx4i;
L2xeWjgx4i:
$tmp="delete from comm where ecid='" . $cs;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx4g;
goto L2xldMhx4g;
goto L2xldMhx4g;
L2xeWjgx4g:
echo "200";
goto L2xx4h;
L2xldMhx4g:
$row=mysql_errno();
echo $row;
L2xldMhx4i:
L2xx4h:
$result=$conn->close();