<?php
$file="ins.bak";
$length=file_exists($file);
if($length){
    echo '你已经安装过了!若您是首次使用请先进行安装,删除文件夹 <span style="color: red;">[install/]</span> 下的 <span style="color: red;">[ins.bak]</span> 文件后进行安装。';
    exit();
}
$iteace=2;
$length=is_file('../config.php');
if($length){
    $tmp=include '../config.php';
}
$servername=$_POST['servername'];
$username=$_POST['username'];
$password=$_POST['password'];
$dbname=$_POST['dbname'];
$adminame=$_POST['admin'];
if($adminame==""){
    exit('<script language="JavaScript">;alert("管理员账号不能为空");location.href="./index.php";</script>');
}
$length=strlen($adminame);
$tmp=$length<5;
if($tmp){
    exit('<script language="JavaScript">;alert("管理员账号不可低于5位");location.href="./index.php";</script>');
}
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$str="Y";
$Y=$str;
$str="m";
$m=$str;
$str="d";
$d=$str;
$str="H";
$H=$str;
$str="i";
$i=$str;
$str="s";
$s=$str;
$str2=$Y . "-";
$val=$str2 . $m;
$str3=$val . "-";
$val2=$str3 . $d;
$str4=$val2 . " ";
$val3=$str4 . $H;
$str5=$val3 . ":";
$val4=$str5 . $i;
$str6=$val4 . ":";
$val5=$str6 . $s;
$length=date($val5);
$sj=$length;
$ip=$_SERVER["REMOTE_ADDR"];
$lx=5;
$num=32;
$gs=1;
$tmp=False;
$tmp=False;
$tmp=False;
$tmp=False;
$tmp=True;
$tmp=112;
$tmp2=51;
$tmp3=False;
goto L2xldMhxu;
echo '{"201":"错误的类型"}';
goto L2xxt;
L2xldMhxu:
$tmp=112;
$tmp2=272;
$tmp3=True;
$strPol="0123456789";
L2xxt:
$x=1;
while(true){
    $tmp=$x<=1;
    if(!($tmp))break;
    $length=strlen($strPol);
    $max=$length-1;
    $str=0;
    $i=$str;
    while(true){
        $tmp=$i<32;
        if(!($tmp))break;
        $rand=rand($max);
        $str=$str . $strPol[$rand];
        $val6=$str;
        $obj=$i;
        $obj2=$i+1;
        $str=$obj2;
        $i=$str;
    }
    $str=$str;
    $obj2=$x;
    $obj3=$x+1;
    $str=$obj3;
    $x=$str;
}
L2xx1j:
$bdm="admin";
$tmp="CREATE TABLE " . $bdm;
$tmp2=$tmp . " (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
name TEXT NOT NULL COMMENT '站点名称',
subtitle TEXT NOT NULL COMMENT '站点介绍',
icon TEXT NOT NULL COMMENT 'icon图标',
logo TEXT NOT NULL COMMENT 'logo图标',
zt TEXT NOT NULL COMMENT '站点状态 1开 0关',
username TEXT NOT NULL COMMENT '管理员账号',
homimg TEXT NOT NULL COMMENT '顶部背景图',
sign TEXT NOT NULL COMMENT '签名(不设置则为空)',
music TEXT NOT NULL COMMENT '网站音乐(-1为不设置)',
essgs TEXT NOT NULL COMMENT '文章输出数量',
commgs TEXT NOT NULL COMMENT '每篇文章的评论输出数量',
lnkzt TEXT NOT NULL COMMENT '是否开启友链显示 0=是 1=否',
regqx TEXT NOT NULL COMMENT '是否开启用户注册 0=开 -1=关',
kqsy TEXT NOT NULL COMMENT '是否开启所有用户发布权限(0=关 1=开)',
comaud TEXT NOT NULL COMMENT '评论是否需要审核(0=不需要 1=需要)',
ptpaud TEXT NOT NULL COMMENT '发布文章是否需要审核(0=不需要 1=需要)',
ptpfan TEXT NOT NULL COMMENT '是否显示前台发布文章按钮(0=不显示 1=显示)',
loginkg TEXT NOT NULL COMMENT '是否显示前台登录按钮(0=不显示 1=显示)',
notname TEXT NOT NULL COMMENT '是否开启匿名发布(0=关闭 1=开启)',
imgpres TEXT NOT NULL COMMENT '是否开启文章图片压缩(0=不压缩 1=压缩)',
rosdomain TEXT NOT NULL COMMENT '是否开启跨域资源(0=不开启 1=开启)',
daymode TEXT NOT NULL COMMENT '是否开启日夜模式(0=不开启 1=开启)',
gotop TEXT NOT NULL COMMENT '是否开启回到顶部(0=不开启 1=开启)',
search TEXT NOT NULL COMMENT '是否开启搜索功能(0=不开启 1=开启)',
videoauplay TEXT NOT NULL COMMENT '是否开启视频自动播放(0=不开启 1=开启)',
regverify TEXT NOT NULL COMMENT '是否开启注册验证邮箱(0=不开启 1=开启)',
pagepass TEXT NOT NULL COMMENT '网站访问密码 为空则无需密码',
emydz TEXT NOT NULL COMMENT '邮箱服务器地址',
emssl TEXT NOT NULL COMMENT '邮箱SSL加密方式',
emduk TEXT NOT NULL COMMENT 'SMTP端口',
emkey TEXT NOT NULL COMMENT '邮箱授权码',
emzh TEXT NOT NULL COMMENT 'SMTP账号',
emfs TEXT NOT NULL COMMENT '发送邮箱',
emfszm TEXT NOT NULL COMMENT '发送者名称',
date TEXT NOT NULL COMMENT '安装时间',
copyright TEXT NOT NULL COMMENT '版权所属',
beian TEXT NOT NULL COMMENT '备案号(没有则为空)',
topes TEXT NOT NULL COMMENT '置顶文文章',
scfont TEXT NOT NULL COMMENT '网站字体',
viscomm TEXT NOT NULL COMMENT '游客评论(-1=关 0=开)',
musplay TEXT NOT NULL COMMENT '悬浮音乐播放器样式',
sigin TEXT NOT NULL COMMENT '签到赠送余额 0=关闭签到功能',
rnking TEXT NOT NULL COMMENT '排行功能 0=关 1=开',
rnggy TEXT NOT NULL COMMENT '发布广告类型文章所需余额',
dywptp TEXT NOT NULL COMMENT '每天第一篇文章奖励余额',
topwcz TEXT NOT NULL COMMENT '置顶文章所需余额',
imgyunc TEXT NOT NULL COMMENT '图像储存配置 0=本地',
ipregx TEXT NOT NULL COMMENT '每个IP允许注册几个账号'
)";
$sql=$tmp2;
$num=4914;
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp){
    $num=25;
}else{
    $num=48;
}
$tmp=77;
$tmp2=48;
$tmp3=$num==48;
if($tmp3)goto L2xeWjgx1s;
goto L2xldMhx1s;
L2xeWjgx1s:
$tmp="创建数据表错误: " . $conn->error;
echo $tmp;
goto L2xx1r;
L2xldMhx1s:
$tmp=20;
$tmp2=25;
$tmp3=$num==25;
if($tmp3)goto L2xx1r;
L2xx1r:
$tmp="INSERT INTO " . $bdm;
$tmp2=$tmp . " (name, subtitle, icon, logo, zt,username,homimg,sign,music,essgs,commgs,lnkzt,regqx,kqsy,comaud,ptpaud,ptpfan,loginkg,notname,imgpres,rosdomain,daymode,gotop,search,videoauplay,regverify,pagepass,emydz,emssl,emduk,emkey,emzh,emfs,emfszm, date,copyright,beian,topes,scfont,viscomm,musplay,sigin,rnking,rnggy,dywptp,topwcz,imgyunc,ipregx)
VALUES ('LAN - 更简洁，更优雅', 'LAN - 更简洁，更优雅', './assets/img/favicon.png', './assets/img/logo.png', '1', '";
$tmp3=$tmp2 . $adminame;
$tmp4=$tmp3 . "','./assets/img/homeimg.jpg','LAN - 更简洁，更优雅','-1','10','10','0','0','0','0','0','1','1','0','0','0','0','0','0','1','0','','smtp.qq.com','ssl','465', '','','','','";
$tmp5=$tmp4 . $sj;
$sql=$tmp5 . "','LAN','','','','-1','1','0','0','0','0','100','0','1')";
$num2=4927;
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp){
    $num2=51;
}else{
    $num2=85;
}
$tmp=22;
$tmp2=85;
$tmp3=$num2==85;
if($tmp3)goto L2xeWjgx1x;
goto L2xldMhx1x;
L2xeWjgx1x:
$tmp="Error: " . $sql;
$tmp2=$tmp . "<br>";
$tmp3=$tmp2 . $conn->error;
echo $tmp3;
goto L2xx1w;
L2xldMhx1x:
$tmp=112;
$tmp2=51;
$tmp3=$num2==51;
if($tmp3)goto L2xx1w;
L2xx1w:
$bdm="kami";
$tmp="CREATE TABLE " . $bdm;
$tmp2=$tmp . " (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
kami TEXT NOT NULL COMMENT '卡密',
auom TEXT NOT NULL COMMENT '卡密金额',
act TEXT NOT NULL COMMENT '使用状态 0=未使用 1=已使用',
ause TEXT NOT NULL COMMENT '使用者账号',
autm TEXT NOT NULL COMMENT '使用时间'
)";
$sql=$tmp2;
$num3=4915;
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp){
    $num3=48;
}else{
    $num3=33;
}
$tmp=20;
$tmp2=48;
$tmp3=$num3==48;
if($tmp3)goto L2xx22;
switch($num3){
    case 33:{
    $tmp="创建数据表错误: " . $conn->error;
    echo $tmp;
        break;
    }
}
L2xx22:
$bdm="money";
$tmp="CREATE TABLE " . $bdm;
$tmp2=$tmp . " (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
muser TEXT NOT NULL COMMENT '发起者账号',
type TEXT NOT NULL COMMENT '类型 0=固定 1=随机',
zsum TEXT NOT NULL COMMENT '总金额',
sum TEXT NOT NULL COMMENT '剩余金额',
total TEXT NOT NULL COMMENT '总数量',
recve TEXT NOT NULL COMMENT '剩余数量',
luser TEXT NOT NULL COMMENT '已领取的账号',
montext TEXT NOT NULL COMMENT '红包祝福',
monimg TEXT NOT NULL COMMENT '红包封面',
ptpmoncid TEXT NOT NULL COMMENT '所属文章cid'
)";
$sql=$tmp2;
$num4=4923;
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp){
    $num4=176;
}else{
    $num4=176;
    $num4=8840;
}
$tmp=196;
$tmp2=176;
$tmp3=$num4==176;
if($tmp3)goto L2xx27;
switch($num4){
    case 4508:{
    $tmp="创建数据表错误: " . $conn->error;
    echo $tmp;
        break;
    }
}
L2xx27:
$bdm="essay";
$tmp="CREATE TABLE " . $bdm;
$tmp2=$tmp . " (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
ptpuser TEXT NOT NULL COMMENT '发布者账号',
ptpimg TEXT NOT NULL COMMENT '发布者头像',
ptpname TEXT NOT NULL COMMENT '发布者昵称',
ptptext TEXT NOT NULL COMMENT '文章内容',
ptpimag TEXT NOT NULL COMMENT '文章图片',
ptpvideo TEXT NOT NULL COMMENT '文章视频',
ptpmusic TEXT NOT NULL COMMENT '文章音乐',
ptplx TEXT NOT NULL COMMENT '文章类型(img=图文 video=视频 music=音乐 only=仅文字)',
ptpdw TEXT NOT NULL COMMENT '文章发布时定位',
ptptime TEXT NOT NULL COMMENT '文章发布时间',
ptpgg TEXT NOT NULL COMMENT '文章是否为广告(0=不是 1=是)',
ptpggurl TEXT NOT NULL COMMENT '广告跳转链接',
ptpys TEXT NOT NULL COMMENT '文章是否可见(0=不可见 1=可见)',
commauth TEXT NOT NULL COMMENT '是否允许评论(0=关 1=开)',
ptpaud TEXT NOT NULL COMMENT '审核状态(0=未审核 1=已审核)',
ip TEXT NOT NULL COMMENT '文章发布时的ip',
cid TEXT NOT NULL COMMENT '文章cid'
)";
$sql=$tmp2;
$num5=4931;
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp){
    $num5=15;
}else{
    $num5=51;
}
$tmp=60;
$tmp2=51;
$tmp3=$num5==51;
if($tmp3)goto L2xeWjgx2d;
goto L2xldMhx2d;
L2xeWjgx2d:
$tmp="创建数据表错误: " . $conn->error;
echo $tmp;
goto L2xx2c;
L2xldMhx2d:
$tmp=28;
$tmp2=15;
$tmp3=$num5==15;
if($tmp3)goto L2xx2c;
L2xx2c:
$tmp="INSERT INTO " . $bdm;
$tmp2=$tmp . " (ptpuser,ptpimg,ptpname,ptptext,ptpimag,ptpvideo,ptpmusic,ptplx,ptpdw,ptptime,ptpgg,ptpggurl,ptpys,commauth,ptpaud,ip,cid)
VALUES ('";
$tmp3=$tmp2 . $adminame;
$tmp4=$tmp3 . "','./assets/img/tx.png','LAN','欢迎使用程序《LAN》此文章由系统生成，您可以删除它，然后开始发布您的内容！','','','','only','','";
$tmp5=$tmp4 . $sj;
$tmp6=$tmp5 . "','0','','1','1','1','";
$tmp7=$tmp6 . $ip;
$tmp8=$tmp7 . "','";
$tmp9=$tmp8 . $str;
$sql=$tmp9 . "')";
$num6=4918;
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp){
    $num6=272;
}else{
    $num6=80;
}
$tmp=12;
$tmp2=272;
$tmp3=$num6==272;
if($tmp3)goto L2xx2h;
switch($num6){
    case 80:{
    $tmp="Error: " . $sql;
    $tmp2=$tmp . "<br>";
    $tmp3=$tmp2 . $conn->error;
    echo $tmp3;
        break;
    }
}
L2xx2h:
$bdm="comm";
$tmp="CREATE TABLE " . $bdm;
$tmp2=$tmp . " (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
couser TEXT NOT NULL COMMENT '评论者账号',
coimg TEXT NOT NULL COMMENT '评论者头像',
coname TEXT NOT NULL COMMENT '评论者昵称',
courl TEXT NOT NULL COMMENT '评论者网址',
cotext TEXT NOT NULL COMMENT '评论内容',
bcouser TEXT NOT NULL COMMENT '被评论者账号(没有被评论者则填false)',
bconame TEXT NOT NULL COMMENT '被评论者昵称(没有被评论者则填false)',
comaud TEXT NOT NULL COMMENT '评论审核状态(0=未审核 1=已审核)',
cotime TEXT NOT NULL COMMENT '评论时间',
ip TEXT NOT NULL COMMENT '评论ip',
wzcid TEXT NOT NULL COMMENT '评论所属文章',
ecid TEXT NOT NULL COMMENT '评论cid'
)";
$sql=$tmp2;
$num7=4913;
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp){
    $num7=55;
}else{
    $num7=25;
}
$tmp=108;
$tmp2=25;
$tmp3=$num7==25;
if($tmp3)goto L2xeWjgx2n;
goto L2xldMhx2n;
L2xeWjgx2n:
$tmp="创建数据表错误: " . $conn->error;
echo $tmp;
goto L2xx2m;
L2xldMhx2n:
$tmp=48;
$tmp2=55;
$tmp3=$num7==55;
if($tmp3)goto L2xx2m;
L2xx2m:
$tmp="INSERT INTO " . $bdm;
$tmp2=$tmp . " (couser,coimg,coname,courl,cotext,bcouser,bconame,comaud,cotime,ip,wzcid,ecid)
VALUES ('";
$tmp3=$tmp2 . $adminame;
$tmp4=$tmp3 . "','./assets/img/tx.png','LAN','','嗨,这是一条由系统生成的评论,当您看到这句话代表您的程序《LAN》已经安装成功,即刻开启您的优雅之旅!','false','false','1','";
$tmp5=$tmp4 . $sj;
$tmp6=$tmp5 . "','";
$tmp7=$tmp6 . $ip;
$tmp8=$tmp7 . "','";
$tmp9=$tmp8 . $str;
$tmp10=$tmp9 . "','";
$tmp11=$tmp10 . $str;
$sql=$tmp11 . "')";
$num8=4917;
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp){
    $num8=51;
}else{
    $num8=51;
    $num8=5067;
}
$tmp=260;
$tmp2=2559;
$tmp3=$num8==2559;
if($tmp3){
$tmp="Error: " . $sql;
$tmp2=$tmp . "<br>";
$tmp3=$tmp2 . $conn->error;
echo $tmp3;
}else{
$tmp=77;
$tmp2=51;
$tmp3=$num8==51;
}
$tmp=77;
$tmp2=51;
$tmp3=$num8==51;
if(!($tmp3)){
}else{
    $lxx=7;
    $numx=64;
    $gsx=1;
    $tmp=False;
}
$tmp=False;
$tmp=False;
$tmp=False;
$tmp=False;
$tmp=False;
$tmp=True;
$tmp=30;
$tmp2=1393;
$tmp3=False;
$tmp=2;
$tmp2=272;
$tmp3=False;
$tmp=196;
$tmp2=51;
$tmp3=False;
$tmp=33;
$tmp2=9;
$tmp3=False;
$tmp=80;
$tmp2=187;
$tmp3=False;
$tmp=70;
$tmp2=48;
$tmp3=False;
$tmp=190;
$tmp2=80;
$tmp3=False;
$tmp=160;
$tmp2=1968;
$tmp3=False;
goto L2xldMhx3b;
echo '{"201":"错误的类型"}';
goto L2xx33;
L2xldMhx3b:
L2xx33:
$xx=1;
while(true){
    $tmp=$xx<=1;
    if(!($tmp))break;
    $length=strlen($strPolx);
    $maxx=$length-1;
    $str=0;
    $i=$str;
    while(true){
        $tmp=$i<64;
        if(!($tmp))break;
        $rand=rand($maxx);
        $strx=$strx . $strPolx[$rand];
        $val6=$strx;
        $obj3=$i;
        $obj4=$i+1;
        $str=$obj4;
        $i=$str;
    }
    $strx=$strx;
    $obj4=$xx;
    $xx=$xx+1;
}
L2xx3s:
$bdm="user";
$tmp="CREATE TABLE " . $bdm;
$tmp2=$tmp . " (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
username TEXT NOT NULL COMMENT '账号',
password TEXT NOT NULL COMMENT '密码',
email TEXT NOT NULL COMMENT '邮箱',
wallet TEXT NOT NULL COMMENT '余额',
ussig TEXT NOT NULL COMMENT '签到日期',
name TEXT NOT NULL COMMENT '昵称',
img TEXT NOT NULL COMMENT '头像',
url TEXT NOT NULL COMMENT '网址',
homeimg TEXT NOT NULL COMMENT '主页背景图(-1则不设置)',
sign TEXT NOT NULL COMMENT '签名(不设置则为空)',
essqx TEXT NOT NULL COMMENT '是否拥有发布权限(0=否 1=是)',
esseam TEXT NOT NULL COMMENT '收到消息是否发送邮件通知(0=否 1=是)',
regtime TEXT NOT NULL COMMENT '注册时间',
regip TEXT NOT NULL COMMENT '注册ip',
logtime TEXT NOT NULL COMMENT '最后登录时间',
logip TEXT NOT NULL COMMENT '最后登录ip',
ban TEXT NOT NULL COMMENT '账号是否被封禁(0=正常 -1=封禁)',
bantime TEXT NOT NULL COMMENT '账号解封时间(true=永久封禁，否则填写解封日期)',
passid TEXT NOT NULL COMMENT '账号唯一id标识'
)";
$sql=$tmp2;
$num9=4923;
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp){
    $num9=176;
}else{
    $num9=55;
}
$tmp=38;
$tmp2=55;
$tmp3=$num9==55;
if($tmp3)goto L2xeWjgx42;
goto L2xldMhx42;
L2xeWjgx42:
$tmp="创建数据表错误: " . $conn->error;
echo $tmp;
goto L2xx41;
L2xldMhx42:
$tmp=220;
$tmp2=176;
$tmp3=$num9==176;
if($tmp3)goto L2xx41;
L2xx41:
$length=md5("123456");
$yhmia=$length;
$mrmzs="用户" . $adminame;
$tmp="INSERT INTO " . $bdm;
$tmp2=$tmp . " (username,password,email,wallet,ussig,name,img,url,homeimg,sign,essqx,esseam,regtime,regip,logtime,logip,ban,bantime,passid)
VALUES ('";
$tmp3=$tmp2 . $adminame;
$tmp4=$tmp3 . "','";
$tmp5=$tmp4 . $yhmia;
$tmp6=$tmp5 . "','','0','','";
$tmp7=$tmp6 . $mrmzs;
$tmp8=$tmp7 . "','./assets/img/tx.png','','-1','LAN - 更简洁，更优雅','1','1','";
$tmp9=$tmp8 . $sj;
$tmp10=$tmp9 . "','";
$tmp11=$tmp10 . $ip;
$tmp12=$tmp11 . "','";
$tmp13=$tmp12 . $sj;
$tmp14=$tmp13 . "','";
$tmp15=$tmp14 . $ip;
$tmp16=$tmp15 . "','0','false','";
$tmp17=$tmp16 . $strx;
$sql=$tmp17 . "')";
$num10=4924;
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp){
    $num10=80;
}else{
    $num10=15;
}
$tmp=150;
$tmp2=15;
$tmp3=$num10==15;
if($tmp3)goto L2xeWjgx47;
goto L2xldMhx47;
L2xeWjgx47:
$tmp="Error: " . $sql;
$tmp2=$tmp . "<br>";
$tmp3=$tmp2 . $conn->error;
echo $tmp3;
goto L2xx46;
L2xldMhx47:
$tmp=380;
$tmp2=80;
$tmp3=$num10==80;
if($tmp3)goto L2xx46;
L2xx46:
$bdm="message";
$tmp="CREATE TABLE " . $bdm;
$tmp2=$tmp . " (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
fuser TEXT NOT NULL COMMENT '发送者账号',
fimg TEXT NOT NULL COMMENT '发送者头像',
fname TEXT NOT NULL COMMENT '发送者昵称',
suser TEXT NOT NULL COMMENT '接收者账号',
title TEXT NOT NULL COMMENT '消息标题',
text TEXT NOT NULL COMMENT '消息内容',
ftime TEXT NOT NULL COMMENT '发送时间',
msg TEXT NOT NULL COMMENT '消息状态 0=未读 1=已读 -1=已删除'
)";
$sql=$tmp2;
$num11=4932;
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp){
    $num11=33;
}else{
    $num11=25;
}
$tmp=48;
$tmp2=33;
$tmp3=$num11==33;
if($tmp3)goto L2xx4b;
switch($num11){
    case 25:{
    $tmp="创建数据表错误: " . $conn->error;
    echo $tmp;
        break;
    }
}
L2xx4b:
$bdm="lcke";
$tmp="CREATE TABLE " . $bdm;
$tmp2=$tmp . " (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
luser TEXT NOT NULL COMMENT '点赞者账号',
lname TEXT NOT NULL COMMENT '点赞者昵称',
limg TEXT NOT NULL COMMENT '点赞者头像',
lwz TEXT NOT NULL COMMENT '点赞所属文章',
ltime TEXT NOT NULL COMMENT '点赞时间'
)";
$sql=$tmp2;
$num12=4930;
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp){
    $num12=9;
}else{
    $num12=176;
}
$tmp=72;
$tmp2=176;
$tmp3=$num12==176;
if($tmp3)goto L2xeWjgx4h;
goto L2xldMhx4h;
L2xeWjgx4h:
$tmp="创建数据表错误: " . $conn->error;
echo $tmp;
goto L2xx4g;
L2xldMhx4h:
$tmp=80;
$tmp2=9;
$tmp3=$num12==9;
if($tmp3)goto L2xx4g;
L2xx4g:
$bdm="configx";
$tmp="CREATE TABLE " . $bdm;
$tmp2=$tmp . " (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
title TEXT NOT NULL COMMENT '配置名称',
text TEXT NOT NULL COMMENT '配置信息'
)";
$sql=$tmp2;
$num13=4913;
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp){
    $num13=121;
}else{
    $num13=272;
}
$tmp=108;
$tmp2=272;
$tmp3=$num13==272;
if($tmp3)goto L2xeWjgx4m;
goto L2xldMhx4m;
L2xeWjgx4m:
$tmp="创建数据表错误: " . $conn->error;
echo $tmp;
goto L2xx4l;
L2xldMhx4m:
$tmp=22;
$tmp2=121;
$tmp3=$num13==121;
if($tmp3)goto L2xx4l;
L2xx4l:
$bdm="link";
$tmp="CREATE TABLE " . $bdm;
$tmp2=$tmp . " (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
url TEXT NOT NULL COMMENT '友链地址',
urls TEXT NOT NULL COMMENT '友链说明',
urlimg TEXT NOT NULL COMMENT '友链图标'
)";
$sql=$tmp2;
$num14=4925;
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp){
    $num14=25;
}else{
    $num14=51;
}
switch($num14){
    case 51:{
    $tmp="创建数据表错误: " . $conn->error;
    echo $tmp;
        break;
    }
    case 25:{
        echo "安装成功,为了你的安全请手动删除install文件夹";
        $length=fopen("ins.bak", "w");
        $myfile=$length;
        $filename='../config.php';
        $tmp='
        $servername = "' . $servername;
        $tmp2=$tmp . '";//数据库地址
        $username = "';
        $tmp3=25 . $username;
        $tmp4=$tmp3 . '";//数据库账号
        $password = "';
        $tmp5=$tmp4 . $password;
        $tmp6=$tmp5 . '";//数据库密码
        $dbname = "';
        $tmp7=$tmp6 . $dbname;
        $tmp8=$tmp7 . '";//数据库名
        ';
        $word=$tmp8;
        $length=fopen($filename, "w");
        $fh=$length;
        $length=fwrite($fh, $word);
        $length=fclose($fh);
        break;
    }
}
$result=$conn->close();