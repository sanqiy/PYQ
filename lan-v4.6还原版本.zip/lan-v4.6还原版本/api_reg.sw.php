<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$num7=6867;
$isArray=is_array($_POST);
if($isArray){
    $num7=209;
}else{
    $num7=45;
}
switch($num7){
    case 45:{
    $allkey=$_POST['zh'];
        break;
    }
    case 209:{
        $allkey=&$_POST['zh'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped2=addslashes($escaped);
$zh=$escaped2;
$num8=6874;
$isArray=is_array($_POST);
if($isArray){
    $num8=57;
}else{
    $num8=225;
}
switch($num8){
    case 57:{
    $allkey=&$_POST['em'];
        break;
    }
    case 225:{
        $allkey=$_POST['em'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped2=addslashes($escaped);
$em=$escaped2;
$num9=6864;
$isArray=is_array($_POST);
if($isArray){
    $num9=209;
}else{
    $num9=45;
}
switch($num9){
    case 209:{
    $allkey=&$_POST['mm'];
        break;
    }
    case 45:{
        $allkey=$_POST['mm'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped2=addslashes($escaped);
$mm=$escaped2;
$num10=6873;
$isArray=is_array($_POST);
if($isArray){
    $num10=225;
}else{
    $num10=361;
}
switch($num10){
    case 225:{
    $allkey=&$_POST['yzm'];
        break;
    }
    case 361:{
        $allkey=$_POST['yzm'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped2=addslashes($escaped);
$yzm=$escaped2;
$num3=6862;
$isArray=is_array($_POST);
if($isArray){
    $num3=57;
}else{
    $num3=45;
}
switch($num3){
    case 57:{
    $allkey=&$_POST['fsyzm'];
        break;
    }
    case 45:{
        $allkey=$_POST['fsyzm'];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped2=addslashes($escaped);
$fsyzm=$escaped2;
if($fsyzm!="1")goto L2xeWjgx1a;
goto L2xldMhx1a;
L2xeWjgx1a:
$tmp=$zh=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$em=="";
    $tmp2=(bool)$tmp4;
}
$tmp5=(bool)$tmp2;
$tmp6=!$tmp5;
if($tmp6){
    $tmp7=$mm=="";
    $tmp5=(bool)$tmp7;
}
if($tmp5)goto L2xeWjgx12;
goto L2xldMhx12;
goto L2xldMhx12;
L2xeWjgx12:
exit("参数不完整");
goto L2xx19;
L2xldMhx12:
$checkmail="/\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/";
$env=preg_match($checkmail, $em);
if($env)goto L2xx13;
goto L2xldMhx14;
L2xldMhx14:
exit("电子邮箱格式不正确");
L2xx13:
$env=strlen($zh);
$tmp=$env<5;
if($tmp){
    exit("账号不可低于5位数");
}
$env=strlen($mm);
$tmp=$env<3;
if($tmp)goto L2xeWjgx18;
goto L2xx19;
goto L2xx19;
L2xeWjgx18:
exit("密码不可低于3位数");
goto L2xx19;
L2xldMhx1a:
L2xx19:
$str="Y";
$Y=$str;
$str="m";
$m=$str;
$str="d";
$d=$str;
$str="H";
$H=$str;
$str="i";
$i=$str;
$str="s";
$s=$str;
$str2=$Y . "-";
$val3=$str2 . $m;
$str3=$val3 . "-";
$val4=$str3 . $d;
$str4=$val4 . " ";
$val5=$str4 . $H;
$str5=$val5 . ":";
$val6=$str5 . $i;
$str6=$val6 . ":";
$val7=$str6 . $s;
$env=date($val7);
$sj=$env;
$num4=6877;
if($HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"]){
    $num4=165;
}else{
    if($HTTP_SERVER_VARS["HTTP_CLIENT_IP"]){
        $num4=45;
    }else{
        if($HTTP_SERVER_VARS["REMOTE_ADDR"]){
            $num4=9;
        }else{
            $env=getenv("HTTP_X_FORWARDED_FOR");
            if($env){
                $num4=285;
            }else{
                $env=getenv("HTTP_CLIENT_IP");
                if($env){
                    $num4=57;
                }else{
                    $env=getenv("REMOTE_ADDR");
                    if($env){
                        $num4=45;
                        $num4=727;
                    }else{
                        $num4=33;
                    }
                }
            }
        }
    }
}
switch($num4){
    case 33:{
    $ip="Unknown";
        break;
    }
    case 386:{
        $env=getenv("REMOTE_ADDR");
        $ip=$env;
        break;
    }
    case 57:{
            $env=getenv("HTTP_CLIENT_IP");
            $ip=$env;
        break;
    }
    case 9:{
                $ip=$HTTP_SERVER_VARS["REMOTE_ADDR"];
        break;
    }
    case 165:{
                    $ip=$HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"];
        break;
    }
    case 45:{
                        $ip=$HTTP_SERVER_VARS["HTTP_CLIENT_IP"];
        break;
    }
    case 285:{
                            $env=getenv("HTTP_X_FORWARDED_FOR");
                            $ip=$env;
        break;
    }
}
$num5=6867;
$isArray=is_array($_POST);
if($isArray){
    $num5=9;
}else{
    $num5=33;
}
switch($num5){
    case 33:{
    $allkey=$_POST["allkey"];
        break;
    }
    case 9:{
        $allkey=&$_POST["allkey"];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped2=addslashes($escaped);
$allkey=$escaped2;
if($allkey==""){
    exit('请传入秘钥');
}
$env=session_start();
$cloudallkey=$_SESSION['allkey'];
$serverVal=$_SERVER['HTTP_HOST'] . "aI4cG0nO3kT5mQ4mL4qL7eP6sL2oS5rS";
$escaped=md5($serverVal);
$hash=md5($escaped);
$appintkey=$hash;
if($allkey!=$cloudallkey){
$tmp=$allkey==$appintkey;
if(!($tmp)){
    exit('秘钥错误');
}
L2xldMhx2h:
}else{
    $tmp=include '../config.php';
    $tmp=new mysqli($servername,$username,$password,$dbname);
    $conn=$tmp;
    if($conn->connect_error){
        die("连接失败: " . $conn->connect_error);
    }
    $sql="select * from admin where regqx='-1'";
    $result=$conn->query($sql);
    $result=$result;
    $env=mysqli_fetch_array($result);
    $row=$env;
    if($row){
        exit("管理员未开启用户注册!");
    }
    $sql="SELECT * FROM admin";
    $result=$conn->query($sql);
    $result=$result;
}
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($str))break;
    $wzname=$row["name"];
    $emydz=$row["emydz"];
    $emssl=$row["emssl"];
    $emduk=$row["emduk"];
    $emkey=$row["emkey"];
    $emzh=$row["emzh"];
    $emfs=$row["emfs"];
    $emfszm=$row["emfszm"];
    $glyusername=$row["username"];
}
L2xx2w:
$sql="select * from admin where regverify='1'";
$result=$conn->query($sql);
$result=$result;
$env=mysqli_fetch_array($result);
$row=$env;
if($row)goto L2xeWjgx3u;
goto L2xldMhx3u;
L2xeWjgx3u:
$env=session_start();
$tmp=$fsyzm=="1";
if($tmp)goto L2xeWjgx32;
goto L2xldMhx32;
goto L2xldMhx32;
L2xeWjgx32:
$tmp=$emydz=="";
$tmp2=(bool)$tmp;
$tmp8=!$tmp2;
if($tmp8){
    $tmp4=$emssl=="";
    $tmp2=(bool)$tmp4;
}
$tmp5=(bool)$tmp2;
$tmp9=!$tmp5;
if($tmp9){
    $tmp7=$emduk=="";
    $tmp5=(bool)$tmp7;
}
$tmp3=(bool)$tmp5;
$tmp10=!$tmp3;
if($tmp10){
    $tmp6=$emkey=="";
    $tmp3=(bool)$tmp6;
}
$tmp11=(bool)$tmp3;
$tmp12=!$tmp11;
if($tmp12){
    $tmp13=$emzh=="";
    $tmp11=(bool)$tmp13;
}
$tmp14=(bool)$tmp11;
$tmp15=!$tmp14;
if($tmp15){
    $tmp16=$emfs=="";
    $tmp14=(bool)$tmp16;
}
$tmp17=(bool)$tmp14;
$tmp18=!$tmp17;
if($tmp18){
    $tmp19=$emfszm=="";
    $tmp17=(bool)$tmp19;
}
if($tmp17){
    exit("请管理员先配置邮箱信息");
}
if(isset($_SESSION['regyz']))goto L2xeWjgx3i;
goto L2xldMhx3i;
goto L2xldMhx3i;
L2xeWjgx3i:
$regyzTime=$_SESSION['regyz_time'];
$env=time();
$currentTime=$env;
$tmp=$currentTime-$regyzTime;
$tmp4=$tmp>60;
if($tmp4)goto L2xeWjgx3k;
goto L2xldMhx3k;
goto L2xldMhx3k;
L2xeWjgx3k:
$env=generateRandomCode();
$randomCode=$env;
$str=$randomCode;
$_SESSION['regyz']=$str;
$str=$currentTime;
$_SESSION['regyz_time']=$str;
$mailapfs='nopost';
$xiangym='ok';
$tmp='[' . $wzname;
$tmp4=$tmp . ']';
$mailtitle=$tmp4 . '账号注册验证码';
$tmp='您正在网站：【' . $wzname;
$title=$tmp . '】申请账号注册，验证码60秒内有效，您的验证码是：';
$text=$randomCode;
$mailbox=$em;
$tmp=include "./sendmail.php";
goto L2xx3h;
L2xldMhx3k:
$tmp=$currentTime-$regyzTime;
$secondsToWait=60-$tmp;
$tmp="请等待" . $secondsToWait;
exit($tmp . "秒后再试");
L2xldMhx3i:
$env=generateRandomCode();
$randomCode=$env;
$str=$randomCode;
$_SESSION['regyz']=$str;
$env=time();
$str=$env;
$_SESSION['regyz_time']=$str;
$mailapfs='nopost';
$xiangym='ok';
$tmp='[' . $wzname;
$tmp4=$tmp . ']';
$mailtitle=$tmp4 . '账号注册验证码';
$tmp='您正在网站：【' . $wzname;
$title=$tmp . '】申请账号注册，验证码60秒内有效，您的验证码是：';
$text=$randomCode;
$mailbox=$em;
$tmp=include "./sendmail.php";
L2xx3h:
exit();
goto L2xx31;
L2xldMhx32:
L2xx31:
$tmp=$yzm=="";
if($tmp){
    exit("请输入验证码");
}
$tmp=!isset($_SESSION['regyz']);
if($tmp){
    exit("请先发送验证码");
}else{
    $env=time();
    $currentTime=$env;
    $regyzTime=$_SESSION['regyz_time'];
    $timeDifference=$currentTime-$regyzTime;
    $tmp=$timeDifference>60;
    if($tmp){
        unset($_SESSION['regyz']);
        unset($_SESSION['regyz_time']);
        exit("请先发送验证码");
    }
}
$tmp=$yzm!=$_SESSION['regyz'];
if($tmp)goto L2xeWjgx3s;
goto L2xx3t;
goto L2xx3t;
L2xeWjgx3s:
exit("验证码错误");
goto L2xx3t;
L2xldMhx3u:
L2xx3t:
$env=strpos($zh, 'vis#-[');
$tmp=$env!==false;
$tmp2=(bool)$tmp;
$tmp7=!$tmp2;
if($tmp7){
    $hash=strpos($zh, ']-#vis');
    $tmp4=$hash!==false;
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit("该字符禁止注册!");
}
$tmp="select * from user where email = '" . $em;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
$env=mysqli_num_rows($result);
$tmp=$env>0;
if($tmp){
    exit("该邮箱已被注册!");
}
$tmp="select * from user where username = '" . $zh;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
$env=mysqli_num_rows($result);
$tmp=$env>0;
if($tmp){
    exit("账号已存在!");
}
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($str))break;
    $ipregx=$row["ipregx"];
}
L2xx57:
$num6=6878;
$isArray=is_array($_POST);
if($isArray){
    $num6=33;
}else{
    $num6=45;
}
switch($num6){
    case 33:{
    $allkey=&$_POST["allkey"];
        break;
    }
    case 45:{
        $allkey=$_POST["allkey"];
        break;
    }
}
$escaped=htmlspecialchars($allkey);
unset($allkey);
$escaped2=addslashes($escaped);
$allkey=$escaped2;
$serverVal=$_SERVER['HTTP_HOST'] . "wQ7gA5kQ0lK9nX4lU9aQ4rC8fS0hY3lY";
$escaped=md5($serverVal);
$hash=md5($escaped);
$appintkey=$hash;
if($allkey!=$appintkey)goto L2xeWjgx5l;
goto L2xldMhx5l;
L2xeWjgx5l:
$tmp="SELECT COUNT(*) AS num FROM user WHERE regip = '" . $ip;
$sql=$tmp . "'";
$env=mysqli_query($conn, $sql);
$result=$env;
if($result)goto L2xeWjgx5h;
goto L2xldMhx5h;
goto L2xldMhx5h;
L2xeWjgx5h:
$env=mysqli_fetch_assoc($result);
$row=$env;
$tmp=$row['num']>$ipregx;
if($tmp)goto L2xeWjgx5j;
goto L2xx5k;
goto L2xx5k;
L2xeWjgx5j:
exit("此IP注册数量已达上限");
goto L2xx5k;
L2xldMhx5h:
exit("获取数据失败");
L2xldMhx5l:
L2xx5k:
$lx=7;
$num=64;
$gs=1;
$tmp=False;
$tmp=False;
$tmp=False;
$tmp=False;
$tmp=False;
$tmp=False;
$tmp=True;
$tmp=44;
$tmp4=2488;
$tmp2=False;
$tmp=90;
$tmp4=6308;
$tmp2=False;
$tmp=24;
$tmp4=209;
$tmp2=False;
$tmp=192;
$tmp4=57;
$tmp2=False;
$tmp=210;
$tmp4=9;
$tmp2=False;
$tmp=80;
$tmp4=33;
$tmp2=False;
$tmp=40;
$tmp4=361;
$tmp2=False;
$tmp=56;
$tmp4=4062;
$tmp2=False;
goto L2xldMhx67;
echo '{"201":"错误的类型"}';
goto L2xx5y;
L2xldMhx67:
L2xx5y:
$x=1;
while(true){
    $tmp=$x<=1;
    if(!($tmp))break;
    $env=strlen($strPol);
    $max=$env-1;
    $str=0;
    $i=$str;
    while(true){
        $tmp=$i<64;
        if(!($tmp))break;
        $escaped=rand($max);
        $str=$str . $strPol[$escaped];
        $val8=$str;
        $obj=$i;
        $obj2=$i+1;
        $str=$obj2;
        $i=$str;
    }
    $str=$str;
    $obj2=$x;
    $obj3=$x+1;
    $str=$obj3;
    $x=$str;
}
L2xx6o:
$bdm="user";
$env=md5($mm);
$yhmia=$env;
$mrmzs="用户" . $zh;
$tmp="INSERT INTO " . $bdm;
$tmp4=$tmp . " (username,password,email,wallet,ussig,name,img,url,homeimg,sign,essqx,esseam,regtime,regip,logtime,logip,ban,bantime,passid)
VALUES ('";
$tmp2=$tmp4 . $zh;
$tmp7=$tmp2 . "','";
$tmp5=$tmp7 . $yhmia;
$tmp6=$tmp5 . "','";
$tmp3=$tmp6 . $em;
$tmp13=$tmp3 . "','0','','";
$tmp11=$tmp13 . $mrmzs;
$tmp16=$tmp11 . "','./assets/img/tx.png','','-1','这里什么都没有哦!','1','1','";
$tmp14=$tmp16 . $sj;
$tmp19=$tmp14 . "','";
$tmp17=$tmp19 . $ip;
$tmp18=$tmp17 . "','";
$tmp15=$tmp18 . $sj;
$tmp12=$tmp15 . "','";
$tmp10=$tmp12 . $ip;
$tmp9=$tmp10 . "','0','false','";
$tmp8=$tmp9 . $str;
$sql=$tmp8 . "')";
$num=6865;
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp){
    $num=285;
}else{
    $num=45;
}
switch($num){
    case 45:{
    $tmp="Error: " . $sql;
    $tmp4=$tmp . "<br>";
    $tmp2=$tmp4 . $conn->error;
    echo $tmp2;
        break;
    }
    case 285:{
        echo "账号注册成功!";
        unset($_SESSION['regyz']);
        unset($_SESSION['regyz_time']);
        $env=generateRandomString($length);
        $allkey=$env;
        $str=$allkey;
        $_SESSION['allkey']=$str;
        break;
    }
}
$result=$conn->close();
unset($val9);function generateRandomString($length) {
    $characters='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString='';
    $i=0;
    while(true){
        $tmp=$i<$length;
        if(!($tmp))break;
        $length=strlen($characters);
        $serverVal=$length-1;
        $rand=rand($serverVal);
        $randomString=$randomString . $characters[$rand];
        $val10=$randomString;
        $obj3=$i;
        $obj4=$i+1;
        $str=$obj4;
        $i=$str;
    }
    return $randomString;
}function generateRandomCode($length) {
    $characters='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $code='';
    $isAlphaNumeric=False;
    $i=0;
    while(true){
        $tmp=$i<$length;
        if(!($tmp))break;
        $num2=5846;
        if($isAlphaNumeric){
            $num2=55;
        }else{
            $num2=55;
            $num2=7579;
        }
        switch($num2){
            case 3817:{
            $escaped=rand();
            $code=$code . $characters[$escaped];
            $val8=$code;
            $isAlphaNumeric=True;
                break;
            }
            case 55:{
                $escaped=rand();
                $code=$code . $characters[$escaped];
                $val8=$code;
                $isAlphaNumeric=False;
                break;
            }
        }
        $obj4=$i;
        $obj5=$i+1;
        $str=$obj5;
        $i=$str;
    }
    return $code;
}