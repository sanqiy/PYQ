<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$num4=6873;
$isArray=is_array($_POST);
if($isArray){
    $num4=361;
}else{
    $num4=95;
}
switch($num4){
    case 95:{
    $zh=$_POST['zh'];
        break;
    }
    case 361:{
        $zh=&$_POST['zh'];
        break;
    }
}
$escaped=htmlspecialchars($zh);
unset($zh);
$escaped2=addslashes($escaped);
$zh=$escaped2;
$num5=6871;
$isArray=is_array($_POST);
if($isArray){
    $num5=38;
}else{
    $num5=190;
}
switch($num5){
    case 38:{
    $zh=&$_POST['mm'];
        break;
    }
    case 190:{
        $zh=$_POST['mm'];
        break;
    }
}
$escaped=htmlspecialchars($zh);
unset($zh);
$escaped2=addslashes($escaped);
$mm=$escaped2;
if($zh==""){
    exit("请输入账号");
}
if($mm==""){
    exit("请输入密码");
}
$env=strlen($zh);
$tmp=$env<5;
if($tmp){
    exit("账号不可低于5位数");
}
$env=strlen($mm);
$tmp=$env<3;
if($tmp){
    exit("密码不可低于3位数？");
}
$str="Y";
$Y=$str;
$str="m";
$m=$str;
$str="d";
$d=$str;
$str="H";
$H=$str;
$str="i";
$i=$str;
$str="s";
$s=$str;
$str2=$Y . "-";
$val3=$str2 . $m;
$str3=$val3 . "-";
$val4=$str3 . $d;
$str4=$val4 . " ";
$val5=$str4 . $H;
$str5=$val5 . ":";
$val6=$str5 . $i;
$str6=$val6 . ":";
$val7=$str6 . $s;
$env=date($val7);
$sj=$env;
$num=6859;
if($HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"]){
    $num=152;
}else{
    if($HTTP_SERVER_VARS["HTTP_CLIENT_IP"]){
        $num=20;
    }else{
        if($HTTP_SERVER_VARS["REMOTE_ADDR"]){
            $num=190;
        }else{
            $env=getenv("HTTP_X_FORWARDED_FOR");
            if($env){
                $num=152;
                $num=4026;
            }else{
                $env=getenv("HTTP_CLIENT_IP");
                if($env){
                    $num=190;
                    $num=10718;
                }else{
                    $env=getenv("REMOTE_ADDR");
                    if($env){
                        $num=80;
                    }else{
                        $num=80;
                        $num=10690;
                    }
                }
            }
        }
    }
}
switch($num){
    case 2089:{
    $env=getenv("HTTP_X_FORWARDED_FOR");
    $ip=$env;
        break;
    }
    case 190:{
        $ip=$HTTP_SERVER_VARS["REMOTE_ADDR"];
        break;
    }
    case 20:{
            $ip=$HTTP_SERVER_VARS["HTTP_CLIENT_IP"];
        break;
    }
    case 152:{
                $ip=$HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"];
        break;
    }
    case 5454:{
                    $env=getenv("HTTP_CLIENT_IP");
                    $ip=$env;
        break;
    }
    case 80:{
                        $env=getenv("REMOTE_ADDR");
                        $ip=$env;
        break;
    }
    case 5385:{
                            $ip="Unknown";
        break;
    }
}
$tmp=include '../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    exit("连接数据库失败");
}
$tmp="select * from user where username = '" . $zh;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
$num2=6862;
$env=mysqli_num_rows($result);
$tmp=$env>0;
if($tmp){
    $num2=95;
}else{
    $num2=40;
}
$tmp=140;
$tmp2=95;
$tmp3=$num2==95;
if($tmp3)goto L2xx1h;
switch($num2){
    case 40:{
    exit("账号不存在!");
        break;
    }
}
L2xx1h:
$env=md5($mm);
$mm=$env;
$tmp="select * from user where username= '" . $zh;
$tmp2=$tmp . "' and password='";
$tmp3=$tmp2 . $mm;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$result=$result;
$env=mysqli_fetch_array($result);
$row=$env;
$num3=6864;
if($row){
    $num3=40;
}else{
    $num3=20;
}
$tmp=25;
$tmp2=40;
$tmp3=$num3==40;
if($tmp3)goto L2xeWjgx1x;
goto L2xldMhx1x;
L2xeWjgx1x:
$username=$row['username'];
$email=$row['email'];
$name=$row['name'];
$img=$row['img'];
$url=$row['url'];
$passid=$row['passid'];
$zzid=$row['id'];
$tmp=$row['ban']=='-1';
if($tmp)goto L2xeWjgx1n;
goto L2xldMhx1n;
goto L2xldMhx1n;
L2xeWjgx1n:
$tmp=$row['bantime']!="true";
if($tmp)goto L2xeWjgx1p;
goto L2xldMhx1p;
goto L2xldMhx1p;
L2xeWjgx1p:
$str2='Y' . 'm';
$val3=$str2 . 'd';
$str3=$val3 . 'H';
$val4=$str3 . 'i';
$env=date($val4);
$dqsj=$env;
$fwsji=$row['bantime'];
$env=str_ireplace('-', '', $fwsji);
$fwsjio=$env;
$env=str_ireplace(':', '', $fwsjio);
$fwsjop=$env;
$env=str_ireplace(' ', '', $fwsjop);
$fwsj=$env;
$tmp=$dqsj>$fwsj;
if($tmp)goto L2xeWjgx1r;
goto L2xldMhx1r;
goto L2xldMhx1r;
L2xeWjgx1r:
$bdm="user";
$tmp="UPDATE " . $bdm;
$tmp2=$tmp . " SET ban='0',bantime='false' WHERE id='";
$tmp3=$tmp2 . $zzid;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xx1q;
goto L2xldMhx1t;
L2xldMhx1t:
$env=mysql_errno();
echo $env;
L2xldMhx1r:
L2xx1q:
die('你的账号已被封禁！解封时间为:' . $fwsji);
goto L2xx1m;
L2xldMhx1p:
die('该账号涉嫌违规,已被永久封禁!');
L2xldMhx1n:
L2xx1m:
$bdm="user";
$tmp="UPDATE " . $bdm;
$tmp2=$tmp . " SET logtime='";
$tmp3=$tmp2 . $sj;
$tmp4=$tmp3 . "',logip='";
$tmp5=$tmp4 . $ip;
$tmp6=$tmp5 . "' WHERE id='";
$tmp7=$tmp6 . $zzid;
$sql=$tmp7 . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xx1u;
goto L2xldMhx1v;
L2xldMhx1v:
exit("时间错误!");
L2xx1u:
$escaped=time();
$str2=$escaped+604800;
$cookieResult=setcookie("username", $username, $str2, "/");
$escaped=time();
$str2=$escaped+604800;
$cookieResult=setcookie("passid", $passid, $str2, "/");
echo '登录成功!';
goto L2xx1w;
L2xldMhx1x:
switch($num3){
    case 20:{
    echo '密码错误！';
        break;
    }
}
L2xx1w:
$result=$conn->close();