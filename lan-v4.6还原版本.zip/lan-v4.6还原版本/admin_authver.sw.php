<?php
$num=5843;
$isArray=is_array($_GET);
if($isArray){
    $num=126;
}else{
    $num=21;
}
switch($num){
    case 21:{
    $condition=$_GET['condition'];
        break;
    }
    case 126:{
        $condition=&$_GET['condition'];
        break;
    }
}
$escaped=htmlspecialchars($condition);
unset($condition);
$escaped2=addslashes($escaped);
$condition=$escaped2;
if($condition!="error"){
    exit('<script language="JavaScript">;alert("非法请求!");location.href="../index.php";;</script>');
}
echo "<!doctype html>";
echo "
<html lang=\"en\">";
echo "
<head>";
echo "
<meta charset=\"utf-8\">";
echo "
<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0\">";
echo "
<title>授权验证失败!</title>";
echo "
<meta name=\"author\" content=\"LAN\">";
echo "
<link rel=\"stylesheet\" href=\"assets/css/css2.css\">";
echo "
<link rel=\"stylesheet\" id=\"css-main\" href=\"assets/css/oneui.min.css\">";
echo "
<style>";
echo "
#main-container {";
echo "
align-items: center;";
echo "
justify-content: center;";
echo "
}";
echo "
</style>";
echo "
</head>";
echo "
<body>";
echo "
<div id=\"page-container\">";
echo "
";
echo "
<!-- Main Container -->";
echo "
<main id=\"main-container\">";
echo "
<!-- Page Content -->";
echo "
<div class=\"col-lg-6\">";
echo "
<!-- Bold -->";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\" style=\"color: #ff0000;\">授权验证失败</h3>";
echo "
</div>";
echo "
<div class=\"block-content\">";
echo "
<h1 style=\"color: #ff0000;\">授权错误!</h1>";
echo "
<p class=\"lead\">您的域名：<code>";
echo $_SERVER['SERVER_NAME'];
echo "</code>&nbsp;&nbsp;授权信息验证失败,系统未获取到您的授权信息,请稍后再试!</p>";
echo "
<hr class=\"my-4\">";
echo "
<p>系统未获取到您的授权信息,可能有以下原因:<br>1.网络问题,未成功连接到授权服务器。<br>2.授权服务器故障,请过段时间再尝试。<br>3.您的授权信息被封禁,请联系作者咨询原因。<br>4.您的授权信息被删除,请联系作者咨询原因。<br>5.您尚未购买授权,请在购买后使用。<br>6.您的授权已过期,请前往授权站重新授权<br></p>";
echo "
<h5 class=\"fw-bold\"><a class=\"btn btn-primary btn-lg\" href=\"https://www.qemao.com\" target=\"_blank\" role=\"button\" style=\"margin-top: 5px;\">前往授权</a></h5>";
echo "
<h5 class=\"fw-bold\">";
echo "
<form class=\"row row-cols-lg-auto g-3 align-items-center\" action=\"../api/auth.php\" method=\"POST\" onsubmit=\"return dosubmit()\" id=\"myForm\" autocomplete=\"off\">";
echo "
<div class=\"col-12\">";
echo "
";
echo "
<input type=\"text\" class=\"form-control\" id=\"example-if-email\" name=\"aukey\" placeholder=\"授权key\" required>";
echo "
<input type=\"hidden\" class=\"form-control\" id=\"lx\" name=\"lx\" value=\"authorize\">";
echo "
</div>";
echo "
";
echo "
<div>";
echo "
<button type=\"submit\" class=\"btn btn-dark\">立即授权</button>";
echo "
</div>";
echo "
</form>";
echo "
</h5>";
echo "
<h5 class=\"fw-normal\"><small>时间：";
$dateStr=date("Y-m-d H:i:s");
echo $dateStr;
echo " | LAN</small></h5>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Bold -->";
echo "
</div>";
echo "
<!-- END Page Content -->";
echo "
</main>";
echo "
<!-- END Main Container -->";
echo "
</div>";
echo "
<script src=\"assets/js/oneui.app.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Plugins -->";
echo "
<script src=\"assets/js/chart.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Code -->";
echo "
<script src=\"assets/js/be_pages_dashboard.min.js\"></script>";
echo "
<script>";
echo "
;function dosubmit() {
    ";echo "
    event.preventDefault();

    ";echo "

    var form = document.getElementById('myForm');
    ";echo "
    ";echo "

    var xhr = new XMLHttpRequest();
    ";echo "
    ";echo "

    xhr.onreadystatechange = function() {  ";echo "
    if (xhr.readyState == 4 && xhr.status == 200) {  ";echo "

    var response = xhr.responseText;
    ";echo "

    if(response == \"key已保存\"){";
    echo "
    window.location = './index.php';";
    echo "
}else{";
echo "
alert(response);";
echo "
}";
echo "
}  ";
echo "
};  ";
echo "
";
echo "
// 设置表单数据为请求主体  ";
echo "
var formData = new FormData(form);  ";
echo "
";
echo "
// 初始化请求  ";
echo "
xhr.open(\"POST\", form.action, true);  ";
echo "
";
echo "
// 发送表单数据  ";
echo "
xhr.send(formData);";
echo "
";
echo "
}";echo "
</script>";echo "
</body>";echo "
</html>";echo "
";

