<?php
$iteace='adminapi';
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp=$user_zh=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$user_passid=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit('<script language="JavaScript">;alert("请先登录!");location.href="../login.php";</script>');
}
$tmp=include '../../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$currentTime=htmlspecialchars($user_zh);
$cookieResult=addslashes($currentTime);
$user_zhsg=$cookieResult;
$tmp="select * from user where username='" . $user_zhsg;
$sqls=$tmp . "'";
$curlOptResult=mysqli_query($conn, $sqls);
$data_results=$curlOptResult;
$curlOptResult=mysqli_fetch_array($data_results);
$data2s_row=$curlOptResult;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($sentinel))break;
    $glyzhuser=$row["username"];
}
L2xxf:
$str="select * from user where username='" . $user_zh;
$str2=$str . "'";
$curlOptResult=mysqli_query($conn, $str2);
$data_result=$curlOptResult;
$curlOptResult=mysqli_fetch_array($data_result);
$data2_row=$curlOptResult;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
$zid=$data2_row["id"];
$zjpassword=$data2_row["password"];
if($user_passid!=$passid){
    $currentTime=time();
    $str=$currentTime+ -1;
    $cookieResult=setcookie("username", "", $str, "/");
    $currentTime=time();
    $str=$currentTime+ -1;
    $cookieResult=setcookie("passid", "", $str, "/");
    exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="../login.php";</script>');
}
if($zjzhq!=$glyzhuser){
    exit('<script language="JavaScript">;alert("没有权限!");history.go(-1);</script>');
}
$auth_keylocation='../../api/key.php';
$auth_keyauth='../../api/auth.php';
$num=4107;
$curlOptResult=file_exists($auth_keyauth);
if($curlOptResult){
    $num=54;
}else{
    $num=48;
}
$tmp=60;
$tmp4=54;
$tmp2=$num==54;
if($tmp2)goto L2xeWjgxw;
goto L2xldMhxw;
L2xeWjgxw:
$tmp=require $auth_keyauth;
$tmp=!defined("sh_auth_state");
if($tmp){
    exit('<script language="JavaScript">;alert("授权验证失败,请确保文件完整且未篡改!");history.go(-1);</script>');
}
$tmp=sh_auth_state!="ok";
if($tmp)goto L2xeWjgxu;
goto L2xxv;
goto L2xxv;
L2xeWjgxu:
exit('<script language="JavaScript">;alert("程序未授权,您的请求已被拒绝,请授权后使用!");history.go(-1);</script>');
goto L2xxv;
L2xldMhxw:
switch($num){
    case 48:{
    exit('<script language="JavaScript">;alert("授权验证文件不存在或被篡改,请确保文件完整且未篡改!");history.go(-1);</script>');
        break;
    }
}
L2xxv:
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($sentinel))break;
    $name=$row["name"];
    $subtitle=$row["subtitle"];
    $icon=$row["icon"];
    $logo=$row["logo"];
    $zt=$row["zt"];
    $username=$row["username"];
    $glyadmin=$row["username"];
    $homimg=$row["homimg"];
    $sign=$row["sign"];
    $wzmusic=$row["music"];
    $essgs=$row["essgs"];
    $commgs=$row["commgs"];
    $lnkzt=$row["lnkzt"];
    $regqx=$row["regqx"];
    $kqsy=$row["kqsy"];
    $comaud=$row["comaud"];
    $ptpaud=$row["ptpaud"];
    $emydz=$row["emydz"];
    $emssl=$row["emssl"];
    $emduk=$row["emduk"];
    $emkey=$row["emkey"];
    $emzh=$row["emzh"];
    $emfs=$row["emfs"];
    $emfszm=$row["emfszm"];
    $copyright=$row["copyright"];
    $beian=$row["beian"];
    $topes=$row["topes"];
    $scfont=$row["scfont"];
    $viscomm=$row["viscomm"];
    $musplay=$row["musplay"];
    $date=$row["date"];
}
L2xx1b:
$tmp='<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Document</title>
</head>
<style>
html,
body {
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    background: #ecf1f3;
}
.main {
    width: 100%;
    /* height: 100%; */
    /* margin-top: 20px;
    margin-bottom: 20px; */
    /* background: #ffffff; */
    display: flex;
    justify-content: center;
    /* flex-direction: column; */
    /* align-items: center;*/
    background: #ecf1f3;
}
.main-con{
    width: 800px;
    display: flex;
    flex-direction: column;
    align-items: center;
    background: #ffffff;
    box-shadow: 0px 0px 5px 2px #f1f1f1;
    margin-top: 20px;
    margin-bottom: 20px;
}
.sh-tu {
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
}
.sh-tu-logo {
    width: 200px;
    height: 100px;
    object-fit: contain;
}
.sh-wz {
    width: 80%;
    color: #55798d;
}
.sh-wz-t {
    margin-bottom: 10px;
    margin-left: 2px;
    font-size: 15px;
}
.sh-wz-n {
    width: 100%;
    display: flex;
    min-height: 40px;
    background: #f7f7f7;
    font-size: 15px;
    border-radius: 4px;
}
.sh-wz-n-nr {
    width: 100%;
    margin: 10px;
}
.sh-wz-b {
    margin-bottom: 10px;
    margin-left: 2px;
    font-size: 15px;
    margin-top: 15px;
}
.sh-wz-b2 {
    margin-bottom: 10px;
    margin-left: 2px;
    font-size: 15px;
    margin-top: 50px;
}
a {
    text-decoration: none;
    color: #1e5494;
    text-decoration: underline;
}
</style>
<body>
<div class="main">
<div class="main-con">
<div class="sh-tu">
<!--img src="' . $logo;
$tmp4=$tmp . '" alt="" class="sh-tu-logo"-->
<p style="font-size: 22px;font-weight: bold;color: #55798d;">';
$tmp2=96 . $name;
$tmp3=$tmp2 . '</p>
</div>
<div class="sh-wz">
<div class="sh-wz-t" style="color: #55798d;">邮件主题：</div>
<div class="sh-wz-n" style="background:#f7f7f7">
<p class="sh-wz-n-nr" style="color: #000000;">系统测试邮件</p>
</div>
<div class="sh-wz-b2" style="color: #55798d;">该邮件为系统测试邮件,若您收到此邮件代表您的网站邮箱配置正确,可以正常收发邮件啦!</div>
<div style="background: #eaf2ff;width: 100%;height: 1px;margin-top: 50px;"></div>
<div style="font-size: 22px;font-weight: bold;margin-top: 20px;color: #55798d;">';
$tmp5=$tmp3 . $name;
$tmp6=$tmp5 . '</div>
<div style="margin:20px 0;color: #6a8895;min-height:4.2em;white-space: pre-wrap;">此信为系统邮件，请不要直接回复。</div>
<div style="margin-bottom: 50px;"><a href="';
$tmp7=$tmp6 . $_SERVER['REQUEST_SCHEME'];
$tmp8=$tmp7 . '://';
$tmp9=$tmp8 . $_SERVER['HTTP_HOST'];
$tmp10=$tmp9 . '" rel="noopener" target="_blank">访问网站</a>
</div>
</div>
</div>
</div>
</body>
</html>';
$shemail_dshwznr=$tmp10;
$str='[' . $name;
$str2=$str . '] 测试邮件!';
$val['emydz']=$emydz;
$val['emssl']=$emssl;
$val['emduk']=$emduk;
$val['key']=$emkey;
$val['username']=$emfs;
$val['fromuser']=$emfs;
$val['fromname']=$emfszm;
$val['title']=$str2;
$val['nr']=$shemail_dshwznr;
$val['reveuser']=$emfs;
$post_data=$val;
$tmp=$_SERVER['REQUEST_SCHEME'] . '://';
$tmp4=$tmp . $_SERVER['HTTP_HOST'];
$url=$tmp4 . '/site/email/email.php';
$data=$post_data;
$currentTime=session_id();
$str='Cookie: PHPSESSID=' . $currentTime;
$val2[]='Authorization: Basic YWRtaW46YWRtaW4xMjMuLi4=';
$val2[]=$str;
$val2[]='User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.71 Safari/537.36';
$headers=$val2;
$curlOptResult=curl_init();
$curl=$curlOptResult;
$curlOptResult=curl_setopt($curl, CURLOPT_URL, $url);
$curlOptResult=curl_setopt($curl, CURLOPT_SSL_VERIFYPEER);
$curlOptResult=curl_setopt($curl, CURLOPT_SSL_VERIFYHOST);
$num2=4100;
$isArray=is_array($_SERVER);
if($isArray){
    $num2=96;
}else{
    $num2=36;
}
switch($num2){
    case 36:{
    $serverVal=$_SERVER['HTTP_USER_AGENT'];
        break;
    }
    case 96:{
        $serverVal=&$_SERVER['HTTP_USER_AGENT'];
        break;
    }
}
$curlOptResult=curl_setopt($curl, CURLOPT_USERAGENT, $serverVal);
unset($serverVal);
$curlOptResult=curl_setopt($curl, CURLOPT_FOLLOWLOCATION);
$curlOptResult=curl_setopt($curl, CURLOPT_AUTOREFERER);
$curlOptResult=curl_setopt($curl, CURLOPT_POST);
$currentTime=http_build_query($data);
$cookieResult=curl_setopt($curl, CURLOPT_POSTFIELDS, $currentTime);
$curlOptResult=curl_setopt($curl, CURLOPT_TIMEOUT);
$curlOptResult=curl_setopt($curl, CURLOPT_HEADER);
$curlOptResult=curl_setopt($curl, CURLOPT_RETURNTRANSFER);
$curlOptResult=curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
$curlOptResult=curl_exec($curl);
$result=$curlOptResult;
$curlOptResult=curl_errno($curl);
if($curlOptResult)goto L2xx1k;
L2xx1k:
$curlOptResult=curl_close($curl);
$num3=4106;
$tmp=$result=="";
if($tmp){
    $num3=128;
}else{
    $num3=84;
}
switch($num3){
    case 84:{
    $tmp='<script language="JavaScript">;alert("' . $result;
    exit($tmp . '");history.go(-1);</script>');
        break;
    }
    case 128:{
        exit('<script language="JavaScript">;alert("未获取到数据");history.go(-1);</script>');
        break;
    }
}
$result=$conn->close();