<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val6[]=$val;
    $arr=$val6;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
if(!function_exists('classLoader')){
    $tmp=require '../site/aliyunoss/autoload.php';
}
use OSS\OssClient;
use OSS\Core\OssException;
$filteraliyun="";
$sql="SELECT text FROM configx WHERE title = 'aliyun'";
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0){
    $result=$result->fetch_assoc();
    $row=$result;
    $filteraliyun=$row['text'];
}
if($filteraliyun!=""){
    $jsonData=json_decode($filteraliyun, true);
    $array=$jsonData;
    $AccessKeyID=$array['AccessKeyID'];
    $AccessKeySecret=$array['AccessKeySecret'];
    $Bucket=$array['Bucket'];
    $Endpoint=$array['Endpoint'];
}
$num=8014;
$tmp=$AccessKeyID=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$AccessKeySecret=="";
    $tmp2=(bool)$tmp4;
}
$tmp5=(bool)$tmp2;
$tmp6=!$tmp5;
if($tmp6){
    $tmp7=$Bucket=="";
    $tmp5=(bool)$tmp7;
}
$tmp8=(bool)$tmp5;
$tmp9=!$tmp8;
if($tmp9){
    $tmp10=$Endpoint=="";
    $tmp8=(bool)$tmp10;
}
if($tmp8){
    $num=340;
}else{
    $num=36;
}
$tmp=32;
$tmp4=36;
$tmp2=$num==36;
if($tmp2)goto L2xeWjgx14;
goto L2xldMhx14;
L2xeWjgx14:
$accessKeyId=$AccessKeyID;
$accessKeySecret=$AccessKeySecret;
$bucket=$Bucket;
$endpoint=$Endpoint;
$tmp=new OssClient($accessKeyId,$accessKeySecret,$endpoint);
$ossClient=$tmp;
$localFile=$newFile;
$bucket=$Bucket;
$ossFilemu='lan' . '/';
$ossFile=$ossFilemu . $upylu;
try{$isSet=isset($GLOBALS["Ox6160"]);
if($isSet){
    $num5=$GLOBALS["Ox6160"];
    $Ox3071[40]=$num5;
    $num5=$GLOBALS["Ox5799"];
    $Ox6628[40]=$num5;
    $num5=$GLOBALS["Ox2663"];
    $Ox2567[40]=$num5;
}else{
    $num5=null;
    $Ox3071[40]=$num5;
    $num5=null;
    $Ox6628[40]=$num5;
    $num5=null;
    $Ox2567[40]=$num5;
}
$Ox3359=1;
$GLOBALS["Ox6160"]=40;
$GLOBALS["Ox5799"]="L2xTex15";
$GLOBALS["Ox2663"]="L2xCtx15";
$isSet=isset($GLOBALS["Ox6160"]);
if($isSet){
    $num5=$GLOBALS["Ox6160"];
    $Ox3071[25]=$num5;
    $num5=$GLOBALS["Ox5799"];
    $Ox6628[25]=$num5;
    $num5=$GLOBALS["Ox2663"];
    $Ox2567[25]=$num5;
}else{
    $num5=null;
    $Ox3071[25]=$num5;
    $num5=null;
    $Ox6628[25]=$num5;
    $num5=null;
    $Ox2567[25]=$num5;
}
$Ox3359=1;
$num5=25;
$GLOBALS["Ox6160"]=$num5;
$num5=2;
$GLOBALS["Ox5799"]=$num5;
$num5=2;
$GLOBALS["Ox2663"]=$num5;
$result=$ossClient->uploadFile($bucket, $ossFile, $localFile);
$str='https://' . $bucket;
$str2=$str . ".";
$val7=$str2 . $endpoint;
$str3=$val7 . "/";
$val8=$str3 . $ossFile;
$jsonData=array_push($arr, $val8);
$upy=1;
$jsonData=file_exists($newFile);
if($jsonData)goto L2xeWjgxr;
goto L2xFaxp;
goto L2xFaxp;
L2xeWjgxr:
$jsonData=unlink($newFile);
goto L2xFaxp;
L2xCtxp:
unset($Ox3359);
$num5=$Ox3071[25];
$GLOBALS["Ox6160"]=$num5;
$num5=$Ox6628[25];
$GLOBALS["Ox5799"]=$num5;
$num5=$Ox2567[25];
$GLOBALS["Ox2663"]=$num5;
$tmp=$val9 instanceof OssException;
if($tmp)goto L2xeWjgxz;
goto L2xldMhxz;
goto L2xldMhxz;
L2xeWjgxz:
$num5=$val9;
$e=$num5;
unset($val9);
$upy=0;
goto L2xFaxp;
goto L2xxy;
L2xldMhxz:
L2xxy:
L2xFaxp:
unset($Ox3359);
$num5=$Ox3071[25];
$GLOBALS["Ox6160"]=$num5;
$num5=$Ox6628[25];
$GLOBALS["Ox5799"]=$num5;
$num5=$Ox2567[25];
$GLOBALS["Ox2663"]=$num5;
if(isset($val2))goto L2xeWjgxx;
goto L2xldMhxx;
goto L2xldMhxx;
L2xeWjgxx:
$val3=&$val10;
$num2=1;
goto L2xFax15;
goto L2xxw;
L2xldMhxx:
L2xxw:
if(isset($val11))goto L2xeWjgxv;
goto L2xldMhxv;
goto L2xldMhxv;
L2xeWjgxv:
$val4=$val11;
goto L2xCtx15;
goto L2xxu;
L2xldMhxv:
L2xxu:
if(isset($val9))goto L2xeWjgxt;
goto L2xFax15;
goto L2xFax15;
L2xeWjgxt:
$num4=1;
$val4=$val9;
goto L2xCtx15;
goto L2xFax15;
L2xCtx15:
unset($Ox3359);
$GLOBALS["Ox6160"]=$Ox3071[40];
$GLOBALS["Ox5799"]=$Ox6628[40];
$GLOBALS["Ox2663"]=$Ox2567[40];
$tmp=$val4 instanceof \Exception;
if($tmp)goto L2xeWjgx2a;
goto L2xldMhx2a;
L2xeWjgx2a:
$num5=$val4;
$e=$num5;
unset($val4);
$tmp=!isset($num4);
$tmp4=(bool)$tmp;
if($tmp4){
    $tmp4=(bool)isset($GLOBALS["Ox2663"]);
}
if($tmp4)goto L2xeWjgx1l;
goto L2xldMhx1l;
goto L2xldMhx1l;
L2xeWjgx1l:
$tmp=$GLOBALS["Ox2663"]=="L2xCtxp";
if($tmp)goto L2xeWjgx1n;
goto L2xx1i;
goto L2xx1i;
L2xeWjgx1n:
$val9=$e;
goto L2xCtxp;
goto L2xx1i;
L2xldMhx1l:
L2xx1i:
$val5=$e;
goto L2xFax15;
goto L2xFax15;
goto L2xx29;
L2xldMhx2a:
L2xx29:
$tmp=$val4 instanceof \Error;
if($tmp)goto L2xeWjgx22;
goto L2xldMhx22;
L2xeWjgx22:
$num5=$val4;
$e=$num5;
unset($val4);
$tmp=!isset($num4);
$tmp4=(bool)$tmp;
if($tmp4){
    $tmp4=(bool)isset($GLOBALS["Ox2663"]);
}
if($tmp4)goto L2xeWjgx1r;
goto L2xldMhx1r;
goto L2xldMhx1r;
L2xeWjgx1r:
$tmp=$GLOBALS["Ox2663"]=="L2xCtxp";
if($tmp)goto L2xeWjgx1t;
goto L2xx1o;
goto L2xx1o;
L2xeWjgx1t:
$val9=$e;
goto L2xCtxp;
goto L2xx1o;
L2xldMhx1r:
L2xx1o:
$val5=$e;
goto L2xFax15;
goto L2xFax15;
goto L2xx21;
L2xldMhx22:
L2xx21:
L2xFax15:
unset($Ox3359);
$GLOBALS["Ox6160"]=$Ox3071[40];
$GLOBALS["Ox5799"]=$Ox6628[40];
$GLOBALS["Ox2663"]=$Ox2567[40];
if(isset($num2)){
    return $val3;
}
if(isset($val5)){
    throw $val5;
}
if(isset($val4)){
    $num3=1;
    throw $val4;
}
}catch(\Exception $e){if(!isset($num3)&&isset($GLOBALS["Ox2663"])){if($GLOBALS["Ox2663"]=="L2xCtx15"){$val4=$e;
goto L2xCtx15;
}}throw $e;
}catch(\Error $e){if(!isset($num3)&&isset($GLOBALS["Ox2663"])){if($GLOBALS["Ox2663"]=="L2xCtx15"){$val4=$e;
goto L2xCtx15;
}}throw $e;
}goto L2xx13;
L2xldMhx14:
switch($num){
    case 340:{
    $upy=0;
        break;
    }
}
L2xx13:

