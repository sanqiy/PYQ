<?php
$iteace='adminapi';
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp2=$user_zh=="";
$tmp3=(bool)$tmp2;
$tmp4=!$tmp3;
if($tmp4){
    $tmp5=$user_passid=="";
    $tmp3=(bool)$tmp5;
}
if($tmp3){
    exit('<script language="JavaScript">;alert("请先登录!");location.href="../login.php";</script>');
}
$tmp2=include '../../config.php';
$tmp2=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp2;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$escaped=htmlspecialchars($user_zh);
$pos=addslashes($escaped);
$user_zhsg=$pos;
$tmp2="select * from user where username='" . $user_zhsg;
$sqls=$tmp2 . "'";
$row=mysqli_query($conn, $sqls);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$data2s_row=$row;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($num3))break;
    $glyzhuser=$row["username"];
}
L2xxf:
$str="select * from user where username='" . $user_zh;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
$zid=$data2_row["id"];
$zjpassword=$data2_row["password"];
if($user_passid!=$passid){
    $escaped=time();
    $str=$escaped+ -1;
    $pos=setcookie("username", "", $str, "/");
    $escaped=time();
    $str=$escaped+ -1;
    $pos=setcookie("passid", "", $str, "/");
    exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="../login.php";</script>');
}
if($zjzhq!=$glyzhuser){
    exit('<script language="JavaScript">;alert("没有权限!");history.go(-1);</script>');
}
$auth_keylocation='../../api/key.php';
$auth_keyauth='../../api/auth.php';
$num=4931;
$row=file_exists($auth_keyauth);
if($row){
    $num=272;
}else{
    $num=255;
}
$tmp2=16;
$tmp5=255;
$tmp3=$num==255;
if($tmp3)goto L2xeWjgxw;
goto L2xldMhxw;
L2xeWjgxw:
exit('<script language="JavaScript">;alert("授权验证文件不存在或被篡改,请确保文件完整且未篡改!");history.go(-1);</script>');
goto L2xxv;
L2xldMhxw:
$tmp2=266;
$tmp5=272;
$tmp3=$num==272;
if($tmp3)goto L2xeWjgxx;
goto L2xldMhxx;
L2xeWjgxx:
$tmp2=require $auth_keyauth;
$tmp2=!defined("sh_auth_state");
if($tmp2){
    exit('<script language="JavaScript">;alert("授权验证失败,请确保文件完整且未篡改!");history.go(-1);</script>');
}
$tmp2=sh_auth_state!="ok";
if($tmp2)goto L2xeWjgxu;
goto L2xxv;
goto L2xxv;
L2xeWjgxu:
exit('<script language="JavaScript">;alert("程序未授权,您的请求已被拒绝,请授权后使用!");history.go(-1);</script>');
goto L2xxv;
L2xldMhxx:
L2xxv:
$num2=4931;
$isArray=is_array($_POST);
if($isArray){
    $num2=64;
}else{
    $num2=64;
    $num2=1412;
}
switch($num2){
    case 64:{
    $userid=&$_POST['lx'];
        break;
    }
    case 738:{
        $userid=$_POST['lx'];
        break;
    }
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$lx=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST["ids"];
}else{
    $userid=$_POST["ids"];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$tmp2=$escaped2!="";
if($tmp2)goto L2xeWjgx2l;
goto L2xldMhx2l;
L2xeWjgx2l:
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST['userid'];
}else{
    $userid=$_POST['userid'];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$id=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST["ids"];
}else{
    $userid=$_POST["ids"];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$data=$escaped2;
$tmp2=$lx=="0";
if($tmp2)goto L2xeWjgx1h;
goto L2xldMhx1h;
goto L2xldMhx1h;
L2xeWjgx1h:
$row=explode(',', $data);
$ids=$row;
unset($tmp);
foreach($ids as $id){$tmp[]=$id;
}
$tmp6=0;
while(true){
    $row=count($tmp);
    $tmp2=$tmp6<$row;
    if(!$tmp2)break;
    $keys=array_keys($tmp);
    $keys=$keys[$tmp6];
    $id=$tmp[$keys];
    $tmp2="UPDATE user SET ban = '0', bantime = 'false' WHERE id = '" . $id;
    $sql=$tmp2 . "'";
    $result=$conn->query($sql);
    $result=$result;
    if(!($result)){
        $val["code"]="200";
        $val["msg"]="更新失败";
        $val2[]=$val;
        $arr=$val2;
        exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
    }
    $tmp6=$tmp6+1;
}
L2xx1p:
$val["code"]="200";
$val["msg"]="更新成功";
$val2[]=$val;
$arr=$val2;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
goto L2xx1g;
L2xldMhx1h:
L2xx1g:
$tmp2=$lx=="-1";
if($tmp2)goto L2xeWjgx1u;
goto L2xldMhx1u;
goto L2xldMhx1u;
L2xeWjgx1u:
$row=explode(',', $data);
$ids=$row;
unset($tmp);
foreach($ids as $id){$tmp[]=$id;
}
$tmp6=0;
while(true){
    $row=count($tmp);
    $tmp2=$tmp6<$row;
    if(!$tmp2)break;
    $keys=array_keys($tmp);
    $keys=$keys[$tmp6];
    $id=$tmp[$keys];
    $tmp2="UPDATE user SET ban = '-1', bantime = 'true' WHERE id = '" . $id;
    $sql=$tmp2 . "'";
    $result=$conn->query($sql);
    $result=$result;
    if(!($result)){
        $val["code"]="200";
        $val["msg"]="更新失败";
        $val2[]=$val;
        $arr=$val2;
        exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
    }
    $tmp6=$tmp6+1;
}
L2xx23:
$val["code"]="200";
$val["msg"]="更新成功";
$val2[]=$val;
$arr=$val2;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
goto L2xx1t;
L2xldMhx1u:
L2xx1t:
$tmp2=$lx=="del";
if($tmp2)goto L2xeWjgx28;
goto L2xldMhx28;
goto L2xldMhx28;
L2xeWjgx28:
$row=explode(',', $data);
$ids=$row;
unset($tmp);
foreach($ids as $id){$tmp[]=$id;
}
$tmp6=0;
while(true){
    $row=count($tmp);
    $tmp2=$tmp6<$row;
    if(!$tmp2)break;
    $keys=array_keys($tmp);
    $keys=$keys[$tmp6];
    $id=$tmp[$keys];
    $tmp2="DELETE FROM user WHERE id = '" . $id;
    $sql=$tmp2 . "'";
    $result=$conn->query($sql);
    $result=$result;
    if(!($result)){
        $val["code"]="200";
        $val["msg"]="用户删除失败";
        $val2[]=$val;
        $arr=$val2;
        exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
    }
    $tmp6=$tmp6+1;
}
L2xx2g:
$val["code"]="200";
$val["msg"]="用户已删除";
$val2[]=$val;
$arr=$val2;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
goto L2xx27;
L2xldMhx28:
L2xx27:
exit();
goto L2xx2k;
L2xldMhx2l:
L2xx2k:
if($lx=="userbj")goto L2xeWjgx8h;
goto L2xldMhx8h;
L2xeWjgx8h:
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST['userid'];
}else{
    $userid=$_POST['userid'];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$userid=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST['uuserzh'];
}else{
    $userid=$_POST['uuserzh'];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$userzh=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST['upwd'];
}else{
    $userid=$_POST['upwd'];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$usermm=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST['uuserem'];
}else{
    $userid=$_POST['uuserem'];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$userem=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST['uuseryue'];
}else{
    $userid=$_POST['uuseryue'];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$uuseryue=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST['uusername'];
}else{
    $userid=$_POST['uusername'];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$username=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST['uuserimg'];
}else{
    $userid=$_POST['uuserimg'];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$userimg=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST['uuserwz'];
}else{
    $userid=$_POST['uuserwz'];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$userwz=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST['uuserbj'];
}else{
    $userid=$_POST['uuserbj'];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$userbj=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST['uuserqm'];
}else{
    $userid=$_POST['uuserqm'];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$userqm=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST['uuserqx'];
}else{
    $userid=$_POST['uuserqx'];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$userqx=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST['uuseres'];
}else{
    $userid=$_POST['uuseres'];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$useres=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST['uuserban'];
}else{
    $userid=$_POST['uuserban'];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$userban=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST['uuserbantime'];
}else{
    $userid=$_POST['uuserbantime'];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$userbantime=$escaped2;
$tmp2="SELECT * FROM user WHERE id = '" . $userid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
$tmp2=$result->num_rows>0;
if($tmp2)goto L2xeWjgx45;
goto L2xldMhx45;
goto L2xldMhx45;
L2xeWjgx45:
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!$num3)break;
    $juserzh=$row['username'];
}
goto L2xx44;
L2xldMhx45:
L2xx44:
$tmp2=$userzh!="";
if($tmp2)goto L2xeWjgx4b;
goto L2xldMhx4b;
goto L2xldMhx4b;
L2xeWjgx4b:
$row=strpos($userzh, 'vis#-[');
$tmp2=$row!==false;
$tmp3=(bool)$tmp2;
$tmp4=!$tmp3;
if($tmp4){
    $pos=strpos($userzh, ']-#vis');
    $tmp5=$pos!==false;
    $tmp3=(bool)$tmp5;
}
if($tmp3)goto L2xx4a;
goto L2xldMhx4f;
L2xldMhx4f:
$row=str_replace(PHP_EOL, '', $userzh);
$userzh=$row;
$row=strlen($userzh);
$tmp2=$row>=5;
if($tmp2)goto L2xeWjgx4h;
goto L2xx4a;
goto L2xx4a;
L2xeWjgx4h:
$tmp2="select * from user where username = '" . $userzh;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
$row=mysqli_num_rows($result);
$tmp2=$row>0;
if($tmp2)goto L2xx4a;
goto L2xldMhx4j;
L2xldMhx4j:
$tmp2="UPDATE user SET username='" . $userzh;
$tmp5=$tmp2 . "' WHERE id='";
$tmp3=$tmp5 . $userid;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$result=$result;
$tmp2="UPDATE essay SET ptpuser = '" . $userzh;
$tmp5=$tmp2 . "' WHERE ptpuser = '";
$tmp3=$tmp5 . $juserzh;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$result=$result;
$tmp2="UPDATE comm SET couser = '" . $userzh;
$tmp5=$tmp2 . "',bcouser = '";
$tmp3=$tmp5 . $userzh;
$tmp4=$tmp3 . "' WHERE couser = '";
$tmp7=$tmp4 . $juserzh;
$sql=$tmp7 . "'";
$result=$conn->query($sql);
$result=$result;
$tmp2="UPDATE lcke SET luser = '" . $userzh;
$tmp5=$tmp2 . "' WHERE luser = '";
$tmp3=$tmp5 . $juserzh;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$result=$result;
$tmp2="UPDATE message SET fuser = '" . $userzh;
$tmp5=$tmp2 . "', suser = '";
$tmp3=$tmp5 . $userzh;
$tmp4=$tmp3 . "' WHERE fuser = '";
$tmp7=$tmp4 . $juserzh;
$sql=$tmp7 . "'";
$result=$conn->query($sql);
$result=$result;
L2xldMhx4b:
L2xx4a:
$tmp2=$usermm!="";
if($tmp2)goto L2xeWjgx4l;
goto L2xldMhx4l;
goto L2xldMhx4l;
L2xeWjgx4l:
$row=str_replace(PHP_EOL, '', $usermm);
$usermm=$row;
$row=md5($usermm);
$usermm=$row;
$row=strlen($usermm);
$tmp2=$row>3;
if($tmp2)goto L2xeWjgx4n;
goto L2xx4k;
goto L2xx4k;
L2xeWjgx4n:
$tmp2="UPDATE user SET password='" . $usermm;
$tmp5=$tmp2 . "' WHERE id='";
$tmp3=$tmp5 . $userid;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$result=$result;
goto L2xx4k;
L2xldMhx4l:
L2xx4k:
$tmp2=$userem!="";
if($tmp2)goto L2xeWjgx4p;
goto L2xldMhx4p;
goto L2xldMhx4p;
L2xeWjgx4p:
$row=str_replace(PHP_EOL, '', $userem);
$userem=$row;
$tmp2="select * from user where email = '" . $userem;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
$row=mysqli_num_rows($result);
$tmp2=$row>0;
if($tmp2)goto L2xx4o;
goto L2xldMhx4r;
L2xldMhx4r:
$tmp2="UPDATE user SET email='" . $userem;
$tmp5=$tmp2 . "' WHERE id='";
$tmp3=$tmp5 . $userid;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$result=$result;
L2xldMhx4p:
L2xx4o:
$tmp2=$uuseryue!="";
if($tmp2){
    $tmp2="UPDATE user SET wallet='" . $uuseryue;
    $tmp5=$tmp2 . "' WHERE id='";
    $tmp3=$tmp5 . $userid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$row=strpos($username, "匿名用户");
$tmp2=$row!==false;
if($tmp2){
    $ncjyc=0;
}else{
    $ncjyc=1;
}
$tmp2=$username!="";
$tmp3=(bool)$tmp2;
if($tmp3){
    $tmp5=$ncjyc=="1";
    $tmp3=(bool)$tmp5;
}
if($tmp3)goto L2xeWjgx5z;
goto L2xldMhx5z;
goto L2xldMhx5z;
L2xeWjgx5z:
$row=str_replace(PHP_EOL, '', $username);
$username=$row;
$tmp2="select * from user where name = '" . $username;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
$row=mysqli_num_rows($result);
$tmp2=$row>0;
if($tmp2)goto L2xx4w;
goto L2xldMhx52;
L2xldMhx52:
$tmp2="UPDATE user SET name='" . $username;
$tmp5=$tmp2 . "' WHERE id='";
$tmp3=$tmp5 . $userid;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx54;
goto L2xx4w;
goto L2xx4w;
L2xeWjgx54:
$tmp2="select * from essay where ptpuser= '" . $userzh;
$sqlol=$tmp2 . "'";
$row=mysqli_query($conn, $sqlol);
$resultol=$row;
$row=mysqli_num_rows($resultol);
$tmp2=$row>0;
if($tmp2)goto L2xeWjgx56;
goto L2xldMhx56;
goto L2xldMhx56;
L2xeWjgx56:
L2xx57:
while(true){
    $row=mysqli_fetch_assoc($resultol);
    $rowo=$row;
    if(!$num3)break;
    $ncid=$rowo['id'];
    $tmp2="UPDATE essay SET ptpname='" . $username;
    $tmp5=$tmp2 . "' WHERE id='";
    $tmp3=$tmp5 . $ncid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx57;
}
goto L2xx55;
L2xldMhx56:
L2xx55:
$tmp2="select * from lcke where luser= '" . $userzh;
$sqlol=$tmp2 . "'";
$row=mysqli_query($conn, $sqlol);
$resultol=$row;
$row=mysqli_num_rows($resultol);
$tmp2=$row>0;
if($tmp2)goto L2xeWjgx5g;
goto L2xldMhx5g;
goto L2xldMhx5g;
L2xeWjgx5g:
L2xx5h:
while(true){
    $row=mysqli_fetch_assoc($resultol);
    $rowo=$row;
    if(!$num3)break;
    $ncid=$rowo['id'];
    $tmp2="UPDATE lcke SET lname='" . $username;
    $tmp5=$tmp2 . "' WHERE id='";
    $tmp3=$tmp5 . $ncid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx5h;
}
goto L2xx5f;
L2xldMhx5g:
L2xx5f:
$tmp2="select * from comm where couser= '" . $userzh;
$sqlol=$tmp2 . "'";
$row=mysqli_query($conn, $sqlol);
$resultol=$row;
$row=mysqli_num_rows($resultol);
$tmp2=$row>0;
if($tmp2)goto L2xeWjgx5q;
goto L2xldMhx5q;
goto L2xldMhx5q;
L2xeWjgx5q:
L2xx5r:
while(true){
    $row=mysqli_fetch_assoc($resultol);
    $rowo=$row;
    if(!$num3)break;
    $ncid=$rowo['id'];
    $tmp2="UPDATE comm SET coname='" . $username;
    $tmp5=$tmp2 . "' WHERE id='";
    $tmp3=$tmp5 . $ncid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx5r;
}
goto L2xx5p;
L2xldMhx5q:
L2xx5p:
$tmp2="select * from message where fuser= '" . $userzh;
$sqlol=$tmp2 . "'";
$row=mysqli_query($conn, $sqlol);
$resultol=$row;
$row=mysqli_num_rows($resultol);
$tmp2=$row>0;
if($tmp2)goto L2xeWjgx61;
goto L2xx4w;
goto L2xx4w;
L2xeWjgx61:
L2xx62:
while(true){
    $row=mysqli_fetch_assoc($resultol);
    $rowo=$row;
    if(!$num3)break;
    $ncid=$rowo['id'];
    $tmp2="UPDATE message SET fname='" . $username;
    $tmp5=$tmp2 . "' WHERE id='";
    $tmp3=$tmp5 . $ncid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx62;
}
goto L2xx4w;
L2xldMhx5z:
L2xx4w:
$tmp2=$userimg!="";
if($tmp2)goto L2xeWjgx6b;
goto L2xldMhx6b;
goto L2xldMhx6b;
L2xeWjgx6b:
$row=str_replace(PHP_EOL, '', $userimg);
$userimg=$row;
$tmp2="UPDATE user SET img='" . $userimg;
$tmp5=$tmp2 . "' WHERE id='";
$tmp3=$tmp5 . $userid;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx6d;
goto L2xx6a;
goto L2xx6a;
L2xeWjgx6d:
$tmp2="select * from essay where ptpuser= '" . $userzh;
$sqlo=$tmp2 . "'";
$row=mysqli_query($conn, $sqlo);
$resulto=$row;
$row=mysqli_num_rows($resulto);
$tmp2=$row>0;
if($tmp2)goto L2xeWjgx6f;
goto L2xldMhx6f;
goto L2xldMhx6f;
L2xeWjgx6f:
L2xx6g:
while(true){
    $row=mysqli_fetch_assoc($resulto);
    $rowo=$row;
    if(!$num3)break;
    $txid=$rowo['id'];
    $tmp2="UPDATE essay SET ptpimg='" . $userimg;
    $tmp5=$tmp2 . "' WHERE id='";
    $tmp3=$tmp5 . $txid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx6g;
}
goto L2xx6e;
L2xldMhx6f:
L2xx6e:
$tmp2="select * from lcke where luser= '" . $userzh;
$sqlol=$tmp2 . "'";
$row=mysqli_query($conn, $sqlol);
$resultol=$row;
$row=mysqli_num_rows($resultol);
$tmp2=$row>0;
if($tmp2)goto L2xeWjgx6p;
goto L2xldMhx6p;
goto L2xldMhx6p;
L2xeWjgx6p:
L2xx6q:
while(true){
    $row=mysqli_fetch_assoc($resultol);
    $rowo=$row;
    if(!$num3)break;
    $ncid=$rowo['id'];
    $tmp2="UPDATE lcke SET limg='" . $userimg;
    $tmp5=$tmp2 . "' WHERE id='";
    $tmp3=$tmp5 . $ncid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx6q;
}
goto L2xx6o;
L2xldMhx6p:
L2xx6o:
$tmp2="select * from comm where couser= '" . $userzh;
$sqlol=$tmp2 . "'";
$row=mysqli_query($conn, $sqlol);
$resultol=$row;
$row=mysqli_num_rows($resultol);
$tmp2=$row>0;
if($tmp2)goto L2xeWjgx7z;
goto L2xldMhx7z;
goto L2xldMhx7z;
L2xeWjgx7z:
L2xx71:
while(true){
    $row=mysqli_fetch_assoc($resultol);
    $rowo=$row;
    if(!$num3)break;
    $ncid=$rowo['id'];
    $tmp2="UPDATE comm SET coimg='" . $userimg;
    $tmp5=$tmp2 . "' WHERE id='";
    $tmp3=$tmp5 . $ncid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx71;
}
goto L2xx6y;
L2xldMhx7z:
L2xx6y:
$tmp2="select * from message where fuser= '" . $userzh;
$sqlol=$tmp2 . "'";
$row=mysqli_query($conn, $sqlol);
$resultol=$row;
$row=mysqli_num_rows($resultol);
$tmp2=$row>0;
if($tmp2)goto L2xeWjgx7a;
goto L2xx6a;
goto L2xx6a;
L2xeWjgx7a:
L2xx7b:
while(true){
    $row=mysqli_fetch_assoc($resultol);
    $rowo=$row;
    if(!$num3)break;
    $ncid=$rowo['id'];
    $tmp2="UPDATE message SET fimg='" . $userimg;
    $tmp5=$tmp2 . "' WHERE id='";
    $tmp3=$tmp5 . $ncid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx7b;
}
goto L2xx6a;
L2xldMhx6b:
L2xx6a:
$tmp2=$userwz!="";
if($tmp2)goto L2xeWjgx7k;
goto L2xldMhx7k;
goto L2xldMhx7k;
L2xeWjgx7k:
$row=str_replace(PHP_EOL, '', $userwz);
$userwz=$row;
$row=strpos($userwz, 'http://');
$tmp2=$row!==false;
$tmp3=(bool)$tmp2;
$tmp4=!$tmp3;
if($tmp4){
    $pos=strpos($userwz, 'https://');
    $tmp5=$pos!==false;
    $tmp3=(bool)$tmp5;
}
if($tmp3)goto L2xeWjgx7o;
goto L2xx7j;
goto L2xx7j;
L2xeWjgx7o:
$tmp2="UPDATE user SET url='" . $userwz;
$tmp5=$tmp2 . "' WHERE id='";
$tmp3=$tmp5 . $userid;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx7q;
goto L2xx7j;
goto L2xx7j;
L2xeWjgx7q:
$tmp2="select * from comm where couser= '" . $userzh;
$sqlol=$tmp2 . "'";
$row=mysqli_query($conn, $sqlol);
$resultol=$row;
$row=mysqli_num_rows($resultol);
$tmp2=$row>0;
if($tmp2)goto L2xeWjgx7s;
goto L2xx7j;
goto L2xx7j;
L2xeWjgx7s:
L2xx7t:
while(true){
    $row=mysqli_fetch_assoc($resultol);
    $rowo=$row;
    if(!$num3)break;
    $ncid=$rowo['id'];
    $tmp2="UPDATE comm SET courl='" . $userwz;
    $tmp5=$tmp2 . "' WHERE id='";
    $tmp3=$tmp5 . $ncid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx7t;
}
goto L2xx7j;
L2xldMhx7k:
L2xx7j:
$tmp2=$userbj!="";
if($tmp2){
    $row=str_replace(PHP_EOL, '', $userbj);
    $userbj=$row;
    $tmp2="UPDATE user SET homeimg='" . $userbj;
    $tmp5=$tmp2 . "' WHERE id='";
    $tmp3=$tmp5 . $userid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp2=$userqm!="";
if($tmp2){
    $row=str_replace(PHP_EOL, '', $userqm);
    $userqm=$row;
    $tmp2="UPDATE user SET sign='" . $userqm;
    $tmp5=$tmp2 . "' WHERE id='";
    $tmp3=$tmp5 . $userid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp2=$userqx!="";
if($tmp2){
    $row=str_replace(PHP_EOL, '', $userqx);
    $userqx=$row;
    $tmp2="UPDATE user SET essqx='" . $userqx;
    $tmp5=$tmp2 . "' WHERE id='";
    $tmp3=$tmp5 . $userid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp2=$useres!="";
if($tmp2){
    $row=str_replace(PHP_EOL, '', $useres);
    $useres=$row;
    $tmp2="UPDATE user SET esseam='" . $useres;
    $tmp5=$tmp2 . "' WHERE id='";
    $tmp3=$tmp5 . $userid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp2=$userban!="";
if($tmp2)goto L2xeWjgx8b;
goto L2xldMhx8b;
goto L2xldMhx8b;
L2xeWjgx8b:
$tmp2=$userzh!=$glyzhuser;
if($tmp2)goto L2xeWjgx8d;
goto L2xx8a;
goto L2xx8a;
L2xeWjgx8d:
$row=str_replace(PHP_EOL, '', $userban);
$userban=$row;
$tmp2="UPDATE user SET ban='" . $userban;
$tmp5=$tmp2 . "' WHERE id='";
$tmp3=$tmp5 . $userid;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$result=$result;
goto L2xx8a;
L2xldMhx8b:
L2xx8a:
$tmp2=$userbantime!="";
if($tmp2){
    $row=str_replace(PHP_EOL, '', $userbantime);
    $userbantime=$row;
    $tmp2="UPDATE user SET bantime='" . $userbantime;
    $tmp5=$tmp2 . "' WHERE id='";
    $tmp3=$tmp5 . $userid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
exit('<script language="JavaScript">;location.href="../userlist.php";</script>;');
goto L2xx8g;
L2xldMhx8h:
L2xx8g:
if($lx=="deluser")goto L2xeWjgxeq;
goto L2xldMhxeq;
L2xeWjgxeq:
$isArray=is_array($_POST);
if($isArray){
    $userid=&$_POST['userid'];
}else{
    $userid=$_POST['userid'];
}
$escaped=htmlspecialchars($userid);
unset($userid);
$escaped2=addslashes($escaped);
$uid=$escaped2;
$tmp2=$uid=="";
if($tmp2){
    exit('<script language="JavaScript">;alert("没有传入参数");location.href="../userlist.php;</script>');
}
$sql="SELECT * FROM user WHERE id = ?";
$row=mysqli_prepare($conn, $sql);
$stmt=$row;
$row=mysqli_stmt_bind_param($stmt, "s", $uid);
$row=mysqli_stmt_execute($stmt);
$row=mysqli_stmt_get_result($stmt);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$datas_row=$row;
if($num3){
    $del_zh=$datas_row["username"];
    $del_img=$datas_row["img"];
    $del_homeimg=$datas_row["homeimg"];
}
$sql="SELECT * FROM user WHERE username = ?";
$result=$conn->prepare($sql);
$stmt=$result;
$result=$stmt->bind_param("s", $del_zh);
$result=$stmt->execute();
$result=$stmt->get_result();
$result=$result;
$tmp2=$result->num_rows>0;
if($tmp2)goto L2xxcs;
goto L2xldMhxct;
L2xldMhxct:
exit('<script language="JavaScript">;alert("账号不存在");location.href="../userlist.php";</script>');
L2xxcs:
$tmp2=$del_zh==$glyzhuser;
if($tmp2){
    exit('<script language="JavaScript">;alert("不可删除管理员账号");location.href="../userlist.php";</script>');
}
$sql="DELETE FROM user WHERE username=?";
$result=$conn->prepare($sql);
$stmt=$result;
$result=$stmt->bind_param("s", $del_zh);
$result=$stmt->execute();
if(!($result)){
    exit('<script language="JavaScript">;alert("删除账号失败");location.href="../userlist.php";</script>');
}else{
    $sql="SELECT * FROM essay WHERE ptpuser=?";
    $result=$conn->prepare($sql);
    $stmt=$result;
    $result=$stmt->bind_param("s", $del_zh);
    $result=$stmt->execute();
    $result=$stmt->get_result();
    $result=$result;
}
while(true){
    while(true){
        $result=$result->fetch_assoc();
        $row=$result;
        if(!$num3)break;
        $ptpimag=$row['ptpimag'];
        $ptpvideo=$row['ptpvideo'];
        $tmp2=$ptpimag!="";
        if(!$tmp2)break;
        $row=explode('(+@+)', $ptpimag);
        $imgar=$row;
        $row=count($imgar);
        $coun=$row;
        $num3=0;
        $i=$num3;
        while(true){
            $tmp2=$i<$coun;
            if(!$tmp2)break;
            $tuimg=$imgar[$i];
            $row=strpos($tuimg, '/upload/');
            $tmp2=$row!==false;
if($tmp2)goto L2xeWjgxd7;
goto L2xldMhxd7;
goto L2xldMhxd7;
goto L2xldMhxd7;
goto L2xldMhxd7;
L2xeWjgxd7:
            $str='../.' . $tuimg;
            $row=is_file($str);
            $tmp5=!$row;
            if(!($tmp5)){
                $str='../.' . $tuimg;
                $row=unlink($str);
L2xldMhxd7:
            }
            $obj=$i;
            $obj2=$i+1;
            $num3=$obj2;
            $i=$num3;
        }
        $tmp2=$ptpvideo!="";
if($tmp2)goto L2xeWjgxdh;
goto L2xldMhxdh;
goto L2xldMhxdh;
goto L2xldMhxdh;
L2xeWjgxdh:
        $row=strpos($ptpvideo, '/upload/');
        $tmp2=$row!==false;
if($tmp2)goto L2xeWjgxdj;
goto L2xxdg;
goto L2xxdg;
goto L2xxdg;
L2xeWjgxdj:
        $str='../..' . $ptpvideo;
        $row=is_file($str);
        $tmp5=!$row;
if($tmp5)goto L2xxdg;
        $str='../..' . $ptpvideo;
        $row=unlink($str);
L2xldMhxdh:
L2xxdg:
        $sql="DELETE FROM essay WHERE ptpuser=?";
        $result=$conn->prepare($sql);
        $stmt=$result;
        $result=$stmt->bind_param("s", $del_zh);
        $result=$stmt->execute();
    }
}
L2xxdo:
$sql="DELETE FROM comm WHERE couser=?";
$result=$conn->prepare($sql);
$stmt=$result;
$result=$stmt->bind_param("s", $del_zh);
$result=$stmt->execute();
if($result)goto L2xxe7;
goto L2xldMhxe8;
L2xldMhxe8:
L2xxe7:
$sql="DELETE FROM lcke WHERE luser=?";
$result=$conn->prepare($sql);
$stmt=$result;
$result=$stmt->bind_param("s", $del_zh);
$result=$stmt->execute();
if($result)goto L2xxe9;
goto L2xldMhxea;
L2xldMhxea:
L2xxe9:
$sql="DELETE FROM message WHERE fuser=?";
$result=$conn->prepare($sql);
$stmt=$result;
$result=$stmt->bind_param("s", $del_zh);
$result=$stmt->execute();
if($result)goto L2xxeb;
goto L2xldMhxec;
L2xldMhxec:
L2xxeb:
$tmp2="select * from user where username= '" . $del_zh;
$sql=$tmp2 . "'";
$row=mysqli_query($conn, $sql);
$result=$row;
$row=mysqli_num_rows($result);
$tmp2=$row>0;
if($tmp2)goto L2xeWjgxee;
goto L2xldMhxee;
goto L2xldMhxee;
L2xeWjgxee:
$row=mysqli_fetch_assoc($result);
$row=$row;
$bdhomebjt='.' . $row["img"];
$row=strstr($bdhomebjt, "/user/headimg");
if($row)goto L2xeWjgxeg;
goto L2xxed;
goto L2xxed;
L2xeWjgxeg:
$row=file_exists($bdhomebjt);
if($row)goto L2xeWjgxei;
goto L2xxed;
goto L2xxed;
L2xeWjgxei:
$row=unlink($bdhomebjt);
goto L2xxed;
L2xldMhxee:
L2xxed:
$tmp2="select * from user where username= '" . $del_zh;
$sql=$tmp2 . "'";
$row=mysqli_query($conn, $sql);
$result=$row;
$row=mysqli_num_rows($result);
$tmp2=$row>0;
if($tmp2)goto L2xeWjgxek;
goto L2xldMhxek;
goto L2xldMhxek;
L2xeWjgxek:
$row=mysqli_fetch_assoc($result);
$row=$row;
$bdhomebjt='.' . $row["homeimg"];
$row=strstr($bdhomebjt, "/user/cover");
if($row)goto L2xeWjgxem;
goto L2xxej;
goto L2xxej;
L2xeWjgxem:
$row=file_exists($bdhomebjt);
if($row)goto L2xeWjgxeo;
goto L2xxej;
goto L2xxej;
L2xeWjgxeo:
$row=unlink($bdhomebjt);
goto L2xxej;
L2xldMhxek:
L2xxej:
$tmp2='<script language="JavaScript">alert("账号[' . $del_zh;
exit($tmp2 . ']已删除");location.href="../userlist.php";</script>;');
goto L2xxep;
L2xldMhxeq:
L2xxep:
$result=$conn->close();