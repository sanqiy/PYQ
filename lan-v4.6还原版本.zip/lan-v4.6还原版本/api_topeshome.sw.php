<?php
$num2=4919;
$parts2=file_exists("./config.php");
if($parts2){
    $num2=165;
}else{
    $num2=100;
}
switch($num2){
    case 100:{
    $parts2=header("Location:../index.php");
        break;
    }
    case 165:{
        $tmp=include './config.php';
        break;
    }
}
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$sqly="SELECT * FROM admin";
$result=$conn->query($sqly);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($sentinel))break;
if($row['topes']=="")goto L2xeWjgxf;
goto L2xldMhxf;
goto L2xldMhxf;
goto L2xldMhxf;
L2xeWjgxf:
    $snk=-403;
goto L2xxb;
goto L2xxe;
L2xldMhxf:
L2xxe:
    $ars=$row['topes'];
}
L2xxm:
L2xxb:
$num=4928;
$tmp=$snk=='-201-201-1';
if($tmp){
    $num=225;
}else{
    $num=165;
}
$tmp=256;
$tmp2=225;
$tmp3=$num==225;
if($tmp3)goto L2xx4z;
$tmp=95;
$tmp2=165;
$tmp3=$num==165;
if($tmp3)goto L2xeWjgx42;
goto L2xldMhx42;
L2xeWjgx42:
$parts=explode(PHP_EOL, $ars);
$reversed=array_reverse($parts);
$ars=$reversed;
$iars=0;
while(true){
    $parts2=count($ars);
    $tmp=$iars<$parts2;
    if(!$tmp)break;
    $cdid=$ars[$iars];
    $tmp="select * from essay where id= '" . $cdid;
    $sqly=$tmp . "'";
    $parts2=mysqli_query($conn, $sqly);
    $result=$parts2;
    $parts2=mysqli_num_rows($result);
    $tmp=$parts2>0;
if($tmp)goto L2xeWjgxy;
goto L2xldMhxy;
goto L2xldMhxy;
goto L2xldMhxy;
L2xeWjgxy:
L2xxz:
    while(true){
        $parts2=mysqli_fetch_assoc($result);
        $row=$parts2;
        if(!$sentinel)break;
        $ptpuser=$row["ptpuser"];
        $ptpimg=$row["ptpimg"];
        $ptpname=$row["ptpname"];
        $ptptext=$row["ptptext"];
        $ptpimag=$row["ptpimag"];
        $ptpvideo=$row["ptpvideo"];
        $ptpmusic=$row["ptpmusic"];
        $ptplx=$row["ptplx"];
        $ptpdw=$row["ptpdw"];
        $ptptime=$row["ptptime"];
        $ptpgg=$row["ptpgg"];
        $ptpggurl=$row["ptpggurl"];
        $ptpys=$row["ptpys"];
        $commauth=$row["commauth"];
        $ptpaud=$row["ptpaud"];
        $ptpip=$row["ip"];
        $cid=$row["cid"];
        $wid=$row["id"];
        $parts2=explode("|", $ptpvideo);
        $partssp=$parts2;
        $ptpvideo=$partssp[0];
        $ptpvideofm=$partssp[1];
        $topxs="置顶";
        $tmp=$ptplx=="mony";
if($tmp)goto L2xeWjgx13;
goto L2xldMhx13;
goto L2xldMhx13;
goto L2xldMhx13;
goto L2xldMhx13;
L2xeWjgx13:
        $tmp=$wzsdbs=="";
if($tmp)goto L2xeWjgx15;
goto L2xldMhx15;
goto L2xldMhx15;
goto L2xldMhx15;
goto L2xldMhx15;
L2xeWjgx15:
        $wzsdbs=132424;
goto L2xx12;
L2xldMhx15:
        $wzsdbs='<i class="iconfont icon-hongbao sh-homecontent-wzsbs" title="红包" style="font-size: 13px;color: #ed2424;bottom: 6px;right: 20px;"></i>' . $wzsdbs;
L2xldMhx13:
L2xx12:
        $tmp=$ptpys==1;
        $tmp3=(bool)$tmp;
        if($tmp3){
            $tmp2=$ptpaud==1;
            $tmp3=(bool)$tmp2;
        }
if($tmp3)goto L2xeWjgx19;
goto L2xxz;
goto L2xxz;
goto L2xxz;
goto L2xxz;
L2xeWjgx19:
        $tmp=$ptplx=="img";
if($tmp)goto L2xeWjgx1b;
goto L2xldMhx1b;
goto L2xldMhx1b;
goto L2xldMhx1b;
goto L2xldMhx1b;
L2xeWjgx1b:
        $parts2=explode('(+@+)', $ptpimag);
        $imgar=$parts2;
        $parts2=count($imgar);
        $coun=$parts2;
        $tmp=$coun==1;
if($tmp)goto L2xeWjgx1d;
goto L2xldMhx1d;
goto L2xldMhx1d;
goto L2xldMhx1d;
goto L2xldMhx1d;
L2xeWjgx1d:
        $tmp='<div class="sh-homecontent-lie">
        <!-- 左边 -->
        <div class="sh-homecontent-left">
        <!-- 日期 -->
        <div class="sh-homecontent-left-time" lang="year-' . $year;
        $tmp2=$tmp . "-";
        $tmp3=$tmp2 . $month;
        $tmp4=$tmp3 . "-";
        $tmp5=$tmp4 . $day;
        $tmp6=$tmp5 . '" style="';
        $tmp7=$tmp6 . $shougbsx;
        $tmp8=$tmp7 . '">
        <span class="homecontent-left-time-h">';
        $tmp9=$tmp8 . $topxs;
        $tmp10=$tmp9 . '</span>
        </div>
        <!-- 地址 -->
        <div class="sh-homecontent-left-time-dw">';
        $tmp11=$tmp10 . $ptpdw;
        $tmp12=$tmp11 . '</div>
        </div>
        <!-- 右边内容框架 -->
        <div class="sh-homecontent-right-wk">
        <!-- 右边内容主体 -->
        <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
        $tmp13=$tmp12 . $cid;
        $tmp14=$tmp13 . '\';">
        <!-- 图片 -->
        <div class="homecontent-right-tw">
        <!-- 图片 -->
        <div class="homecontent-right-tw-img" style="grid-template-columns: 1fr;grid-template-rows: 1fr;">
        <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
        $tmp15=$tmp14 . $imgar[0];
        $tmp16=$tmp15 . '" alt=""></div>
        ';
        $tmp17=$tmp16 . $wzsdbs;
        $tmp18=$tmp17 . '
        </div>
        </div>
        <!-- 文字内容 -->
        <div class="homecontent-right-nr">
        <div class="homecontent-right-nr-text">';
        $tmp19=$tmp18 . $ptptext;
        $tmp20=$tmp19 . '</div>
        <p class="homecontent-right-nr-tus">共';
        $tmp21=$tmp20 . $coun;
        $tmp22=$tmp21 . '张</p>
        </div>
        </div>
        </div>
        </div>';
        $wzbank=$tmp22;
goto L2xx1a;
L2xldMhx1d:
        $tmp=$coun==2;
if($tmp)goto L2xeWjgx1e;
goto L2xldMhx1e;
goto L2xldMhx1e;
goto L2xldMhx1e;
goto L2xldMhx1e;
L2xeWjgx1e:
        $tmp='<div class="sh-homecontent-lie">
        <!-- 左边 -->
        <div class="sh-homecontent-left">
        <!-- 日期 -->
        <div class="sh-homecontent-left-time" lang="year-' . $year;
        $tmp2=$tmp . "-";
        $tmp3=$tmp2 . $month;
        $tmp4=$tmp3 . "-";
        $tmp5=$tmp4 . $day;
        $tmp6=$tmp5 . '" style="';
        $tmp7=$tmp6 . $shougbsx;
        $tmp8=$tmp7 . '">
        <span class="homecontent-left-time-h">';
        $tmp9=$tmp8 . $topxs;
        $tmp10=$tmp9 . '</span>
        </div>
        <!-- 地址 -->
        <div class="sh-homecontent-left-time-dw">';
        $tmp11=$tmp10 . $ptpdw;
        $tmp12=$tmp11 . '</div>
        </div>
        <!-- 右边内容框架 -->
        <div class="sh-homecontent-right-wk">
        <!-- 右边内容主体 -->
        <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
        $tmp13=$tmp12 . $cid;
        $tmp14=$tmp13 . '\';">
        <!-- 图片 -->
        <div class="homecontent-right-tw">
        <!-- 图片 -->
        <div class="homecontent-right-tw-img">
        <div class="homecontent-right-tw-img-wk" style="grid-row: 1 / 3;"><img src="./assets/img/thumbnail.svg" data-src="';
        $tmp15=$tmp14 . $imgar[0];
        $tmp16=$tmp15 . '" alt=""></div>
        <div class="homecontent-right-tw-img-wk" style="grid-row: 1 / 3;"><img src="./assets/img/thumbnail.svg" data-src="';
        $tmp17=$tmp16 . $imgar[1];
        $tmp18=$tmp17 . '" alt=""></div>
        ';
        $tmp19=$tmp18 . $wzsdbs;
        $tmp20=$tmp19 . '
        </div>
        </div>
        <!-- 文字内容 -->
        <div class="homecontent-right-nr">
        <div class="homecontent-right-nr-text">';
        $tmp21=$tmp20 . $ptptext;
        $tmp22=$tmp21 . '</div>
        <p class="homecontent-right-nr-tus">共';
        $tmp23=$tmp22 . $coun;
        $tmp24=$tmp23 . '张</p>
        </div>
        </div>
        </div>
        </div>';
        $wzbank=$tmp24;
goto L2xx1a;
L2xldMhx1e:
        $tmp=$coun==3;
if($tmp)goto L2xeWjgx1f;
goto L2xldMhx1f;
goto L2xldMhx1f;
goto L2xldMhx1f;
goto L2xldMhx1f;
L2xeWjgx1f:
        $tmp='<div class="sh-homecontent-lie">
        <!-- 左边 -->
        <div class="sh-homecontent-left">
        <!-- 日期 -->
        <div class="sh-homecontent-left-time" lang="year-' . $year;
        $tmp2=$tmp . "-";
        $tmp3=$tmp2 . $month;
        $tmp4=$tmp3 . "-";
        $tmp5=$tmp4 . $day;
        $tmp6=$tmp5 . '" style="';
        $tmp7=$tmp6 . $shougbsx;
        $tmp8=$tmp7 . '">
        <span class="homecontent-left-time-h">';
        $tmp9=$tmp8 . $topxs;
        $tmp10=$tmp9 . '</span>
        </div>
        <!-- 地址 -->
        <div class="sh-homecontent-left-time-dw">';
        $tmp11=$tmp10 . $ptpdw;
        $tmp12=$tmp11 . '</div>
        </div>
        <!-- 右边内容框架 -->
        <div class="sh-homecontent-right-wk">
        <!-- 右边内容主体 -->
        <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
        $tmp13=$tmp12 . $cid;
        $tmp14=$tmp13 . '\';">
        <!-- 图片 -->
        <div class="homecontent-right-tw">
        <!-- 图片 -->
        <div class="homecontent-right-tw-img">
        <div class="homecontent-right-tw-img-wk" style="grid-row: 1 / 3;"><img src="./assets/img/thumbnail.svg" data-src="';
        $tmp15=$tmp14 . $imgar[0];
        $tmp16=$tmp15 . '" alt=""></div>
        <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
        $tmp17=$tmp16 . $imgar[1];
        $tmp18=$tmp17 . '" alt=""></div>
        <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
        $tmp19=$tmp18 . $imgar[2];
        $tmp20=$tmp19 . '" alt=""></div>
        ';
        $tmp21=$tmp20 . $wzsdbs;
        $tmp22=$tmp21 . '
        </div>
        </div>
        <!-- 文字内容 -->
        <div class="homecontent-right-nr">
        <div class="homecontent-right-nr-text">';
        $tmp23=$tmp22 . $ptptext;
        $tmp24=$tmp23 . '</div>
        <p class="homecontent-right-nr-tus">共';
        $tmp25=$tmp24 . $coun;
        $tmp26=$tmp25 . '张</p>
        </div>
        </div>
        </div>
        </div>';
        $wzbank=$tmp26;
goto L2xx1a;
L2xldMhx1f:
        $tmp=$coun==4;
        $tmp3=(bool)$tmp;
        $tmp4=!$tmp3;
        if($tmp4){
            $tmp2=$coun>=4;
            $tmp3=(bool)$tmp2;
        }
if($tmp3)goto L2xeWjgx1i;
goto L2xx1a;
goto L2xx1a;
goto L2xx1a;
goto L2xx1a;
L2xeWjgx1i:
        $tmp='<div class="sh-homecontent-lie">
        <!-- 左边 -->
        <div class="sh-homecontent-left">
        <!-- 日期 -->
        <div class="sh-homecontent-left-time" lang="year-' . $year;
        $tmp2=$tmp . "-";
        $tmp3=$tmp2 . $month;
        $tmp4=$tmp3 . "-";
        $tmp5=$tmp4 . $day;
        $tmp6=$tmp5 . '" style="';
        $tmp7=$tmp6 . $shougbsx;
        $tmp8=$tmp7 . '">
        <span class="homecontent-left-time-h">';
        $tmp9=$tmp8 . $topxs;
        $tmp10=$tmp9 . '</span>
        </div>
        <!-- 地址 -->
        <div class="sh-homecontent-left-time-dw">';
        $tmp11=$tmp10 . $ptpdw;
        $tmp12=$tmp11 . '</div>
        </div>
        <!-- 右边内容框架 -->
        <div class="sh-homecontent-right-wk">
        <!-- 右边内容主体 -->
        <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
        $tmp13=$tmp12 . $cid;
        $tmp14=$tmp13 . '\';">
        <!-- 图片 -->
        <div class="homecontent-right-tw">
        <!-- 图片 -->
        <div class="homecontent-right-tw-img">
        <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
        $tmp15=$tmp14 . $imgar[0];
        $tmp16=$tmp15 . '" alt=""></div>
        <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
        $tmp17=$tmp16 . $imgar[1];
        $tmp18=$tmp17 . '" alt=""></div>
        <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
        $tmp19=$tmp18 . $imgar[2];
        $tmp20=$tmp19 . '" alt=""></div>
        <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
        $tmp21=$tmp20 . $imgar[3];
        $tmp22=$tmp21 . '" alt=""></div>
        ';
        $tmp23=$tmp22 . $wzsdbs;
        $tmp24=$tmp23 . '
        </div>
        </div>
        <!-- 文字内容 -->
        <div class="homecontent-right-nr">
        <div class="homecontent-right-nr-text">';
        $tmp25=$tmp24 . $ptptext;
        $tmp26=$tmp25 . '</div>
        <p class="homecontent-right-nr-tus">共';
        $tmp27=$tmp26 . $coun;
        $tmp28=$tmp27 . '张</p>
        </div>
        </div>
        </div>
        </div>';
        $wzbank=$tmp28;
goto L2xx1a;
L2xldMhx1b:
        $tmp=$ptplx=="video";
        if($tmp){
            $tmp=$videoauplay==1;
            if($tmp){
                $videobf='autoplay';
                $videobfplas='';
            }else{
                $videobf='';
                $tmp='<i class="iconfont icon-sa4f56" id="sh-content-video-videobfb-' . $cid;
                $tmp2=$tmp . '" style="width: fit-content;height: fit-content;grid-column: 1;grid-row: 1;z-index: 5;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);font-size: 30px;color: #ffffff;display: flex;cursor: pointer;padding: 15px;pointer-events: none;"></i>';
                $videobfplas=$tmp2;
            }
            $tmp='<div class="sh-homecontent-lie">
            <!-- 左边 -->
            <div class="sh-homecontent-left">
            <!-- 日期 -->
            <div class="sh-homecontent-left-time" lang="year-' . $year;
            $tmp2=$tmp . "-";
            $tmp3=$tmp2 . $month;
            $tmp4=$tmp3 . "-";
            $tmp5=$tmp4 . $day;
            $tmp6=$tmp5 . '" style="';
            $tmp7=$tmp6 . $shougbsx;
            $tmp8=$tmp7 . '">
            <span class="homecontent-left-time-h">';
            $tmp9=$tmp8 . $topxs;
            $tmp10=$tmp9 . '</span>
            </div>
            <!-- 地址 -->
            <div class="sh-homecontent-left-time-dw">';
            $tmp11=$tmp10 . $ptpdw;
            $tmp12=$tmp11 . '</div>
            </div>
            <!-- 右边内容框架 -->
            <div class="sh-homecontent-right-wk">
            <!-- 右边内容主体 -->
            <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
            $tmp13=$tmp12 . $cid;
            $tmp14=$tmp13 . '\';">
            <!-- 视频 -->
            <div class="homecontent-right-tw">
            <!-- 视频 -->
            <div class="homecontent-right-tw-video">
            <video class="homecontent-right-tw-videoau" poster="';
            $tmp15=$tmp14 . $ptpvideofm;
            $tmp16=$tmp15 . '" src="';
            $tmp17=$tmp16 . $ptpvideo;
            $tmp18=$tmp17 . '" playsinline="" webkit-playsinline="" preload="metadata" ';
            $tmp19=$tmp18 . $videobf;
            $tmp20=$tmp19 . ' muted="" loop=""></video>
            ';
            $tmp21=$tmp20 . $videobfplas;
            $tmp22=$tmp21 . '
            <span class="sh-video-span" style="left: 4px;bottom: 4px;">MP4</span>
            ';
            $tmp23=$tmp22 . $wzsdbs;
            $tmp24=$tmp23 . '
            </div>
            </div>
            <!-- 文字内容 -->
            <div class="homecontent-right-nr">
            <div class="homecontent-right-nr-text">';
            $tmp25=$tmp24 . $ptptext;
            $tmp26=$tmp25 . '</div>
            </div>
            </div>
            </div>
            </div>';
            $wzbank=$tmp26;
        }else{
            $tmp=$ptplx=="music";
            if($tmp){
                $parts2=explode('|', $ptpmusic);
                $mus=$parts2;
                $tmp=$mus[3]=="";
                if($tmp){
                    $musimg="./assets/img/musicba.jpg";
                }else{
                    $musimg=$mus[3];
                }
                $tmp=$ptptext=="";
                if($tmp){
                    $ptpnr='';
                }else{
                    $tmp='<div class="sh-homecontent-right-lie-music-title">' . $ptptext;
                    $ptpnr=$tmp . '</div>';
                }
                $tmp='<div class="sh-homecontent-lie">
                <!-- 左边 -->
                <div class="sh-homecontent-left">
                <!-- 日期 -->
                <div class="sh-homecontent-left-time" lang="year-' . $year;
                $tmp2=$tmp . "-";
                $tmp3=$tmp2 . $month;
                $tmp4=$tmp3 . "-";
                $tmp5=$tmp4 . $day;
                $tmp6=$tmp5 . '" style="';
                $tmp7=$tmp6 . $shougbsx;
                $tmp8=$tmp7 . '">
                <span class="homecontent-left-time-h">';
                $tmp9=$tmp8 . $topxs;
                $tmp10=$tmp9 . '</span>
                </div>
                <!-- 地址 -->
                <div class="sh-homecontent-left-time-dw">';
                $tmp11=$tmp10 . $ptpdw;
                $tmp12=$tmp11 . '</div>
                </div>
                <!-- 右边内容框架 -->
                <div class="sh-homecontent-right-wk">
                <!-- 右边内容主体 -->
                <div class="sh-homecontent-right-lie-musicwk" onclick="window.location.href = \'./view.php?cid=';
                $tmp13=$tmp12 . $cid;
                $tmp14=$tmp13 . '\';">';
                $tmp15=$tmp14 . $wzsdbs;
                $tmp16=$tmp15 . '
                ';
                $tmp17=$tmp16 . $ptpnr;
                $tmp18=$tmp17 . '
                <div class="sh-homecontent-right-lie sh-homecontent-right-lie-music">
                <!-- 音乐 -->
                <div class="homecontent-right-tw homecontent-right-tw-music">
                <!-- 图片 -->
                <div class="homecontent-right-tw-img" style="grid-template-columns: 1fr;grid-template-rows: 1fr;">
                <div class="homecontent-right-tw-img-wk homecontent-right-tw-img-wk-music"><img src="./assets/img/thumbnail.svg" data-src="';
                $tmp19=$tmp18 . $musimg;
                $tmp20=$tmp19 . '" alt=""><i class="iconfont icon-sa4f56"></i></div>
                </div>
                </div>
                <!-- 文字内容 -->
                <div class="homecontent-right-nr homecontent-right-nr-music">
                <div class="homecontent-right-nr-text homecontent-right-nr-text-music" style="color: var(--thetitle);">';
                $tmp21=$tmp20 . $mus[1];
                $tmp22=$tmp21 . '</div>
                <p class="homecontent-right-nr-text-music-p homecontent-right-nr-text-music">';
                $tmp23=$tmp22 . $mus[2];
                $tmp24=$tmp23 . '</p>
                </div>
                </div>
                </div>
                </div>
                </div>';
                $wzbank=$tmp24;
            }else{
                $tmp=$ptplx=="only";
                if($tmp){
                    $tmp='<div class="sh-homecontent-lie">
                    <!-- 左边 -->
                    <div class="sh-homecontent-left">
                    <!-- 日期 -->
                    <div class="sh-homecontent-left-time" lang="year-' . $year;
                    $tmp2=$tmp . "-";
                    $tmp3=$tmp2 . $month;
                    $tmp4=$tmp3 . "-";
                    $tmp5=$tmp4 . $day;
                    $tmp6=$tmp5 . '" style="';
                    $tmp7=$tmp6 . $shougbsx;
                    $tmp8=$tmp7 . '">
                    <span class="homecontent-left-time-h">';
                    $tmp9=$tmp8 . $topxs;
                    $tmp10=$tmp9 . '</span>
                    </div>
                    <!-- 地址 -->
                    <div class="sh-homecontent-left-time-dw">';
                    $tmp11=$tmp10 . $ptpdw;
                    $tmp12=$tmp11 . '</div>
                    </div>
                    <div class="sh-homecontent-right-wk">
                    <!-- 右边内容主体 -->
                    <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
                    $tmp13=$tmp12 . $cid;
                    $tmp14=$tmp13 . '\';">
                    <!-- 仅文字 -->
                    <!-- 文字内容 -->
                    <div class="homecontent-right-nr" style="min-height: 10px;background: var(--fgxys);position:relative;">
                    <div class="homecontent-right-nr-text homecontent-right-nr-textjw" style="margin: 10px;">';
                    $tmp15=$tmp14 . $ptptext;
                    $tmp16=$tmp15 . '</div>
                    ';
                    $tmp17=$tmp16 . $wzsdbs;
                    $tmp18=$tmp17 . '
                    </div>
                    </div>
                    </div>
                    </div>';
                    $wzbank=$tmp18;
                }else{
                    $tmp=$ptplx=="mony";
                    if($tmp){
                        $tmp='<div class="sh-homecontent-lie">
                        <!-- 左边 -->
                        <div class="sh-homecontent-left">
                        <!-- 日期 -->
                        <div class="sh-homecontent-left-time" lang="year-' . $year;
                        $tmp2=$tmp . "-";
                        $tmp3=$tmp2 . $month;
                        $tmp4=$tmp3 . "-";
                        $tmp5=$tmp4 . $day;
                        $tmp6=$tmp5 . '" style="';
                        $tmp7=$tmp6 . $shougbsx;
                        $tmp8=$tmp7 . '">
                        <span class="homecontent-left-time-h">';
                        $tmp9=$tmp8 . $topxs;
                        $tmp10=$tmp9 . '</span>
                        </div>
                        <!-- 地址 -->
                        <div class="sh-homecontent-left-time-dw">';
                        $tmp11=$tmp10 . $ptpdw;
                        $tmp12=$tmp11 . '</div>
                        </div>
                        <div class="sh-homecontent-right-wk">
                        <!-- 右边内容主体 -->
                        <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
                        $tmp13=$tmp12 . $cid;
                        $tmp14=$tmp13 . '\';">
                        <!-- 仅文字 -->
                        <!-- 文字内容 -->
                        <div class="homecontent-right-nr" style="min-height: 10px;background: var(--fgxys);position:relative;">
                        <div class="homecontent-right-nr-text homecontent-right-nr-textjw" style="margin: 10px;">';
                        $tmp15=$tmp14 . $ptptext;
                        $tmp16=$tmp15 . '</div>
                        ';
                        $tmp17=$tmp16 . $wzsdbs;
                        $tmp18=$tmp17 . '
                        </div>
                        </div>
                        </div>
                        </div>';
                        $wzbank=$tmp18;
                    }
L2xx1a:
                }
            }
        }
        echo $wzbank;
    }
goto L2xxx;
L2xldMhxy:
L2xxx:
    $obj=$iars;
    $iars=$iars+1;
}
L2xx2u:
echo '<div class="sh-homecontent-lie" style="margin-top: 25px;display:flex;justify-content: center;">
<div style="width: 90%;border-bottom: 1px solid var(--fgxys);margin: 15px 0;"></div>
</div>';
goto L2xx4z;
L2xldMhx42:
L2xx4z: