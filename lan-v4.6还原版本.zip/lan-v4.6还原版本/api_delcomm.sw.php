<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp=$user_zh=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$user_passid=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit("请先登录!");
}
$num3=2763;
$isArray=is_array($_POST);
if($isArray){
    $num3=156;
}else{
    $num3=156;
    $num3=282;
}
switch($num3){
    case 156:{
    $plid=&$_POST['plid'];
        break;
    }
    case 219:{
        $plid=$_POST['plid'];
        break;
    }
}
$escaped=htmlspecialchars($plid);
unset($plid);
$escaped2=addslashes($escaped);
$plid=$escaped2;
if($plid==""){
    exit("参数不完整!");
}
$tmp=include '../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    exit("连接数据库失败");
}
$escaped=htmlspecialchars($user_zh);
$cookieResult=addslashes($escaped);
$user_zhsg=$cookieResult;
$tmp="select * from user where username='" . $user_zhsg;
$sqls=$tmp . "'";
$row=mysqli_query($conn, $sqls);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$data2s_row=$row;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$str="select * from user where username='" . $user_zh;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
if($user_passid!=$passid){
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("username", "", $str, "/");
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("passid", "", $str, "/");
    exit("账号信息异常,请重新登录!");
}
$auth_keylocation='./key.php';
$auth_keyauth='./auth.php';
$num=2753;
$row=file_exists($auth_keyauth);
if($row){
    $num=156;
}else{
    $num=168;
}
$tmp=14;
$tmp4=168;
$tmp2=$num==168;
if($tmp2)goto L2xeWjgxz;
goto L2xldMhxz;
L2xeWjgxz:
exit("授权验证文件不存在或被篡改,请确保文件完整且未篡改!");
goto L2xxy;
L2xldMhxz:
$tmp=42;
$tmp4=156;
$tmp2=$num==156;
if($tmp2)goto L2xeWjgx11;
goto L2xldMhx11;
L2xeWjgx11:
$tmp=require $auth_keyauth;
$tmp=!defined("sh_auth_state");
if($tmp){
    exit('授权验证失败,请确保文件完整且未篡改!');
}
$tmp=sh_auth_state!="ok";
if($tmp)goto L2xeWjgxx;
goto L2xxy;
goto L2xxy;
L2xeWjgxx:
exit('程序未授权,您的请求已被拒绝,请授权后使用!');
goto L2xxy;
L2xldMhx11:
L2xxy:
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($sentinel))break;
    $glyadmin=$row["username"];
}
L2xx1a:
$num2=2756;
$tmp=$zjzhq==$glyadmin;
if($tmp){
    $num2=144;
}else{
    $num2=144;
    $num2=4012;
}
$tmp=170;
$tmp4=144;
$tmp2=$num2==144;
if($tmp2)goto L2xeWjgx1p;
goto L2xldMhx1p;
L2xeWjgx1p:
$tmp="delete from comm where ecid='" . $plid;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx1f;
goto L2xldMhx1f;
goto L2xldMhx1f;
L2xeWjgx1f:
exit("删除评论成功!");
goto L2xx1o;
L2xldMhx1f:
exit("删除评论失败!");
L2xldMhx1p:
$tmp=72;
$tmp4=2078;
$tmp2=$num2==2078;
if($tmp2)goto L2xeWjgx1s;
goto L2xldMhx1s;
L2xeWjgx1s:
$tmp="select * from comm where ecid= '" . $plid;
$sql=$tmp . "'";
$row=mysqli_query($conn, $sql);
$result=$row;
$row=mysqli_num_rows($result);
$tmp=$row>0;
if($tmp){
    $row=mysqli_fetch_assoc($result);
    $row=$row;
    $sswid=$row["wzcid"];
}else{
    exit("该评论不存在!");
}
$tmp="select * from essay where cid= '" . $sswid;
$sql=$tmp . "'";
$row=mysqli_query($conn, $sql);
$result=$row;
$row=mysqli_num_rows($result);
$tmp=$row>0;
if($tmp){
    $row=mysqli_fetch_assoc($result);
    $row=$row;
    $wsuzh=$row["ptpuser"];
}else{
    exit("对应文章不存在!");
}
$tmp=$zjzhq==$wsuzh;
if($tmp)goto L2xeWjgx1l;
goto L2xldMhx1l;
goto L2xldMhx1l;
L2xeWjgx1l:
$tmp="delete from comm where ecid='" . $plid;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx1n;
goto L2xldMhx1n;
goto L2xldMhx1n;
L2xeWjgx1n:
exit("删除评论成功!");
goto L2xx1o;
L2xldMhx1n:
exit("删除评论失败!");
L2xldMhx1l:
exit("您无权删除其他用户的文章评论!");
L2xldMhx1s:
L2xx1o: