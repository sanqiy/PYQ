<?php
$iteace=1;
$replaced=is_file('../config.php');
if($replaced){
    $tmp=include '../config.php';
}
$tmp=include '../api/wz.php';
if($userdlzt==0){
    $replaced=header('location: ./login.php');
    exit();
}
$num6=5835;
$tmp=$user_zh==$glyadmin;
if($tmp){
    $num6=169;
}else{
    $num6=169;
    $num6=6345;
}
$tmp=17;
$tmp2=3257;
$tmp3=$num6==3257;
if($tmp3)goto L2xeWjgxe;
goto L2xldMhxe;
L2xeWjgxe:
exit('<script language="JavaScript">;alert("没有权限!");location.href="../index.php";</script>;');
goto L2xxd;
L2xldMhxe:
$tmp=196;
$tmp2=169;
$tmp3=$num6==169;
if($tmp3)goto L2xeWjgxf;
goto L2xldMhxf;
L2xeWjgxf:
$tmp=$user_passid!=$passid;
if($tmp)goto L2xeWjgxc;
goto L2xxd;
goto L2xxd;
L2xeWjgxc:
exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="./login.php";</script>;');
goto L2xxd;
L2xldMhxf:
L2xxd:
echo "<!doctype html>";
echo "
<html lang=\"en\">";
echo "
<head>";
echo "
<meta charset=\"utf-8\">";
echo "
<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0\">";
echo "
<title>评论列表 - ";
echo $name;
echo "</title>";
echo "
<meta name=\"keywords\" content=\"";
echo $filterkeyw;
echo "\">";
echo "
<meta name=\"description\" content=\"";
echo $subtitle;
echo "\">";
echo "
<meta name=\"author\" content=\"";
echo $name;
echo "\">";
echo "
<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"";
$num7=5834;
$replaced=strpos($icon, 'http');
$tmp=$replaced!==false;
if($tmp){
    $num7=234;
}else{
    $num7=169;
}
switch($num7){
    case 234:{
    echo $icon;
        break;
    }
    case 169:{
        $tmp='.' . $icon;
        echo $tmp;
        break;
    }
}
echo "\">";
echo "
<link rel=\"stylesheet\" href=\"assets/css/css2.css\">";
echo "
<link rel=\"stylesheet\" id=\"css-main\" href=\"assets/css/oneui.min.css\">";
echo "
<style>";
echo "
.table-vcenter td>a{";
echo "
width: 150px;";
echo "
display: -webkit-box;";
echo "
-webkit-box-orient: vertical;";
echo "
-webkit-line-clamp: 1;";
echo "
overflow: hidden;";
echo "
}";
echo "
.fa-fw{";
echo "
pointer-events: none;";
echo "
}";
echo "
</style>";
echo "
</head>";
echo "
<body>";
echo "
<div id=\"page-container\" class=\"sidebar-o sidebar-dark page-header-fixed main-content-narrow\">";
echo "
<nav id=\"sidebar\" aria-label=\"Main Navigation\">";
echo "
<!-- Side Header -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Logo -->";
echo "
<a class=\"fw-semibold text-dual\" href=\"index.php\">";
echo "
<span class=\"smini-visible\">";
echo "
<i class=\"fa fa-circle-notch text-primary\"></i>";
echo "
</span>";
echo "
<span class=\"smini-hide fs-5 tracking-wider\">后台管理</span>";
echo "
</a>";
echo "
<!-- END Logo -->";
echo "
";
echo "
<!-- Extra -->";
echo "
<div>";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" data-toggle=\"layout\" data-action=\"dark_mode_toggle\">";
echo "
<i class=\"far fa-moon\"></i>";
echo "
</button>";
echo "
<!-- END Dark Mode -->";
echo "
";
echo "
<!-- Options -->";
echo "
<div class=\"dropdown d-inline-block ms-1\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" id=\"sidebar-themes-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<i class=\"far fa-circle\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-end fs-sm smini-hide border-0\" aria-labelledby=\"sidebar-themes-dropdown\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"default\" href=\"#\">";
echo "
<span>默认</span>";
echo "
<i class=\"fa fa-circle text-default\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/amethyst.min.css\" href=\"#\">";
echo "
<span>紫色</span>";
echo "
<i class=\"fa fa-circle text-amethyst\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/city.min.css\" href=\"#\">";
echo "
<span>红色</span>";
echo "
<i class=\"fa fa-circle text-city\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/flat.min.css\" href=\"#\">";
echo "
<span>青色</span>";
echo "
<i class=\"fa fa-circle text-flat\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/modern.min.css\" href=\"#\">";
echo "
<span>蓝色</span>";
echo "
<i class=\"fa fa-circle text-modern\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/smooth.min.css\" href=\"#\">";
echo "
<span>粉色</span>";
echo "
<i class=\"fa fa-circle text-smooth\"></i>";
echo "
</a>";
echo "
<!-- END Color Themes -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_light\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 黑色</span>";
echo "
</a>";
echo "
<!-- END Sidebar Styles -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_light\" href=\"javascript:void(0)\">";
echo "
<span>导航 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>导航 黑色</span>";
echo "
</a>";
echo "
<!-- END Header Styles -->";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Options -->";
echo "
<a class=\"d-lg-none btn btn-sm btn-alt-secondary ms-1\" data-toggle=\"layout\" data-action=\"sidebar_close\" href=\"javascript:void(0)\">";
echo "
<i class=\"fa fa-fw fa-times\"></i>";
echo "
</a>";
echo "
<!-- END Close Sidebar -->";
echo "
</div>";
echo "
<!-- END Extra -->";
echo "
</div>";
echo "
<!-- END Side Header -->";
echo "
";
echo "
<!-- Sidebar Scrolling -->";
echo "
<div class=\"js-sidebar-scroll\">";
echo "
<!-- Side Navigation -->";
echo "
<div class=\"content-side\">";
echo "
<ul class=\"nav-main\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./index.php\">";
echo "
<i class=\"nav-main-link-icon si si-speedometer\"></i>";
echo "
<span class=\"nav-main-link-name\">后台首页</span>";
echo "
</a>";
echo "
</li>";
echo "
";
echo "
<li class=\"nav-main-heading\">设置</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-energy\"></i>";
echo "
<span class=\"nav-main-link-name\">网站设置</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./basic.php\">";
echo "
<span class=\"nav-main-link-name\">基础设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./authority.php\">";
echo "
<span class=\"nav-main-link-name\">权限设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./imgset.php\">";
echo "
<span class=\"nav-main-link-name\">图像设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./emailset.php\">";
echo "
<span class=\"nav-main-link-name\">邮箱设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./calis.php\">";
echo "
<span class=\"nav-main-link-name\">卡密管理</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-users\"></i>";
echo "
<span class=\"nav-main-link-name\">用户管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./userlist.php\">";
echo "
<span class=\"nav-main-link-name\">用户列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-book-open\"></i>";
echo "
<span class=\"nav-main-link-name\">文章管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditesli.php\">";
echo "
<span class=\"nav-main-link-name\">文章列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditessh.php\">";
echo "
<span class=\"nav-main-link-name\">审核文章</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item open\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-speech\"></i>";
echo "
<span class=\"nav-main-link-name\">评论管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link active\" href=\"./auditcoli.php\">";
echo "
<span class=\"nav-main-link-name\">评论列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditcosh.php\">";
echo "
<span class=\"nav-main-link-name\">审核评论</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-paper-clip\"></i>";
echo "
<span class=\"nav-main-link-name\">友链管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./linkset.php\">";
echo "
<span class=\"nav-main-link-name\">友链列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
</ul>";
echo "
</div>";
echo "
<!-- END Side Navigation -->";
echo "
</div>";
echo "
<!-- END Sidebar Scrolling -->";
echo "
</nav>";
echo "
<!-- END Sidebar -->";
echo "
";
echo "
<!-- Header -->";
echo "
<header id=\"page-header\">";
echo "
<!-- Header Content -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Left Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- Toggle Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-lg-none\" data-toggle=\"layout\" data-action=\"sidebar_toggle\">";
echo "
<i class=\"fa fa-fw fa-bars\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Sidebar -->";
echo "
";
echo "
<!-- Toggle Mini Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-none d-lg-inline-block\" data-toggle=\"layout\" data-action=\"sidebar_mini_toggle\">";
echo "
<i class=\"fa fa-fw fa-ellipsis-v\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Mini Sidebar -->";
echo "
";
echo "
<!-- Open Search Section (visible on smaller screens) -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
";
echo "
<!-- END Open Search Section -->";
echo "
";
echo "
<!-- Search Form (visible on larger screens) -->";
echo "
";
echo "
<!-- END Search Form -->";
echo "
</div>";
echo "
<!-- END Left Section -->";
echo "
";
echo "
<!-- Right Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- User Dropdown -->";
echo "
<div class=\"dropdown d-inline-block ms-2\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary d-flex align-items-center\" id=\"page-header-user-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<img class=\"rounded-circle\" src=\"";
$num=5851;
$replaced=strpos($user_img, 'http');
$tmp=$replaced!==false;
if($tmp){
    $num=324;
}else{
    $num=324;
    $num=5580;
}
switch($num){
    case 2952:{
    $tmp='.' . $user_img;
    echo $tmp;
        break;
    }
    case 324:{
        echo $user_img;
        break;
    }
}
echo "\" alt=\"Header Avatar\" style=\"width: 21px;\">";
echo "
<span class=\"d-none d-sm-inline-block ms-2\">";
echo $user_name;
echo "</span>";
echo "
<i class=\"fa fa-fw fa-angle-down d-none d-sm-inline-block opacity-50 ms-1 mt-1\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-md dropdown-menu-end p-0 border-0\" aria-labelledby=\"page-header-user-dropdown\">";
echo "
<div class=\"p-3 text-center bg-body-light border-bottom rounded-top\">";
echo "
<img class=\"img-avatar img-avatar48 img-avatar-thumb\" src=\"";
$num2=5839;
$replaced=strpos($user_img, 'http');
$tmp=$replaced!==false;
if($tmp){
    $num2=169;
}else{
    $num2=234;
}
switch($num2){
    case 234:{
    $tmp='.' . $user_img;
    echo $tmp;
        break;
    }
    case 169:{
        echo $user_img;
        break;
    }
}
echo "\" alt=\"\">";
echo "
<p class=\"mt-2 mb-0 fw-medium\">";
echo $user_name;
echo "</p>";
echo "
<!--p class=\"mb-0 text-muted fs-sm fw-medium\">介绍</p-->";
echo "
</div>";
echo "
<div role=\"separator\" class=\"dropdown-divider m-0\"></div>";
echo "
<div class=\"p-2\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"../\">";
echo "
<span class=\"fs-sm fw-medium\">返回前台</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"JavaScript:;\" onclick=\"logut()\">";
echo "
<span class=\"fs-sm fw-medium\">退出登录</span>";
echo "
</a>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
<!-- END User Dropdown -->";
echo "
";
echo "
<!-- Notifications Dropdown -->";
echo "
";
echo "
<!-- END Notifications Dropdown -->";
echo "
";
echo "
<!-- Toggle Side Overlay -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
<!-- END Toggle Side Overlay -->";
echo "
</div>";
echo "
<!-- END Right Section -->";
echo "
</div>";
echo "
<!-- END Header Content -->";
echo "
";
echo "
<!-- Header Loader -->";
echo "
<!-- Please check out the Loaders page under Components category to see examples of showing/hiding it -->";
echo "
<div id=\"page-header-loader\" class=\"overlay-header bg-body-extra-light\">";
echo "
<div class=\"content-header\">";
echo "
<div class=\"w-100 text-center\">";
echo "
<i class=\"fa fa-fw fa-circle-notch fa-spin\"></i>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Header Loader -->";
echo "
</header>";
echo "
<!-- END Header -->";
echo "
";
echo "
<!-- Main Container -->";
echo "
<main id=\"main-container\">";
echo "
";
echo "
<!-- Page Content -->";
echo "
<div class=\"content\">";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\">评论列表</h3>";
echo "
<div class=\"block-options space-x-1\">";
echo "
<button id=\"so-search\" type=\"button\" class=\"btn btn-sm btn-alt-secondary js-class-toggle-enabled\" data-toggle=\"class-toggle\" data-target=\"#one-dashboard-search-orders\" data-class=\"d-none\">";
echo "
<i class=\"fa fa-search\"></i>";
echo "
</button>";
echo "
";
echo "
</div>";
echo "
</div>";
echo "
<div id=\"one-dashboard-search-orders\" class=\"block-content border-bottom d-none\">";
echo "
<!-- Search Form -->";
echo "
<form action=\"be_pages_dashboard.php\" method=\"POST\" onsubmit=\"return false;\">";
echo "
<div class=\"push\">";
echo "
<div class=\"input-group\">";
echo "
<input type=\"text\" class=\"form-control form-control-alt\" id=\"one-ecom-orders-search\" name=\"one-ecom-orders-search\" placeholder=\"Search all orders..\">";
echo "
<span class=\"input-group-text bg-body border-0\">";
echo "
<i class=\"fa fa-search\"></i>";
echo "
</span>";
echo "
</div>";
echo "
</div>";
echo "
</form>";
echo "
<!-- END Search Form -->";
echo "
</div>";
echo "
<div class=\"block-content block-content-full\">";
echo "
<!-- Recent Orders Table -->";
echo "
<div class=\"table-responsive\">";
echo "
<table class=\"table table-hover table-vcenter\">";
echo "
<thead>";
echo "
<tr>";
echo "
<th class=\"text-center\" style=\"width: 70px;\">";
echo "
<div class=\"form-check d-inline-block\">";
echo "
<input class=\"form-check-input\" type=\"checkbox\" value=\"\" id=\"check-all\" name=\"check-all\">";
echo "
<label class=\"form-check-label\" for=\"check-all\"></label>";
echo "
</div>";
echo "
</th>";
echo "
<th>昵称</th>";
echo "
<th>邮箱</th>";
echo "
<th>评论内容</th>";
echo "
<th>来自文章</th>";
echo "
<th>IP</th>";
echo "
<th>时间</th>";
echo "
<th>操作</th>";
echo "
</tr>";
echo "
</thead>";
echo "
<tbody class=\"fs-sm\">";
echo "
";
$num3=5841;
$isArray=is_array($_GET);
if($isArray){
    $type=&$_GET['page'];
}else{
    $type=$_GET['page'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$tmp=$escaped2!="";
if($tmp){
    $num3=234;
}else{
    $num3=169;
}
switch($num3){
    case 234:{
    $page=$_GET['page'];
        break;
    }
    case 169:{
        $page=1;
        break;
    }
}
$perPage=50;
$tmp=$page-1;
$offset=$tmp*50;
$tmp="SELECT * FROM comm where comaud= '1' order by id desc LIMIT " . 50;
$tmp2=$tmp . " OFFSET ";
$sql3=$tmp2 . $offset;
$result=$conn->query("SELECT COUNT(*) AS total FROM comm where comaud= '1'");
$row=$result->fetch_assoc();
$totalRecords=$row;
$num4=5843;
$isArray=is_array($_GET);
if($isArray){
    $num4=169;
}else{
    $num4=324;
}
switch($num4){
    case 169:{
    $type=&$_GET['keyword'];
        break;
    }
    case 324:{
        $type=$_GET['keyword'];
        break;
    }
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$keyword=$escaped2;
if($keyword!=""){
    $tmp="SELECT * FROM comm WHERE cotext LIKE '%" . $keyword;
    $sql3=$tmp . "%' AND comaud = '1' ORDER BY id DESC";
}
$result=$conn->query($sql3);
$result3=$result;
if($result3->num_rows>0)goto L2xeWjgx3f;
goto L2xldMhx3f;
L2xeWjgx3f:
while(true){
    $result=$result3->fetch_assoc();
    $row3=$result;
    if(!$replaced2)break;
    $couser=$row3["couser"];
    $coimg=$row3["coimg"];
    $coname=$row3["coname"];
    $courl=$row3["courl"];
    $cotext=$row3["cotext"];
    $bcouser=$row3["bcouser"];
    $bconame=$row3["bconame"];
    $comaud=$row3["comaud"];
    $cotime=$row3["cotime"];
    $coip=$row3["ip"];
    $wzcid=$row3["wzcid"];
    $ecid=$row3["ecid"];
    $pldid=$row3["id"];
    $tmp="SELECT * FROM essay WHERE cid = '" . $wzcid;
    $sql33=$tmp . "'";
    $result=$conn->query($sql33);
    $result33=$result;
    $tmp=$result33->num_rows>0;
if($tmp)goto L2xeWjgx1j;
goto L2xldMhx1j;
goto L2xldMhx1j;
goto L2xldMhx1j;
L2xeWjgx1j:
    while(true){
        $result=$result33->fetch_assoc();
        $row33=$result;
        if(!$replaced2)break;
        $wzdnr=$row33["ptptext"];
        $wzdnrlx=$row33["ptplx"];
        $tmp=$wzdnr=="";
if($tmp)goto L2xeWjgx1n;
goto L2xldMhx1n;
goto L2xldMhx1n;
goto L2xldMhx1n;
goto L2xldMhx1n;
L2xeWjgx1n:
        $tmp=$wzdnrlx=="video";
if($tmp)goto L2xeWjgx1p;
goto L2xldMhx1p;
goto L2xldMhx1p;
goto L2xldMhx1p;
goto L2xldMhx1p;
L2xeWjgx1p:
        $wzdnr="视频文章不支持预览";
goto L2xx1m;
L2xldMhx1p:
        $tmp=$wzdnrlx=="music";
if($tmp)goto L2xeWjgx1q;
goto L2xx1m;
goto L2xx1m;
goto L2xx1m;
goto L2xx1m;
L2xeWjgx1q:
        $wzdnr="音乐文章不支持预览";
goto L2xx1m;
L2xldMhx1n:
L2xx1m:
        $pattern='/<a\s+[^>]*>(.*?)<\/a>/i';
        $replacement='$1';
        $replaced2=preg_replace($pattern,$replacement,$cotext);
        $cotext=$replaced2;
        $replaced=str_replace('./assets/owo/paopao/', '../../assets/owo/paopao/', $wzdnr, $count);
        $wzdnr=$replaced;
        $wzdnr=$wzdnr . PHP_EOL;
        $replaced=str_replace('src="./assets/img/thumbnail.svg"', '', $wzdnr, $count);
        $wzdnr=$replaced;
        $wzdnr=$wzdnr . PHP_EOL;
        $replaced=str_replace('data-src="', 'src="', $wzdnr, $count);
        $wzdnr=$replaced;
        $wzdnr=$wzdnr . PHP_EOL;
        $replaced=str_replace('<img ', '<img style="width: 24px;height: 24px;" ', $wzdnr, $count);
        $wzdnr=$replaced;
        $wzdnr=$wzdnr . PHP_EOL;
        $pattern='/<a\s+[^>]*>(.*?)<\/a>/i';
        $replacement='$1';
        $replaced2=preg_replace($pattern,$replacement,$wzdnr);
        $wzdnr=$replaced2;
    }
goto L2xx1i;
L2xldMhx1j:
L2xx1i:
    $tmp="SELECT * FROM user WHERE username = '" . $couser;
    $sql33=$tmp . "'";
    $result=$conn->query($sql33);
    $result33=$result;
    $tmp=$result33->num_rows>0;
if($tmp)goto L2xeWjgx21;
goto L2xldMhx21;
goto L2xldMhx21;
goto L2xldMhx21;
L2xeWjgx21:
    while(true){
        $result=$result33->fetch_assoc();
        $row33=$result;
        if(!$replaced2)break;
        $couseremail=$row33["email"];
    }
goto L2xx2z;
L2xldMhx21:
L2xx2z:
    $replaced=strpos($couser, "vis#-[");
    $tmp=$replaced!==false;
    $tmp3=(bool)$tmp;
    $tmp4=!$tmp3;
    if($tmp4){
        $pos=strpos($couser, "-#vis");
        $tmp2=$pos!==false;
        $tmp3=(bool)$tmp2;
    }
    if($tmp3){
        $val[]='vis#-[';
        $val[]=']-#vis';
        $replaced3=str_replace($val, '', $couser);
        $couseremail=$replaced3;
    }
    $str="select * from essay where cid='" . $wzcid;
    $str2=$str . "'";
    $replaced=mysqli_query($conn, $str2);
    $data_result=$replaced;
    $replaced=mysqli_fetch_array($data_result);
    $data_row=$replaced;
    $wzdlx=$data_row["ptplx"];
    $wzdtp=$data_row["ptpimag"];
    $tmp=$wzdlx=="img";
if($tmp)goto L2xeWjgx2b;
goto L2xldMhx2b;
goto L2xldMhx2b;
goto L2xldMhx2b;
L2xeWjgx2b:
    $tmp=$wzdtp!="";
if($tmp)goto L2xeWjgx2d;
goto L2xldMhx2d;
goto L2xldMhx2d;
goto L2xldMhx2d;
L2xeWjgx2d:
    $replaced=explode('(+@+)', $wzdtp);
    $imgar=$replaced;
    $replaced=count($imgar);
    $coun=$replaced;
    $wzdtp=$imgar[0];
    $replaced=strpos($wzdtp, './upload/');
    $tmp=$replaced!==false;
if($tmp)goto L2xeWjgx2f;
goto L2xx2a;
goto L2xx2a;
goto L2xx2a;
L2xeWjgx2f:
    $wzdtp='../../' . $wzdtp;
goto L2xx2a;
L2xldMhx2d:
    $wzdtp="./../assets/img/thumbnailbg.svg";
L2xldMhx2b:
    $wzdtp="../../assets/img/thumbnailbg.svg";
L2xx2a:
    $tmp=$coimg=="./assets/img/tx.png";
    if($tmp){
        $coimg="../../assets/img/tx.png";
    }else{
        $replaced=strpos($coimg, './user/headimg/');
        $tmp=$replaced!==false;
        if($tmp){
            $coimg="../." . $coimg;
        }
    }
    $replaced=str_replace('./assets/owo/paopao/', '../../assets/owo/paopao/', $cotext, $count);
    $cotext=$replaced;
    $cotext=$cotext . PHP_EOL;
    $replaced=str_replace('src="./assets/img/thumbnail.svg"', '', $cotext, $count);
    $cotext=$replaced;
    $cotext=$cotext . PHP_EOL;
    $replaced=str_replace('data-src="', 'src="', $cotext, $count);
    $cotext=$replaced;
    $cotext=$cotext . PHP_EOL;
    $replaced=str_replace('<img ', '<img style="width: 24px;height: 24px;" ', $cotext, $count);
    $cotext=$replaced;
    $cotext=$cotext . PHP_EOL;
    $tmp='<tr id="sh-plid-' . $ecid;
    $tmp2=$tmp . '">
    <td class="text-center">
    <div class="form-check d-inline-block">
    <input class="form-check-input" type="checkbox" value="" id="row_1" name="row_1">
    <label class="form-check-label" for="row_1"></label>
    </div>
    </td>
    <td><img style="border-radius: 4px;object-fit: cover;margin-right: 10px;margin-bottom: 10px;" class="img-avatar img-avatar-36 m-r-10" src="';
    $tmp3=$tmp2 . $coimg;
    $tmp4=$tmp3 . '" alt="头像">';
    $tmp5=$tmp4 . $coname;
    $tmp6=$tmp5 . '</td>
    <td>';
    $tmp7=$tmp6 . $couseremail;
    $tmp8=$tmp7 . '</td>
    <td style="color: #e83e8c;"><a>';
    $tmp9=$tmp8 . $cotext;
    $tmp10=$tmp9 . '</a></td>
    <td><a href="../view.php?cid=';
    $tmp11=$tmp10 . $wzcid;
    $tmp12=$tmp11 . '" target="_blank" title="" data-toggle="tooltip" data-original-title="" style="color: var(--dark);">';
    $tmp13=$tmp12 . $wzdnr;
    $tmp14=$tmp13 . '</a></td>
    <td>';
    $tmp15=$tmp14 . $coip;
    $tmp16=$tmp15 . '</td>
    <td>';
    $tmp17=$tmp16 . $cotime;
    $tmp18=$tmp17 . '</td>
    <td>
    <button type="button" class="btn btn-sm btn-danger" onclick="scwtgpl()" lang="';
    $tmp19=$tmp18 . $ecid;
    $tmp20=$tmp19 . '">
    <i class="fa fa-fw fa-times"></i>
    </button>';
    echo $tmp20;
    echo '</td>
    </tr>';
}
goto L2xx3e;
L2xldMhx3f:
L2xx3e:
$totalRecords=$totalRecords['total'];
$str=$totalRecords/$perPage;
$replaced=ceil($str);
$maxPages=$replaced;
echo "                      </tbody>";
echo "
</table>";
echo "
</div>";
echo "
";
$tmp='<div class="fixed-table-pagination callout" style="background-color: rgb(255 255 255 / 0%);display: flex;justify-content: space-between;align-items: center;margin-top:10px;">
<div class="float-left pagination-detail" style="margin-bottom: 10px;">
<span class="pagination-info">
每页显示' . $perPage;
$tmp2=$tmp . '条数据，总共';
$tmp3=$tmp2 . $totalRecords;
$tmp4=$tmp3 . '条数据
</span>
</div>
<div class="float-right pagination">
<ul class="pagination">';
echo $tmp4;
$num5=5849;
$isArray=is_array($_GET);
if($isArray){
    $type=&$_GET['type'];
}else{
    $type=$_GET['type'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$tmp=$escaped2!="";
if($tmp){
    $num5=169;
}else{
    $num5=169;
    $num5=10627;
}
switch($num5){
    case 5398:{
    $typez="";
        break;
    }
    case 169:{
        $isArray=is_array($_GET);
        if($isArray){
            $type=&$_GET['type'];
        }else{
            $type=$_GET['type'];
        }
        $escaped=htmlspecialchars($type);
        unset($type);
        $escaped2=addslashes($escaped);
        $tmp='type=' . $escaped2;
        $typez=$tmp . '&';
        break;
    }
}
if($maxPages>1)goto L2xeWjgx57;
goto L2xldMhx57;
L2xeWjgx57:
$tmp=$page>1;
if($tmp){
    $tmp='<li class="page-item"><a class="page-link" aria-label="首页" href="./auditcoli.php?' . $typez;
    $tmp2=$tmp . 'page=1">首页</a></li>';
    echo $tmp2;
    $tmp='<li class="page-item page-pre"><a class="page-link" aria-label="上一页" href="./auditcoli.php?' . $typez;
    $tmp2=$tmp . 'page=';
    $tmp3=$page-1;
    $tmp4=$tmp2 . $tmp3;
    $tmp5=$tmp4 . '">‹</a></li>';
    echo $tmp5;
}
$str=$page-1;
$replaced=max($str);
$start=$replaced;
$str=$page+1;
$replaced=min($str, $maxPages);
$end=$replaced;
$tmp=$start>1;
if(!($tmp)){
}else{
    $replaced2=$start;
    $i=$replaced2;
}
while(true){
    $tmp=$i<=$end;
    if(!$tmp)break;
    $tmp=$i==$page;
    if($tmp){
        $tmp='<li class="page-item active"><a class="page-link" aria-label="第' . $i;
        $tmp2=$tmp . '页" href="./auditcoli.php?';
        $tmp3=$tmp2 . $typez;
        $tmp4=$tmp3 . 'page=';
        $tmp5=$tmp4 . $i;
        $tmp6=$tmp5 . '">';
        $tmp7=$tmp6 . $i;
        $tmp8=$tmp7 . '</a></li>';
        echo $tmp8;
    }else{
        $tmp='<li class="page-item "><a class="page-link" aria-label="第' . $i;
        $tmp2=$tmp . '页" href="./auditcoli.php?';
        $tmp3=$tmp2 . $typez;
        $tmp4=$tmp3 . 'page=';
        $tmp5=$tmp4 . $i;
        $tmp6=$tmp5 . '">';
        $tmp7=$tmp6 . $i;
        $tmp8=$tmp7 . '</a></li>';
        echo $tmp8;
    }
    $obj=$i;
    $obj2=$i+1;
    $replaced2=$obj2;
    $i=$replaced2;
}
L2xx4x:
$tmp=$end<$maxPages;
if($tmp){
    echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
}
$tmp=$page<$maxPages;
if($tmp)goto L2xeWjgx55;
goto L2xx56;
goto L2xx56;
L2xeWjgx55:
$tmp='<li class="page-item page-pre"><a class="page-link" aria-label="下一页" href="./auditcoli.php?' . $typez;
$tmp2=$tmp . 'page=';
$tmp3=$page+1;
$tmp4=$tmp2 . $tmp3;
$tmp5=$tmp4 . '">›</a></li>';
echo $tmp5;
$tmp='<li class="page-item"><a class="page-link" aria-label="尾页" href="./auditcoli.php?' . $typez;
$tmp2=$tmp . 'page=';
$tmp3=$tmp2 . $maxPages;
$tmp4=$tmp3 . '">尾页</a></li>';
echo $tmp4;
goto L2xx56;
L2xldMhx57:
L2xx56:
echo '
</ul>
</div>
</div>';
echo "                ";
echo "
<!-- END Recent Orders Table -->";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
</div>";
echo "
<!-- END Page Content -->";
echo "
</main>";
echo "
<!-- END Main Container -->";
echo "
";
echo "
<!-- Footer -->";
echo "
<footer id=\"page-footer\" class=\"bg-body-light\">";
echo "
<div class=\"content py-3\">";
echo "
<div class=\"row fs-sm\">";
echo "
<div class=\"col-sm-6 order-sm-2 py-1 text-center text-sm-end\">";
echo "
Crafted with <i class=\"fa fa-heart text-danger\"></i> by <a class=\"fw-semibold\" href=\"https://qemao.com\" target=\"_blank\">苏画</a>";
echo "
</div>";
echo "
<div class=\"col-sm-6 order-sm-1 py-1 text-center text-sm-start\">";
echo "
<a class=\"fw-semibold\" href=\"https://www.qemao.com\" target=\"_blank\">LAN</a> &copy; <span data-toggle=\"year-copy\"></span>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</footer>";
echo "
<!-- END Footer -->";
echo "
</div>";
echo "
<!-- END Page Container -->";
echo "
";
echo "
<!--";
echo "
OneUI JS";
echo "
";
echo "
Core libraries and functionality";
echo "
webpack is putting everything together at assets/_js/main/app.js";
echo "
-->";
echo "
<script src=\"assets/js/oneui.app.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Plugins -->";
echo "
<script src=\"assets/js/chart.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Code -->";
echo "
<script src=\"assets/js/be_pages_dashboard.min.js\"></script>";
echo "
<script type=\"text/javascript\">";
echo "
//驳回删除评论事件";
echo "
;function scwtgpl() {
    ";echo "
    if (confirm(\"确定要删除此评论吗?\")) {";
    echo "
    // 用户点击了确认按钮";
    echo "
} else {";
echo "
// 用户点击了取消按钮或关闭了弹窗";
echo "
return;";
echo "
}";
echo "
";
echo "
var ele = window.event.srcElement.lang;";
echo "
// 异步对象";
echo "
var xhr = new XMLHttpRequest();";
echo "
// 设置属性";
echo "
xhr.open('post', './api/escoaud.php');";
echo "
// 如果想要使用post提交数据,必须添加此行";
echo "
xhr.setRequestHeader(\"Content-type\", \"application/x-www-form-urlencoded\");";
echo "
// 将数据通过send方法传递";
echo "
xhr.send('ztm=bhpl&cs='+ele);";
echo "
// 发送并接受返回值";
echo "
xhr.onreadystatechange = function () {";
echo "
// 这步为判断服务器是否正确响应";
echo "
if (xhr.readyState == 4 && xhr.status == 200) {";
echo "
if (xhr.responseText == \"\") {";
echo "
alert(\"未获取到数据!\");";
echo "
return;";
echo "
}";
echo "
//alert(xhr.responseText);";
echo "
if (xhr.responseText == \"200\") {";
echo "
var x = document.getElementById(\"sh-plid-\"+ele);";
echo "
//如果对象x不为空";
echo "
if (x != null){";
echo "
x.remove();";
echo "
}";
echo "
}else{";
echo "
alert(xhr.responseText);";
echo "
}";
echo "
}";
echo "
};";
echo "
}";echo "
</script>";echo "
</body>";echo "
</html>";echo "
";