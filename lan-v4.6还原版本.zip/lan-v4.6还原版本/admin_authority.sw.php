<?php
$iteace=1;
$pos=is_file('../config.php');
if($pos){
    $tmp=include '../config.php';
}
$tmp=include '../api/wz.php';
if($userdlzt==0){
    $pos=header('location: ./login.php');
    exit();
}
$num20=6872;
$tmp=$user_zh==$glyadmin;
if($tmp){
    $num20=361;
}else{
    $num20=55;
}
$tmp=36;
$tmp2=361;
$tmp3=$num20==361;
if($tmp3)goto L2xeWjgxe;
goto L2xldMhxe;
L2xeWjgxe:
$tmp=$user_passid!=$passid;
if($tmp)goto L2xeWjgxc;
goto L2xxd;
goto L2xxd;
L2xeWjgxc:
exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="./login.php";</script>;');
goto L2xxd;
L2xldMhxe:
switch($num20){
    case 55:{
    exit('<script language="JavaScript">;alert("没有权限!");location.href="../index.php";</script>;');
        break;
    }
}
L2xxd:
echo "<!doctype html>";
echo "
<html lang=\"en\">";
echo "
<head>";
echo "
<meta charset=\"utf-8\">";
echo "
<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0\">";
echo "
<title>权限设置 - ";
echo $name;
echo "</title>";
echo "
<meta name=\"keywords\" content=\"";
echo $filterkeyw;
echo "\">";
echo "
<meta name=\"description\" content=\"";
echo $subtitle;
echo "\">";
echo "
<meta name=\"author\" content=\"";
echo $name;
echo "\">";
echo "
<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"";
$num21=6872;
$pos=strpos($icon, 'http');
$tmp=$pos!==false;
if($tmp){
    $num21=60;
}else{
    $num21=30;
}
switch($num21){
    case 30:{
    $tmp='.' . $icon;
    echo $tmp;
        break;
    }
    case 60:{
        echo $icon;
        break;
    }
}
echo "\">";
echo "
<link rel=\"stylesheet\" href=\"assets/css/css2.css\">";
echo "
<link rel=\"stylesheet\" id=\"css-main\" href=\"assets/css/oneui.min.css\">";
echo "
</head>";
echo "
<body>";
echo "
<div id=\"page-container\" class=\"sidebar-o sidebar-dark page-header-fixed main-content-narrow\">";
echo "
<nav id=\"sidebar\" aria-label=\"Main Navigation\">";
echo "
<!-- Side Header -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Logo -->";
echo "
<a class=\"fw-semibold text-dual\" href=\"index.php\">";
echo "
<span class=\"smini-visible\">";
echo "
<i class=\"fa fa-circle-notch text-primary\"></i>";
echo "
</span>";
echo "
<span class=\"smini-hide fs-5 tracking-wider\">后台管理</span>";
echo "
</a>";
echo "
<!-- END Logo -->";
echo "
";
echo "
<!-- Extra -->";
echo "
<div>";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" data-toggle=\"layout\" data-action=\"dark_mode_toggle\">";
echo "
<i class=\"far fa-moon\"></i>";
echo "
</button>";
echo "
<!-- END Dark Mode -->";
echo "
";
echo "
<!-- Options -->";
echo "
<div class=\"dropdown d-inline-block ms-1\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" id=\"sidebar-themes-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<i class=\"far fa-circle\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-end fs-sm smini-hide border-0\" aria-labelledby=\"sidebar-themes-dropdown\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"default\" href=\"#\">";
echo "
<span>默认</span>";
echo "
<i class=\"fa fa-circle text-default\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/amethyst.min.css\" href=\"#\">";
echo "
<span>紫色</span>";
echo "
<i class=\"fa fa-circle text-amethyst\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/city.min.css\" href=\"#\">";
echo "
<span>红色</span>";
echo "
<i class=\"fa fa-circle text-city\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/flat.min.css\" href=\"#\">";
echo "
<span>青色</span>";
echo "
<i class=\"fa fa-circle text-flat\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/modern.min.css\" href=\"#\">";
echo "
<span>蓝色</span>";
echo "
<i class=\"fa fa-circle text-modern\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/smooth.min.css\" href=\"#\">";
echo "
<span>粉色</span>";
echo "
<i class=\"fa fa-circle text-smooth\"></i>";
echo "
</a>";
echo "
<!-- END Color Themes -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_light\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 黑色</span>";
echo "
</a>";
echo "
<!-- END Sidebar Styles -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_light\" href=\"javascript:void(0)\">";
echo "
<span>导航 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>导航 黑色</span>";
echo "
</a>";
echo "
<!-- END Header Styles -->";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Options -->";
echo "
<a class=\"d-lg-none btn btn-sm btn-alt-secondary ms-1\" data-toggle=\"layout\" data-action=\"sidebar_close\" href=\"javascript:void(0)\">";
echo "
<i class=\"fa fa-fw fa-times\"></i>";
echo "
</a>";
echo "
<!-- END Close Sidebar -->";
echo "
</div>";
echo "
<!-- END Extra -->";
echo "
</div>";
echo "
<!-- END Side Header -->";
echo "
";
echo "
<!-- Sidebar Scrolling -->";
echo "
<div class=\"js-sidebar-scroll\">";
echo "
<!-- Side Navigation -->";
echo "
<div class=\"content-side\">";
echo "
<ul class=\"nav-main\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./index.php\">";
echo "
<i class=\"nav-main-link-icon si si-speedometer\"></i>";
echo "
<span class=\"nav-main-link-name\">后台首页</span>";
echo "
</a>";
echo "
</li>";
echo "
";
echo "
<li class=\"nav-main-heading\">设置</li>";
echo "
<li class=\"nav-main-item  open\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-energy\"></i>";
echo "
<span class=\"nav-main-link-name\">网站设置</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./basic.php\">";
echo "
<span class=\"nav-main-link-name\">基础设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link active\" href=\"./authority.php\">";
echo "
<span class=\"nav-main-link-name\">权限设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./imgset.php\">";
echo "
<span class=\"nav-main-link-name\">图像设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./emailset.php\">";
echo "
<span class=\"nav-main-link-name\">邮箱设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./calis.php\">";
echo "
<span class=\"nav-main-link-name\">卡密管理</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-users\"></i>";
echo "
<span class=\"nav-main-link-name\">用户管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./userlist.php\">";
echo "
<span class=\"nav-main-link-name\">用户列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-book-open\"></i>";
echo "
<span class=\"nav-main-link-name\">文章管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditesli.php\">";
echo "
<span class=\"nav-main-link-name\">文章列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditessh.php\">";
echo "
<span class=\"nav-main-link-name\">审核文章</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-speech\"></i>";
echo "
<span class=\"nav-main-link-name\">评论管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditcoli.php\">";
echo "
<span class=\"nav-main-link-name\">评论列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditcosh.php\">";
echo "
<span class=\"nav-main-link-name\">审核评论</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-paper-clip\"></i>";
echo "
<span class=\"nav-main-link-name\">友链管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./linkset.php\">";
echo "
<span class=\"nav-main-link-name\">友链列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
</ul>";
echo "
</div>";
echo "
<!-- END Side Navigation -->";
echo "
</div>";
echo "
<!-- END Sidebar Scrolling -->";
echo "
</nav>";
echo "
<!-- END Sidebar -->";
echo "
";
echo "
<!-- Header -->";
echo "
<header id=\"page-header\">";
echo "
<!-- Header Content -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Left Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- Toggle Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-lg-none\" data-toggle=\"layout\" data-action=\"sidebar_toggle\">";
echo "
<i class=\"fa fa-fw fa-bars\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Sidebar -->";
echo "
";
echo "
<!-- Toggle Mini Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-none d-lg-inline-block\" data-toggle=\"layout\" data-action=\"sidebar_mini_toggle\">";
echo "
<i class=\"fa fa-fw fa-ellipsis-v\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Mini Sidebar -->";
echo "
";
echo "
<!-- Open Search Section (visible on smaller screens) -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
";
echo "
<!-- END Open Search Section -->";
echo "
";
echo "
<!-- Search Form (visible on larger screens) -->";
echo "
";
echo "
<!-- END Search Form -->";
echo "
</div>";
echo "
<!-- END Left Section -->";
echo "
";
echo "
<!-- Right Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- User Dropdown -->";
echo "
<div class=\"dropdown d-inline-block ms-2\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary d-flex align-items-center\" id=\"page-header-user-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<img class=\"rounded-circle\" src=\"";
$num=6874;
$pos=strpos($user_img, 'http');
$tmp=$pos!==false;
if($tmp){
    $num=209;
}else{
    $num=95;
}
switch($num){
    case 209:{
    echo $user_img;
        break;
    }
    case 95:{
        $tmp='.' . $user_img;
        echo $tmp;
        break;
    }
}
echo "\" alt=\"Header Avatar\" style=\"width: 21px;\">";
echo "
<span class=\"d-none d-sm-inline-block ms-2\">";
echo $user_name;
echo "</span>";
echo "
<i class=\"fa fa-fw fa-angle-down d-none d-sm-inline-block opacity-50 ms-1 mt-1\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-md dropdown-menu-end p-0 border-0\" aria-labelledby=\"page-header-user-dropdown\">";
echo "
<div class=\"p-3 text-center bg-body-light border-bottom rounded-top\">";
echo "
<img class=\"img-avatar img-avatar48 img-avatar-thumb\" src=\"";
$num2=6866;
$pos=strpos($user_img, 'http');
$tmp=$pos!==false;
if($tmp){
    $num2=190;
}else{
    $num2=114;
}
switch($num2){
    case 190:{
    echo $user_img;
        break;
    }
    case 114:{
        $tmp='.' . $user_img;
        echo $tmp;
        break;
    }
}
echo "\" alt=\"\">";
echo "
<p class=\"mt-2 mb-0 fw-medium\">";
echo $user_name;
echo "</p>";
echo "
<!--p class=\"mb-0 text-muted fs-sm fw-medium\">介绍</p-->";
echo "
</div>";
echo "
<div role=\"separator\" class=\"dropdown-divider m-0\"></div>";
echo "
<div class=\"p-2\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"../\">";
echo "
<span class=\"fs-sm fw-medium\">返回前台</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"JavaScript:;\" onclick=\"logut()\">";
echo "
<span class=\"fs-sm fw-medium\">退出登录</span>";
echo "
</a>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
<!-- END User Dropdown -->";
echo "
";
echo "
<!-- Notifications Dropdown -->";
echo "
";
echo "
<!-- END Notifications Dropdown -->";
echo "
";
echo "
<!-- Toggle Side Overlay -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
<!-- END Toggle Side Overlay -->";
echo "
</div>";
echo "
<!-- END Right Section -->";
echo "
</div>";
echo "
<!-- END Header Content -->";
echo "
";
echo "
<!-- Header Loader -->";
echo "
<!-- Please check out the Loaders page under Components category to see examples of showing/hiding it -->";
echo "
<div id=\"page-header-loader\" class=\"overlay-header bg-body-extra-light\">";
echo "
<div class=\"content-header\">";
echo "
<div class=\"w-100 text-center\">";
echo "
<i class=\"fa fa-fw fa-circle-notch fa-spin\"></i>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Header Loader -->";
echo "
</header>";
echo "
<!-- END Header -->";
echo "
";
echo "
<!-- Main Container -->";
echo "
<main id=\"main-container\">";
echo "
";
echo "
<!-- Page Content -->";
echo "
<div class=\"content\">";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"row\">";
echo "
<div class=\"col-md-12\">";
echo "
<form action=\"./api/adminupdata.php\" method=\"POST\">";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\">权限配置</h3>";
echo "
<div class=\"block-options\">";
echo "
<button type=\"submit\" class=\"btn btn-sm btn-primary\">保存</button>";
echo "
<input type=\"hidden\" value=\"wzqxp\" name=\"lx\">";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"block-content\">";
echo "
<div class=\"row justify-content: flex-start;\">";
echo "
<div class=\"col-sm-12 col-md-12 block\">";
echo "
<div class=\"row g-4\">";
echo "
<div class=\"col-3\">";
echo "
<label class=\"form-label\">站点开关</label>";
echo "
<div class=\"space-y-2\">";
echo "
<div class=\"form-check form-switch\">";
echo "
";
$num3=6870;
$tmp=$zt==0;
if($tmp){
    $num3=50;
}else{
    $tmp=$zt==1;
    if($tmp){
        $num3=209;
    }
}
switch($num3){
    case 50:{
    echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_zt">';
        break;
    }
    case 209:{
        echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_zt" checked="">';
        break;
    }
}
echo "                                  </div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"col-3\">";
echo "
<label class=\"form-label\">用户注册</label>";
echo "
<div class=\"space-y-2\">";
echo "
<div class=\"form-check form-switch\">";
echo "
";
$num4=6874;
$tmp=$regqx==-1;
if($tmp){
    $num4=55;
}else{
    $tmp=$regqx==0;
    if($tmp){
        $num4=50;
    }
}
switch($num4){
    case 55:{
    echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_reg">';
        break;
    }
    case 50:{
        echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_reg" checked="">';
        break;
    }
}
echo "                                  </div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"col-3\">";
echo "
<label class=\"form-label\">前台登录</label>";
echo "
<div class=\"space-y-2\">";
echo "
<div class=\"form-check form-switch\">";
echo "
";
$num5=6863;
$tmp=$loginkg==0;
if($tmp){
    $num5=95;
}else{
    $tmp=$loginkg==1;
    if($tmp){
        $num5=190;
    }
}
switch($num5){
    case 95:{
    echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_qlogin">';
        break;
    }
    case 190:{
        echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_qlogin" checked="">';
        break;
    }
}
echo "                                  </div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"col-3\">";
echo "
<label class=\"form-label\">显示友链</label>";
echo "
<div class=\"space-y-2\">";
echo "
<div class=\"form-check form-switch\">";
echo "
";
$num6=6867;
$tmp=$lnkzt==1;
if($tmp){
    $num6=361;
}else{
    $tmp=$lnkzt==0;
    if($tmp){
        $num6=190;
    }
}
switch($num6){
    case 361:{
    echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_lnk">';
        break;
    }
    case 190:{
        echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_lnk" checked="">';
        break;
    }
}
echo "                                  </div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"col-3\">";
echo "
<label class=\"form-label\">用户发布</label>";
echo "
<div class=\"space-y-2\">";
echo "
<div class=\"form-check form-switch\">";
echo "
";
$num7=6863;
$tmp=$kqsy==0;
if($tmp){
    $num7=114;
}else{
    $tmp=$kqsy==1;
    if($tmp){
        $num7=55;
    }
}
switch($num7){
    case 55:{
    echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_fowz" checked="">';
        break;
    }
    case 114:{
        echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_fowz">';
        break;
    }
}
echo "                                  </div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"col-3\">";
echo "
<label class=\"form-label\">前台发布</label>";
echo "
<div class=\"space-y-2\">";
echo "
<div class=\"form-check form-switch\">";
echo "
";
$num8=6873;
$tmp=$ptpfan==0;
if($tmp){
    $num8=114;
}else{
    $tmp=$ptpfan==1;
    if($tmp){
        $num8=114;
        $num8=11810;
    }
}
switch($num8){
    case 114:{
    echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_qfowz">';
        break;
    }
    case 5962:{
        echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_qfowz" checked="">';
        break;
    }
}
echo "                                  </div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"col-3\">";
echo "
<label class=\"form-label\">匿名发布</label>";
echo "
<div class=\"space-y-2\">";
echo "
<div class=\"form-check form-switch\">";
echo "
";
$num9=6870;
$tmp=$notname==0;
if($tmp){
    $num9=110;
}else{
    $tmp=$notname==1;
    if($tmp){
        $num9=95;
    }
}
switch($num9){
    case 95:{
    echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_nmfowz" checked="">';
        break;
    }
    case 110:{
        echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_nmfowz">';
        break;
    }
}
echo "                                  </div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"col-3\">";
echo "
<label class=\"form-label\">图片压缩</label>";
echo "
<div class=\"space-y-2\">";
echo "
<div class=\"form-check form-switch\">";
echo "
";
$num10=6868;
$tmp=$imgpres==0;
if($tmp){
    $num10=30;
}else{
    $tmp=$imgpres==1;
    if($tmp){
        $num10=100;
    }
}
switch($num10){
    case 30:{
    echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_imgys">';
        break;
    }
    case 100:{
        echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_imgys" checked="">';
        break;
    }
}
echo "                                  </div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"col-3\">";
echo "
<label class=\"form-label\">游客评论</label>";
echo "
<div class=\"space-y-2\">";
echo "
<div class=\"form-check form-switch\">";
echo "
";
$num11=6867;
$tmp=$viscomm==-1;
if($tmp){
    $num11=209;
}else{
    $tmp=$viscomm==0;
    if($tmp){
        $num11=36;
    }
}
switch($num11){
    case 209:{
    echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_vispl">';
        break;
    }
    case 36:{
        echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_vispl" checked="">';
        break;
    }
}
echo "                                  </div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"col-3\">";
echo "
<label class=\"form-label\">评论审核</label>";
echo "
<div class=\"space-y-2\">";
echo "
<div class=\"form-check form-switch\">";
echo "
";
$num12=6874;
$tmp=$comaud==0;
if($tmp){
    $num12=95;
}else{
    $tmp=$comaud==1;
    if($tmp){
        $num12=95;
        $num12=6619;
    }
}
switch($num12){
    case 95:{
    echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_plsh">';
        break;
    }
    case 3357:{
        echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_plsh" checked="">';
        break;
    }
}
echo "                                  </div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"col-3\">";
echo "
<label class=\"form-label\">文章审核</label>";
echo "
<div class=\"space-y-2\">";
echo "
<div class=\"form-check form-switch\">";
echo "
";
$num13=6876;
$tmp=$ptpaud==0;
if($tmp){
    $num13=121;
}else{
    $tmp=$ptpaud==1;
    if($tmp){
        $num13=30;
    }
}
switch($num13){
    case 30:{
    echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_wzsh" checked="">';
        break;
    }
    case 121:{
        echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_wzsh">';
        break;
    }
}
echo "                                  </div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"col-3\">";
echo "
<label class=\"form-label\">跨域资源</label>";
echo "
<div class=\"space-y-2\">";
echo "
<div class=\"form-check form-switch\">";
echo "
";
$num14=6866;
$tmp=$rosdomain==0;
if($tmp){
    $num14=95;
}else{
    $tmp=$rosdomain==1;
    if($tmp){
        $num14=100;
    }
}
switch($num14){
    case 95:{
    echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_kyurl">';
        break;
    }
    case 100:{
        echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_kyurl" checked="">';
        break;
    }
}
echo "                                  </div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"col-3\">";
echo "
<label class=\"form-label\">日夜模式</label>";
echo "
<div class=\"space-y-2\">";
echo "
<div class=\"form-check form-switch\">";
echo "
";
$num15=6871;
$tmp=$daymode==0;
if($tmp){
    $num15=110;
}else{
    $tmp=$daymode==1;
    if($tmp){
        $num15=95;
    }
}
switch($num15){
    case 95:{
    echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_ryms" checked="">';
        break;
    }
    case 110:{
        echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_ryms">';
        break;
    }
}
echo "                                  </div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"col-3\">";
echo "
<label class=\"form-label\">回到顶部</label>";
echo "
<div class=\"space-y-2\">";
echo "
<div class=\"form-check form-switch\">";
echo "
";
$num16=6876;
$tmp=$gotop==0;
if($tmp){
    $num16=114;
}else{
    $tmp=$gotop==1;
    if($tmp){
        $num16=36;
    }
}
switch($num16){
    case 114:{
    echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_gotop">';
        break;
    }
    case 36:{
        echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_gotop" checked="">';
        break;
    }
}
echo "                                  </div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"col-3\">";
echo "
<label class=\"form-label\">搜索功能</label>";
echo "
<div class=\"space-y-2\">";
echo "
<div class=\"form-check form-switch\">";
echo "
";
$num17=6868;
$tmp=$search==0;
if($tmp){
    $num17=66;
}else{
    $tmp=$search==1;
    if($tmp){
        $num17=110;
    }
}
switch($num17){
    case 66:{
    echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_so">';
        break;
    }
    case 110:{
        echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_so" checked="">';
        break;
    }
}
echo "                                  </div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"col-3\">";
echo "
<label class=\"form-label\">视频自动播放</label>";
echo "
<div class=\"space-y-2\">";
echo "
<div class=\"form-check form-switch\">";
echo "
";
$num18=6867;
$tmp=$videoauplay==0;
if($tmp){
    $num18=100;
}else{
    $tmp=$videoauplay==1;
    if($tmp){
        $num18=50;
    }
}
switch($num18){
    case 50:{
    echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_videoplay" checked="">';
        break;
    }
    case 100:{
        echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_videoplay">';
        break;
    }
}
echo "                                  </div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"col-3\">";
echo "
<label class=\"form-label\">视频圆角</label>";
echo "
<div class=\"space-y-2\">";
echo "
<div class=\"form-check form-switch\">";
echo "
";
$num19=6866;
$tmp=$filterpiccir==0;
if($tmp){
    $num19=36;
}else{
    $tmp=$filterpiccir==1;
    if($tmp){
        $num19=60;
    }
}
switch($num19){
    case 36:{
    echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_piccir">';
        break;
    }
    case 60:{
        echo '<input class="form-check-input" type="checkbox" value="" id="example-switch-default1" name="develop_piccir" checked="">';
        break;
    }
}
echo "                                  </div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</form>";
echo "
</div>";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
</div>";
echo "
<!-- END Page Content -->";
echo "
</main>";
echo "
<!-- END Main Container -->";
echo "
";
echo "
<!-- Footer -->";
echo "
<footer id=\"page-footer\" class=\"bg-body-light\">";
echo "
<div class=\"content py-3\">";
echo "
<div class=\"row fs-sm\">";
echo "
<div class=\"col-sm-6 order-sm-2 py-1 text-center text-sm-end\">";
echo "
Crafted with <i class=\"fa fa-heart text-danger\"></i> by <a class=\"fw-semibold\" href=\"https://qemao.com\" target=\"_blank\">苏画</a>";
echo "
</div>";
echo "
<div class=\"col-sm-6 order-sm-1 py-1 text-center text-sm-start\">";
echo "
<a class=\"fw-semibold\" href=\"https://www.qemao.com\" target=\"_blank\">LAN</a> &copy; <span data-toggle=\"year-copy\"></span>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</footer>";
echo "
<!-- END Footer -->";
echo "
</div>";
echo "
<!-- END Page Container -->";
echo "
";
echo "
<!--";
echo "
OneUI JS";
echo "
";
echo "
Core libraries and functionality";
echo "
webpack is putting everything together at assets/_js/main/app.js";
echo "
-->";
echo "
<script src=\"assets/js/oneui.app.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Plugins -->";
echo "
<script src=\"assets/js/chart.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Code -->";
echo "
<script src=\"assets/js/be_pages_dashboard.min.js\"></script>";
echo "
</body>";
echo "
</html>";
echo "
";

