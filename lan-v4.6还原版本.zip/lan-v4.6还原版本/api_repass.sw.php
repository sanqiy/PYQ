<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$num2=5846;
$isArray=is_array($_POST);
if($isArray){
    $num2=204;
}else{
    $num2=255;
}
switch($num2){
    case 255:{
    $useke=$_POST['useke'];
        break;
    }
    case 204:{
        $useke=&$_POST['useke'];
        break;
    }
}
$escaped=htmlspecialchars($useke);
unset($useke);
$escaped2=addslashes($escaped);
$useke=$escaped2;
$num3=5844;
$isArray=is_array($_POST);
if($isArray){
    $num3=216;
}else{
    $num3=204;
}
switch($num3){
    case 204:{
    $useke=$_POST['useem'];
        break;
    }
    case 216:{
        $useke=&$_POST['useem'];
        break;
    }
}
$escaped=htmlspecialchars($useke);
unset($useke);
$escaped2=addslashes($escaped);
$useem=$escaped2;
$num4=5834;
$isArray=is_array($_POST);
if($isArray){
    $num4=289;
}else{
    $num4=216;
}
switch($num4){
    case 216:{
    $useke=$_POST['safyzm'];
        break;
    }
    case 289:{
        $useke=&$_POST['safyzm'];
        break;
    }
}
$escaped=htmlspecialchars($useke);
unset($useke);
$escaped2=addslashes($escaped);
$useyz=$escaped2;
$num5=5847;
$isArray=is_array($_POST);
if($isArray){
    $num5=180;
}else{
    $num5=306;
}
switch($num5){
    case 306:{
    $useke=$_POST['safxmm'];
        break;
    }
    case 180:{
        $useke=&$_POST['safxmm'];
        break;
    }
}
$escaped=htmlspecialchars($useke);
unset($useke);
$escaped2=addslashes($escaped);
$usexm=$escaped2;
$num=5834;
$isArray=is_array($_POST);
if($isArray){
    $num=144;
}else{
    $num=204;
}
switch($num){
    case 144:{
    $useke=&$_POST['tig'];
        break;
    }
    case 204:{
        $useke=$_POST['tig'];
        break;
    }
}
$escaped=htmlspecialchars($useke);
unset($useke);
$escaped2=addslashes($escaped);
$tig=$escaped2;
if($tig==""){
    exit("未传入参数!");
}
$tmp=include '../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($sentinel))break;
    $name=$row["name"];
    $subtitle=$row["subtitle"];
    $icon=$row["icon"];
    $logo=$row["logo"];
    $zt=$row["zt"];
    $username=$row["username"];
    $glyadmin=$row["username"];
    $homimg=$row["homimg"];
    $sign=$row["sign"];
    $wzmusic=$row["music"];
    $essgs=$row["essgs"];
    $commgs=$row["commgs"];
    $lnkzt=$row["lnkzt"];
    $regqx=$row["regqx"];
    $kqsy=$row["kqsy"];
    $emydz=$row["emydz"];
    $emssl=$row["emssl"];
    $emduk=$row["emduk"];
    $emkey=$row["emkey"];
    $emzh=$row["emzh"];
    $emfs=$row["emfs"];
    $emfszm=$row["emfszm"];
    $copyright=$row["copyright"];
    $beian=$row["beian"];
    $topes=$row["topes"];
}
L2xx17:
if($tig==0)goto L2xeWjgx1w;
goto L2xldMhx1w;
L2xeWjgx1w:
$tmp=$useke=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$useem=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit("未传入账号或邮箱!");
}
$tmp="select * from user where username= '" . $useke;
$tmp4=$tmp . "' and email='";
$tmp2=$tmp4 . $useem;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
$row=mysqli_fetch_array($result);
$row=$row;
if($row)goto L2xeWjgx1g;
goto L2xldMhx1g;
goto L2xldMhx1g;
L2xeWjgx1g:
$row=rand();
$suiyzm=$row;
$tmp=$emydz!="";
$tmp2=(bool)$tmp;
if($tmp2){
    $tmp4=$emssl!="";
    $tmp2=(bool)$tmp4;
}
$tmp5=(bool)$tmp2;
if($tmp5){
    $tmp3=$emduk!="";
    $tmp5=(bool)$tmp3;
}
$tmp6=(bool)$tmp5;
if($tmp6){
    $tmp7=$emkey!="";
    $tmp6=(bool)$tmp7;
}
$tmp8=(bool)$tmp6;
if($tmp8){
    $tmp9=$emzh!="";
    $tmp8=(bool)$tmp9;
}
$tmp10=(bool)$tmp8;
if($tmp10){
    $tmp11=$emfs!="";
    $tmp10=(bool)$tmp11;
}
$tmp12=(bool)$tmp10;
if($tmp12){
    $tmp13=$emfszm!="";
    $tmp12=(bool)$tmp13;
}
if($tmp12)goto L2xeWjgx1u;
goto L2xldMhx1u;
goto L2xldMhx1u;
L2xeWjgx1u:
$mailapfs='nopost';
$xiangym='ok';
$tmp='[' . $name;
$tmp4=$tmp . ']';
$mailtitle=$tmp4 . '验证码';
$tmp='您正在网站：【' . $name;
$title=$tmp . '】申请找回密码，若不是您本人操作,您的账号可能存在安全隐患，两分钟内有效，验证码为：';
$text=$suiyzm;
$mailbox=$useem;
$tmp=include "./sendmail.php";
$hash=md5($suiyzm);
$hash2=md5($hash);
$currentTime=time();
$str=$currentTime+120;
$cookieResult=setcookie("suiyzm", $hash2, $str, "/");
goto L2xx1v;
L2xldMhx1u:
exit("请网站管理员先配置邮箱!");
L2xldMhx1g:
echo "账号与邮箱不匹配!";
L2xldMhx1w:
L2xx1v:
if($tig==1)goto L2xeWjgx3z;
goto L2xldMhx3z;
L2xeWjgx3z:
$row=strlen($usexm);
$tmp=$row<3;
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $length=strlen($usexm);
    $tmp4=$length>16;
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit("密码参数格式不正确");
}
$tmp="select * from user where username= '" . $useke;
$tmp4=$tmp . "' and email='";
$tmp2=$tmp4 . $useem;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
$row=mysqli_fetch_array($result);
$row=$row;
if($row)goto L2xx2o;
goto L2xldMhx2p;
L2xldMhx2p:
echo "账号与邮箱不匹配!";
exit();
L2xx2o:
$hcyzm=$_COOKIE["suiyzm"];
$tmp=$hcyzm=="";
if($tmp){
    echo "请先获取验证码!";
    exit();
}
$escaped=md5($useyz);
$length=md5($escaped);
$jmhyz=$length;
$tmp=$jmhyz==$hcyzm;
if($tmp)goto L2xeWjgx2t;
goto L2xldMhx2t;
goto L2xldMhx2t;
L2xeWjgx2t:
$str="select * from user where username='" . $useke;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
$zid=$data2_row["id"];
$zjpassword=$data2_row["password"];
$row=md5($usexm);
$usexm=$row;
$tmp=$zjpassword==$usexm;
if($tmp){
    exit("新密码不能与旧密码相同!");
}
$tmp="UPDATE user SET password='" . $usexm;
$tmp4=$tmp . "' WHERE id='";
$tmp2=$tmp4 . $zid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx2x;
goto L2xldMhx2x;
goto L2xldMhx2x;
L2xeWjgx2x:
$escaped=time();
$str=$escaped+0;
$length=setcookie("suiyzm", "", $str, "/");
exit("密码已重置!");
goto L2xx2y;
L2xldMhx2x:
exit("重置密码失败!");
L2xldMhx2t:
echo '验证码错误!';
L2xldMhx3z:
L2xx2y: