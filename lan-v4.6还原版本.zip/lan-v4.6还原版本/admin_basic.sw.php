<?php
$iteace=1;
$pos=is_file('../config.php');
if($pos){
    $tmp=include '../config.php';
}
$tmp=include '../api/wz.php';
if($userdlzt==0){
    $pos=header('location: ./login.php');
    exit();
}
$num6=5839;
$tmp=$user_zh==$glyadmin;
if($tmp){
    $num6=225;
}else{
    $num6=105;
}
$tmp=12;
$tmp2=105;
$tmp3=$num6==105;
if($tmp3)goto L2xeWjgxe;
goto L2xldMhxe;
L2xeWjgxe:
exit('<script language="JavaScript">;alert("没有权限!");location.href="../index.php";</script>;');
goto L2xxd;
L2xldMhxe:
$tmp=39;
$tmp2=225;
$tmp3=$num6==225;
if($tmp3)goto L2xeWjgxf;
goto L2xldMhxf;
L2xeWjgxf:
$tmp=$user_passid!=$passid;
if($tmp)goto L2xeWjgxc;
goto L2xxd;
goto L2xxd;
L2xeWjgxc:
exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="./login.php";</script>;');
goto L2xxd;
L2xldMhxf:
L2xxd:
echo "<!doctype html>";
echo "
<html lang=\"en\">";
echo "
<head>";
echo "
<meta charset=\"utf-8\">";
echo "
<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0\">";
echo "
<title>基础设置 - ";
echo $name;
echo "</title>";
echo "
<meta name=\"keywords\" content=\"";
echo $filterkeyw;
echo "\">";
echo "
<meta name=\"description\" content=\"";
echo $subtitle;
echo "\">";
echo "
<meta name=\"author\" content=\"";
echo $name;
echo "\">";
echo "
<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"";
$num7=5844;
$pos=strpos($icon, 'http');
$tmp=$pos!==false;
if($tmp){
    $num7=49;
}else{
    $num7=21;
}
switch($num7){
    case 49:{
    echo $icon;
        break;
    }
    case 21:{
        $tmp='.' . $icon;
        echo $tmp;
        break;
    }
}
echo "\">";
echo "
<link rel=\"stylesheet\" href=\"assets/css/css2.css\">";
echo "
<link rel=\"stylesheet\" id=\"css-main\" href=\"assets/css/oneui.min.css\">";
echo "
</head>";
echo "
<body>";
echo "
<div id=\"page-container\" class=\"sidebar-o sidebar-dark page-header-fixed main-content-narrow\">";
echo "
<nav id=\"sidebar\" aria-label=\"Main Navigation\">";
echo "
<!-- Side Header -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Logo -->";
echo "
<a class=\"fw-semibold text-dual\" href=\"index.php\">";
echo "
<span class=\"smini-visible\">";
echo "
<i class=\"fa fa-circle-notch text-primary\"></i>";
echo "
</span>";
echo "
<span class=\"smini-hide fs-5 tracking-wider\">后台管理</span>";
echo "
</a>";
echo "
<!-- END Logo -->";
echo "
";
echo "
<!-- Extra -->";
echo "
<div>";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" data-toggle=\"layout\" data-action=\"dark_mode_toggle\">";
echo "
<i class=\"far fa-moon\"></i>";
echo "
</button>";
echo "
<!-- END Dark Mode -->";
echo "
";
echo "
<!-- Options -->";
echo "
<div class=\"dropdown d-inline-block ms-1\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" id=\"sidebar-themes-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<i class=\"far fa-circle\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-end fs-sm smini-hide border-0\" aria-labelledby=\"sidebar-themes-dropdown\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"default\" href=\"#\">";
echo "
<span>默认</span>";
echo "
<i class=\"fa fa-circle text-default\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/amethyst.min.css\" href=\"#\">";
echo "
<span>紫色</span>";
echo "
<i class=\"fa fa-circle text-amethyst\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/city.min.css\" href=\"#\">";
echo "
<span>红色</span>";
echo "
<i class=\"fa fa-circle text-city\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/flat.min.css\" href=\"#\">";
echo "
<span>青色</span>";
echo "
<i class=\"fa fa-circle text-flat\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/modern.min.css\" href=\"#\">";
echo "
<span>蓝色</span>";
echo "
<i class=\"fa fa-circle text-modern\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/smooth.min.css\" href=\"#\">";
echo "
<span>粉色</span>";
echo "
<i class=\"fa fa-circle text-smooth\"></i>";
echo "
</a>";
echo "
<!-- END Color Themes -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_light\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 黑色</span>";
echo "
</a>";
echo "
<!-- END Sidebar Styles -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_light\" href=\"javascript:void(0)\">";
echo "
<span>导航 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>导航 黑色</span>";
echo "
</a>";
echo "
<!-- END Header Styles -->";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Options -->";
echo "
<a class=\"d-lg-none btn btn-sm btn-alt-secondary ms-1\" data-toggle=\"layout\" data-action=\"sidebar_close\" href=\"javascript:void(0)\">";
echo "
<i class=\"fa fa-fw fa-times\"></i>";
echo "
</a>";
echo "
<!-- END Close Sidebar -->";
echo "
</div>";
echo "
<!-- END Extra -->";
echo "
</div>";
echo "
<!-- END Side Header -->";
echo "
";
echo "
<!-- Sidebar Scrolling -->";
echo "
<div class=\"js-sidebar-scroll\">";
echo "
<!-- Side Navigation -->";
echo "
<div class=\"content-side\">";
echo "
<ul class=\"nav-main\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./index.php\">";
echo "
<i class=\"nav-main-link-icon si si-speedometer\"></i>";
echo "
<span class=\"nav-main-link-name\">后台首页</span>";
echo "
</a>";
echo "
</li>";
echo "
";
echo "
<li class=\"nav-main-heading\">设置</li>";
echo "
<li class=\"nav-main-item  open\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-energy\"></i>";
echo "
<span class=\"nav-main-link-name\">网站设置</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link active\" href=\"./basic.php\">";
echo "
<span class=\"nav-main-link-name\">基础设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./authority.php\">";
echo "
<span class=\"nav-main-link-name\">权限设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./imgset.php\">";
echo "
<span class=\"nav-main-link-name\">图像设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./emailset.php\">";
echo "
<span class=\"nav-main-link-name\">邮箱设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./calis.php\">";
echo "
<span class=\"nav-main-link-name\">卡密管理</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-users\"></i>";
echo "
<span class=\"nav-main-link-name\">用户管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./userlist.php\">";
echo "
<span class=\"nav-main-link-name\">用户列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-book-open\"></i>";
echo "
<span class=\"nav-main-link-name\">文章管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditesli.php\">";
echo "
<span class=\"nav-main-link-name\">文章列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditessh.php\">";
echo "
<span class=\"nav-main-link-name\">审核文章</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-speech\"></i>";
echo "
<span class=\"nav-main-link-name\">评论管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditcoli.php\">";
echo "
<span class=\"nav-main-link-name\">评论列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditcosh.php\">";
echo "
<span class=\"nav-main-link-name\">审核评论</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-paper-clip\"></i>";
echo "
<span class=\"nav-main-link-name\">友链管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./linkset.php\">";
echo "
<span class=\"nav-main-link-name\">友链列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
</ul>";
echo "
</div>";
echo "
<!-- END Side Navigation -->";
echo "
</div>";
echo "
<!-- END Sidebar Scrolling -->";
echo "
</nav>";
echo "
<!-- END Sidebar -->";
echo "
";
echo "
<!-- Header -->";
echo "
<header id=\"page-header\">";
echo "
<!-- Header Content -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Left Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- Toggle Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-lg-none\" data-toggle=\"layout\" data-action=\"sidebar_toggle\">";
echo "
<i class=\"fa fa-fw fa-bars\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Sidebar -->";
echo "
";
echo "
<!-- Toggle Mini Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-none d-lg-inline-block\" data-toggle=\"layout\" data-action=\"sidebar_mini_toggle\">";
echo "
<i class=\"fa fa-fw fa-ellipsis-v\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Mini Sidebar -->";
echo "
";
echo "
<!-- Open Search Section (visible on smaller screens) -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
";
echo "
<!-- END Open Search Section -->";
echo "
";
echo "
<!-- Search Form (visible on larger screens) -->";
echo "
";
echo "
<!-- END Search Form -->";
echo "
</div>";
echo "
<!-- END Left Section -->";
echo "
";
echo "
<!-- Right Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- User Dropdown -->";
echo "
<div class=\"dropdown d-inline-block ms-2\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary d-flex align-items-center\" id=\"page-header-user-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<img class=\"rounded-circle\" src=\"";
$num=5849;
$pos=strpos($user_img, 'http');
$tmp=$pos!==false;
if($tmp){
    $num=45;
}else{
    $num=210;
}
switch($num){
    case 45:{
    echo $user_img;
        break;
    }
    case 210:{
        $tmp='.' . $user_img;
        echo $tmp;
        break;
    }
}
echo "\" alt=\"Header Avatar\" style=\"width: 21px;\">";
echo "
<span class=\"d-none d-sm-inline-block ms-2\">";
echo $user_name;
echo "</span>";
echo "
<i class=\"fa fa-fw fa-angle-down d-none d-sm-inline-block opacity-50 ms-1 mt-1\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-md dropdown-menu-end p-0 border-0\" aria-labelledby=\"page-header-user-dropdown\">";
echo "
<div class=\"p-3 text-center bg-body-light border-bottom rounded-top\">";
echo "
<img class=\"img-avatar img-avatar48 img-avatar-thumb\" src=\"";
$num2=5838;
$pos=strpos($user_img, 'http');
$tmp=$pos!==false;
if($tmp){
    $num2=9;
}else{
    $num2=210;
}
switch($num2){
    case 9:{
    echo $user_img;
        break;
    }
    case 210:{
        $tmp='.' . $user_img;
        echo $tmp;
        break;
    }
}
echo "\" alt=\"\">";
echo "
<p class=\"mt-2 mb-0 fw-medium\">";
echo $user_name;
echo "</p>";
echo "
<!--p class=\"mb-0 text-muted fs-sm fw-medium\">介绍</p-->";
echo "
</div>";
echo "
<div role=\"separator\" class=\"dropdown-divider m-0\"></div>";
echo "
<div class=\"p-2\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"../\">";
echo "
<span class=\"fs-sm fw-medium\">返回前台</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"JavaScript:;\" onclick=\"logut()\">";
echo "
<span class=\"fs-sm fw-medium\">退出登录</span>";
echo "
</a>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
<!-- END User Dropdown -->";
echo "
";
echo "
<!-- Notifications Dropdown -->";
echo "
";
echo "
<!-- END Notifications Dropdown -->";
echo "
";
echo "
<!-- Toggle Side Overlay -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
<!-- END Toggle Side Overlay -->";
echo "
</div>";
echo "
<!-- END Right Section -->";
echo "
</div>";
echo "
<!-- END Header Content -->";
echo "
";
echo "
<!-- Header Loader -->";
echo "
<!-- Please check out the Loaders page under Components category to see examples of showing/hiding it -->";
echo "
<div id=\"page-header-loader\" class=\"overlay-header bg-body-extra-light\">";
echo "
<div class=\"content-header\">";
echo "
<div class=\"w-100 text-center\">";
echo "
<i class=\"fa fa-fw fa-circle-notch fa-spin\"></i>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Header Loader -->";
echo "
</header>";
echo "
<!-- END Header -->";
echo "
";
echo "
<!-- Main Container -->";
echo "
<main id=\"main-container\">";
echo "
";
echo "
<!-- Page Content -->";
echo "
<div class=\"content\">";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"row\">";
echo "
<div class=\"col-md-12\">";
echo "
<form action=\"./api/adminupdata.php\" method=\"post\" enctype=\"multipart/form-data\">";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\">网站配置</h3>";
echo "
<div class=\"block-options\">";
echo "
<button type=\"submit\" class=\"btn btn-sm btn-primary\">保存</button>";
echo "
<input type=\"hidden\" value=\"wzpz\" name=\"lx\">";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"block-content\">";
echo "
<div class=\"row justify-content: flex-start;\">";
echo "
<div class=\"col-sm-12 col-md-12\">";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-username\">网站标题</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-username\" value=\"";
echo $name;
echo "\" minlength=\"1\" placeholder=\"\" name=\"wzbt\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">网站关键词</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" value=\"";
echo $filterkeyw;
echo "\" minlength=\"1\" placeholder=\"可定义多个描述词以逗号分开\" name=\"wzgjc\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">网站描述</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" value=\"";
echo $subtitle;
echo "\" minlength=\"1\" placeholder=\"可定义多个描述词以逗号分开\" name=\"wzms\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">管理员账号 <span class=\"text-danger\">*</span></label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" value=\"";
echo $glyadmin;
echo "\" minlength=\"5\" maxlength=\"32\" placeholder=\"\" name=\"wzglyzh\" required>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">网站首页签名</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" value=\"";
echo $sign;
echo "\" minlength=\"1\" placeholder=\"\" name=\"wzqm\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">文章显示数量 <span class=\"text-danger\">*</span></label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" value=\"";
echo $essgs;
echo "\" minlength=\"1\" maxlength=\"2\" placeholder=\"\" name=\"wzmrxw\" required>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">评论显示数量 <span class=\"text-danger\">*</span></label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" value=\"";
echo $commgs;
echo "\" minlength=\"1\" maxlength=\"2\" placeholder=\"\" name=\"wzmrxp\" required>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">备案号</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" value=\"";
echo $beian;
echo "\" maxlength=\"500\" placeholder='示例:<a href=\"http://beian.miit.gov.cn/\">蜀ICP备20220202号</a>' name=\"wzba\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">网站字体(TTF字体链接)</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" value=\"";
echo $scfont;
echo "\" maxlength=\"500\" placeholder=\"\" name=\"wzzit\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">网站版权</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" value=\"";
echo $copyright;
echo "\" maxlength=\"50\" placeholder=\"\" name=\"wzcopy\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">网站访问密码(不设置请留空)</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" value=\"";
echo $pagepass;
echo "\" maxlength=\"100\" placeholder=\"\" name=\"pagepass\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">敏感词过滤(用 || 符号分开)</label>";
echo "
<textarea class=\"js-maxlength form-control js-maxlength-enabled\" id=\"example-maxlength10\" id=\"exampleFormControlInput1\" placeholder=\"\" name=\"mask\" data-always-show=\"true\">";
if($filtertext!=""){
    $pos=json_decode($filtertext, true);
    $data=$pos;
    $pos=implode("||", $data);
    $result=$pos;
    echo $result;
}
echo "</textarea>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">每个IP允许注册几个账号</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" value=\"";
echo $ipregx;
echo "\" maxlength=\"50\" placeholder=\"\" name=\"ipregx\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">同IP每分钟允许发几条评论</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" value=\"";
echo $filterpljg;
echo "\" maxlength=\"50\" placeholder=\"\" name=\"pljg\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">签到赠送余额(设置0将关闭签到功能)</label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" value=\"";
echo $sigin;
echo "\" placeholder=\"\" name=\"qiandao\">";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">发布广告类型文章所需余额 <span class=\"text-danger\">*</span></label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" value=\"";
echo $rnggy;
echo "\" placeholder=\"\" name=\"fggye\" required>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">每天首篇文章奖励余额 <span class=\"text-danger\">*</span></label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" value=\"";
echo $dywptp;
echo "\" placeholder=\"\" name=\"fdywptp\" required>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">置顶文章所需余额 <span class=\"text-danger\">*</span></label>";
echo "
<input type=\"text\" class=\"form-control\" id=\"block-form1-password\" value=\"";
echo $topwcz;
echo "\" placeholder=\"\" name=\"topwcz\" required>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">排行功能</label>";
echo "
<select class=\"form-select\" id=\"example-select\" name=\"rnking\">";
echo "
";
$num3=5846;
$tmp=$rnking==0;
if($tmp){
    $num3=210;
}else{
    $tmp=$rnking==1;
    if($tmp){
        $num3=225;
    }else{
        $num3=270;
    }
}
switch($num3){
    case 270:{
    echo '<option value="">设置错误,请重新设置</option><option value="0">关闭</option>
    <option value="1">开启</option>';
        break;
    }
    case 210:{
        echo '<option value="0">关闭</option>
        <option value="1">开启</option>';
        break;
    }
    case 225:{
            echo '<option value="1">开启</option>
            <option value="0">关闭</option>';
        break;
    }
}
echo "                                  </select>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">悬浮音乐播放器样式</label>";
echo "
<select class=\"form-select\" id=\"example-select\" name=\"wzmusplay\">";
echo "
";
$num4=5847;
$tmp=$musplay==0;
if($tmp){
    $num4=98;
}else{
    $tmp=$musplay==1;
    if($tmp){
        $num4=42;
    }else{
        $num4=270;
    }
}
switch($num4){
    case 270:{
    echo '<option value="">设置错误,请重新设置</option><option value="0">经典</option>
    <option value="1">新颖</option>';
        break;
    }
    case 42:{
        echo '<option value="1">新颖</option>
        <option value="0">经典</option>';
        break;
    }
    case 98:{
            echo '<option value="0">经典</option>
            <option value="1">新颖</option>';
        break;
    }
}
echo "                                  </select>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">注册验证邮箱(需先配置邮箱)</label>";
echo "
<select class=\"form-select\" id=\"example-select\" name=\"regverify\">";
echo "
";
$num5=5845;
$tmp=$regverify==0;
if($tmp){
    $num5=270;
}else{
    $tmp=$regverify==1;
    if($tmp){
        $num5=252;
    }else{
        $num5=42;
    }
}
switch($num5){
    case 270:{
    echo '<option value="0">不验证</option>
    <option value="1">验证</option>';
        break;
    }
    case 252:{
        echo '<option value="1">验证</option>
        <option value="0">不验证</option>';
        break;
    }
    case 42:{
            echo '<option value="">设置错误,请重新设置</option><option value="0">不验证</option>
            <option value="1">验证</option>';
        break;
    }
}
echo "                                  </select>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">网站音乐(一行一个,不设置则留空)</label>";
echo "
<textarea class=\"js-maxlength form-control js-maxlength-enabled\" id=\"example-maxlength10\" name=\"wzmusic\" style=\"min-height:150px\" placeholder=\"\" data-always-show=\"true\">";
echo $wzmusic;
echo "</textarea>";
echo "
<p class=\"fs-sm text-muted\">";
echo "
直链音乐格式：歌名|链接<br>";
echo "
网易云音乐格式(请填写前缀:网易音乐+音乐id)：网易音乐|25906124</p>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">自定义CSS</label>";
echo "
<textarea class=\"js-maxlength form-control js-maxlength-enabled\" id=\"example-maxlength10\" name=\"cucss\" style=\"min-height:150px\" placeholder=\"\" data-always-show=\"true\">";
echo $filtercucss;
echo "</textarea>";
echo "
<p class=\"fs-sm text-muted\">";
echo "
请填写自定义CSS内容，不用填写style标签，请直接写代码</p>";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<label class=\"form-label\" for=\"block-form1-password\">自定义JS</label>";
echo "
<textarea class=\"js-maxlength form-control js-maxlength-enabled\" id=\"example-maxlength10\" name=\"cujs\" style=\"min-height:150px\" placeholder=\"\" data-always-show=\"true\">";
echo $filtercujs;
echo "</textarea>";
echo "
<p class=\"fs-sm text-muted\">";
echo "
请填写自定义JS内容，例如网站统计等，不要填写script标签，请直接写代码</p>";
echo "
</div>";
echo "
";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</form>";
echo "
</div>";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
</div>";
echo "
<!-- END Page Content -->";
echo "
</main>";
echo "
<!-- END Main Container -->";
echo "
";
echo "
<!-- Footer -->";
echo "
<footer id=\"page-footer\" class=\"bg-body-light\">";
echo "
<div class=\"content py-3\">";
echo "
<div class=\"row fs-sm\">";
echo "
<div class=\"col-sm-6 order-sm-2 py-1 text-center text-sm-end\">";
echo "
Crafted with <i class=\"fa fa-heart text-danger\"></i> by <a class=\"fw-semibold\" href=\"https://qemao.com\" target=\"_blank\">苏画</a>";
echo "
</div>";
echo "
<div class=\"col-sm-6 order-sm-1 py-1 text-center text-sm-start\">";
echo "
<a class=\"fw-semibold\" href=\"https://www.qemao.com\" target=\"_blank\">LAN</a> &copy; <span data-toggle=\"year-copy\"></span>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</footer>";
echo "
<!-- END Footer -->";
echo "
</div>";
echo "
<!-- END Page Container -->";
echo "
";
echo "
<!--";
echo "
OneUI JS";
echo "
";
echo "
Core libraries and functionality";
echo "
webpack is putting everything together at assets/_js/main/app.js";
echo "
-->";
echo "
<script src=\"assets/js/oneui.app.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Plugins -->";
echo "
<script src=\"assets/js/chart.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Code -->";
echo "
<script src=\"assets/js/be_pages_dashboard.min.js\"></script>";
echo "
</body>";
echo "
</html>";
echo "
";

