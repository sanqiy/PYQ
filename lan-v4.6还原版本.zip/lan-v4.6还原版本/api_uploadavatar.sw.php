<?php
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp=$user_zh=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$user_passid=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit('<script language="JavaScript">;alert("请先登录!");location.href="../index.php";</script>');
}
$tmp=include '../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$currentTime=htmlspecialchars($user_zh);
$cookieResult=addslashes($currentTime);
$user_zhsg=$cookieResult;
$tmp="select * from user where username='" . $user_zhsg;
$sqls=$tmp . "'";
$row=mysqli_query($conn, $sqls);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$data2s_row=$row;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($sentinel))break;
    $glyzhuser=$row["username"];
}
L2xxf:
$str="select * from user where username='" . $user_zh;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
$zid=$data2_row["id"];
$zjpassword=$data2_row["password"];
if($user_passid!=$passid){
    $currentTime=time();
    $str=$currentTime+ -1;
    $cookieResult=setcookie("username", "", $str, "/");
    $currentTime=time();
    $str=$currentTime+ -1;
    $cookieResult=setcookie("passid", "", $str, "/");
    exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="../index.php";</script>');
}
$auth_keylocation='./key.php';
$auth_keyauth='./auth.php';
$num=6876;
$row=file_exists($auth_keyauth);
if($row){
    $num=288;
}else{
    $num=361;
}
$tmp=14;
$tmp4=361;
$tmp2=$num==361;
if($tmp2)goto L2xeWjgxs;
goto L2xldMhxs;
L2xeWjgxs:
exit('<script language="JavaScript">;alert("授权验证文件不存在或被篡改,请确保文件完整且未篡改!");location.href="../setup.php";</script>;');
goto L2xxr;
L2xldMhxs:
$tmp=108;
$tmp4=288;
$tmp2=$num==288;
if($tmp2)goto L2xeWjgxt;
goto L2xldMhxt;
L2xeWjgxt:
$tmp=require $auth_keyauth;
$tmp=!defined("sh_auth_state");
if($tmp){
    exit('<script language="JavaScript">;alert("授权验证失败,请确保文件完整且未篡改!");location.href="../setup.php";</script>;');
}
$tmp=sh_auth_state!="ok";
if($tmp)goto L2xeWjgxq;
goto L2xxr;
goto L2xxr;
L2xeWjgxq:
exit('<script language="JavaScript">;alert("程序未授权,您的请求已被拒绝,请授权后使用!");location.href="../setup.php";</script>;');
goto L2xxr;
L2xldMhxt:
L2xxr:
$str="../user/";
$row=iconv("UTF-8", "GBK", $str);
$dir=$row;
$num2=6876;
$row=file_exists($dir);
$tmp=!$row;
if($tmp){
    $num2=252;
}else{
    $num2=162;
}
$tmp=80;
$tmp4=162;
$tmp2=$num2==162;
if($tmp2)goto L2xx11;
switch($num2){
    case 252:{
    $row=mkdir($dir, true);
        break;
    }
}
L2xx11:
$str="../user/headimg/";
$row=iconv("UTF-8", "GBK", $str);
$dir=$row;
$num3=6868;
$row=file_exists($dir);
$tmp=!$row;
if($tmp){
    $num3=304;
}else{
    $num3=288;
}
$tmp=10;
$tmp4=304;
$tmp2=$num3==304;
if($tmp2)goto L2xeWjgx17;
goto L2xldMhx17;
L2xeWjgx17:
$row=mkdir($dir, true);
goto L2xx16;
L2xldMhx17:
$tmp=27;
$tmp4=288;
$tmp2=$num3==288;
if($tmp2)goto L2xx16;
L2xx16:
$file=$_FILES['file'];
$val[]="gif";
$val[]="jpeg";
$val[]="jpg";
$val[]="png";
$val[]="webp";
$allowedExts=$val;
$num4=6862;
$isArray=is_array($_FILES);
if($isArray){
    $file=&$_FILES["file"];
}else{
    $file=$_FILES["file"];
}
$isArray2=is_array($file);
unset($file);
if($isArray2){
    $num4=324;
}else{
    $num4=81;
}
switch($num4){
    case 324:{
    $file2=&$_FILES["file"]["name"];
        break;
    }
    case 81:{
        $file2=$_FILES["file"]["name"];
        break;
    }
}
$row=explode(".", $file2);
unset($file2);
$temp=$row;
$row=end($temp);
$extension=$row;
if($extension==''){
    exit('<script language="JavaScript">;alert("未选择图片!");location.href="../setup.php";</script>;');
}
$isArray3=is_array($_FILES);
if($isArray3){
    $file3=&$_FILES["file"];
}else{
    $file3=$_FILES["file"];
}
$isArray4=is_array($file3);
unset($file3);
if($isArray4){
    $file2=&$_FILES["file"]["name"];
}else{
    $file2=$_FILES["file"]["name"];
}
$row=strpos($file2, "php");
unset($file2);
$tmp=$row!==false;
$tmp2=(bool)$tmp;
$tmp5=!$tmp2;
if($tmp5){
    $isArray5=is_array($_FILES);
    if($isArray5){
        $file4=&$_FILES["file"];
    }else{
        $file4=$_FILES["file"];
    }
    $isArray6=is_array($file4);
    unset($file4);
    if($isArray6){
        $file=&$_FILES["file"]["name"];
    }else{
        $file=$_FILES["file"]["name"];
    }
    $isArray2=strpos($file, "js");
    unset($file);
    $tmp4=$isArray2!==false;
    $tmp2=(bool)$tmp4;
}
$tmp6=(bool)$tmp2;
$tmp7=!$tmp6;
if($tmp7){
    $isArray7=is_array($_FILES);
    if($isArray7){
        $file5=&$_FILES["file"];
    }else{
        $file5=$_FILES["file"];
    }
    $isArray8=is_array($file5);
    unset($file5);
    if($isArray8){
        $file6=&$_FILES["file"]["name"];
    }else{
        $file6=$_FILES["file"]["name"];
    }
    $isArray=strpos($file6, "html");
    unset($file6);
    $tmp3=$isArray!==false;
    $tmp6=(bool)$tmp3;
}
if($tmp2){
    exit("文件有风险，请重试!");
}
$num5=6868;
$tmp=$file['type']=='image/jpeg';
$tmp2=(bool)$tmp;
$tmp8=!$tmp2;
if($tmp8){
    $tmp4=$file['type']=='image/png';
    $tmp2=(bool)$tmp4;
}
$tmp6=(bool)$tmp2;
$tmp9=!$tmp6;
if($tmp9){
    $tmp3=$file['type']=='image/jpg';
    $tmp6=(bool)$tmp3;
}
$tmp5=(bool)$tmp6;
$tmp10=!$tmp5;
if($tmp10){
    $tmp7=$file['type']=='image/gif';
    $tmp5=(bool)$tmp7;
}
$tmp11=(bool)$tmp5;
$tmp12=!$tmp11;
if($tmp12){
    $tmp13=$file['type']=='image/webp';
    $tmp14=(bool)$tmp13;
    if($tmp14){
        $row=in_array($extension, $allowedExts);
        $tmp14=(bool)$row;
    }
    $tmp11=(bool)$tmp14;
}
if($tmp11){
    $num5=224;
}else{
    $num5=224;
    $num5=8310;
}
$tmp=65;
$tmp4=224;
$tmp2=$num5==224;
if($tmp2)goto L2xx2h;
switch($num5){
    case 4267:{
    exit('<script language="JavaScript">;alert("文件类型错误,请上传图片!");location.href="../setup.php";</script>;');
        break;
    }
}
L2xx2h:
if($file["size"]>5242880){
    exit('<script language="JavaScript">;alert("请上传5MB以内的图片!");location.href="../setup.php";</script>;');
}
$path="../user/headimg/";
$row=mt_rand();
$microtime=microtime(true);
$replaced=str_replace('.', '', $microtime);
$tmp=$row . $replaced;
$hash=md5($zjzhq);
$substr=substr($hash);
$tmp4=$tmp . $substr;
$file_name=$tmp4 . $file["name"];
$file_path=$path . $file_name;
$row=strpos($file_path, "php");
$tmp=$row!==false;
$tmp2=(bool)$tmp;
$tmp5=!$tmp2;
if($tmp5){
    $cookieResult=strpos($file_path, "js");
    $tmp4=$cookieResult!==false;
    $tmp2=(bool)$tmp4;
}
$tmp6=(bool)$tmp2;
$tmp7=!$tmp6;
if($tmp7){
    $replaced=strpos($file_path, "html");
    $tmp3=$replaced!==false;
    $tmp6=(bool)$tmp3;
}
if($tmp2){
    exit("文件有风险，请重试!");
}
$userimg="./user/headimg/" . $file_name;
$num6=6873;
$isArray2=is_array($file);
if($isArray2){
    $file2=&$file["tmp_name"];
}else{
    $file2=$file["tmp_name"];
}
$row=move_uploaded_file($file2, $file_path);
unset($file2);
if($row){
    $num6=171;
}else{
    $num6=288;
}
$tmp=14;
$tmp4=171;
$tmp2=$num6==171;
if($tmp2)goto L2xeWjgx49;
goto L2xldMhx49;
L2xeWjgx49:
$tmp="UPDATE user SET img='" . $userimg;
$tmp4=$tmp . "' WHERE id='";
$tmp2=$tmp4 . $zid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx32;
goto L2xldMhx32;
goto L2xldMhx32;
L2xeWjgx32:
$tmp="select * from essay where ptpuser= '" . $user_zh;
$sqlo=$tmp . "'";
$row=mysqli_query($conn, $sqlo);
$resulto=$row;
$row=mysqli_num_rows($resulto);
$tmp=$row>0;
if($tmp)goto L2xeWjgx34;
goto L2xldMhx34;
goto L2xldMhx34;
L2xeWjgx34:
L2xx35:
while(true){
    $row=mysqli_fetch_assoc($resulto);
    $rowo=$row;
    if(!$sentinel)break;
    $txid=$rowo['id'];
    $tmp="UPDATE essay SET ptpimg='" . $userimg;
    $tmp4=$tmp . "' WHERE id='";
    $tmp2=$tmp4 . $txid;
    $sql=$tmp2 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx35;
}
goto L2xx33;
L2xldMhx34:
L2xx33:
$tmp="select * from lcke where luser= '" . $user_zh;
$sqlol=$tmp . "'";
$row=mysqli_query($conn, $sqlol);
$resultol=$row;
$row=mysqli_num_rows($resultol);
$tmp=$row>0;
if($tmp)goto L2xeWjgx3e;
goto L2xldMhx3e;
goto L2xldMhx3e;
L2xeWjgx3e:
L2xx3f:
while(true){
    $row=mysqli_fetch_assoc($resultol);
    $rowo=$row;
    if(!$sentinel)break;
    $ncid=$rowo['id'];
    $tmp="UPDATE lcke SET limg='" . $userimg;
    $tmp4=$tmp . "' WHERE id='";
    $tmp2=$tmp4 . $ncid;
    $sql=$tmp2 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx3f;
}
goto L2xx3d;
L2xldMhx3e:
L2xx3d:
$tmp="select * from comm where couser= '" . $user_zh;
$sqlol=$tmp . "'";
$row=mysqli_query($conn, $sqlol);
$resultol=$row;
$row=mysqli_num_rows($resultol);
$tmp=$row>0;
if($tmp)goto L2xeWjgx3o;
goto L2xldMhx3o;
goto L2xldMhx3o;
L2xeWjgx3o:
L2xx3p:
while(true){
    $row=mysqli_fetch_assoc($resultol);
    $rowo=$row;
    if(!$sentinel)break;
    $ncid=$rowo['id'];
    $tmp="UPDATE comm SET coimg='" . $userimg;
    $tmp4=$tmp . "' WHERE id='";
    $tmp2=$tmp4 . $ncid;
    $sql=$tmp2 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx3p;
}
goto L2xx3n;
L2xldMhx3o:
L2xx3n:
$tmp="select * from message where fuser= '" . $user_zh;
$sqlol=$tmp . "'";
$row=mysqli_query($conn, $sqlol);
$resultol=$row;
$row=mysqli_num_rows($resultol);
$tmp=$row>0;
if($tmp)goto L2xeWjgx3y;
goto L2xx31;
goto L2xx31;
L2xeWjgx3y:
L2xx4z:
while(true){
    $row=mysqli_fetch_assoc($resultol);
    $rowo=$row;
    if(!$sentinel)break;
    $ncid=$rowo['id'];
    $tmp="UPDATE message SET fimg='" . $userimg;
    $tmp4=$tmp . "' WHERE id='";
    $tmp2=$tmp4 . $ncid;
    $sql=$tmp2 . "'";
    $result=$conn->query($sql);
    $result=$result;
goto L2xx4z;
}
goto L2xx31;
L2xldMhx32:
L2xx31:
echo '<script language="JavaScript">;alert("上传成功！");location.href="../setup.php";</script>;';
goto L2xx48;
L2xldMhx49:
switch($num6){
    case 288:{
    echo '<script language="JavaScript">;alert("上传失败！");location.href="../setup.php";</script>;';
        break;
    }
}
L2xx48:
$result=$conn->close();