<?php
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp2=$user_zh=="";
$tmp3=(bool)$tmp2;
$tmp4=!$tmp3;
if($tmp4){
    $tmp5=$user_passid=="";
    $tmp3=(bool)$tmp5;
}
if($tmp3){
    $val["code"]="201";
    $val["msg"]="请先登录";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$tmp2=include '../config.php';
$tmp2=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp2;
if($conn->connect_error){
    $val["code"]="201";
    $val["msg"]="连接数据库失败";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$currentTime=htmlspecialchars($user_zh);
$cookieResult=addslashes($currentTime);
$user_zhsg=$cookieResult;
$tmp2="select * from user where username='" . $user_zhsg;
$sqls=$tmp2 . "'";
$row=mysqli_query($conn, $sqls);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$data2s_row=$row;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($num4))break;
    $name=$row["name"];
    $subtitle=$row["subtitle"];
    $icon=$row["icon"];
    $logo=$row["logo"];
    $zt=$row["zt"];
    $glyusername=$row["username"];
    $username=$row["username"];
    $glyadmin=$row["username"];
    $homimg=$row["homimg"];
    $sign=$row["sign"];
    $wzmusic=$row["music"];
    $essgs=$row["essgs"];
    $commgs=$row["commgs"];
    $lnkzt=$row["lnkzt"];
    $regqx=$row["regqx"];
    $kqsy=$row["kqsy"];
    $comaud=$row["comaud"];
    $ptpaud=$row["ptpaud"];
    $ptpfan=$row["ptpfan"];
    $loginkg=$row["loginkg"];
    $notname=$row["notname"];
    $imgpres=$row["imgpres"];
    $rosdomain=$row["rosdomain"];
    $daymode=$row["daymode"];
    $gotop=$row["gotop"];
    $search=$row["search"];
    $videoauplay=$row["videoauplay"];
    $regverify=$row["regverify"];
    $pagepass=$row["pagepass"];
    $emydz=$row["emydz"];
    $emssl=$row["emssl"];
    $emduk=$row["emduk"];
    $emkey=$row["emkey"];
    $emzh=$row["emzh"];
    $emfs=$row["emfs"];
    $emfszm=$row["emfszm"];
    $copyright=$row["copyright"];
    $beian=$row["beian"];
    $topes=$row["topes"];
    $scfont=$row["scfont"];
    $viscomm=$row["viscomm"];
    $musplay=$row["musplay"];
    $sigin=$row["sigin"];
    $rnking=$row["rnking"];
    $rnggy=$row["rnggy"];
    $dywptp=$row["dywptp"];
    $topwcz=$row["topwcz"];
    $imgyunc=$row["imgyunc"];
    $date=$row["date"];
}
L2xxf:
$str2="select * from user where username='" . $user_zh;
$str3=$str2 . "'";
$row=mysqli_query($conn, $str3);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjwallet=$data2_row["wallet"];
$zjussig=$data2_row["ussig"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
$ban=$data2_row["ban"];
$bantime=$data2_row["bantime"];
if($user_passid!=$passid){
    $currentTime=time();
    $str2=$currentTime+ -1;
    $cookieResult=setcookie("username", "", $str2, "/");
    $currentTime=time();
    $str2=$currentTime+ -1;
    $cookieResult=setcookie("passid", "", $str2, "/");
    $val["code"]="201";
    $val["msg"]="账号信息异常,请重新登录!";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$tmp2=$ban!="0";
$tmp3=(bool)$tmp2;
if($tmp3){
    $tmp5=$bantime!="false";
    $tmp3=(bool)$tmp5;
}
if($tmp3)goto L2xeWjgxs;
goto L2xldMhxs;
L2xeWjgxs:
$tmp2=$bantime==="true";
if($tmp2)goto L2xeWjgxq;
goto L2xldMhxq;
goto L2xldMhxq;
L2xeWjgxq:
$currentTime=time();
$str2=$currentTime+ -1;
$cookieResult=setcookie("username", "", $str2, "/");
$currentTime=time();
$str2=$currentTime+ -1;
$cookieResult=setcookie("passid", "", $str2, "/");
$val["code"]="201";
$val["msg"]="该账号涉嫌违规,已被永久封禁!";
$val2[]=$val;
$arr=$val2;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
goto L2xxr;
L2xldMhxq:
$currentTime=time();
$str2=$currentTime+ -1;
$cookieResult=setcookie("username", "", $str2, "/");
$currentTime=time();
$str2=$currentTime+ -1;
$cookieResult=setcookie("passid", "", $str2, "/");
$str="你的账号已被封禁！解封时间为:" . $bantime;
$val["code"]="201";
$val["msg"]=$str;
$val2[]=$val;
$arr=$val2;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
L2xldMhxs:
L2xxr:
$num=6864;
$isArray=is_array($_POST);
if($isArray){
    $num=38;
}else{
    $num=32;
}
switch($num){
    case 32:{
    $moncid=$_POST['moncid'];
        break;
    }
    case 38:{
        $moncid=&$_POST['moncid'];
        break;
    }
}
$currentTime=htmlspecialchars($moncid);
unset($moncid);
$escaped=addslashes($currentTime);
$ptpmoncid=$escaped;
$tmp2="SELECT * FROM money WHERE ptpmoncid = '" . $ptpmoncid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
$num2=6863;
$tmp2=$result->num_rows>0;
if($tmp2){
    $num2=36;
}else{
    $num2=36;
    $num2=2038;
}
$tmp2=209;
$tmp5=36;
$tmp3=$num2==36;
if($tmp3)goto L2xx13;
switch($num2){
    case 1037:{
    $val["code"]="201";
    $val["msg"]="红包不存在";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
        break;
    }
}
L2xx13:
$tmp2="SELECT * FROM money WHERE ptpmoncid = '" . $ptpmoncid;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$result=$result;
$num3=6867;
$tmp2=$result->num_rows>0;
if($tmp2){
    $num3=32;
}else{
    $num3=32;
    $num3=2908;
}
$tmp2=126;
$tmp5=32;
$tmp3=$num3==32;
if($tmp3){
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!$num4)break;
    $muser=$row["muser"];
    $type=$row["type"];
    $zsum=$row["zsum"];
    $sum=$row["sum"];
    $total=$row["total"];
    $recve=$row["recve"];
    $luser=$row["luser"];
    $montext=$row["montext"];
    $ptpmoncid=$row["ptpmoncid"];
}
}else{
switch($num3){
    case 1470:{
    $val["code"]="201";
    $val["msg"]="未获取到红包信息";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
        break;
    }
}
}
switch($num3){
    case 1470:{
    $val["code"]="201";
    $val["msg"]="未获取到红包信息";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
        break;
    }
}
L2xx1c:
$data=$luser;
$row=explode(PHP_EOL, $data);
$lines=$row;
unset($tmp);
foreach($lines as $line){$tmp[]=$line;
}
$tmp6=0;
while(true){
    $row=count($tmp);
    $tmp2=$tmp6<$row;
    if(!($tmp2))break;
    $keys=array_keys($tmp);
    $keys=$keys[$tmp6];
    $line=$tmp[$keys];
    $row=explode("|", $line);
    $parts=$row;
    $before_pipe=$parts[0];
    $after_pipe=$parts[1];
    $tmp2=$before_pipe==$zjzhq;
    if($tmp2){
        $val["code"]="201";
        $val["msg"]="你已经领取过了";
        $val2[]=$val;
        $arr=$val2;
        exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
    }
    $tmp6=$tmp6+1;
}
L2xx1y:
$tmp2=$recve<1;
$tmp3=(bool)$tmp2;
$tmp4=!$tmp3;
if($tmp4){
    $tmp5=$sum<0.01;
    $tmp3=(bool)$tmp5;
}
if($tmp3){
    $val["code"]="201";
    $val["msg"]="来晚了,红包已领完";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
if($type==0)goto L2xeWjgx2k;
goto L2xldMhx2k;
L2xeWjgx2k:
$linghb=$sum/$recve;
$sum=$sum-$linghb;
$recve=$recve-1;
$tmp2=$luser!="";
if($tmp2){
    $tmp2=$luser . PHP_EOL;
    $tmp5=$tmp2 . $zjzhq;
    $tmp3=$tmp5 . "|";
    $luser=$tmp3 . $linghb;
}else{
    $tmp2=$zjzhq . "|";
    $luser=$tmp2 . $linghb;
}
$zjwallet=$zjwallet+$linghb;
$tmp2="UPDATE user SET wallet = '" . $zjwallet;
$tmp5=$tmp2 . "' WHERE username = '";
$tmp3=$tmp5 . $zjzhq;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$tmp2=$result===TRUE;
if($tmp2)goto L2xx2f;
goto L2xldMhx2g;
L2xldMhx2g:
$val["code"]="201";
$val["msg"]="领取红包失败,请重试";
$val2[]=$val;
$arr=$val2;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
L2xx2f:
$tmp2="UPDATE money SET sum = '" . $sum;
$tmp5=$tmp2 . "', recve = '";
$tmp3=$tmp5 . $recve;
$tmp4=$tmp3 . "', luser = '";
$tmp7=$tmp4 . $luser;
$tmp8=$tmp7 . "' WHERE ptpmoncid = '";
$tmp9=$tmp8 . $ptpmoncid;
$sql=$tmp9 . "'";
$result=$conn->query($sql);
$tmp2=$result===TRUE;
if($tmp2)goto L2xx2h;
goto L2xldMhx2i;
L2xldMhx2i:
L2xx2h:
$str="领取成功,余额加：" . $linghb;
$val["code"]="200";
$val["msg"]=$str;
$val2[]=$val;
$arr=$val2;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
goto L2xx2j;
L2xldMhx2k:
L2xx2j:
if($type==1)goto L2xeWjgx36;
goto L2xldMhx36;
L2xeWjgx36:
$total_amount=$sum;
$total_count=$recve;
$red_packets=$val3;
$num4=1;
$i=$num4;
while(true){
    $tmp2=$i<$total_count;
    if(!$tmp2)break;
    $row=array_sum($red_packets);
    $tmp2=$total_amount-$row;
    $tmp5=$total_count-$i;
    $tmp3=$tmp5-1;
    $tmp4=$tmp3*0.01;
    $tmp7=$tmp2-$tmp4;
    $tmp8=$total_count-$i;
    $max_amount=$tmp7/$tmp8;
    $str2=$max_amount*100;
    $row=mt_rand($str2);
    $random_amount=$row/100;
    $num4=$random_amount;
    $red_packets[]=$num4;
    $obj=$i;
    $obj2=$i+1;
    $num4=$obj2;
    $i=$num4;
}
L2xx2w:
$row=array_sum($red_packets);
$tmp2=$total_amount-$row;
$sentinel=$tmp2;
$num4=$sentinel;
$red_packets[]=$num4;
$currentTime=array_rand($red_packets);
$random_red_packet=$red_packets[$currentTime];
$linghb=$random_red_packet;
$sum=$sum-$linghb;
$recve=$recve-1;
$tmp2=$luser!="";
if($tmp2){
    $tmp2=$luser . PHP_EOL;
    $tmp5=$tmp2 . $zjzhq;
    $tmp3=$tmp5 . "|";
    $luser=$tmp3 . $linghb;
}else{
    $tmp2=$zjzhq . "|";
    $luser=$tmp2 . $linghb;
}
$zjwallet=$zjwallet+$linghb;
$tmp2="UPDATE user SET wallet = '" . $zjwallet;
$tmp5=$tmp2 . "' WHERE username = '";
$tmp3=$tmp5 . $zjzhq;
$sql=$tmp3 . "'";
$result=$conn->query($sql);
$tmp2=$result===TRUE;
if($tmp2)goto L2xx31;
goto L2xldMhx32;
L2xldMhx32:
$val["code"]="201";
$val["msg"]="领取红包失败,请重试";
$val2[]=$val;
$arr=$val2;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
L2xx31:
$tmp2="UPDATE money SET sum = '" . $sum;
$tmp5=$tmp2 . "', recve = '";
$tmp3=$tmp5 . $recve;
$tmp4=$tmp3 . "', luser = '";
$tmp7=$tmp4 . $luser;
$tmp8=$tmp7 . "' WHERE ptpmoncid = '";
$tmp9=$tmp8 . $ptpmoncid;
$sql=$tmp9 . "'";
$result=$conn->query($sql);
$tmp2=$result===TRUE;
if($tmp2)goto L2xx33;
goto L2xldMhx34;
L2xldMhx34:
L2xx33:
$str="领取成功,余额加：" . $linghb;
$val["code"]="200";
$val["msg"]=$str;
$val2[]=$val;
$arr=$val2;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
goto L2xx35;
L2xldMhx36:
L2xx35: