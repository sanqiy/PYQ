<?php
$iteace='adminapi';
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp=$user_zh=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$user_passid=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit('<script language="JavaScript">;alert("请先登录!");location.href="../login.php";</script>');
}
$tmp=include '../../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$escaped=htmlspecialchars($user_zh);
$cookieResult=addslashes($escaped);
$user_zhsg=$cookieResult;
$tmp="select * from user where username='" . $user_zhsg;
$sqls=$tmp . "'";
$env=mysqli_query($conn, $sqls);
$data_results=$env;
$env=mysqli_fetch_array($data_results);
$data2s_row=$env;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($str))break;
    $glyzhuser=$row["username"];
}
L2xxf:
$str2="select * from user where username='" . $user_zh;
$str3=$str2 . "'";
$env=mysqli_query($conn, $str3);
$data_result=$env;
$env=mysqli_fetch_array($data_result);
$data2_row=$env;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
$zid=$data2_row["id"];
$zjpassword=$data2_row["password"];
if($user_passid!=$passid){
    $escaped=time();
    $str2=$escaped+ -1;
    $cookieResult=setcookie("username", "", $str2, "/");
    $escaped=time();
    $str2=$escaped+ -1;
    $cookieResult=setcookie("passid", "", $str2, "/");
    exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="../login.php";</script>');
}
if($zjzhq!=$glyzhuser){
    exit('<script language="JavaScript">;alert("没有权限!");history.go(-1);</script>');
}
$auth_keylocation='../../api/key.php';
$auth_keyauth='../../api/auth.php';
$num=6859;
$env=file_exists($auth_keyauth);
if($env){
    $num=104;
}else{
    $num=247;
}
$tmp=72;
$tmp4=104;
$tmp2=$num==104;
if($tmp2)goto L2xeWjgxw;
goto L2xldMhxw;
L2xeWjgxw:
$tmp=require $auth_keyauth;
$tmp=!defined("sh_auth_state");
if($tmp){
    exit('<script language="JavaScript">;alert("授权验证失败,请确保文件完整且未篡改!");history.go(-1);</script>');
}
$tmp=sh_auth_state!="ok";
if($tmp)goto L2xeWjgxu;
goto L2xxv;
goto L2xxv;
L2xeWjgxu:
exit('<script language="JavaScript">;alert("程序未授权,您的请求已被拒绝,请授权后使用!");history.go(-1);</script>');
goto L2xxv;
L2xldMhxw:
switch($num){
    case 247:{
    exit('<script language="JavaScript">;alert("授权验证文件不存在或被篡改,请确保文件完整且未篡改!");history.go(-1);</script>');
        break;
    }
}
L2xxv:
$str="Y";
$Y=$str;
$str="m";
$m=$str;
$str="d";
$d=$str;
$str="H";
$H=$str;
$str="i";
$i=$str;
$str="s";
$s=$str;
$str2=$Y . "-";
$str3=$str2 . $m;
$str4=$str3 . "-";
$val=$str4 . $d;
$str5=$val . " ";
$val2=$str5 . $H;
$str6=$val2 . ":";
$val3=$str6 . $i;
$str7=$val3 . ":";
$val4=$str7 . $s;
$env=date($val4);
$sj=$env;
$num2=6869;
if($_SERVER["HTTP_X_FORWARDED_FOR"]){
    $num2=39;
}else{
    if($_SERVER["HTTP_CLIENT_IP"]){
        $num2=104;
    }else{
        if($_SERVER["REMOTE_ADDR"]){
            $num2=24;
        }else{
            $env=getenv("HTTP_X_FORWARDED_FOR");
            if($env){
                $num2=39;
                $num2=7009;
            }else{
                $env=getenv("HTTP_CLIENT_IP");
                if($env){
                    $num2=247;
                }else{
                    $env=getenv("REMOTE_ADDR");
                    if($env){
                        $num2=39;
                        $num2=10385;
                    }else{
                        $num2=247;
                        $num2=5773;
                    }
                }
            }
        }
    }
}
switch($num2){
    case 247:{
    $env=getenv("HTTP_CLIENT_IP");
    $ip=$env;
        break;
    }
    case 3524:{
        $env=getenv("HTTP_X_FORWARDED_FOR");
        $ip=$env;
        break;
    }
    case 24:{
            $ip=$_SERVER["REMOTE_ADDR"];
        break;
    }
    case 39:{
                $ip=$_SERVER["HTTP_X_FORWARDED_FOR"];
        break;
    }
    case 104:{
                    $ip=$_SERVER["HTTP_CLIENT_IP"];
        break;
    }
    case 5212:{
                        $env=getenv("REMOTE_ADDR");
                        $ip=$env;
        break;
    }
    case 3010:{
                            $ip="Unknown";
        break;
    }
}
$num3=6868;
$isArray=is_array($_POST);
if($isArray){
    $num3=169;
}else{
    $num3=152;
}
switch($num3){
    case 152:{
    $kms=$_POST["kms"];
        break;
    }
    case 169:{
        $kms=&$_POST["kms"];
        break;
    }
}
$escaped=htmlspecialchars($kms);
unset($kms);
$escaped2=addslashes($escaped);
$kms=$escaped2;
$num4=6868;
$isArray=is_array($_POST);
if($isArray){
    $num4=247;
}else{
    $num4=39;
}
switch($num4){
    case 39:{
    $kms=$_POST["kmg"];
        break;
    }
    case 247:{
        $kms=&$_POST["kmg"];
        break;
    }
}
$escaped=htmlspecialchars($kms);
unset($kms);
$escaped2=addslashes($escaped);
$kmg=$escaped2;
$num5=6877;
$isArray=is_array($_GET);
if($isArray){
    $num5=247;
}else{
    $num5=247;
    $num5=4657;
}
switch($num5){
    case 247:{
    $kms=&$_GET["del"];
        break;
    }
    case 2452:{
        $kms=$_GET["del"];
        break;
    }
}
$escaped=htmlspecialchars($kms);
unset($kms);
$escaped2=addslashes($escaped);
$del=$escaped2;
if($del!=""){
    $tmp="delete from kami where id='" . $del;
    $sql=$tmp . "'";
    $result=$conn->query($sql);
    $result=$result;
    if($result){
        exit('<script language="JavaScript">;alert("已删除该卡密");location.href="../calis.php";</script>');
    }else{
        exit('<script language="JavaScript">;alert("卡密删除失败");location.href="../calis.php";</script>');
    }
    exit();
}
if($kms==""){
    exit('<script language="JavaScript">;alert("请输入生成卡密数量");location.href="../calis.php";</script>');
}
if($kmg==""){
    exit('<script language="JavaScript">;alert("请输入每张卡密金额");location.href="../calis.php";</script>');
}
$bdm="kami";
$i=0;
while(true){
    $tmp=$i<$kms;
    if(!($tmp))break;
    $env=make_password();
    $kami=$env;
    $tmp="INSERT INTO " . $bdm;
    $tmp4=$tmp . " (kami,auom,act,ause,autm)
    VALUES ('";
    $tmp2=$tmp4 . $kami;
    $tmp3=$tmp2 . "','";
    $tmp5=$tmp3 . $kmg;
    $sql=$tmp5 . "','0','','')";
    $num6=6860;
    $result=$conn->query($sql);
    $tmp=$result===TRUE;
    if($tmp){
        $num6=169;
    }else{
        $num6=24;
    }
    $tmp=360;
    $tmp4=169;
    $tmp2=$num6==169;
if($tmp2)goto L2xx2j;
goto L2xldMhx2k;
L2xldMhx2k:
    $tmp=85;
    $tmp4=24;
    $tmp2=$num6==24;
if($tmp2)goto L2xeWjgx2l;
goto L2xldMhx2l;
goto L2xldMhx2l;
goto L2xldMhx2l;
L2xeWjgx2l:
    exit('<script language="JavaScript">;alert("卡密生成出错");location.href="../calis.php";</script>');
goto L2xx2g;
goto L2xx2j;
L2xldMhx2l:
L2xx2j:
    $obj=$i;
    $obj2=$i+1;
    $str=$obj2;
    $i=$str;
}
L2xx2u:
L2xx2g:
$tmp='<script language="JavaScript">;alert("成功生成卡密*' . $kms;
$tmp4=$tmp . '(金额:';
$tmp2=$tmp4 . $kmg;
exit($tmp2 . ')");location.href="../calis.php";</script>');
$result=$conn->close();
unset($val5);function make_password($length) {
    $str=null;
    $strPol="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
    $env=strlen($strPol);
    $max=$env-1;
    $i=0;
    while(true){
        $tmp=$i<$length;
        if(!($tmp))break;
        $escaped=rand($max);
        $str=$str . $strPol[$escaped];
        $val6=$str;
        $obj2=$i;
        $obj3=$i+1;
        $str=$obj3;
        $i=$str;
    }
    return $str;
}