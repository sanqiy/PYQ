<?php
$num=8010;
$tmp2=(bool)isset($mailapfs);
if($tmp2){
    $tmp3=$mailapfs==='nopost';
    $tmp2=(bool)$tmp3;
}
if($tmp2){
    $num=50;
}else{
    $num=50;
    $num=12446;
}
$tmp3=165;
$tmp2=6248;
$tmp4=$num==6248;
if($tmp4)goto L2xeWjgxm;
goto L2xldMhxm;
L2xeWjgxm:
$mailapfs='post';
$isArray=is_array($_POST);
if($isArray){
    $mailtitle=&$_POST['mailtitle'];
}else{
    $mailtitle=$_POST['mailtitle'];
}
$escaped=htmlspecialchars($mailtitle);
unset($mailtitle);
$escaped2=addslashes($escaped);
$mailtitle=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $mailtitle=&$_POST['title'];
}else{
    $mailtitle=$_POST['title'];
}
$escaped=htmlspecialchars($mailtitle);
unset($mailtitle);
$escaped2=addslashes($escaped);
$title=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $mailtitle=&$_POST['text'];
}else{
    $mailtitle=$_POST['text'];
}
$escaped=htmlspecialchars($mailtitle);
unset($mailtitle);
$escaped2=addslashes($escaped);
$text=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $mailtitle=&$_POST['mailbox'];
}else{
    $mailtitle=$_POST['mailbox'];
}
$escaped=htmlspecialchars($mailtitle);
unset($mailtitle);
$escaped2=addslashes($escaped);
$mailbox=$escaped2;
$tmp3=$mailtitle=="";
if($tmp3){
    $val["code"]="201";
    $val["msg"]="请传入邮件标题";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$tmp3=$title=="";
if($tmp3){
    $val["code"]="201";
    $val["msg"]="请传入邮件内标题";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$tmp3=$text=="";
if($tmp3){
    $val["code"]="201";
    $val["msg"]="请传入内容";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$tmp3=$mailbox=="";
if($tmp3)goto L2xeWjgxk;
goto L2xxl;
goto L2xxl;
L2xeWjgxk:
$val["code"]="201";
$val["msg"]="请传入收件箱";
$val2[]=$val;
$arr=$val2;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
goto L2xxl;
L2xldMhxm:
switch($num){
    case 50:{
    $mailtitle=$mailtitle;
    $title=$title;
    $text=$text;
    $mailbox=$mailbox;
        break;
    }
}
L2xxl:
$cond=preg_replace_callback('/<a(?!.*\bid\b)[^>]*>(.*?)<\/a>/i',function($match){$arr=array();
$arr[]=5;
$arr[]=20;
$arr[]=8;
$arr[]=16;
$arr[]=5;
return $match[1];
},$title);
$title=$cond;
$cond=preg_replace_callback('/<a(?!.*\bid\b)[^>]*>(.*?)<\/a>/i',function($match){$arr2=array();
$arr2[]=12;
$arr2[]=8;
$arr2[]=2;
$arr2[]=16;
$arr2[]=18;
return $match[1];
},$text);
$text=$cond;
$tmp3=include '../config.php';
$tmp3=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp3;
if($conn->connect_error){
    $val["code"]="201";
    $val["msg"]="连接数据库失败";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($cond))break;
    $wzname=$row["name"];
    $emydz=$row["emydz"];
    $emssl=$row["emssl"];
    $emduk=$row["emduk"];
    $emkey=$row["emkey"];
    $emzh=$row["emzh"];
    $emfs=$row["emfs"];
    $emfszm=$row["emfszm"];
    $comaud=$row["comaud"];
    $glyusername=$row["username"];
}
L2xx1d:
$variables=$val3;
$cond=$wzname;
$variables['wz_name']=$cond;
$cond=$title;
$variables['title']=$cond;
$cond=$text;
$variables['text']=$cond;
$tmp3=$_SERVER['REQUEST_SCHEME'] . '://';
$tmp2=$tmp3 . $_SERVER['HTTP_HOST'];
$sentinel=$tmp2;
$variables['url']=$sentinel;
$curlOptResult=file_get_contents("../site/mailtemplate.php");
$template=$curlOptResult;
unset($tmp);
foreach($variables as $key=>$value){$tmp[$key]=$value;
}
$tmp5=0;
while(true){
    $curlOptResult=count($tmp);
    $tmp3=$tmp5<$curlOptResult;
    if(!($tmp3))break;
    $curlOptResult=array_keys($tmp);
    $key=$curlOptResult;
    $key=$key[$tmp5];
    $value=$tmp[$key];
    $str='{{ ' . $key;
    $val4=$str . ' }}';
    $curlOptResult=str_replace($val4, $value, $template);
    $template=$curlOptResult;
    $tmp5=$tmp5+1;
}
L2xx1k:
$template=$template;
$val3['emydz']=$emydz;
$val3['emssl']=$emssl;
$val3['emduk']=$emduk;
$val3['key']=$emkey;
$val3['username']=$emfs;
$val3['fromuser']=$emfs;
$val3['fromname']=$emfszm;
$val3['title']=$mailtitle;
$val3['nr']=$template;
$val3['reveuser']=$mailbox;
$post_data=$val3;
$curlOptResult=session_start();
$tmp3=$_SERVER['REQUEST_SCHEME'] . '://';
$tmp2=$tmp3 . $_SERVER['HTTP_HOST'];
$url=$tmp2 . '/site/email/email.php';
$data=$post_data;
$escaped=session_id();
$str='Cookie: PHPSESSID=' . $escaped;
$val5[]='Authorization: Basic YWRtaW46YWRtaW4xMjMuLi4=';
$val5[]=$str;
$val5[]='User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.71 Safari/537.36';
$headers=$val5;
$curlOptResult=curl_init();
$curl=$curlOptResult;
$curlOptResult=curl_setopt($curl, CURLOPT_URL, $url);
$curlOptResult=curl_setopt($curl, CURLOPT_SSL_VERIFYPEER);
$curlOptResult=curl_setopt($curl, CURLOPT_SSL_VERIFYHOST);
$num2=8012;
$isArray=is_array($_SERVER);
if($isArray){
    $num2=15;
}else{
    $num2=25;
}
switch($num2){
    case 25:{
    $serverVal=$_SERVER['HTTP_USER_AGENT'];
        break;
    }
    case 15:{
        $serverVal=&$_SERVER['HTTP_USER_AGENT'];
        break;
    }
}
$curlOptResult=curl_setopt($curl, CURLOPT_USERAGENT, $serverVal);
unset($serverVal);
$curlOptResult=curl_setopt($curl, CURLOPT_FOLLOWLOCATION);
$curlOptResult=curl_setopt($curl, CURLOPT_AUTOREFERER);
$curlOptResult=curl_setopt($curl, CURLOPT_POST);
$escaped=http_build_query($data);
$curlOptResult2=curl_setopt($curl, CURLOPT_POSTFIELDS, $escaped);
$curlOptResult=curl_setopt($curl, CURLOPT_TIMEOUT);
$curlOptResult=curl_setopt($curl, CURLOPT_HEADER);
$curlOptResult=curl_setopt($curl, CURLOPT_RETURNTRANSFER);
$curlOptResult=curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
$curlOptResult=curl_exec($curl);
$result=$curlOptResult;
$curlOptResult=curl_errno($curl);
if($curlOptResult)goto L2xx1t;
L2xx1t:
$curlOptResult=curl_close($curl);
if($mailapfs!="nopost"){
    echo $result;
}
if($xiangym=='ok'){
    echo $result;
}