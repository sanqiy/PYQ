<?php
$iteace=1;
$isFile=is_file('../config.php');
if($isFile){
    $tmp=include '../config.php';
}
$tmp=include '../api/wz.php';
if($userdlzt==1){
    $isFile=header('location: ./index.php');
    exit();
}
$num=4914;
$tmp=$user_zh=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$user_name=="";
    $tmp2=(bool)$tmp4;
}
$tmp5=(bool)$tmp2;
$tmp6=!$tmp5;
if($tmp6){
    $tmp7=$user_img=="";
    $tmp5=(bool)$tmp7;
}
$tmp8=(bool)$tmp5;
$tmp9=!$tmp8;
if($tmp9){
    $tmp10=$user_passid=="";
    $tmp8=(bool)$tmp10;
}
if($tmp8){
    $num=176;
}else{
    $num=170;
}
$tmp=6;
$tmp4=170;
$tmp2=$num==170;
if($tmp2)goto L2xeWjgxm;
goto L2xldMhxm;
L2xeWjgxm:
$userdlzt=1;
$tmp=$user_zh==$glyadmin;
if($tmp)goto L2xeWjgxi;
goto L2xldMhxi;
goto L2xldMhxi;
L2xeWjgxi:
$tmp=$user_passid!=$passid;
if($tmp)goto L2xeWjgxk;
goto L2xldMhxk;
goto L2xldMhxk;
L2xeWjgxk:
exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="../index.php";</script>;');
goto L2xxl;
L2xldMhxk:
$isFile=header("Location: ./index.php");
exit();
L2xldMhxi:
exit('<script language="JavaScript">;alert("没有权限!");location.href="../index.php";</script>;');
L2xldMhxm:
switch($num){
    case 176:{
    $userdlzt=0;
        break;
    }
}
L2xxl:
echo "<!doctype html>";
echo "
<html lang=\"en\">";
echo "
<head>";
echo "
<meta charset=\"utf-8\">";
echo "
<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0\">";
echo "
<title>管理员登录 - ";
echo $name;
echo "</title>";
echo "
<meta name=\"keywords\" content=\"";
echo $filterkeyw;
echo "\">";
echo "
<meta name=\"description\" content=\"";
echo $subtitle;
echo "\">";
echo "
<meta name=\"author\" content=\"";
echo $name;
echo "\">";
echo "
<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"";
$num2=4926;
$isFile=strpos($icon, 'http');
$tmp=$isFile!==false;
if($tmp){
    $num2=187;
}else{
    $num2=187;
    $num2=7539;
}
switch($num2){
    case 3863:{
    $tmp='.' . $icon;
    echo $tmp;
        break;
    }
    case 187:{
        echo $icon;
        break;
    }
}
echo "\">";
echo "
<link rel=\"stylesheet\" href=\"assets/css/css2.css\">";
echo "
<link rel=\"stylesheet\" id=\"css-main\" href=\"assets/css/oneui.min.css\">";
echo "
</head>";
echo "
<body>";
echo "
<div id=\"page-container\">";
echo "
";
echo "
<!-- Main Container -->";
echo "
<main id=\"main-container\">";
echo "
<!-- Page Content -->";
echo "
<div class=\"hero-static d-flex align-items-center\">";
echo "
<div class=\"content\">";
echo "
<div class=\"row justify-content-center push\">";
echo "
<div class=\"col-md-8 col-lg-6 col-xl-4\">";
echo "
<!-- Sign In Block -->";
echo "
<div class=\"block block-rounded mb-0\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\"><trans oldtip=\"登录\" newtip=\"登录\">管理员登录</trans></h3>";
echo "
";
echo "
</div>";
echo "
<div class=\"block-content\">";
echo "
<div class=\"p-sm-3 px-lg-4 px-xxl-5 py-lg-5\">";
echo "
<h1 class=\"h2 mb-1\"><trans oldtip=\"LAN\" newtip=\"LAN\" style=\"\">LAN</trans></h1>";
echo "
<p class=\"fw-medium text-muted\"><trans oldtip=\" Welcome, please login. \" newtip=\"欢迎，请登录。\" style=\"\">欢迎，请登录。</trans></p>";
echo "
";
echo "
<!-- Sign In Form -->";
echo "
<!-- jQuery Validation (.js-validation-signin class is initialized in js/pages/op_auth_signin.min.js which was auto compiled from _js/pages/op_auth_signin.js) -->";
echo "
<!-- For more info and examples you can check out https://github.com/jzaefferer/jquery-validation -->";
echo "
<form class=\"js-validation-signin\" action=\"./api/login.php\" method=\"post\" class=\"login-form\" autocomplete=\"off\">";
echo "
<div class=\"py-3\">";
echo "
<div class=\"mb-4\">";
echo "
<input type=\"text\" class=\"form-control form-control-alt form-control-lg valid\" id=\"username\" placeholder=\"账号\" name=\"username\" required=\"required\" >";
echo "
</div>";
echo "
<div class=\"mb-4\">";
echo "
<input type=\"password\" class=\"form-control form-control-alt form-control-lg valid\" id=\"password\" placeholder=\"密码\" name=\"password\" required=\"required\" >";
echo "
</div>";
echo "
";
echo "
</div>";
echo "
<div class=\"row mb-4\">";
echo "
<div class=\"col-md-6 col-xl-5\">";
echo "
<button type=\"submit\" class=\"btn w-100 btn-alt-primary\">";
echo "
<i class=\"fa fa-fw fa-sign-in-alt me-1 opacity-50\"></i><trans oldtip=\"登录\" newtip=\"登录\"> 登录 </trans></button>";
echo "
</div>";
echo "
</div>";
echo "
</form>";
echo "
<!-- END Sign In Form -->";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Sign In Block -->";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"fs-sm text-muted text-center\">";
echo "
<strong><trans oldtip=\"LAN\" newtip=\"LAN\">LAN</trans></strong> © <span data-toggle=\"year-copy\" class=\"js-year-copy-enabled\">";
$isFile=date("Y");
echo $isFile;
echo "</span>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Page Content -->";
echo "
</main>";
echo "
<!-- END Main Container -->";
echo "
</div>";
echo "
<script src=\"assets/js/oneui.app.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Plugins -->";
echo "
<script src=\"assets/js/chart.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Code -->";
echo "
<script src=\"assets/js/be_pages_dashboard.min.js\"></script>";
echo "
</body>";
echo "
</html>";
echo "
";

