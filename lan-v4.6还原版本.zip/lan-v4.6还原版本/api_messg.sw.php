<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp=$user_zh=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$user_passid=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit("请先登录!");
}
$tmp=include '../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    exit("连接数据库失败");
}
$escaped=htmlspecialchars($user_zh);
$cookieResult=addslashes($escaped);
$user_zhsg=$cookieResult;
$tmp="select * from user where username='" . $user_zhsg;
$sqls=$tmp . "'";
$row=mysqli_query($conn, $sqls);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$data2s_row=$row;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$num3=6861;
$isArray=is_array($_POST);
if($isArray){
    $num3=35;
}else{
    $num3=35;
    $num3=3735;
}
switch($num3){
    case 1885:{
    $plid=$_POST['plid'];
        break;
    }
    case 35:{
        $plid=&$_POST['plid'];
        break;
    }
}
$escaped=htmlspecialchars($plid);
unset($plid);
$escaped2=addslashes($escaped);
$plid=$escaped2;
$num=6867;
$isArray=is_array($_POST);
if($isArray){
    $num=49;
}else{
    $num=55;
}
switch($num){
    case 49:{
    $plid=&$_POST['type'];
        break;
    }
    case 55:{
        $plid=$_POST['type'];
        break;
    }
}
$escaped=htmlspecialchars($plid);
unset($plid);
$escaped2=addslashes($escaped);
$type=$escaped2;
$tmp=$plid=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$type=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit("参数不完整!");
}
$str="select * from user where username='" . $user_zh;
$str2=$str . "'";
$row=mysqli_query($conn, $str2);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
if($user_passid!=$passid){
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("username", "", $str, "/");
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("passid", "", $str, "/");
    exit("账号信息异常,请重新登录!");
}
$num2=6862;
$tmp=$type==0;
if($tmp){
    $num2=95;
}else{
    $tmp=$type==-1;
    if($tmp){
        $num2=95;
        $num2=653;
    }else{
        $tmp=$type==-2;
        if($tmp){
            $num2=98;
        }else{
            $tmp=$type==-3;
            if($tmp){
                $num2=361;
            }
        }
    }
}
$tmp=72;
$tmp4=361;
$tmp2=$num2==361;
if($tmp2)goto L2xeWjgx1e;
goto L2xldMhx1e;
L2xeWjgx1e:
$tmp="UPDATE message SET msg = '1' WHERE suser = '" . $zjzhq;
$sql=$tmp . "'";
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp)goto L2xeWjgx1c;
goto L2xldMhx1c;
goto L2xldMhx1c;
L2xeWjgx1c:
echo "消息已读";
goto L2xx1d;
L2xldMhx1c:
echo $conn->error;
L2xldMhx1e:
$tmp=48;
$tmp4=98;
$tmp2=$num2==98;
if($tmp2)goto L2xeWjgx1h;
goto L2xldMhx1h;
L2xeWjgx1h:
$tmp="delete from message where suser='" . $zjzhq;
$sql6=$tmp . "'";
$result=$conn->query($sql6);
$result6=$result;
if($result6)goto L2xeWjgx19;
goto L2xldMhx19;
goto L2xldMhx19;
L2xeWjgx19:
echo "消息已删除";
goto L2xx1d;
L2xldMhx19:
$row=mysql_errno();
echo $row;
L2xldMhx1h:
$tmp=342;
$tmp4=95;
$tmp2=$num2==95;
if($tmp2)goto L2xeWjgx1k;
goto L2xldMhx1k;
L2xeWjgx1k:
$tmp="UPDATE message SET msg='1' WHERE id='" . $plid;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx13;
goto L2xldMhx13;
goto L2xldMhx13;
L2xeWjgx13:
echo "消息已读";
goto L2xx1d;
L2xldMhx13:
$row=mysql_errno();
echo $row;
L2xldMhx1k:
$tmp=102;
$tmp4=374;
$tmp2=$num2==374;
if($tmp2)goto L2xeWjgx1n;
goto L2xldMhx1n;
L2xeWjgx1n:
$tmp="UPDATE message SET msg='-1' WHERE id='" . $plid;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx16;
goto L2xldMhx16;
goto L2xldMhx16;
L2xeWjgx16:
echo "消息已删除";
$tmp="delete from message where id='" . $plid;
$sql6=$tmp . "'";
$result=$conn->query($sql6);
$result6=$result;
goto L2xx1d;
L2xldMhx16:
$row=mysql_errno();
echo $row;
L2xldMhx1n:
L2xx1d:
$result=$conn->close();

