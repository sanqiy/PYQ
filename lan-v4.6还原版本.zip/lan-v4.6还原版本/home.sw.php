<?php
if($_SERVER['REQUEST_METHOD']==='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$iteace=0;
$num16=8017;
$fileExists=is_file('./config.php');
if($fileExists){
    $num16=361;
}else{
    $num16=121;
}
switch($num16){
    case 361:{
    $tmp2=require './config.php';
        break;
    }
    case 121:{
        exit('未检测到配置文件：<span style="color: red;">config.php</span>，若您是首次使用请先进行安装,删除文件夹 <span style="color: red;">[install/]</span> 下的 <span style="color: red;">[ins.bak]</span> 文件后进行安装。若已删除请<a href="./install/">【点击安装】</a>');
        break;
    }
}
$tmp2=require './api/wz.php';
$tmp2="select * from user where username= '" . $user_zh;
$sql=$tmp2 . "'";
$fileExists=mysqli_query($conn, $sql);
$result=$fileExists;
$num17=8000;
$fileExists=mysqli_num_rows($result);
$tmp2=$fileExists>0;
if($tmp2){
    $num17=209;
}else{
    $num17=209;
    $num17=14473;
}
$tmp2=171;
$tmp3=209;
$tmp4=$num17==209;
if($tmp4){
while(true){
    $fileExists=mysqli_fetch_assoc($result);
    $row=$fileExists;
    if(!$cond)break;
    $zjnc=$row["name"];
    $zjimg=$row["img"];
    $zjhomeimgy=$row["homeimg"];
    $zjsign=$row["sign"];
}
}else{
switch($num17){
    case 7341:{
    $fileExists=Header("Location:./index.php");
        break;
    }
}
}
switch($num17){
    case 7341:{
    $fileExists=Header("Location:./index.php");
        break;
    }
}
L2xxg:
if($zjhomeimgy==-1){
    $zjhomeimgy=$homimg;
}
echo "<!DOCTYPE html>";
echo "
<html lang=\"zh-CN\">";
echo "
<head>";
echo "
<meta charset=\"UTF-8\">";
echo "
<title>个人中心 - ";
echo $name;
echo "</title>";
echo "
<!--为搜索引擎定义关键词-->";
echo "
<meta name=\"keywords\" content=\"";
echo $filterkeyw;
echo "\">";
echo "
<!--为网页定义描述内容 用于告诉搜索引擎，你网站的主要内容-->";
echo "
<meta name=\"description\" content=\"";
echo $subtitle;
echo "\">";
echo "
<meta name=\"author\" content=\"";
echo $name;
echo "\">";
echo "
<meta name=\"copyright\" content=\"";
echo $name;
echo "\">";
echo "
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" />";
echo "
<meta http-equiv=\"cache-control\" content=\"no-cache\">";
echo "
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0,minimum-scale=1.0, user-scalable=no minimal-ui\">";
echo "
<link rel=\"apple-touch-icon\" sizes=\"57x57\" href=\"";
echo $icon;
echo "\" /><!-- Standard iPhone -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"114x114\" href=\"";
echo $icon;
echo "\" /><!-- Retina iPhone -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"72x72\" href=\"";
echo $icon;
echo "\" /><!-- Standard iPad -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"144x144\" href=\"";
echo $icon;
echo "\" /><!-- Retina iPad -->";
echo "
<link rel=\"icon\" href=\"";
echo $icon;
echo "\" type=\"image/x-icon\" />";
echo "
<meta name=\"robots\" content=\"index,follow\">";
echo "
<meta name=\"format-detection\" content=\"telephone=no\">";
echo "
<meta http-equiv=\"x-rim-auto-match\" content=\"none\">";
echo "
";
if($rosdomain==1){
    echo '<meta name="referrer" content="no-referrer">';
}
echo "    <link rel=\"stylesheet\" href=\"";
echo $iconurl_url;
echo "\">";
echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"./assets/css/style.css\">";
echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"./assets/mesg/dist/css/style.css\"><!--引入弹窗对话框-->";
echo "
";
echo $scfontzt;
echo "    ";
$folderPath='./user/bobg/';
$fileExists=file_exists($folderPath);
$tmp2=!$fileExists;
if($tmp2){
    $fileExists=mkdir($folderPath, true);
}
$num5=8012;
$fileExists=file_exists("./user/bobg/bobg.jpg");
if($fileExists){
    $num5=114;
}else{
    $fileExists=file_exists("./user/bobg/bobg.png");
    if($fileExists){
        $num5=120;
    }else{
        $fileExists=file_exists("./user/bobg/bobg.jpeg");
        if($fileExists){
            $num5=361;
        }else{
            $fileExists=file_exists("./user/bobg/bobg.gif");
            if($fileExists){
                $num5=209;
            }
        }
    }
}
switch($num5){
    case 114:{
    echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.jpg);}</style>';
        break;
    }
    case 120:{
        echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.png);}</style>';
        break;
    }
    case 361:{
            echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.jpeg);}</style>';
        break;
    }
    case 209:{
                echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.gif);}</style>';
        break;
    }
}
echo "    ";
$tmp2='<style>' . $filtercucss;
$tmp3=$tmp2 . '</style>';
echo $tmp3;
echo "</head>";
echo "
<body class=\"";
$num6=8012;
if(isset($_COOKIE['dark_theme'])){
    $num6=120;
}else{
    $num6=120;
    $num6=13380;
}
$tmp2=70;
$tmp3=120;
$tmp4=$num6==120;
if($tmp4)goto L2xeWjgx1d;
goto L2xldMhx1d;
L2xeWjgx1d:
$tmp2=$_COOKIE["dark_theme"]=="dark-theme";
if($tmp2)goto L2xeWjgx1b;
goto L2xx1c;
goto L2xx1c;
L2xeWjgx1b:
echo 'dark-theme';
goto L2xx1c;
L2xldMhx1d:
$tmp2=152;
$tmp3=6750;
$tmp4=$num6==6750;
if($tmp4)goto L2xx1c;
L2xx1c:
echo "\">";
echo "
";
if($pagepass!="")goto L2xeWjgx1o;
goto L2xldMhx1o;
L2xeWjgx1o:
if(isset($_COOKIE['pagepass']))goto L2xeWjgx1k;
goto L2xldMhx1k;
goto L2xldMhx1k;
L2xeWjgx1k:
$timestamp=md5($pagepass);
$dateStr=md5($timestamp);
$tmp2=$_COOKIE['pagepass']!=$dateStr;
if($tmp2)goto L2xeWjgx1m;
goto L2xx1n;
goto L2xx1n;
L2xeWjgx1m:
$tmp2=include './site/pagepass.php';
goto L2xx1n;
L2xldMhx1k:
$tmp2=include './site/pagepass.php';
L2xldMhx1o:
L2xx1n:
echo "    <div class=\"centent\">";
echo "
<div class=\"sh-main\">";
echo "
<div class=\"sh-main-head\">";
echo "
<div class=\"sh-main-head-top\" id=\"sh-main-head-top\">";
echo "
<!-- 左边 -->";
echo "
<div class=\"sh-main-head-top-left\">";
echo "
<div class=\"sh-main-head-top-left-s\" onclick=\"location.href='./index.php'\">";
echo "
<i class=\"iconfont icon-weibiaoti al-sxb\" id=\"top-left-1\"></i>";
echo "
</div>";
echo "
</div>";
echo "
<!-- 右边 -->";
echo "
<div class=\"sh-main-head-top-right\">";
echo "
";
$fileExists=date("Ymd");
$tmp2=$zjussig!=$fileExists;
$tmp4=(bool)$tmp2;
if($tmp4){
    $tmp3=$sigin>0;
    $tmp4=(bool)$tmp3;
}
if($tmp4){
    echo '<div class="sh-main-head-top-right-s" id="sh-main-head-top-right-s-qiandao">
    <a href="JavaScript:;" onclick="qiandao()"><i class="iconfont icon-qiandao1 al-sxb" id="top-right-3"></i></a>
    </div>';
}
echo "                            ";
echo "
<div class=\"sh-main-head-top-right-s\">";
echo "
<a href=\"./setup.php\"><i class=\"iconfont icon-a31shezhi al-sxb\" id=\"top-right-2\"></i></a>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"sh-main-head-img\" style=\"background-image:url(";
echo $zjhomeimgy;
echo ")\">";
echo "
<div class=\"sh-main-head-top-scba\" onclick=\"reckq()\">";
echo "
<i class=\"iconfont icon-tianjiatupian al-sxb2\"></i></div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
<div class=\"sh-main-head-headimg\">";
echo "
<div class=\"sh-main-head-headimg-tx\">";
echo "
<h4>";
echo $zjnc;
echo "</h4>";
echo "
<a href=\"JavaScript:;\"><img src=\"./assets/img/thumbnail.svg\" data-src=\"";
echo $zjimg;
echo "\" alt=\"头像\"></a>";
echo "
</div>";
echo "
<div class=\"sh-main-head-headimg-qm\">";
echo "
<p>";
echo $zjsign;
echo "</p>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
<div class=\"sh-homecontent\" id=\"sh-nrbk\">";
echo "
";
$tmp2=require './config.php';
$tmp2=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp2;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$tmp2=include "./api/topeshome.php";
$prevDay='';
$prevMonth=$cond;
$prevYear=$cond;
$timebss='';
$wzsl=0;
$num7=8014;
$tmp2=$user_zh==$glyadmin;
if($tmp2){
    $num7=114;
}else{
    $num7=380;
}
switch($num7){
    case 114:{
    $query="SELECT * FROM essay WHERE ptpaud='1'";
        break;
    }
    case 380:{
        $tmp2="SELECT * FROM essay WHERE ptpaud='1' and ptpuser = '" . $user_zh;
        $query=$tmp2 . "'";
        break;
    }
}
$fileExists=mysqli_query($conn, $query);
$result=$fileExists;
$ptptime_values=$val3;
while(true){
    $fileExists=mysqli_fetch_assoc($result);
    $row=$fileExists;
    if(!($cond))break;
    $num8=8002;
    $isArray=is_array($row);
    if($isArray){
        $num8=66;
    }else{
        $num8=120;
    }
    switch($num8){
        case 120:{
        $key=$row['ptptime'];
            break;
        }
        case 66:{
            $key=&$row['ptptime'];
            break;
        }
    }
    $timestamp=strtotime($key);
    unset($key);
    $dateStr2=date('Y', $timestamp);
    $num9=8003;
    $isArray2=is_array($row);
    if($isArray2){
        $num9=380;
    }else{
        $num9=209;
    }
    switch($num9){
        case 209:{
        $key2=$row['ptptime'];
            break;
        }
        case 380:{
            $key2=&$row['ptptime'];
            break;
        }
    }
    $timestamp2=strtotime($key2);
    unset($key2);
    $dateStr3=date('m', $timestamp2);
    $tmp5=$dateStr2 . $dateStr3;
    $num10=8013;
    $isArray3=is_array($row);
    if($isArray3){
        $num10=380;
    }else{
        $num10=114;
    }
    switch($num10){
        case 380:{
        $key3=&$row['ptptime'];
            break;
        }
        case 114:{
            $key3=$row['ptptime'];
            break;
        }
    }
    $timestamp3=strtotime($key3);
    unset($key3);
    $dateStr4=date('d', $timestamp3);
    $tmp6=$tmp5 . $dateStr4;
    $num11=8005;
    $isArray4=is_array($row);
    if($isArray4){
        $num11=114;
    }else{
        $num11=66;
    }
    $tmp7=48;
    $tmp8=66;
    $tmp9=$num11==66;
    if($tmp9){
        $key4=$row['ptptime'];
    }else{
        $tmp10=7;
        $tmp11=114;
        $tmp12=$num11==114;
        if($tmp12){
            $key4=&$row['ptptime'];
        }
    }
    $timestamp4=strtotime($key4);
    unset($key4);
    $dateStr5=date('H', $timestamp4);
    $tmp13=$tmp6 . $dateStr5;
    $num12=8014;
    $isArray5=is_array($row);
    if($isArray5){
        $num12=361;
    }else{
        $num12=114;
    }
    $tmp14=$num12==361;
    if($tmp14){
        $key5=&$row['ptptime'];
    }else{
        $tmp15=114;
        $tmp16=$num12==114;
        if($tmp16){
            $key5=$row['ptptime'];
        }
    }
    $timestamp5=strtotime($key5);
    unset($key5);
    $dateStr6=date('i', $timestamp5);
    $tmp17=$tmp13 . $dateStr6;
    $num13=8002;
    $isArray6=is_array($row);
    if($isArray6){
        $num13=209;
    }else{
        $num13=380;
    }
    $tmp18=110;
    $tmp19=380;
    $tmp20=$num13==380;
    if($tmp20){
        $key6=$row['ptptime'];
    }else{
        $tmp21=180;
        $tmp22=209;
        $tmp23=$num13==209;
        if($tmp23){
            $key6=&$row['ptptime'];
        }
    }
    $timestamp6=strtotime($key6);
    unset($key6);
    $dateStr7=date('s', $timestamp6);
    $ptptime=$tmp17 . $dateStr7;
    $num14=8009;
    $fileExists=strpos($ptptime, '-');
    $tmp2=$fileExists!==false;
    if($tmp2){
        $num14=220;
    }else{
        $num14=361;
    }
    switch($num14){
        case 361:{
        $cond=DateTime::createFromFormat('YmdHis',$ptptime)->getTimestamp();
        $timestamp=$cond;
            break;
        }
        case 220:{
            $fileExists=strtotime($ptptime);
            $timestamp=$fileExists;
            break;
        }
    }
    $cond=$row;
    $ptptime_values[$timestamp]=$cond;
}
L2xx4k:
$fileExists=krsort($ptptime_values);
unset($tmp);
foreach($ptptime_values as $row){$tmp[]=$row;
}
$tmp24=0;
while(true){
    $fileExists=count($tmp);
    $tmp2=$tmp24<$fileExists;
    if(!($tmp2))break;
    $keys=array_keys($tmp);
    $keys=$keys[$tmp24];
    $row=$tmp[$keys];
    $wzsl=$wzsl+1;
    $tmp2=$wzsl>$essgs;
if($tmp2)goto L2xeWjgx5w;
goto L2xldMhx5w;
goto L2xldMhx5w;
goto L2xldMhx5w;
goto L2xldMhx5w;
L2xeWjgx5w:
    $wzsl=$wzsl-1;
goto L2xx81;
goto L2xx5v;
L2xldMhx5w:
L2xx5v:
    $ptpuser=$row["ptpuser"];
    $ptpimg=$row["ptpimg"];
    $ptpname=$row["ptpname"];
    $ptptext=$row["ptptext"];
    $ptpimag=$row["ptpimag"];
    $ptpvideo=$row["ptpvideo"];
    $ptpmusic=$row["ptpmusic"];
    $ptplx=$row["ptplx"];
    $ptpdw=$row["ptpdw"];
    $ptptime=$row["ptptime"];
    $ptpgg=$row["ptpgg"];
    $ptpggurl=$row["ptpggurl"];
    $ptpys=$row["ptpys"];
    $commauth=$row["commauth"];
    $ptpaud=$row["ptpaud"];
    $ptpip=$row["ip"];
    $cid=$row["cid"];
    $wid=$row["id"];
    $fileExists=explode("|", $ptpvideo);
    $partssp=$fileExists;
    $ptpvideo=$partssp[0];
    $ptpvideofm=$partssp[1];
    $timestamp=strtotime($ptptime);
    $dateStr=date('Y', $timestamp);
    $year=$dateStr;
    $timestamp=strtotime($ptptime);
    $dateStr=date('m', $timestamp);
    $month=$dateStr;
    $timestamp=strtotime($ptptime);
    $dateStr=date('d', $timestamp);
    $day=$dateStr;
    $timestamp=strtotime($ptptime);
    $dateStr=date('H', $timestamp);
    $hour=$dateStr;
    $timestamp=strtotime($ptptime);
    $dateStr=date('i', $timestamp);
    $minute=$dateStr;
    $timestamp=strtotime($ptptime);
    $dateStr=date('s', $timestamp);
    $second=$dateStr;
    $tmp2=$year . "-";
    $tmp3=$tmp2 . $month;
    $tmp4=$tmp3 . "-";
    $givenDates=$tmp4 . $day;
    $tmp2=$year . $month;
    $given_time=$tmp2 . $day;
    $num15=8015;
    $fileExists=date("Ymd");
    $tmp2=$given_time==$fileExists;
    if($tmp2){
        $num15=361;
    }else{
        $timestamp=strtotime('-1 day');
        $dateStr=date('Ymd', $timestamp);
        $tmp2=$given_time==$dateStr;
        if($tmp2){
            $num15=66;
        }else{
            $num15=120;
        }
    }
    switch($num15){
        case 120:{
        $day=$day;
        $month=$month . "月";
            break;
        }
        case 361:{
            $day="今天";
            $month='';
            break;
        }
        case 66:{
                $day="昨天";
                $month='';
            break;
        }
    }
    $tmp2=$year!=$prevYear;
    if($tmp2){
        $fileExists=date('Y');
        $tmp2=$fileExists!=$year;
        if($tmp2){
            $tmp2='<h2 class="sh-homecontent-timed">' . $year;
            $tmp3=$tmp2 . '<span class="sh-homecontent-timed-n">年</span></h2>';
            echo $tmp3;
        }
        $prevYear=$year;
    }
    $num=8015;
    $tmp2=$ptpys==0;
    if($tmp2){
        $num=209;
    }else{
        $tmp2=$ptpaud==0;
        if($tmp2){
            $num=220;
        }else{
            $num=361;
        }
    }
    switch($num){
        case 220:{
        $cond='<i class="iconfont icon-suoding sh-homecontent-wzsbs" style="color:var(--protext)" title="文章未通过审核"></i>';
        $wzsdbs=$cond;
            break;
        }
        case 209:{
            $wzsdbs='<i class="iconfont icon-suoding sh-homecontent-wzsbs" title="文章已设为隐私"></i>';
            break;
        }
        case 361:{
                $wzsdbs='';
            break;
        }
    }
    $tmp2=$ptplx=="mony";
if($tmp2)goto L2xeWjgx6p;
goto L2xldMhx6p;
goto L2xldMhx6p;
goto L2xldMhx6p;
goto L2xldMhx6p;
L2xeWjgx6p:
    $tmp2=$wzsdbs=="";
if($tmp2)goto L2xeWjgx6n;
goto L2xldMhx6n;
goto L2xldMhx6n;
goto L2xldMhx6n;
goto L2xldMhx6n;
goto L2xldMhx6n;
L2xeWjgx6n:
    $wzsdbs=132424;
goto L2xx6o;
L2xldMhx6n:
    $wzsdbs='<i class="iconfont icon-hongbao sh-homecontent-wzsbs" title="红包" style="font-size: 13px;color: #ed2424;bottom: 6px;right: 20px;"></i>' . $wzsdbs;
L2xldMhx6p:
L2xx6o:
    $num2=8014;
    $tmp2=$ptplx=="img";
    if($tmp2){
        $num2=120;
    }else{
        $tmp2=$ptplx=="video";
        if($tmp2){
            $num2=66;
        }else{
            $tmp2=$ptplx=="music";
            if($tmp2){
                $num2=120;
                $num2=8450;
            }else{
                $tmp2=$ptplx=="only";
                if($tmp2){
                    $num2=380;
                }else{
                    $tmp2=$ptplx=="mony";
                    if($tmp2){
                        $num2=114;
                    }
                }
            }
        }
    }
    $tmp2=60;
    $tmp3=4285;
    $tmp4=$num2==4285;
if($tmp4)goto L2xeWjgx7d;
goto L2xldMhx7d;
goto L2xldMhx7d;
goto L2xldMhx7d;
goto L2xldMhx7d;
L2xeWjgx7d:
    $fileExists=explode('|', $ptpmusic);
    $mus=$fileExists;
    $tmp2=$mus[3]=="";
    if($tmp2){
        $musimg="./assets/img/musicba.jpg";
    }else{
        $musimg=$mus[3];
    }
    $tmp2=$ptptext=="";
    if($tmp2){
        $ptpnr='';
    }else{
        $tmp2='<div class="sh-homecontent-right-lie-music-title">' . $ptptext;
        $ptpnr=$tmp2 . '</div>';
    }
    $tmp2='<div class="sh-homecontent-lie">
    <!-- 左边 -->
    <div class="sh-homecontent-left">
    <!-- 日期 -->
    <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
    $tmp3=$tmp2 . '" style="';
    $tmp4=$tmp3 . $shougbsx;
    $tmp25=$tmp4 . '">
    <span class="homecontent-left-time-h">';
    $tmp26=$tmp25 . $day;
    $tmp27=$tmp26 . '</span>
    <span class="homecontent-left-time-y">';
    $tmp28=$tmp27 . $month;
    $tmp29=$tmp28 . '</span>
    </div>
    <!-- 地址 -->
    <div class="sh-homecontent-left-time-dw">';
    $tmp30=$tmp29 . $ptpdw;
    $tmp31=$tmp30 . '</div>
    </div>
    <!-- 右边内容框架 -->
    <div class="sh-homecontent-right-wk">
    <!-- 右边内容主体 -->
    <div class="sh-homecontent-right-lie-musicwk" onclick="window.location.href = \'./view.php?cid=';
    $tmp32=$tmp31 . $cid;
    $tmp33=$tmp32 . '\';">';
    $tmp5=$tmp33 . $wzsdbs;
    $tmp34=$tmp5 . '
    ';
    $tmp35=$tmp34 . $ptpnr;
    $tmp36=$tmp35 . '
    <div class="sh-homecontent-right-lie sh-homecontent-right-lie-music">
    <!-- 音乐 -->
    <div class="homecontent-right-tw homecontent-right-tw-music">
    <!-- 图片 -->
    <div class="homecontent-right-tw-img" style="grid-template-columns: 1fr;grid-template-rows: 1fr;">
    <div class="homecontent-right-tw-img-wk homecontent-right-tw-img-wk-music"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp37=$tmp36 . $musimg;
    $tmp38=$tmp37 . '" alt=""><i class="iconfont icon-sa4f56"></i></div>
    </div>
    </div>
    <!-- 文字内容 -->
    <div class="homecontent-right-nr homecontent-right-nr-music">
    <div class="homecontent-right-nr-text homecontent-right-nr-text-music" style="color: var(--thetitle);">';
    $tmp39=$tmp38 . $mus[1];
    $tmp6=$tmp39 . '</div>
    <p class="homecontent-right-nr-text-music-p homecontent-right-nr-text-music">';
    $tmp7=$tmp6 . $mus[2];
    $tmp8=$tmp7 . '</p>
    </div>
    </div>
    </div>
    </div>
    </div>';
    $wzbank=$tmp8;
goto L2xx7c;
L2xldMhx7d:
    $tmp2=15;
    $tmp3=120;
    $tmp4=$num2==120;
if($tmp4)goto L2xeWjgx7i;
goto L2xldMhx7i;
goto L2xldMhx7i;
goto L2xldMhx7i;
goto L2xldMhx7i;
L2xeWjgx7i:
    $fileExists=explode('(+@+)', $ptpimag);
    $imgar=$fileExists;
    $fileExists=count($imgar);
    $coun=$fileExists;
    $tmp2=$coun==1;
if($tmp2)goto L2xeWjgx6v;
goto L2xldMhx6v;
goto L2xldMhx6v;
goto L2xldMhx6v;
goto L2xldMhx6v;
goto L2xldMhx6v;
L2xeWjgx6v:
    $tmp2='<div class="sh-homecontent-lie">
    <!-- 左边 -->
    <div class="sh-homecontent-left">
    <!-- 日期 -->
    <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
    $tmp3=$tmp2 . '" style="';
    $tmp4=$tmp3 . $shougbsx;
    $tmp25=$tmp4 . '">
    <span class="homecontent-left-time-h">';
    $tmp26=$tmp25 . $day;
    $tmp27=$tmp26 . '</span>
    <span class="homecontent-left-time-y">';
    $tmp28=$tmp27 . $month;
    $tmp29=$tmp28 . '</span>
    </div>
    <!-- 地址 -->
    <div class="sh-homecontent-left-time-dw">';
    $tmp30=$tmp29 . $ptpdw;
    $tmp31=$tmp30 . '</div>
    </div>
    <!-- 右边内容框架 -->
    <div class="sh-homecontent-right-wk">
    <!-- 右边内容主体 -->
    <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
    $tmp32=$tmp31 . $cid;
    $tmp33=$tmp32 . '\';">
    <!-- 图片 -->
    <div class="homecontent-right-tw">
    <!-- 图片 -->
    <div class="homecontent-right-tw-img" style="grid-template-columns: 1fr;grid-template-rows: 1fr;">
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp5=$tmp33 . $imgar[0];
    $tmp34=$tmp5 . '" alt=""></div>
    ';
    $tmp35=$tmp34 . $wzsdbs;
    $tmp36=$tmp35 . '
    </div>
    </div>
    <!-- 文字内容 -->
    <div class="homecontent-right-nr">
    <div class="homecontent-right-nr-text">';
    $tmp37=$tmp36 . $ptptext;
    $tmp38=$tmp37 . '</div>
    <p class="homecontent-right-nr-tus">共';
    $tmp39=$tmp38 . $coun;
    $tmp6=$tmp39 . '张</p>
    </div>
    </div>
    </div>
    </div>';
    $wzbank=$tmp6;
goto L2xx7c;
L2xldMhx6v:
    $tmp2=$coun==2;
if($tmp2)goto L2xeWjgx6w;
goto L2xldMhx6w;
goto L2xldMhx6w;
goto L2xldMhx6w;
goto L2xldMhx6w;
goto L2xldMhx6w;
L2xeWjgx6w:
    $tmp2='<div class="sh-homecontent-lie">
    <!-- 左边 -->
    <div class="sh-homecontent-left">
    <!-- 日期 -->
    <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
    $tmp3=$tmp2 . '" style="';
    $tmp4=$tmp3 . $shougbsx;
    $tmp25=$tmp4 . '">
    <span class="homecontent-left-time-h">';
    $tmp26=$tmp25 . $day;
    $tmp27=$tmp26 . '</span>
    <span class="homecontent-left-time-y">';
    $tmp28=$tmp27 . $month;
    $tmp29=$tmp28 . '</span>
    </div>
    <!-- 地址 -->
    <div class="sh-homecontent-left-time-dw">';
    $tmp30=$tmp29 . $ptpdw;
    $tmp31=$tmp30 . '</div>
    </div>
    <!-- 右边内容框架 -->
    <div class="sh-homecontent-right-wk">
    <!-- 右边内容主体 -->
    <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
    $tmp32=$tmp31 . $cid;
    $tmp33=$tmp32 . '\';">
    <!-- 图片 -->
    <div class="homecontent-right-tw">
    <!-- 图片 -->
    <div class="homecontent-right-tw-img">
    <div class="homecontent-right-tw-img-wk" style="grid-row: 1 / 3;"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp5=$tmp33 . $imgar[0];
    $tmp34=$tmp5 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk" style="grid-row: 1 / 3;"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp35=$tmp34 . $imgar[1];
    $tmp36=$tmp35 . '" alt=""></div>
    ';
    $tmp37=$tmp36 . $wzsdbs;
    $tmp38=$tmp37 . '
    </div>
    </div>
    <!-- 文字内容 -->
    <div class="homecontent-right-nr">
    <div class="homecontent-right-nr-text">';
    $tmp39=$tmp38 . $ptptext;
    $tmp6=$tmp39 . '</div>
    <p class="homecontent-right-nr-tus">共';
    $tmp7=$tmp6 . $coun;
    $tmp8=$tmp7 . '张</p>
    </div>
    </div>
    </div>
    </div>';
    $wzbank=$tmp8;
goto L2xx7c;
L2xldMhx6w:
    $tmp2=$coun==3;
if($tmp2)goto L2xeWjgx6x;
goto L2xldMhx6x;
goto L2xldMhx6x;
goto L2xldMhx6x;
goto L2xldMhx6x;
goto L2xldMhx6x;
L2xeWjgx6x:
    $tmp2='<div class="sh-homecontent-lie">
    <!-- 左边 -->
    <div class="sh-homecontent-left">
    <!-- 日期 -->
    <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
    $tmp3=$tmp2 . '" style="';
    $tmp4=$tmp3 . $shougbsx;
    $tmp25=$tmp4 . '">
    <span class="homecontent-left-time-h">';
    $tmp26=$tmp25 . $day;
    $tmp27=$tmp26 . '</span>
    <span class="homecontent-left-time-y">';
    $tmp28=$tmp27 . $month;
    $tmp29=$tmp28 . '</span>
    </div>
    <!-- 地址 -->
    <div class="sh-homecontent-left-time-dw">';
    $tmp30=$tmp29 . $ptpdw;
    $tmp31=$tmp30 . '</div>
    </div>
    <!-- 右边内容框架 -->
    <div class="sh-homecontent-right-wk">
    <!-- 右边内容主体 -->
    <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
    $tmp32=$tmp31 . $cid;
    $tmp33=$tmp32 . '\';">
    <!-- 图片 -->
    <div class="homecontent-right-tw">
    <!-- 图片 -->
    <div class="homecontent-right-tw-img">
    <div class="homecontent-right-tw-img-wk" style="grid-row: 1 / 3;"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp5=$tmp33 . $imgar[0];
    $tmp34=$tmp5 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp35=$tmp34 . $imgar[1];
    $tmp36=$tmp35 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp37=$tmp36 . $imgar[2];
    $tmp38=$tmp37 . '" alt=""></div>
    ';
    $tmp39=$tmp38 . $wzsdbs;
    $tmp6=$tmp39 . '
    </div>
    </div>
    <!-- 文字内容 -->
    <div class="homecontent-right-nr">
    <div class="homecontent-right-nr-text">';
    $tmp7=$tmp6 . $ptptext;
    $tmp8=$tmp7 . '</div>
    <p class="homecontent-right-nr-tus">共';
    $tmp9=$tmp8 . $coun;
    $tmp10=$tmp9 . '张</p>
    </div>
    </div>
    </div>
    </div>';
    $wzbank=$tmp10;
goto L2xx7c;
L2xldMhx6x:
    $tmp2=$coun==4;
    $tmp4=(bool)$tmp2;
    $tmp25=!$tmp4;
    if($tmp25){
        $tmp3=$coun>=4;
        $tmp4=(bool)$tmp3;
    }
if($tmp4)goto L2xeWjgx71;
goto L2xx7c;
goto L2xx7c;
goto L2xx7c;
goto L2xx7c;
goto L2xx7c;
L2xeWjgx71:
    $tmp2='<div class="sh-homecontent-lie">
    <!-- 左边 -->
    <div class="sh-homecontent-left">
    <!-- 日期 -->
    <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
    $tmp3=$tmp2 . '" style="';
    $tmp4=$tmp3 . $shougbsx;
    $tmp25=$tmp4 . '">
    <span class="homecontent-left-time-h">';
    $tmp26=$tmp25 . $day;
    $tmp27=$tmp26 . '</span>
    <span class="homecontent-left-time-y">';
    $tmp28=$tmp27 . $month;
    $tmp29=$tmp28 . '</span>
    </div>
    <!-- 地址 -->
    <div class="sh-homecontent-left-time-dw">';
    $tmp30=$tmp29 . $ptpdw;
    $tmp31=$tmp30 . '</div>
    </div>
    <!-- 右边内容框架 -->
    <div class="sh-homecontent-right-wk">
    <!-- 右边内容主体 -->
    <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
    $tmp32=$tmp31 . $cid;
    $tmp33=$tmp32 . '\';">
    <!-- 图片 -->
    <div class="homecontent-right-tw">
    <!-- 图片 -->
    <div class="homecontent-right-tw-img">
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp5=$tmp33 . $imgar[0];
    $tmp34=$tmp5 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp35=$tmp34 . $imgar[1];
    $tmp36=$tmp35 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp37=$tmp36 . $imgar[2];
    $tmp38=$tmp37 . '" alt=""></div>
    <div class="homecontent-right-tw-img-wk"><img src="./assets/img/thumbnail.svg" data-src="';
    $tmp39=$tmp38 . $imgar[3];
    $tmp6=$tmp39 . '" alt=""></div>
    ';
    $tmp7=$tmp6 . $wzsdbs;
    $tmp8=$tmp7 . '
    </div>
    </div>
    <!-- 文字内容 -->
    <div class="homecontent-right-nr">
    <div class="homecontent-right-nr-text">';
    $tmp9=$tmp8 . $ptptext;
    $tmp10=$tmp9 . '</div>
    <p class="homecontent-right-nr-tus">共';
    $tmp11=$tmp10 . $coun;
    $tmp12=$tmp11 . '张</p>
    </div>
    </div>
    </div>
    </div>';
    $wzbank=$tmp12;
goto L2xx7c;
L2xldMhx7i:
    $tmp2=150;
    $tmp3=66;
    $tmp4=$num2==66;
    if($tmp4){
        $tmp2=$videoauplay==1;
        if($tmp2){
            $videobf='autoplay';
            $videobfplas='';
        }else{
            $videobf='';
            $tmp2='<i class="iconfont icon-sa4f56" id="sh-content-video-videobfb-' . $cid;
            $tmp3=$tmp2 . '" style="width: fit-content;height: fit-content;grid-column: 1;grid-row: 1;z-index: 5;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);font-size: 30px;color: #ffffff;display: flex;cursor: pointer;padding: 15px;pointer-events: none;"></i>';
            $videobfplas=$tmp3;
        }
        $tmp2='<div class="sh-homecontent-lie">
        <!-- 左边 -->
        <div class="sh-homecontent-left">
        <!-- 日期 -->
        <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
        $tmp3=$tmp2 . '" style="';
        $tmp4=$tmp3 . $shougbsx;
        $tmp25=$tmp4 . '">
        <span class="homecontent-left-time-h">';
        $tmp26=$tmp25 . $day;
        $tmp27=$tmp26 . '</span>
        <span class="homecontent-left-time-y">';
        $tmp28=$tmp27 . $month;
        $tmp29=$tmp28 . '</span>
        </div>
        <!-- 地址 -->
        <div class="sh-homecontent-left-time-dw">';
        $tmp30=$tmp29 . $ptpdw;
        $tmp31=$tmp30 . '</div>
        </div>
        <!-- 右边内容框架 -->
        <div class="sh-homecontent-right-wk">
        <!-- 右边内容主体 -->
        <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
        $tmp32=$tmp31 . $cid;
        $tmp33=$tmp32 . '\';">
        <!-- 视频 -->
        <div class="homecontent-right-tw">
        <!-- 视频 -->
        <div class="homecontent-right-tw-video">
        <video class="homecontent-right-tw-videoau" poster="';
        $tmp5=$tmp33 . $ptpvideofm;
        $tmp34=$tmp5 . '" src="';
        $tmp35=$tmp34 . $ptpvideo;
        $tmp36=$tmp35 . '" playsinline="" webkit-playsinline="" preload="metadata" ';
        $tmp37=$tmp36 . $videobf;
        $tmp38=$tmp37 . ' muted="" loop=""></video>
        ';
        $tmp39=$tmp38 . $videobfplas;
        $tmp6=$tmp39 . '
        <span class="sh-video-span" style="left: 4px;bottom: 4px;">MP4</span>
        ';
        $tmp7=$tmp6 . $wzsdbs;
        $tmp8=$tmp7 . '
        </div>
        </div>
        <!-- 文字内容 -->
        <div class="homecontent-right-nr">
        <div class="homecontent-right-nr-text">';
        $tmp9=$tmp8 . $ptptext;
        $tmp10=$tmp9 . '</div>
        </div>
        </div>
        </div>
        </div>';
        $wzbank=$tmp10;
    }else{
        $tmp2=180;
        $tmp3=380;
        $tmp4=$num2==380;
        if($tmp4){
            $tmp2='<div class="sh-homecontent-lie">
            <!-- 左边 -->
            <div class="sh-homecontent-left">
            <!-- 日期 -->
            <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
            $tmp3=180;
            $tmp4=180 . $shougbsx;
            $tmp25=$tmp4 . '">
            <span class="homecontent-left-time-h">';
            $tmp26=$tmp25 . $day;
            $tmp27=$tmp26 . '</span>
            <span class="homecontent-left-time-y">';
            $tmp28=$tmp27 . $month;
            $tmp29=$tmp28 . '</span>
            </div>
            <!-- 地址 -->
            <div class="sh-homecontent-left-time-dw">';
            $tmp30=$tmp29 . $ptpdw;
            $tmp31=$tmp30 . '</div>
            </div>
            <div class="sh-homecontent-right-wk">
            <!-- 右边内容主体 -->
            <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
            $tmp32=$tmp31 . $cid;
            $tmp33=$tmp32 . '\';">
            <!-- 仅文字 -->
            <!-- 文字内容 -->
            <div class="homecontent-right-nr" style="min-height: 10px;background: var(--fgxys);position:relative;">
            <div class="homecontent-right-nr-text homecontent-right-nr-textjw" style="margin: 10px;">';
            $tmp5=$tmp33 . $ptptext;
            $tmp34=$tmp5 . '</div>
            ';
            $tmp35=$tmp34 . $wzsdbs;
            $tmp36=$tmp35 . '
            </div>
            </div>
            </div>
            </div>';
            $wzbank=$tmp36;
        }else{
            switch($num2){
                case 114:{
                $tmp2='<div class="sh-homecontent-lie">
                <!-- 左边 -->
                <div class="sh-homecontent-left">
                <!-- 日期 -->
                <div class="sh-homecontent-left-time" lang="year-' . $givenDates;
                $tmp3=44;
                $tmp4=44 . $shougbsx;
                $tmp25=$tmp4 . '">
                <span class="homecontent-left-time-h">';
                $tmp26=$tmp25 . $day;
                $tmp27=$tmp26 . '</span>
                <span class="homecontent-left-time-y">';
                $tmp28=$tmp27 . $month;
                $tmp29=$tmp28 . '</span>
                </div>
                <!-- 地址 -->
                <div class="sh-homecontent-left-time-dw">';
                $tmp30=$tmp29 . $ptpdw;
                $tmp31=$tmp30 . '</div>
                </div>
                <div class="sh-homecontent-right-wk">
                <!-- 右边内容主体 -->
                <div class="sh-homecontent-right-lie" onclick="window.location.href = \'./view.php?cid=';
                $tmp32=$tmp31 . $cid;
                $tmp33=$tmp32 . '\';">
                <!-- 仅文字 -->
                <!-- 文字内容 -->
                <div class="homecontent-right-nr" style="min-height: 10px;background: var(--fgxys);position:relative;">
                <div class="homecontent-right-nr-text homecontent-right-nr-textjw" style="margin: 10px;">';
                $tmp5=$tmp33 . $ptptext;
                $tmp34=$tmp5 . '</div>
                ';
                $tmp35=$tmp34 . $wzsdbs;
                $tmp36=$tmp35 . '
                </div>
                </div>
                </div>
                </div>';
                $wzbank=$tmp36;
                    break;
                }
            }
L2xx7c:
        }
    }
    echo $wzbank;
    $tmp24=$tmp24+1;
}
L2xxc8:
L2xx81:
echo "</div>";
echo "
";
echo "
";
echo "
";
echo "
<!--个人主页封面图片上传器-->";
echo "
<!--?php include(\"./site/resces.php\");?-->";
echo "
<div class=\"sh-resces-gl\" id=\"sh-resces-gl\" onclick=\"recgb()\" style=\"display: none;\">";
echo "
<form action=\"../api/uploadcover.php\" method=\"post\" enctype=\"multipart/form-data\" onsubmit=\"return dosubmit()\" id=\"myFormbg\" class=\"sh-resces-gl-k\" onclick=\"evjz()\">";
echo "
<div class=\"sh-resces-gl-s\">";
echo "
<span>修改相册封面</span>";
echo "
</div>";
echo "
<div class=\"sh-resces-gl-z\">";
echo "
<div class=\"sh-resces-gl-z-formup\">";
echo "
<img src=\"./assets/img/thumbnail.svg\" data-src=\"\" id=\"sh-resces-gl-z-formup-img\" alt=\"\">";
echo "
<span id=\"sh-resces-gl-z-upload-btn\">+</span>";
echo "
<input type=\"file\" name=\"file\" accept=\"image/*\" id=\"files\" required>";
echo "
</div>";
echo "
</div>";
echo "
<div class=\"sh-resces-gl-x\" id=\"sctfm\">";
echo "
<input type=\"submit\" name=\"submit\" value=\"确认修改\" onclick=\"sctfm()\">";
echo "
</div>";
echo "
</form>";
echo "
</div>";
echo "
";
echo "
";
echo "
<div class=\"footer\">";
echo "
<div class=\"footer-text\" id=\"footer-text-zt\" onclick=\"hqgd()\">加载更多..</div>";
echo "
<p style=\"display:none\" id=\"footer-text-hqgd\">";
echo $wzsl;
echo "</p>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<!--右下角悬浮菜单-->";
echo "
<div class=\"sh-menu\" id=\"sh-menu\">";
echo "
";
$darktheme=$_COOKIE["dark_theme"];
$num3=8003;
$tmp2=$darktheme=="dark-theme";
if($tmp2){
    $num3=380;
}else{
    $num3=380;
    $num3=1820;
}
switch($num3){
    case 1100:{
    echo '<div class="sh-menu-k" id="day" lang="1"><i class="iconfont icon-ai250" id="day-i"></i></div>';
        break;
    }
    case 380:{
        echo '<div class="sh-menu-k" id="day" lang="0"><i class="iconfont icon-yueliang" id="day-i"></i></div>';
        break;
    }
}
echo "    <div class=\"sh-menu-k\" id=\"scrtop\" onclick=\"scrollToTop()\"><i class=\"iconfont icon-weibiaoti-x-copy\"></i></div>";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
$num4=8018;
$tmp2=$musplay==0;
if($tmp2){
    $num4=380;
}else{
    $tmp2=$musplay==1;
    if($tmp2){
        $num4=121;
    }
}
switch($num4){
    case 380:{
    $tmp2=include './site/musicbk.php';
        break;
    }
    case 121:{
        $tmp2=include './site/musicbkcla.php';
        break;
    }
}
echo "";
echo "
";
echo "
";
echo auth_ts;
echo "<div class=\"sh-copyright\">";
echo "
<span class=\"sh-copyright-banquan\" id=\"sh-copyright-banquan\">";
echo $copyright;
echo "</span>&nbsp;";
echo "
";
if($beian!=""){
    $fileExists=html_entity_decode($beian);
    $tmp2='<span class="sh-copyright-banquan">' . $fileExists;
    $tmp3=$tmp2 . '</span>';
    echo $tmp3;
}
echo "</div>";
echo "
";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<script type=\"text/javascript\" src=\"./assets/js/home.js\"></script>";
echo "
<script type=\"text/javascript\" src=\"./assets/js/jquery.min.js\"></script>";
echo "
<script type=\"text/javascript\" src=\"./assets/mesg/dist/js/sh-noytf.js\"></script>";
echo "
<script type=\"text/javascript\">";
echo "
//删除重复年";
echo "
var timedElements = document.getElementsByClassName('sh-homecontent-timed');";
echo "
var timedElementsArray = Array.from(timedElements);";
echo "
";
echo "
timedElementsArray.forEach((element, index) => {";
echo "
if (index > 0 && element.innerHTML === timedElementsArray[index - 1].innerHTML) {";
echo "
element.remove();";
echo "
}";
echo "
});";
echo "
//隐藏重复日期";
echo "
var elements = document.getElementsByClassName('sh-homecontent-left-time');";
echo "
var langValues = [];";
echo "
var duplicateIndexes = [];";
echo "
for (var i = 0; i < elements.length; i++) {";
echo "
var lang = elements[i].lang;";
echo "
";
echo "
if (langValues.includes(lang)) {";
echo "
duplicateIndexes.push(i);";
echo "
} else {";
echo "
langValues.push(lang);";
echo "
}";
echo "
}";
echo "
for (var j = 0; j < elements.length; j++) {";
echo "
if (duplicateIndexes.includes(j)) {";
echo "
elements[j].style.display = 'none';";
echo "
elements[j].lang = '';";
echo "
}";
echo "
}";
echo "
";
echo "
//设置每个不同月日的顶部间距";
echo "
// 获取所有class为sh-homecontent-left-time的元素";
echo "
var elements = document.querySelectorAll('.sh-homecontent-left-time');";
echo "
// 遍历元素";
echo "
for (var i = 0; i < elements.length; i++) {";
echo "
// 判断元素是否有display: none;属性";
echo "
if (window.getComputedStyle(elements[i]).display !== 'none') {";
echo "
// 给父元素的父元素添加属性 margin-top: 20px;";
echo "
elements[i].parentNode.parentNode.style.marginTop = '25px';";
echo "
}";
echo "
}";
echo "
";
echo "
//恢复时间颜色";
echo "
document.querySelectorAll(\".homecontent-left-time-h, .homecontent-left-time-y\").forEach(function(element) {";
echo "
element.style.color = \"var(--textqh)\";";
echo "
});";
echo "
</script>";
echo "
";
$tmp2='<script type="text/javascript">' . $filtercujs;
$tmp3=$tmp2 . '</script>';
echo $tmp3;
echo "</body>";
echo "
</html>";