<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val62[]=$val;
    $arr=$val62;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp2=include '../config.php';
$tmp2=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp2;
if($conn->connect_error){
    $val["code"]="201";
    $val["msg"]="连接数据库失败";
    $val62[]=$val;
    $arr=$val62;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$escaped=htmlspecialchars($user_zh);
$pos=addslashes($escaped);
$user_zhsg=$pos;
$tmp2="select * from user where username='" . $user_zhsg;
$sqls=$tmp2 . "'";
$row=mysqli_query($conn, $sqls);
$data_results=$row;
$row=mysqli_fetch_array($data_results);
$data2s_row=$row;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
$filtertext="";
$sql="SELECT text FROM configx WHERE title = 'filtertext'";
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0){
    $result=$result->fetch_assoc();
    $row=$result;
    $filtertext=$row['text'];
}
$tmp2=$user_zh=="";
$tmp3=(bool)$tmp2;
$tmp4=!$tmp3;
if($tmp4){
    $tmp5=$user_passid=="";
    $tmp3=(bool)$tmp5;
}
if($tmp3)goto L2xeWjgx13;
goto L2xldMhx13;
L2xeWjgx13:
$isArray=is_array($_POST);
if($isArray){
    $vis_name=&$_POST['vis_name'];
}else{
    $vis_name=$_POST['vis_name'];
}
$escaped=htmlspecialchars($vis_name);
unset($vis_name);
$escaped2=addslashes($escaped);
$vis_name=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $vis_name=&$_POST['vis_email'];
}else{
    $vis_name=$_POST['vis_email'];
}
$escaped=htmlspecialchars($vis_name);
unset($vis_name);
$escaped2=addslashes($escaped);
$vis_email=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $vis_name=&$_POST['vis_url'];
}else{
    $vis_name=$_POST['vis_url'];
}
$escaped=htmlspecialchars($vis_name);
unset($vis_name);
$escaped2=addslashes($escaped);
$vis_url=$escaped2;
$row=strpos($vis_url, 'http://');
$tmp2=$row!==0;
$tmp3=(bool)$tmp2;
if($tmp3){
    $pos=strpos($vis_url, 'https://');
    $tmp5=$pos!==0;
    $tmp3=(bool)$tmp5;
}
if($tmp3){
    $vis_url='http://' . $vis_url;
}
$tmp2=$vis_name!="";
$tmp3=(bool)$tmp2;
if($tmp3){
    $tmp5=$vis_email!="";
    $tmp3=(bool)$tmp5;
}
if($tmp3)goto L2xeWjgxu;
goto L2xldMhxu;
goto L2xldMhxu;
L2xeWjgxu:
$row=filter_var($vis_email, FILTER_VALIDATE_EMAIL);
if($row)goto L2xxv;
goto L2xldMhxw;
L2xldMhxw:
$val["code"]="201";
$val["msg"]="邮箱格式不正确!";
$val62[]=$val;
$arr=$val62;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
L2xxv:
$escaped=strpos($vis_email, '@');
$pos=substr($vis_email, $escaped);
$yktxyx=$pos;
$row=is_numeric($yktxyx);
$tmp5=(bool)$row;
if($tmp5){
    $pos=iconv_strlen($yktxyx, "UTF-8");
    $tmp2=$pos>=5;
    $tmp5=(bool)$tmp2;
}
if($tmp5){
    $tmp2="http://q1.qlogo.cn/g?b=qq&nk=" . $yktxyx;
    $vis_naimg=$tmp2 . "&s=100";
}else{
    $vis_naimg="./assets/img/tx.png";
}
$tmp2='vis#-[' . $vis_email;
$user_zh=$tmp2 . ']-#vis';
$user_name=$vis_name;
$user_img=$vis_naimg;
$user_url=$vis_url;
$user_passid="vis_youke";
goto L2xx12;
L2xldMhxu:
$val["code"]="201";
$val["msg"]="请先登录!";
$val62[]=$val;
$arr=$val62;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
L2xldMhx13:
L2xx12:
$num4=8017;
$isArray=is_array($_POST);
if($isArray){
    $num4=8;
}else{
    $num4=324;
}
switch($num4){
    case 324:{
    $vis_name=$_POST['tieid'];
        break;
    }
    case 8:{
        $vis_name=&$_POST['tieid'];
        break;
    }
}
$escaped=htmlspecialchars($vis_name);
unset($vis_name);
$escaped2=addslashes($escaped);
$tieid=$escaped2;
$num5=8018;
$isArray=is_array($_POST);
if($isArray){
    $num5=36;
}else{
    $num5=4;
}
switch($num5){
    case 4:{
    $vis_name=$_POST['tiehf'];
        break;
    }
    case 36:{
        $vis_name=&$_POST['tiehf'];
        break;
    }
}
$escaped=htmlspecialchars($vis_name);
unset($vis_name);
$escaped2=addslashes($escaped);
$tiehf=$escaped2;
$num6=8008;
$isArray=is_array($_POST);
if($isArray){
    $num6=4;
}else{
    $num6=40;
}
switch($num6){
    case 40:{
    $vis_name=$_POST['tieea'];
        break;
    }
    case 4:{
        $vis_name=&$_POST['tieea'];
        break;
    }
}
$escaped=htmlspecialchars($vis_name);
unset($vis_name);
$escaped2=addslashes($escaped);
$tieea=$escaped2;
$num7=8004;
$isArray=is_array($_POST);
if($isArray){
    $num7=80;
}else{
    $num7=8;
}
switch($num7){
    case 80:{
    $vis_name=&$_POST['pltext'];
        break;
    }
    case 8:{
        $vis_name=$_POST['pltext'];
        break;
    }
}
$escaped=htmlspecialchars($vis_name);
unset($vis_name);
$escaped2=addslashes($escaped);
$pltexty=$escaped2;
if($tieid==""){
    $val["code"]="201";
    $val["msg"]="未获取到文章id";
    $val62[]=$val;
    $arr=$val62;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
if($tiehf==""){
    $val["code"]="201";
    $val["msg"]="未获取到被评论人昵称";
    $val62[]=$val;
    $arr=$val62;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
if($tieea==""){
    $val["code"]="201";
    $val["msg"]="未获取到被评论人账号";
    $val62[]=$val;
    $arr=$val62;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
if($pltexty==""){
    $val["code"]="201";
    $val["msg"]="未获取到评论内容";
    $val62[]=$val;
    $arr=$val62;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$row=iconv_strlen($pltexty, "UTF-8");
$tmp2=$row>500;
if($tmp2){
    $val["code"]="201";
    $val["msg"]="字数超过最大限制!";
    $val62[]=$val;
    $arr=$val62;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$row=containsTenOrMoreRepeatedSubstrings($pltexty);
if($row){
    $val["code"]="201";
    $val["msg"]="重复内容过多";
    $val62[]=$val;
    $arr=$val62;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
if($filtertext!=""){
    $row=json_decode($filtertext, true);
    $arrayData=$row;
    $row=str_replace($arrayData, "*", $pltexty);
    $pltexty=$row;
}
$emtext=$pltexty;
$row=parseUrls($pltexty);
$pltexty=$row;
$val["title"]="::(呵呵)";
$val["img"]="./assets/owo/paopao/E591B5E591B5_2x.png";
$val2["title"]="::(哈哈)";
$val2["img"]="./assets/owo/paopao/E59388E59388_2x.png";
$val3["title"]="::(吐舌)";
$val3["img"]="./assets/owo/paopao/E59090E8888C_2x.png";
$val4["title"]="::(太开心)";
$val4["img"]="./assets/owo/paopao/E5A4AAE5BC80E5BF83_2x.png";
$val5["title"]="::(笑眼)";
$val5["img"]="./assets/owo/paopao/E7AC91E79CBC_2x.png";
$val6["title"]="::(花心)";
$val6["img"]="./assets/owo/paopao/E88AB1E5BF83_2x.png";
$val7["title"]="::(小乖)";
$val7["img"]="./assets/owo/paopao/E5B08FE4B996_2x.png";
$val8["title"]="::(乖)";
$val8["img"]="./assets/owo/paopao/E4B996_2x.png";
$val9["title"]="::(捂嘴笑)";
$val9["img"]="./assets/owo/paopao/E68D82E598B4E7AC91_2x.png";
$val10["title"]="::(滑稽)";
$val10["img"]="./assets/owo/paopao/E6BB91E7A8BD_2x.png";
$val11["title"]="::(你懂的)";
$val11["img"]="./assets/owo/paopao/E4BDA0E68782E79A84_2x.png";
$val12["title"]="::(不高兴)";
$val12["img"]="./assets/owo/paopao/E4B88DE9AB98E585B4_2x.png";
$val13["title"]="::(怒)";
$val13["img"]="./assets/owo/paopao/E68092_2x.png";
$val14["title"]="::(汗)";
$val14["img"]="./assets/owo/paopao/E6B197_2x.png";
$val15["title"]="::(黑线)";
$val15["img"]="./assets/owo/paopao/E9BB91E7BABF_2x.png";
$val16["title"]="::(泪)";
$val16["img"]="./assets/owo/paopao/E6B3AA_2x.png";
$val17["title"]="::(真棒)";
$val17["img"]="./assets/owo/paopao/E79C9FE6A392_2x.png";
$val18["title"]="::(喷)";
$val18["img"]="./assets/owo/paopao/E596B7_2x.png";
$val19["title"]="::(惊哭)";
$val19["img"]="./assets/owo/paopao/E6838AE593AD_2x.png";
$val20["title"]="::(阴险)";
$val20["img"]="./assets/owo/paopao/E998B4E999A9_2x.png";
$val21["title"]="::(鄙视)";
$val21["img"]="./assets/owo/paopao/E98499E8A786_2x.png";
$val22["title"]="::(酷)";
$val22["img"]="./assets/owo/paopao/E985B7_2x.png";
$val23["title"]="::(啊)";
$val23["img"]="./assets/owo/paopao/E5958A_2x.png";
$val24["title"]="::(狂汗)";
$val24["img"]="./assets/owo/paopao/E78B82E6B197_2x.png";
$val25["title"]="::(what)";
$val25["img"]="./assets/owo/paopao/what_2x.png";
$val26["title"]="::(疑问)";
$val26["img"]="./assets/owo/paopao/E79691E997AE_2x.png";
$val27["title"]="::(酸爽)";
$val27["img"]="./assets/owo/paopao/E985B8E788BD_2x.png";
$val28["title"]="::(呀咩蹀)";
$val28["img"]="./assets/owo/paopao/E59180E592A9E788B9_2x.png";
$val29["title"]="::(委屈)";
$val29["img"]="./assets/owo/paopao/E5A794E5B188_2x.png";
$val30["title"]="::(惊讶)";
$val30["img"]="./assets/owo/paopao/E6838AE8AEB6_2x.png";
$val31["title"]="::(睡觉)";
$val31["img"]="./assets/owo/paopao/E79DA1E8A789_2x.png";
$val32["title"]="::(笑尿)";
$val32["img"]="./assets/owo/paopao/E7AC91E5B0BF_2x.png";
$val33["title"]="::(挖鼻)";
$val33["img"]="./assets/owo/paopao/E68C96E9BCBB_2x.png";
$val34["title"]="::(吐)";
$val34["img"]="./assets/owo/paopao/E59090_2x.png";
$val35["title"]="::(犀利)";
$val35["img"]="./assets/owo/paopao/E78A80E588A9_2x.png";
$val36["title"]="::(小红脸)";
$val36["img"]="./assets/owo/paopao/E5B08FE7BAA2E884B8_2x.png";
$val37["title"]="::(懒得理)";
$val37["img"]="./assets/owo/paopao/E68792E5BE97E79086_2x.png";
$val38["title"]="::(勉强)";
$val38["img"]="./assets/owo/paopao/E58B89E5BCBA_2x.png";
$val39["title"]="::(爱心)";
$val39["img"]="./assets/owo/paopao/E788B1E5BF83_2x.png";
$val40["title"]="::(心碎)";
$val40["img"]="./assets/owo/paopao/E5BF83E7A28E_2x.png";
$val41["title"]="::(玫瑰)";
$val41["img"]="./assets/owo/paopao/E78EABE791B0_2x.png";
$val42["title"]="::(礼物)";
$val42["img"]="./assets/owo/paopao/E7A4BCE789A9_2x.png";
$val43["title"]="::(彩虹)";
$val43["img"]="./assets/owo/paopao/E5BDA9E899B9_2x.png";
$val44["title"]="::(太阳)";
$val44["img"]="./assets/owo/paopao/E5A4AAE998B3_2x.png";
$val45["title"]="::(星星月亮)";
$val45["img"]="./assets/owo/paopao/E6989FE6989FE69C88E4BAAE_2x.png";
$val46["title"]="::(钱币)";
$val46["img"]="./assets/owo/paopao/E992B1E5B881_2x.png";
$val47["title"]="::(茶杯)";
$val47["img"]="./assets/owo/paopao/E88CB6E69DAF_2x.png";
$val48["title"]="::(蛋糕)";
$val48["img"]="./assets/owo/paopao/E89B8BE7B395_2x.png";
$val49["title"]="::(大拇指)";
$val49["img"]="./assets/owo/paopao/E5A4A7E68B87E68C87_2x.png";
$val50["title"]="::(胜利)";
$val50["img"]="./assets/owo/paopao/E8839CE588A9_2x.png";
$val51["title"]="::(haha)";
$val51["img"]="./assets/owo/paopao/haha_2x.png";
$val52["title"]="::(OK)";
$val52["img"]="./assets/owo/paopao/OK_2x.png";
$val53["title"]="::(沙发)";
$val53["img"]="./assets/owo/paopao/E6B299E58F91_2x.png";
$val54["title"]="::手纸";
$val54["img"]="./assets/owo/paopao/E6898BE7BAB8_2x.png";
$val55["title"]="::(香蕉)";
$val55["img"]="./assets/owo/paopao/E9A699E89589_2x.png";
$val56["title"]="::(便便)";
$val56["img"]="./assets/owo/paopao/E4BEBFE4BEBF_2x.png";
$val57["title"]="::(药丸)";
$val57["img"]="./assets/owo/paopao/E88DAFE4B8B8_2x.png";
$val58["title"]="::(红领巾)";
$val58["img"]="./assets/owo/paopao/E7BAA2E9A286E5B7BE_2x.png";
$val59["title"]="::(蜡烛)";
$val59["img"]="./assets/owo/paopao/E89CA1E7839B_2x.png";
$val60["title"]="::(音乐)";
$val60["img"]="./assets/owo/paopao/E99FB3E4B990_2x.png";
$val61["title"]="::(灯泡)";
$val61["img"]="./assets/owo/paopao/E781AFE6B3A1_2x.png";
$val63[]=$val;
$val63[]=$val2;
$val63[]=$val3;
$val63[]=$val4;
$val63[]=$val5;
$val63[]=$val6;
$val63[]=$val7;
$val63[]=$val8;
$val63[]=$val9;
$val63[]=$val10;
$val63[]=$val11;
$val63[]=$val12;
$val63[]=$val13;
$val63[]=$val14;
$val63[]=$val15;
$val63[]=$val16;
$val63[]=$val17;
$val63[]=$val18;
$val63[]=$val19;
$val63[]=$val20;
$val63[]=$val21;
$val63[]=$val22;
$val63[]=$val23;
$val63[]=$val24;
$val63[]=$val25;
$val63[]=$val26;
$val63[]=$val27;
$val63[]=$val28;
$val63[]=$val29;
$val63[]=$val30;
$val63[]=$val31;
$val63[]=$val32;
$val63[]=$val33;
$val63[]=$val34;
$val63[]=$val35;
$val63[]=$val36;
$val63[]=$val37;
$val63[]=$val38;
$val63[]=$val39;
$val63[]=$val40;
$val63[]=$val41;
$val63[]=$val42;
$val63[]=$val43;
$val63[]=$val44;
$val63[]=$val45;
$val63[]=$val46;
$val63[]=$val47;
$val63[]=$val48;
$val63[]=$val49;
$val63[]=$val50;
$val63[]=$val51;
$val63[]=$val52;
$val63[]=$val53;
$val63[]=$val54;
$val63[]=$val55;
$val63[]=$val56;
$val63[]=$val57;
$val63[]=$val58;
$val63[]=$val59;
$val63[]=$val60;
$val63[]=$val61;
$arr=$val63;
$i=0;
while(true){
    $row=count($arr);
    $tmp2=$i<$row;
    if(!($tmp2))break;
    $danm=$arr[$i]["title"];
    $dang=$arr[$i]["img"];
    $tmp2='<span class="sh-nr-bq-img-wk"><img src="./assets/img/thumbnail.svg" data-src="' . $dang;
    $tmp5=$tmp2 . '" class="sh-nr-bq-img" alt="';
    $tmp3=$tmp5 . $danm;
    $aeimg=$tmp3 . '"></span>';
    $row=str_ireplace($danm, $aeimg, $pltexty);
    $pltexty=$row;
    $obj=$i;
    $obj2=$i+1;
    $str3=$obj2;
    $i=$str3;
}
L2xx37:
$pltext=$pltexty;
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($str3))break;
    $wzname=$row["name"];
    $emydz=$row["emydz"];
    $emssl=$row["emssl"];
    $emduk=$row["emduk"];
    $emkey=$row["emkey"];
    $emzh=$row["emzh"];
    $emfs=$row["emfs"];
    $emfszm=$row["emfszm"];
    $comaud=$row["comaud"];
    $glyusername=$row["username"];
}
L2xx3d:
$str4="select * from user where username='" . $user_zh;
$str5=$str4 . "'";
$row=mysqli_query($conn, $str5);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data2_row=$row;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
$ban=$data2_row["ban"];
$bantime=$data2_row["bantime"];
if($user_passid!="vis_youke")goto L2xeWjgx3q;
goto L2xldMhx3q;
L2xeWjgx3q:
$tmp2=$user_passid!=$passid;
if($tmp2){
    $escaped=time();
    $str4=$escaped+ -1;
    $pos=setcookie("username", "", $str4, "/");
    $escaped=time();
    $str4=$escaped+ -1;
    $pos=setcookie("passid", "", $str4, "/");
    $val["code"]="201";
    $val["msg"]="账号信息异常,请重新登录!";
    $val62[]=$val;
    $arr=$val62;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$tmp2=$ban!="0";
$tmp3=(bool)$tmp2;
if($tmp3){
    $tmp5=$bantime!="false";
    $tmp3=(bool)$tmp5;
}
if($tmp3)goto L2xeWjgx3m;
goto L2xx3p;
goto L2xx3p;
L2xeWjgx3m:
$tmp2=$bantime==="true";
if($tmp2)goto L2xeWjgx3o;
goto L2xldMhx3o;
goto L2xldMhx3o;
L2xeWjgx3o:
$escaped=time();
$str4=$escaped+ -1;
$pos=setcookie("username", "", $str4, "/");
$escaped=time();
$str4=$escaped+ -1;
$pos=setcookie("passid", "", $str4, "/");
$val["code"]="201";
$val["msg"]="该账号涉嫌违规,已被永久封禁!";
$val62[]=$val;
$arr=$val62;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
goto L2xx3p;
L2xldMhx3o:
$escaped=time();
$str4=$escaped+ -1;
$pos=setcookie("username", "", $str4, "/");
$escaped=time();
$str4=$escaped+ -1;
$pos=setcookie("passid", "", $str4, "/");
$str="你的账号已被封禁！解封时间为:" . $bantime;
$val["code"]="201";
$val["msg"]=$str;
$val62[]=$val;
$arr=$val62;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
L2xldMhx3q:
L2xx3p:
$str4="select * from essay where cid='" . $tieid;
$str5=$str4 . "'";
$row=mysqli_query($conn, $str5);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data_row=$row;
if($data_row["commauth"]!=1){
    $val["code"]="201";
    $val["msg"]="该文章禁止评论!";
    $val62[]=$val;
    $arr=$val62;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$str3="Y";
$Y=$str3;
$str3="m";
$m=$str3;
$str3="d";
$d=$str3;
$str3="H";
$H=$str3;
$str3="i";
$i=$str3;
$str3="s";
$s=$str3;
$str4=$Y . "-";
$str5=$str4 . $m;
$str6=$str5 . "-";
$val64=$str6 . $d;
$str7=$val64 . " ";
$val65=$str7 . $H;
$str8=$val65 . ":";
$val66=$str8 . $i;
$str9=$val66 . ":";
$val67=$str9 . $s;
$row=date($val67);
$sj=$row;
$num8=8019;
if($HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"]){
    $num8=16;
}else{
    if($HTTP_SERVER_VARS["HTTP_CLIENT_IP"]){
        $num8=8;
    }else{
        if($HTTP_SERVER_VARS["REMOTE_ADDR"]){
            $num8=360;
        }else{
            $row=getenv("HTTP_X_FORWARDED_FOR");
            if($row){
                $num8=8;
                $num8=3686;
            }else{
                $row=getenv("HTTP_CLIENT_IP");
                if($row){
                    $num8=16;
                    $num8=4312;
                }else{
                    $row=getenv("REMOTE_ADDR");
                    if($row){
                        $num8=72;
                    }else{
                        $num8=16;
                        $num8=1766;
                    }
                }
            }
        }
    }
}
switch($num8){
    case 891:{
    $ip="Unknown";
        break;
    }
    case 72:{
        $row=getenv("REMOTE_ADDR");
        $ip=$row;
        break;
    }
    case 2164:{
            $row=getenv("HTTP_CLIENT_IP");
            $ip=$row;
        break;
    }
    case 1847:{
                $row=getenv("HTTP_X_FORWARDED_FOR");
                $ip=$row;
        break;
    }
    case 8:{
                    $ip=$HTTP_SERVER_VARS["HTTP_CLIENT_IP"];
        break;
    }
    case 16:{
                        $ip=$HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"];
        break;
    }
    case 360:{
                            $ip=$HTTP_SERVER_VARS["REMOTE_ADDR"];
        break;
    }
}
$filterpljg="";
$sql="SELECT text FROM configx WHERE title = 'pljg'";
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0){
    $result=$result->fetch_assoc();
    $row=$result;
    $isArray=is_array($row);
    if($isArray){
        $val68=&$row['text'];
    }else{
        $val68=$row['text'];
    }
    $row=htmlspecialchars_decode($val68);
    unset($val68);
    $filterpljg=$row;
}
$tmp2="SELECT * FROM comm WHERE ip = '" . $ip;
$sql=$tmp2 . "'";
$row=mysqli_query($conn, $sql);
$result=$row;
$count=0;
L2xx4r:
while(true){
    $row=mysqli_fetch_assoc($result);
    $row=$row;
    if(!($str3))break;
    $cotime=$row['cotime'];
    $row=strtotime($sj);
    $pos=strtotime($cotime);
    $time_diff=$row-$pos;
if($time_diff<=60)goto L2xeWjgx4w;
goto L2xx4r;
goto L2xx4r;
goto L2xx4r;
L2xeWjgx4w:
    $obj2=$count;
    $count=$count+1;
}
L2xx54:
$tmp2=$filterpljg-1;
$tmp5=$count>$tmp2;
if($tmp5)goto L2xeWjgx5f;
goto L2xldMhx5f;
L2xeWjgx5f:
$tmp2=$zjzhq!=$glyusername;
if($tmp2)goto L2xeWjgx5d;
goto L2xx5e;
goto L2xx5e;
L2xeWjgx5d:
$str="每分钟只允许发布" . $filterpljg;
$str2=$str . "条评论";
$val["code"]="201";
$val["msg"]=$str2;
$val62[]=$val;
$arr=$val62;
exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
goto L2xx5e;
L2xldMhx5f:
L2xx5e:
$escaped=microtime(true);
$pos=str_replace('.', '', $escaped);
$microtime=$pos;
$randomDigits='';
L2xx5i:
$i=0;
while(true){
    $tmp2=$i<5;
    if(!($tmp2))break;
    $row=rand();
    $randomDigits=$randomDigits . $row;
    $val69=$randomDigits;
    $obj3=$i;
    $obj4=$i+1;
    $str3=$obj4;
    $i=$str3;
}
L2xx5q:
$row=strlen($randomDigits);
$tmp2=$row<5;
if($tmp2)goto L2xx5i;
goto L2xldMhx5v;
goto L2xx5u;
L2xldMhx5v:
L2xx5u:
$str=$microtime . $randomDigits;
$num9=8007;
$row=strpos($tieea, 'vis#-[');
$tmp2=$row!==false;
$tmp3=(bool)$tmp2;
if($tmp3){
    $pos=strpos($tieea, ']-#vis');
    $tmp5=$pos!==false;
    $tmp3=(bool)$tmp5;
}
if($tmp3){
    $num9=16;
}else{
    $num9=16;
    $num9=1206;
}
$tmp2=247;
$tmp5=611;
$tmp3=$num9==611;
if($tmp3)goto L2xeWjgx66;
goto L2xldMhx66;
L2xeWjgx66:
$tmp2=$tieea==$user_zh;
if($tmp2)goto L2xeWjgx64;
goto L2xx65;
goto L2xx65;
L2xeWjgx64:
$tiehf="false";
$tieea="false";
goto L2xx65;
L2xldMhx66:
$tmp2=171;
$tmp5=16;
$tmp3=$num9==16;
if($tmp3)goto L2xeWjgx69;
goto L2xldMhx69;
L2xeWjgx69:
$tmp2=$tiehf==$vis_name;
if($tmp2)goto L2xeWjgx62;
goto L2xx65;
goto L2xx65;
L2xeWjgx62:
$tiehf="false";
$tieea="false";
goto L2xx65;
L2xldMhx69:
L2xx65:
$str4="select * from essay where cid='" . $tieid;
$str5=$str4 . "'";
$row=mysqli_query($conn, $str5);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data_row=$row;
$wzfszh=$data_row["ptpuser"];
$wzfsptptext=$data_row["ptptext"];
$str4="select * from user where username='" . $wzfszh;
$str5=$str4 . "'";
$row=mysqli_query($conn, $str5);
$data_resultl=$row;
$row=mysqli_fetch_array($data_resultl);
$data_rowl=$row;
$wzfszh=$data_rowl["username"];
$wzfsnc=$data_rowl["name"];
$wzfstx=$data_rowl["img"];
$wzfseam=$data_rowl["esseam"];
$wzfsemail=$data_rowl["email"];
if($tieea!="false"){
    $str4="select * from user where username='" . $tieea;
    $str5=$str4 . "'";
    $row=mysqli_query($conn, $str5);
    $data_result=$row;
    $row=mysqli_fetch_array($data_result);
    $data_row=$row;
    $wzfseam=$data_row["esseam"];
    $wzfsemail=$data_row["email"];
}
$str4="select * from user where username='" . $user_zh;
$str5=$str4 . "'";
$row=mysqli_query($conn, $str5);
$data_result=$row;
$row=mysqli_fetch_array($data_result);
$data_row=$row;
$huifzmail=$data_row["email"];
$huifzdurl=$data_row["url"];
if($huifzmail==""){
    $huifzmail=$vis_email;
}
if($huifzdurl==""){
    $huifzdurl=$vis_url;
}
if($user_name==""){
    $user_name=$vis_name;
}
if($wzfsnc==""){
    $wzfsnc=$tiehf;
}
$num=8011;
$tmp2=$zjzhq==$glyusername;
if($tmp2){
    $num=40;
}else{
    $num=8;
}
$tmp2=77;
$tmp5=40;
$tmp3=$num==40;
if($tmp3)goto L2xeWjgx72;
goto L2xldMhx72;
L2xeWjgx72:
$comaud=0;
$comaudzt=1;
goto L2xx71;
L2xldMhx72:
$tmp2=90;
$tmp5=8;
$tmp3=$num==8;
if($tmp3)goto L2xeWjgx73;
goto L2xldMhx73;
L2xeWjgx73:
$tmp2=$comaud==0;
if($tmp2)goto L2xeWjgx7z;
goto L2xldMhx7z;
goto L2xldMhx7z;
L2xeWjgx7z:
$comaudzt=1;
goto L2xx71;
L2xldMhx7z:
$comaudzt=0;
L2xldMhx73:
L2xx71:
$bdm="comm";
$tmp2="INSERT INTO " . $bdm;
$tmp5=$tmp2 . " (couser,coimg,coname,courl,cotext,bcouser,bconame,comaud,cotime,ip,wzcid,ecid)
VALUES ('";
$tmp3=$tmp5 . $user_zh;
$tmp4=$tmp3 . "','";
$tmp6=$tmp4 . $user_img;
$tmp7=$tmp6 . "','";
$tmp8=$tmp7 . $user_name;
$tmp9=$tmp8 . "','";
$tmp10=$tmp9 . $user_url;
$tmp11=$tmp10 . "','";
$tmp12=$tmp11 . $pltext;
$tmp13=$tmp12 . "','";
$tmp14=$tmp13 . $tieea;
$tmp15=$tmp14 . "','";
$tmp16=$tmp15 . $tiehf;
$tmp17=$tmp16 . "','";
$tmp18=$tmp17 . $comaudzt;
$tmp19=$tmp18 . "','";
$tmp20=$tmp19 . $sj;
$tmp21=$tmp20 . "','";
$tmp22=$tmp21 . $ip;
$tmp23=$tmp22 . "','";
$tmp24=$tmp23 . $tieid;
$tmp25=$tmp24 . "','";
$tmp26=$tmp25 . $str;
$sql=$tmp26 . "')";
$num2=8018;
$result=$conn->query($sql);
$tmp2=$result===TRUE;
if($tmp2){
    $num2=8;
}else{
    $num2=360;
}
$tmp2=54;
$tmp5=360;
$tmp3=$num2==360;
if($tmp3)goto L2xeWjgx7x;
goto L2xldMhx7x;
L2xeWjgx7x:
$val["code"]="201";
$val["msg"]="评论失败!";
$val["uuzh"]=$user_zh;
$val["uunc"]=$user_name;
$val["uutx"]=$user_img;
$val["uuwz"]=$user_url;
$val['buunc']=$tiehf;
$val['buuzh']=$tieea;
$val['pluunr']=$pltext;
$val['plecid']=$str;
$val['tieid']=$tieid;
$val62[]=$val;
$arr=$val62;
$row=json_encode($arr, JSON_UNESCAPED_UNICODE);
echo $row;
goto L2xx7w;
L2xldMhx7x:
$tmp2=105;
$tmp5=8;
$tmp3=$num2==8;
if($tmp3)goto L2xeWjgx7y;
goto L2xldMhx7y;
L2xeWjgx7y:
$tmp2=$comaud==0;
if($tmp2){
    $val["code"]="200";
    $val["msg"]="评论成功!";
    $val["uuzh"]=$user_zh;
    $val["uunc"]=$user_name;
    $val["uutx"]=$user_img;
    $val["uuwz"]=$user_url;
    $val['buunc']=$tiehf;
    $val['buuzh']=$tieea;
    $val['pluunr']=$pltext;
    $val['plecid']=$str;
    $val['tieid']=$tieid;
    $val62[]=$val;
    $arr=$val62;
    $row=json_encode($arr, JSON_UNESCAPED_UNICODE);
    echo $row;
}else{
    $str4="select * from user where username='" . $glyusername;
    $str5=$str4 . "'";
    $row=mysqli_query($conn, $str5);
    $data_resultgl=$row;
    $row=mysqli_fetch_array($data_resultgl);
    $data_rowgl=$row;
    $glydem=$data_rowgl["email"];
    $tmp2=$user_name . "回复了:";
    $btm=$tmp2 . $wzfsnc;
    $mailapfs='nopost';
    $tmp2='[' . $wzname;
    $tmp5=$tmp2 . ']';
    $mailtitle=$tmp5 . '您有新的待审核评论!';
    $tmp2=55021;
    $tmp5=55021 . $_SERVER['REQUEST_SCHEME'];
    $tmp3=$tmp5 . '://';
    $tmp4=$tmp3 . $_SERVER['HTTP_HOST'];
    $tmp6=$tmp4 . '/view.php?cid=';
    $tmp7=$tmp6 . $tieid;
    $tmp8=$tmp7 . '" style="text-decoration: none! important;" target="_blank" id="0">';
    $tmp9=$tmp8 . $wzfsptptext;
    $title=$tmp9 . '</a></p></div><div class="sh-wz-b" style="color: #55798d;">评论内容：</div>';
    $tmp2=$btm . '<br>';
    $text=$tmp2 . $emtext;
    $mailbox=$glydem;
    $tmp2=include "./sendmail.php";
    $val["code"]="201";
    $val["msg"]="评论成功,审核通过后即可显示!";
    $val62[]=$val;
    $arr=$val62;
    $row=json_encode($arr, JSON_UNESCAPED_UNICODE);
    echo $row;
}
$row=strpos($tieea, 'vis#-[');
$tmp2=$row!==false;
$tmp3=(bool)$tmp2;
if($tmp3){
    $pos=strpos($tieea, ']-#vis');
    $tmp5=$pos!==false;
    $tmp3=(bool)$tmp5;
}
if($tmp3)goto L2xx7a;
goto L2xldMhx7d;
L2xldMhx7d:
$tmp2=$tieea=="false";
if($tmp2)goto L2xeWjgx7f;
goto L2xldMhx7f;
goto L2xldMhx7f;
L2xeWjgx7f:
$tmp2=$wzfszh!=$user_zh;
if($tmp2)goto L2xeWjgx7h;
goto L2xx7e;
goto L2xx7e;
L2xeWjgx7h:
$bdm2="message";
$tmp2=$user_name . "回复了:";
$btm=$tmp2 . $wzfsnc;
$tmp2="INSERT INTO " . $bdm2;
$tmp5=$tmp2 . " (fuser,fimg,fname,suser,title,text,ftime,msg)
VALUES ('";
$tmp3=$tmp5 . $user_zh;
$tmp4=$tmp3 . "','";
$tmp6=$tmp4 . $user_img;
$tmp7=$tmp6 . "','";
$tmp8=$tmp7 . $user_name;
$tmp9=$tmp8 . "','";
$tmp10=$tmp9 . $wzfszh;
$tmp11=$tmp10 . "','";
$tmp12=$tmp11 . $btm;
$tmp13=$tmp12 . "','";
$tmp14=$tmp13 . $pltext;
$tmp15=$tmp14 . "','";
$tmp16=$tmp15 . $sj;
$sql2=$tmp16 . "','0')";
$result=$conn->query($sql2);
$tmp2=$result===TRUE;
goto L2xx7e;
L2xldMhx7f:
$bdm2="message";
$tmp2=$user_name . "回复了：";
$btm=$tmp2 . $tiehf;
$tmp2="INSERT INTO " . $bdm2;
$tmp5=$tmp2 . " (fuser,fimg,fname,suser,title,text,ftime,msg)
VALUES ('";
$tmp3=$tmp5 . $user_zh;
$tmp4=$tmp3 . "','";
$tmp6=$tmp4 . $user_img;
$tmp7=$tmp6 . "','";
$tmp8=$tmp7 . $user_name;
$tmp9=$tmp8 . "','";
$tmp10=$tmp9 . $tieea;
$tmp11=$tmp10 . "','";
$tmp12=$tmp11 . $btm;
$tmp13=$tmp12 . "','";
$tmp14=$tmp13 . $pltext;
$tmp15=$tmp14 . "','";
$tmp16=$tmp15 . $sj;
$sql2=$tmp16 . "','0')";
$result=$conn->query($sql2);
$tmp2=$result===TRUE;
if(!($tmp2)){
}
L2xx7e:
L2xx7a:
$row=strpos($tieea, 'vis#-[');
$tmp2=$row!==false;
$tmp3=(bool)$tmp2;
if($tmp3){
    $pos=strpos($tieea, ']-#vis');
    $tmp5=$pos!==false;
    $tmp3=(bool)$tmp5;
}
if($tmp3)goto L2xeWjgx7p;
goto L2xldMhx7p;
goto L2xldMhx7p;
L2xeWjgx7p:
$row=str_replace('vis#-[', '', $tieea);
$ykx=$row;
$row=str_replace(']-#vis', '', $ykx);
$ykx1=$row;
$wzfsemail=$ykx1;
$tmp2=$user_name . "回复了:";
$btm=$tmp2 . $tiehf;
$tmp2=$wzfsemail!=$vis_email;
if($tmp2)goto L2xeWjgx7r;
goto L2xx7w;
goto L2xx7w;
L2xeWjgx7r:
$mailapfs='nopost';
$tmp2='[' . $wzname;
$tmp5=$tmp2 . ']';
$mailtitle=$tmp5 . '新评论！';
$tmp2=55021;
$tmp5=55021 . $_SERVER['REQUEST_SCHEME'];
$tmp3=$tmp5 . '://';
$tmp4=$tmp3 . $_SERVER['HTTP_HOST'];
$tmp6=$tmp4 . '/view.php?cid=';
$tmp7=$tmp6 . $tieid;
$tmp8=$tmp7 . '" style="text-decoration: none! important;" target="_blank" id="0">';
$tmp9=$tmp8 . $wzfsptptext;
$title=$tmp9 . '</a></p></div><div class="sh-wz-b" style="color: #55798d;">评论内容：</div>';
$tmp2=$btm . '<br>';
$text=$tmp2 . $emtext;
$mailbox=$wzfsemail;
$tmp2=include "./sendmail.php";
goto L2xx7w;
L2xldMhx7p:
$tmp2=$wzfsemail!=$zjemail;
if($tmp2)goto L2xeWjgx7t;
goto L2xx7w;
goto L2xx7w;
L2xeWjgx7t:
$tmp2=$wzfseam==1;
if($tmp2)goto L2xeWjgx7v;
goto L2xx7w;
goto L2xx7w;
L2xeWjgx7v:
$mailapfs='nopost';
$tmp2='[' . $wzname;
$tmp5=$tmp2 . ']';
$mailtitle=$tmp5 . '新评论！';
$tmp2=55021;
$tmp5=55021 . $_SERVER['REQUEST_SCHEME'];
$tmp3=$tmp5 . '://';
$tmp4=$tmp3 . $_SERVER['HTTP_HOST'];
$tmp6=$tmp4 . '/view.php?cid=';
$tmp7=$tmp6 . $tieid;
$tmp8=$tmp7 . '" style="text-decoration: none! important;" target="_blank" id="0">';
$tmp9=$tmp8 . $wzfsptptext;
$title=$tmp9 . '</a></p></div><div class="sh-wz-b" style="color: #55798d;">评论内容：</div>';
$tmp2=$btm . '<br>';
$text=$tmp2 . $emtext;
$mailbox=$wzfsemail;
$tmp2=include "./sendmail.php";
goto L2xx7w;
L2xldMhx7y:
L2xx7w:
$result=$conn->close();
unset($val70);function containsTenOrMoreRepeatedSubstrings($str) {
    $pattern=1115;
    $matches=$val71;
    $row=preg_match_all($pattern, $str, $matches);
    if($row){
        return true;
    }
    return false;
}function parseUrls($string) {
    $urls=$val71;
    $pattern='/\b(?:https?:\/\/|www\.)([a-z0-9.-]+\.[a-z]{2,4}(?:\/[^\s]*)?)/i';
    $row=preg_match_all($pattern, $string, $matches);
    unset($tmp);
    foreach($matches[0] as $url){$tmp[]=$url;
}
$tmp27=0;
while(true){
    $row=count($tmp);
    $tmp2=$tmp27<$row;
    if(!($tmp2))break;
    $keys=array_keys($tmp);
    $keys=$keys[$tmp27];
    $url=$tmp[$keys];
    $row=strpos($url, 'http://');
    $tmp2=$row!==0;
    $tmp3=(bool)$tmp2;
    if($tmp3){
        $pos=strpos($url, 'https://');
        $tmp5=$pos!==0;
        $tmp3=(bool)$tmp5;
    }
    if($tmp3){
        $url='http://' . $url;
    }
    $tmp2='<a href="' . $url;
    $tmp5=$tmp2 . '" target="_blank" class="sh-wz-nr-pl-url" onclick="hfljurl()">';
    $tmp3=$tmp5 . $url;
    $tmp4=$tmp3 . '</a>';
    $sentinel=$tmp4;
    $str3=$sentinel;
    $urls[]=$str3;
    $tmp27=$tmp27+1;
}
L2xx9g:
$num3=4102;
$isArray=is_array($matches);
if($isArray){
    $num3=33;
}else{
    $num3=81;
}
switch($num3){
    case 81:{
    $val68=$matches[0];
        break;
    }
    case 33:{
        $val68=&$matches[0];
        break;
    }
}
$row=str_replace($val68, $urls, $string);
unset($val68);
$string=$row;
return $string;
}