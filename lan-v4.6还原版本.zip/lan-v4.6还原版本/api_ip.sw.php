<?php
$env=header("Access-Control-Allow-Origin: *");
$ip=$_GET['ip'];
if($ip!='ok'){
    exit("错误的指令");
}
$num2=8013;
if($HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"]){
    $num2=160;
}else{
    if($HTTP_SERVER_VARS["HTTP_CLIENT_IP"]){
        $num2=144;
    }else{
        if($HTTP_SERVER_VARS["REMOTE_ADDR"]){
            $num2=136;
        }else{
            $env=getenv("HTTP_X_FORWARDED_FOR");
            if($env){
                $num2=204;
            }else{
                $env=getenv("HTTP_CLIENT_IP");
                if($env){
                    $num2=136;
                    $num2=8826;
                }else{
                    $env=getenv("REMOTE_ADDR");
                    if($env){
                        $num2=80;
                    }else{
                        $num2=400;
                    }
                }
            }
        }
    }
}
switch($num2){
    case 400:{
    $ip="Unknown";
        break;
    }
    case 80:{
        $env=getenv("REMOTE_ADDR");
        $ip=$env;
        break;
    }
    case 4481:{
            $env=getenv("HTTP_CLIENT_IP");
            $ip=$env;
        break;
    }
    case 160:{
                $ip=$HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"];
        break;
    }
    case 144:{
                    $ip=$HTTP_SERVER_VARS["HTTP_CLIENT_IP"];
        break;
    }
    case 136:{
                        $ip=$HTTP_SERVER_VARS["REMOTE_ADDR"];
        break;
    }
    case 204:{
                            $env=getenv("HTTP_X_FORWARDED_FOR");
                            $ip=$env;
        break;
    }
}
$val2[]='getMethod_1';
$val2[]='getMethod_2';
$val2[]='getMethod_3';
$val2[]='getMethod_4';
$val2[]='getMethod_5';
$methods=$val2;
$val2[]="北京";
$val2[]="天津";
$val2[]="河北";
$val2[]="山西";
$val2[]="内蒙古";
$val2[]="辽宁";
$val2[]="吉林";
$val2[]="黑龙江";
$val2[]="上海";
$val2[]="江苏";
$val2[]="浙江";
$val2[]="安徽";
$val2[]="福建";
$val2[]="江西";
$val2[]="山东";
$val2[]="河南";
$val2[]="湖北";
$val2[]="湖南";
$val2[]="广东";
$val2[]="广西";
$val2[]="海南";
$val2[]="重庆";
$val2[]="四川";
$val2[]="贵州";
$val2[]="云南";
$val2[]="西藏";
$val2[]="陕西";
$val2[]="甘肃";
$val2[]="青海";
$val2[]="宁夏";
$val2[]="新疆";
$val2[]="香港";
$val2[]="澳门";
$val2[]="台湾";
$provinces=$val2;
$env=getMethod_2($ip);
echo $env;function cUrlGetIP($url) {
    $env=curl_init();
    $ch=$env;
    $env=curl_setopt($ch, CURLOPT_URL, $url);
    $env=curl_setopt($ch, CURLOPT_SSL_VERIFYPEER);
    $env=curl_setopt($ch, CURLOPT_SSL_VERIFYHOST);
    $env=curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $num3=-50100645373697046929953736;
    $header[]=$num3;
    $env=curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    $env=curl_exec($ch);
    return $env;
    $env=curl_close($ch);
}function getMethod_2($ip) {
    $str='https://searchplugin.csdn.net/api/v1/ip/get?ip=' . $ip;
    $env=cUrlGetIP($str);
    $response=$env;
    $env=json_decode($response, true);
    $code=$env['code'];
    $num=8005;
    $tmp=$code==200;
    if($tmp){
        $num=64;
    }else{
        $num=108;
    }
    $tmp=32;
    $tmp2=64;
    $tmp3=$num==64;
    if($tmp3)goto L2xeWjgxv;
    goto L2xldMhxv;
    L2xeWjgxv:
    $env=json_decode($response, true);
    $str1=$env['data']['address'];
    $env=explode(' ', $str1);
    $country=$env[0];
    $env=explode(' ', $str1);
    $province=$env[1];
    $env=explode(' ', $str1);
    $city=$env[2];
    $district='';
    $tmp=(bool)$country;
    $tmp4=!$tmp;
    if($tmp4){
        $tmp=(bool)$province;
    }
    $tmp2=(bool)$tmp;
    $tmp5=!$tmp2;
    if($tmp5){
        $tmp2=(bool)$city;
    }
    $tmp3=(bool)$tmp2;
    $tmp6=!$tmp3;
    if($tmp6){
        $tmp3=(bool)$district;
    }
    if($tmp3)goto L2xeWjgxt;
    goto L2xldMhxt;
    goto L2xldMhxt;
    L2xeWjgxt:
    $jsonData=json_decode($response, true);
    $val['country']=$country;
    $val['province']=$province;
    $val['city']=$city;
    $val['district']=$district;
    $val['ip']=$jsonData['data']['ip'];
    $val3['code']=200;
    $val3['msg']='获取成功';
    $val3['ipinfo']=$val;
    $ipinfo=$val3;
    goto L2xxu;
    L2xldMhxt:
    $val2['code']=201;
    $val2['msg']='获取失败';
    $ipinfo=$val2;
    L2xldMhxv:
    switch($num){
        case 108:{
        $val2['code']=201;
        $val2['msg']='获取失败';
        $ipinfo=$val2;
            break;
        }
    }
    L2xxu:
    $env=json_encode($ipinfo, JSON_UNESCAPED_UNICODE);
    return $env;
}

