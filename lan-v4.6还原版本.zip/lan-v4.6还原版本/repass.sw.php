<?php
if($_SERVER['REQUEST_METHOD']==='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$iteace=0;
$num3=8000;
$fileExists=is_file('./config.php');
if($fileExists){
    $num3=140;
}else{
    $num3=49;
}
switch($num3){
    case 49:{
    exit('未检测到配置文件：<span style="color: red;">config.php</span>，若您是首次使用请先进行安装,删除文件夹 <span style="color: red;">[install/]</span> 下的 <span style="color: red;">[ins.bak]</span> 文件后进行安装。若已删除请<a href="./install/">【点击安装】</a>');
        break;
    }
    case 140:{
        $tmp=require './config.php';
        break;
    }
}
$tmp=require './api/wz.php';
$num4=8012;
$isArray=is_array($_GET);
if($isArray){
    $num4=140;
}else{
    $num4=49;
}
switch($num4){
    case 140:{
    $useke=&$_GET['useke'];
        break;
    }
    case 49:{
        $useke=$_GET['useke'];
        break;
    }
}
$escaped=htmlspecialchars($useke);
unset($useke);
$escaped2=addslashes($escaped);
$useke=$escaped2;
$tmp="select * from user where username = '" . $useke;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
$fileExists=mysqli_num_rows($result);
$tmp=!$fileExists;
$tmp2=$tmp>0;
if($tmp2){
    exit('<script language="JavaScript">;alert("账号不存在!");location.href="../index.php";</script>');
}
echo "<!DOCTYPE html>";
echo "
<html lang=\"zh-CN\">";
echo "
<head>";
echo "
<meta charset=\"UTF-8\">";
echo "
<title>找回密码 - ";
echo $name;
echo "</title>";
echo "
<!--为搜索引擎定义关键词-->";
echo "
<meta name=\"keywords\" content=\"";
echo $filterkeyw;
echo "\">";
echo "
<!--为网页定义描述内容 用于告诉搜索引擎，你网站的主要内容-->";
echo "
<meta name=\"description\" content=\"";
echo $subtitle;
echo "\">";
echo "
<meta name=\"author\" content=\"";
echo $name;
echo "\">";
echo "
<meta name=\"copyright\" content=\"";
echo $name;
echo "\">";
echo "
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" />";
echo "
<meta http-equiv=\"cache-control\" content=\"no-cache\">";
echo "
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0,minimum-scale=1.0, user-scalable=no minimal-ui\">";
echo "
<link rel=\"apple-touch-icon\" sizes=\"57x57\" href=\"";
echo $icon;
echo "\" /><!-- Standard iPhone -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"114x114\" href=\"";
echo $icon;
echo "\" /><!-- Retina iPhone -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"72x72\" href=\"";
echo $icon;
echo "\" /><!-- Standard iPad -->";
echo "
<link rel=\"apple-touch-icon\" sizes=\"144x144\" href=\"";
echo $icon;
echo "\" /><!-- Retina iPad -->";
echo "
<link rel=\"icon\" href=\"";
echo $icon;
echo "\" type=\"image/x-icon\" />";
echo "
<meta name=\"robots\" content=\"index,follow\">";
echo "
<meta name=\"format-detection\" content=\"telephone=no\">";
echo "
<meta http-equiv=\"x-rim-auto-match\" content=\"none\">";
echo "
";
if($rosdomain==1){
    echo '<meta name="referrer" content="no-referrer">';
}
echo "    <link rel=\"stylesheet\" href=\"";
echo $iconurl_url;
echo "\">";
echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"./assets/css/style.css\">";
echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"./assets/mesg/dist/css/style.css\"><!--引入弹窗对话框-->";
echo "
";
echo $scfontzt;
echo "    ";
$folderPath='./user/bobg/';
$fileExists=file_exists($folderPath);
$tmp=!$fileExists;
if($tmp){
    $fileExists=mkdir($folderPath, true);
}
$num=8004;
$fileExists=file_exists("./user/bobg/bobg.jpg");
if($fileExists){
    $num=126;
}else{
    $fileExists=file_exists("./user/bobg/bobg.png");
    if($fileExists){
        $num=140;
    }else{
        $fileExists=file_exists("./user/bobg/bobg.jpeg");
        if($fileExists){
            $num=126;
            $num=11964;
        }else{
            $fileExists=file_exists("./user/bobg/bobg.gif");
            if($fileExists){
                $num=126;
                $num=2766;
            }
        }
    }
}
switch($num){
    case 140:{
    echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.png);}</style>';
        break;
    }
    case 126:{
        echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.jpg);}</style>';
        break;
    }
    case 6045:{
            echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.jpeg);}</style>';
        break;
    }
    case 1446:{
                echo '<!--背景图--><style>body{background-image: url(./user/bobg/bobg.gif);}</style>';
        break;
    }
}
echo "    ";
$tmp='<style>' . $filtercucss;
$tmp2=$tmp . '</style>';
echo $tmp2;
echo "</head>";
echo "
<body class=\"";
$num2=8019;
if(isset($_COOKIE['dark_theme'])){
    $num2=140;
}else{
    $num2=126;
}
$tmp=216;
$tmp2=140;
$tmp3=$num2==140;
if($tmp3)goto L2xeWjgx17;
goto L2xldMhx17;
L2xeWjgx17:
$tmp=$_COOKIE["dark_theme"]=="dark-theme";
if($tmp)goto L2xeWjgx15;
goto L2xx16;
goto L2xx16;
L2xeWjgx15:
echo 'dark-theme';
goto L2xx16;
L2xldMhx17:
$tmp=99;
$tmp2=126;
$tmp3=$num2==126;
if($tmp3)goto L2xx16;
L2xx16:
echo "\">";
echo "
";
if($pagepass!="")goto L2xeWjgx1i;
goto L2xldMhx1i;
L2xeWjgx1i:
if(isset($_COOKIE['pagepass']))goto L2xeWjgx1e;
goto L2xldMhx1e;
goto L2xldMhx1e;
L2xeWjgx1e:
$escaped=md5($pagepass);
$hash=md5($escaped);
$tmp=$_COOKIE['pagepass']!=$hash;
if($tmp)goto L2xeWjgx1g;
goto L2xx1h;
goto L2xx1h;
L2xeWjgx1g:
$tmp=include './site/pagepass.php';
goto L2xx1h;
L2xldMhx1e:
$tmp=include './site/pagepass.php';
L2xldMhx1i:
L2xx1h:
echo "    <!--网页主体框架-->";
echo "
<div class=\"centent\">";
echo "
<!-- 页面载体 -->";
echo "
<div class=\"sh-main setup-main\">";
echo "
<!-- 头部 -->";
echo "
<div class=\"sh-main-head setup-main-head\">";
echo "
<!-- 顶部菜单 -->";
echo "
<div class=\"sh-main-head-top setup-main-top\" id=\"sh-main-head-top\">";
echo "
<!-- 左边 -->";
echo "
<div class=\"sh-main-head-top-left\">";
echo "
<div class=\"sh-main-head-top-left-s\" onclick=\"location.href='./index.php'\">";
echo "
<i class=\"iconfont icon-weibiaoti al-sxbh\" id=\"top-left-1\"></i>";
echo "
</div>";
echo "
<div class=\"sh-main-head-top-left-s setup-main-head-top-left-s\">";
echo "
<span class=\"setup-main-title\">返回</span>";
echo "
</div>";
echo "
</div>";
echo "
<!-- 右边 -->";
echo "
<!--div class=\"sh-main-head-top-right\">";
echo "
</div-->";
echo "
</div>";
echo "
";
echo "
</div>";
echo "
<!-- 头部 end -->";
echo "
";
echo "
<!-- 设置内容区域 -->";
echo "
";
echo "
<div class=\"sh-login-main-con\" style=\"margin-top: 0px;background: var(--cobg);padding-top: 10px;\">";
echo "
<div class=\"sh-login-main-con-anu\">";
echo "
<p>账号</p>";
echo "
<input type=\"text\" name=\"zh\" id=\"saf-zh\" spellcheck=\"false\" minlength=\"5\" maxlength=\"32\" required=\"required\" value=\"";
echo $useke;
echo "\" placeholder=\"账号\" disabled style=\"border-bottom: 0px solid #f0f0f0;\">";
echo "
</div>";
echo "
<div class=\"sh-login-main-con-anu\" id=\"sh-login-main-con-anu\">";
echo "
<p>邮箱</p>";
echo "
<input type=\"email\" name=\"email\" id=\"saf-email\" spellcheck=\"false\" maxlength=\"100\" required=\"required\" value=\"\" placeholder=\"输入您账号绑定的邮箱\" pattern=\"^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+\$\" title=\"请输入正确的邮箱格式\" style=\"border-bottom: 0px solid #f0f0f0;\" autocomplete=\"off\">";
echo "
</div>";
echo "
<div class=\"sh-login-main-con-anu\">";
echo "
<p>验证码</p>";
echo "
<input type=\"password\" name=\"pwd\" id=\"saf-yzm\" spellcheck=\"false\" minlength=\"3\" maxlength=\"16\" required=\"required\" value=\"\" placeholder=\"输入邮箱验证码\" style=\"border-bottom: 0px solid #f0f0f0;\">";
echo "
</div>";
echo "
<div class=\"sh-login-main-con-anu\">";
echo "
<p>新密码</p>";
echo "
<input type=\"password\" name=\"pwd\" id=\"saf-pass\" spellcheck=\"false\" minlength=\"3\" maxlength=\"16\" required=\"required\" value=\"\" placeholder=\"设置您的新密码\" style=\"border-bottom: 0px solid #f0f0f0;\">";
echo "
</div>";
echo "
<div class=\"sh-login-main-con-anu\" id=\"sh-fsyk\">";
echo "
<a href=\"JavaScript:;\" onclick=\"zhfsyzm()\" id=\"sh-fsyzm-k\">发送验证码</a>";
echo "
</div>";
echo "
";
echo "
<div class=\"sh-login-main-bot\" style=\"margin-bottom: 30px;\">";
echo "
<input type=\"button\" value=\"重置\" class=\"sh-right\" id=\"sh-czmman-a\" onclick=\"czmman()\">";
echo "
</div>";
echo "
";
echo "
</div>";
echo "
";
echo "
<!-- 设置内容区域 end -->";
echo "
";
echo "
</div>";
echo "
<!-- 页面载体 end -->";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo auth_ts;
echo "<!--版权-->";
echo "
<div class=\"sh-copyright\">";
echo "
<span class=\"sh-copyright-banquan\" id=\"sh-copyright-banquan\">";
echo $copyright;
echo "</span>&nbsp;";
echo "
";
if($beian!=""){
    $fileExists=html_entity_decode($beian);
    $tmp='<span class="sh-copyright-banquan">' . $fileExists;
    $tmp2=$tmp . '</span>';
    echo $tmp2;
}
echo "</div>";
echo "
<!--版权-->";
echo "
";
echo "
";
echo "
</div>";
echo "
";
echo "
<script type=\"text/javascript\" src=\"./assets/js/repass.js\"></script>";
echo "
<script type=\"text/javascript\" src=\"./assets/mesg/dist/js/sh-noytf.js\"></script><!--引入弹窗对话框-->";
echo "
";
$tmp='<script type="text/javascript">' . $filtercujs;
$tmp2=$tmp . '</script>';
echo $tmp2;
echo "</body>";
echo "
</html>";