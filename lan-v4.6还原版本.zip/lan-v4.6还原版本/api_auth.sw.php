<?php
$cpcid=5157990486;
$num4=8007;
$isArray=is_array($_POST);
if($isArray){
    $num4=190;
}else{
    $num4=380;
}
switch($num4){
    case 190:{
    $aukey=&$_POST["aukey"];
        break;
    }
    case 380:{
        $aukey=$_POST["aukey"];
        break;
    }
}
$escaped=htmlspecialchars($aukey);
unset($aukey);
$escaped2=addslashes($escaped);
$aukey=$escaped2;
$num5=8001;
$isArray=is_array($_POST);
if($isArray){
    $num5=38;
}else{
    $num5=38;
    $num5=3626;
}
switch($num5){
    case 38:{
    $aukey=&$_POST["lx"];
        break;
    }
    case 1832:{
        $aukey=$_POST["lx"];
        break;
    }
}
$escaped=htmlspecialchars($aukey);
unset($aukey);
$escaped2=addslashes($escaped);
$lx=$escaped2;
if($lx=="authorize")goto L2xeWjgxo;
goto L2xldMhxo;
L2xeWjgxo:
$tmp2=$aukey!="";
if($tmp2)goto L2xeWjgxe;
goto L2xxn;
goto L2xxn;
L2xeWjgxe:
$count=explode("|", $aukey);
$array=$count;
$count=count($array);
$tmp2=$count>=2;
if($tmp2){
    $auth_first=$array[0];
    $isArray=is_array($array);
    if($isArray){
        $aukey=&$array[1];
    }else{
        $aukey=$array[1];
    }
    $escaped=restoreString($aukey);
    unset($aukey);
    $escaped2=derestoreNumbersFromLetters($escaped);
    $auth_second=$escaped2;
}else{
    exit("授权key错误");
}
$serverVal=$_SERVER['HTTP_HOST'] . $cpcid;
$hash=md5($serverVal);
$hash2=md5($hash);
$hash3=md5($hash2);
$env=hash('sha512', $hash3);
$auth_hashedData=$env;
$tmp2=$auth_first!=$auth_hashedData;
if($tmp2){
    exit("授权key不匹配");
}
$tmp2=' define("auth_key", "' . $aukey;
$content=$tmp2 . '"); ';
$count=file_put_contents('./key.php', $content);
$tmp2=$count!==false;
if($tmp2)goto L2xeWjgxm;
goto L2xldMhxm;
goto L2xldMhxm;
L2xeWjgxm:
exit("key已保存");
goto L2xxn;
L2xldMhxm:
exit("key保存失败");
L2xldMhxo:
L2xxn:
$num=8003;
$count=file_exists($auth_keylocation);
if($count){
    $num=40;
}else{
    $num=160;
}
$tmp2=33;
$tmp3=160;
$tmp4=$num==160;
if($tmp4)goto L2xeWjgx1h;
goto L2xldMhx1h;
L2xeWjgx1h:
$count=define("sh_auth_state", "no");
goto L2xx1g;
L2xldMhx1h:
$tmp2=260;
$tmp3=40;
$tmp4=$num==40;
if($tmp4)goto L2xeWjgx1i;
goto L2xldMhx1i;
L2xeWjgx1i:
$count=filemtime($auth_keylocation);
$lastModified=$count;
$count=date('YmdHi', $lastModified);
$formattedDate=$count;
$tmp2=require $auth_keylocation;
if(defined("auth_key"))goto L2xeWjgx13;
goto L2xldMhx13;
goto L2xldMhx13;
L2xeWjgx13:
$count=explode("|", auth_key);
$array=$count;
$count=count($array);
$tmp2=$count>=2;
if($tmp2)goto L2xeWjgx15;
goto L2xldMhx15;
goto L2xldMhx15;
L2xeWjgx15:
$auth_first=$array[0];
$isArray=is_array($array);
if($isArray){
    $aukey=&$array[1];
}else{
    $aukey=$array[1];
}
$escaped=restoreString($aukey);
unset($aukey);
$escaped2=derestoreNumbersFromLetters($escaped);
$auth_second=$escaped2;
goto L2xx12;
L2xldMhx15:
$count=define("sh_auth_state", "no");
L2xldMhx13:
$count=define("sh_auth_state", "no");
L2xx12:
$data=$cpcid;
$serverVal=$_SERVER['HTTP_HOST'] . $data;
$hash=md5($serverVal);
$hash2=md5($hash);
$hash3=md5($hash2);
$env=hash('sha512', $hash3);
$auth_hashedData=$env;
$tmp2=$auth_first!=$auth_hashedData;
if($tmp2){
    $count=define("sh_auth_state", "no");
}
$count=date('YmdHi');
$tmp2=$count>$auth_second;
if($tmp2){
    $count=define("sh_auth_state", "no");
}
$cond=DateTime::createFromFormat('YmdHi',$auth_second);
$dateTime=$cond;
$tmp2=$dateTime!==false;
if($tmp2)goto L2xeWjgx1d;
goto L2xldMhx1d;
goto L2xldMhx1d;
L2xeWjgx1d:
$cond2=$dateTime->modify('-180 days');
$cond2=$dateTime->format('YmdHi');
$expdateTime=$cond2;
$tmp2=$expdateTime!=$formattedDate;
if($tmp2)goto L2xeWjgx1f;
goto L2xldMhx1f;
goto L2xldMhx1f;
L2xeWjgx1f:
$count=define("sh_auth_state", "no");
goto L2xx1g;
L2xldMhx1f:
$count=define("sh_auth_state", "ok");
L2xldMhx1d:
$count=define("sh_auth_state", "no");
L2xldMhx1i:
L2xx1g:
$num2=8000;
$tmp2=sh_auth_state!="ok";
if($tmp2){
    $num2=304;
}else{
    $num2=304;
    $num2=13140;
}
$tmp2=70;
$tmp3=6722;
$tmp4=$num2==6722;
if($tmp4){
    $count=define("auth_ts", '');
}else{
    switch($num2){
        case 304:{
        $cond='<!--程序未授权--><a href="https://www.qemao.com" target="_blank" class="sh-lan-auth"><p>程序未授权</p></a>';
        $auth_tsx=$cond;
        $count=define("auth_ts", $auth_tsx);
            break;
        }
    }
};function derestoreNumbersFromLetters($input) {
    $val['!-']='0';
    $val['-!']='1';
    $val['~*']='2';
    $val['*~']='3';
    $val['@#']='4';
    $val['#@']='5';
    $val['!$']='6';
    $val['$#']='7';
    $val['!@']='8';
    $val['!#']='9';
    $mapping=$val;
    $output='';
    $i=0;
    while(true){
        $count=strlen($input);
        $tmp2=$i<$count;
        if(!($tmp2))break;
        $count=substr($input, $i);
        $chars=$count;
        $num3=6874;
        if(isset($mapping[$chars])){
            $num3=144;
        }else{
            $num3=285;
        }
        switch($num3){
            case 285:{
            $output=$output . $chars;
            $val2=$output;
                break;
            }
            case 144:{
                $output=$output . $mapping[$chars];
                $val2=$output;
                break;
            }
        }
        $tmp2=$i+2;
        $sentinel=$tmp2;
        $i=$sentinel;
        $val2=$i;
    }
    return $output;
}function restoreString($string) {
    $val[]='=';
    $val[]='%';
    $val[]='^';
    $val[]='`';
    $val[]=';';
    $disturbSymbols=$val;
    unset($tmp);
    foreach($disturbSymbols as $symbol){$tmp[]=$symbol;
}
$tmp5=0;
while(true){
    $count=count($tmp);
    $tmp2=$tmp5<$count;
    if(!($tmp2))break;
    $keys=array_keys($tmp);
    $keys=$keys[$tmp5];
    $symbol=$tmp[$keys];
    $count=str_replace($symbol, '', $string);
    $string=$count;
    $tmp5=$tmp5+1;
}
L2xx2w:
return $string;
}