<?php
$num=8003;
$isArray=is_array($_POST);
if($isArray){
    $num=400;
}else{
    $num=240;
}
switch($num){
    case 240:{
    $domcankey=$_POST['domcankey'];
        break;
    }
    case 400:{
        $domcankey=&$_POST['domcankey'];
        break;
    }
}
$escaped=htmlspecialchars($domcankey);
unset($domcankey);
$escaped2=addslashes($escaped);
$domcankey=$escaped2;
if($domcankey==""){
    exit("未传入参数");
}
$hash=md5($domcankey);
$hash2=md5($hash);
$hash3=md5($hash2);
$env=hash('sha512', $hash3);
$tmp=$env!="372a8bce3e81a0d32dd062417a9e3ef157f31cf38f3f74157e1beb19775cd85d94b3fa6a827e2c38ef23d9500a0b02d5750db9b0b05caae973524f918be20aad";
if($tmp){
    exit("秘钥错误");
}
$filePath='./key.php';
$fileExists=file_exists($filePath);
if($fileExists)goto L2xeWjgxj;
goto L2xldMhxj;
L2xeWjgxj:
$fileExists=unlink($filePath);
if($fileExists)goto L2xeWjgxh;
goto L2xldMhxh;
goto L2xldMhxh;
L2xeWjgxh:
exit("授权删除成功");
goto L2xxi;
L2xldMhxh:
exit("授权删除失败");
L2xldMhxj:
L2xxi:

