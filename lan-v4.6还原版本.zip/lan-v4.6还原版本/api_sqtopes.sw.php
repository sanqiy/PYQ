<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$tmp=$user_zh=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$user_passid=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit('请先登录');
}
$num3=3388;
$isArray=is_array($_POST);
if($isArray){
    $num3=195;
}else{
    $num3=117;
}
switch($num3){
    case 195:{
    $wid=&$_POST['wid'];
        break;
    }
    case 117:{
        $wid=$_POST['wid'];
        break;
    }
}
$escaped=htmlspecialchars($wid);
unset($wid);
$escaped2=addslashes($escaped);
$wid=$escaped2;
$num4=3379;
$isArray=is_array($_POST);
if($isArray){
    $num4=143;
}else{
    $num4=195;
}
switch($num4){
    case 195:{
    $wid=$_POST['lx'];
        break;
    }
    case 143:{
        $wid=&$_POST['lx'];
        break;
    }
}
$escaped=htmlspecialchars($wid);
unset($wid);
$escaped2=addslashes($escaped);
$lx=$escaped2;
$tmp=$wid=="";
$tmp2=(bool)$tmp;
$tmp3=!$tmp2;
if($tmp3){
    $tmp4=$lx=="";
    $tmp2=(bool)$tmp4;
}
if($tmp2){
    exit('未传入参数');
}
$iteace=1;
$tmp=include '../config.php';
$tmp=include './wz.php';
$tmp="SELECT ptpuser FROM essay WHERE id = '" . $wid;
$sql=$tmp . "'";
$result=$conn->query($sql);
$result=$result;
$num=3375;
$tmp=$result->num_rows>0;
if($tmp){
    $num=195;
}else{
    $num=165;
}
$tmp=11;
$tmp4=165;
$tmp2=$num==165;
if($tmp2)goto L2xeWjgxy;
goto L2xldMhxy;
L2xeWjgxy:
$ptpuserContent="";
goto L2xxx;
L2xldMhxy:
$tmp=40;
$tmp4=195;
$tmp2=$num==195;
if($tmp2){
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!$sentinel)break;
    $ptpuserContent=$row["ptpuser"];
}
}else{
}
L2xxx:
$str="select * from user where username='" . $user_zh;
$str2=$str . "'";
$found=mysqli_query($conn, $str2);
$data_result=$found;
$found=mysqli_fetch_array($data_result);
$data2_row=$found;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjwallet=$data2_row["wallet"];
$zjussig=$data2_row["ussig"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
if($user_passid!=$passid){
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("username", "", $str, "/");
    $escaped=time();
    $str=$escaped+ -1;
    $cookieResult=setcookie("passid", "", $str, "/");
    exit('账号信息异常,请重新登录');
}
$num2=3388;
$tmp=$user_zh==$glyadmin;
if($tmp){
    $num2=195;
}else{
    $num2=169;
}
$tmp=14;
$tmp4=169;
$tmp2=$num2==169;
if($tmp2)goto L2xeWjgx1g;
goto L2xldMhx1g;
L2xeWjgx1g:
$tmp=$zjzhq==$ptpuserContent;
if($tmp)goto L2xeWjgx1a;
goto L2xldMhx1a;
goto L2xldMhx1a;
L2xeWjgx1a:
$tmp=$topwcz>$zjwallet;
if($tmp)goto L2xeWjgx1c;
goto L2xldMhx1c;
goto L2xldMhx1c;
L2xeWjgx1c:
$tmp="置顶需要:" . $topwcz;
exit($tmp . "余额,你的余额不足!");
goto L2xx1f;
L2xldMhx1c:
$xwyaeg=$zjwallet-$topwcz;
$tmp="UPDATE user SET wallet = '" . $xwyaeg;
$tmp4=$tmp . "' WHERE username = '";
$tmp2=$tmp4 . $zjzhq;
$sql=$tmp2 . "'";
$result=$conn->query($sql);
$tmp=$result===TRUE;
if($tmp)goto L2xx1f;
goto L2xldMhx1e;
L2xldMhx1e:
exit('扣除余额失败,请重试');
L2xldMhx1a:
exit('没有权限');
L2xldMhx1g:
$tmp=224;
$tmp4=195;
$tmp2=$num2==195;
if($tmp2)goto L2xx1f;
L2xx1f:
if($lx=="sw")goto L2xeWjgx1v;
goto L2xldMhx1v;
L2xeWjgx1v:
$found=explode(PHP_EOL, $topes);
$arsj=$found;
$found=in_array($wid, $arsj);
if($found){
    exit("该文章已置顶过了");
}
$tmp=$topes . PHP_EOL;
$xtopes=$tmp . $wid;
$tmp="UPDATE admin SET topes='" . $xtopes;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx1t;
goto L2xldMhx1t;
goto L2xldMhx1t;
L2xeWjgx1t:
exit("已设为置顶");
goto L2xx1u;
L2xldMhx1t:
exit("置顶失败");
L2xldMhx1v:
L2xx1u:
if($lx=="qx")goto L2xeWjgx2c;
goto L2xldMhx2c;
L2xeWjgx2c:
$tmp=$topes=="";
if($tmp){
    exit('没有任何置顶文章');
}
$str=$wid . PHP_EOL;
$found=strstr($topes, $str);
if($found){
    $qxsu=$wid . PHP_EOL;
}else{
    $str=PHP_EOL . $wid;
    $found=strstr($topes, $str);
    if($found){
        $qxsu=PHP_EOL . $wid;
    }else{
        $str=PHP_EOL . $wid;
        $str2=$str . PHP_EOL;
        $found=strstr($topes, $str2);
        if($found){
            $tmp=PHP_EOL . $wid;
            $qxsu=$tmp . PHP_EOL;
        }else{
            $qxsu=$wid;
        }
    }
}
$found=str_replace($qxsu, "", $topes);
$xtopsu=$found;
$tmp="UPDATE admin SET topes='" . $xtopsu;
$sql=$tmp . "' WHERE id='1'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx2a;
goto L2xldMhx2a;
goto L2xldMhx2a;
L2xeWjgx2a:
exit("已取消置顶");
goto L2xx2b;
L2xldMhx2a:
exit("取消置顶失败");
L2xldMhx2c:
L2xx2b:
$result=$conn->close();