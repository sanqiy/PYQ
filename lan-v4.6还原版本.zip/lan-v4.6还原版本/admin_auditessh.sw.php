<?php
$iteace=1;
$pos=is_file('../config.php');
if($pos){
    $tmp=include '../config.php';
}
$tmp=include '../api/wz.php';
if($userdlzt==0){
    $pos=header('location: ./login.php');
    exit();
}
$num8=4924;
$tmp=$user_zh==$glyadmin;
if($tmp){
    $num8=63;
}else{
    $num8=49;
}
$tmp=300;
$tmp2=49;
$tmp3=$num8==49;
if($tmp3)goto L2xeWjgxe;
goto L2xldMhxe;
L2xeWjgxe:
exit('<script language="JavaScript">;alert("没有权限!");location.href="../index.php";</script>;');
goto L2xxd;
L2xldMhxe:
$tmp=96;
$tmp2=63;
$tmp3=$num8==63;
if($tmp3)goto L2xeWjgxf;
goto L2xldMhxf;
L2xeWjgxf:
$tmp=$user_passid!=$passid;
if($tmp)goto L2xeWjgxc;
goto L2xxd;
goto L2xxd;
L2xeWjgxc:
exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="./login.php";</script>;');
goto L2xxd;
L2xldMhxf:
L2xxd:
$num9=4915;
$isArray=is_array($_POST);
if($isArray){
    $num9=153;
}else{
    $num9=153;
    $num9=171;
}
switch($num9){
    case 153:{
    $type=&$_POST['wzxgcid'];
        break;
    }
    case 162:{
        $type=$_POST['wzxgcid'];
        break;
    }
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$wzxgcid=$escaped2;
if($wzxgcid!="")goto L2xeWjgx1l;
goto L2xldMhx1l;
L2xeWjgx1l:
$isArray=is_array($_POST);
if($isArray){
    $type=&$_POST['exampleRadios'];
}else{
    $type=$_POST['exampleRadios'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$exampleRadios=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $type=&$_POST['ptpnr'];
}else{
    $type=$_POST['ptpnr'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$ptpnr=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $type=&$_POST['ptptup'];
}else{
    $type=$_POST['ptptup'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$ptptup=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $type=&$_POST['ptpsp'];
}else{
    $type=$_POST['ptpsp'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$ptpsp=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $type=&$_POST['ptpyy'];
}else{
    $type=$_POST['ptpyy'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$ptpyy=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $type=&$_POST['ptpdw'];
}else{
    $type=$_POST['ptpdw'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$ptpdw=$escaped2;
$isArray=is_array($_POST);
if($isArray){
    $type=&$_POST['ptpgg'];
}else{
    $type=$_POST['ptpgg'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$ptpgg=$escaped2;
$pos=str_replace(PHP_EOL, "(+@+)", $ptptup);
$ptptup=$pos;
$tmp=$exampleRadios!="";
if($tmp){
    $tmp="UPDATE essay SET ptplx='" . $exampleRadios;
    $tmp2=$tmp . "' WHERE cid='";
    $tmp3=$tmp2 . $wzxgcid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$ptpnr!="";
if($tmp){
    $tmp="UPDATE essay SET ptptext='" . $ptpnr;
    $tmp2=$tmp . "' WHERE cid='";
    $tmp3=$tmp2 . $wzxgcid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$ptptup!="";
if($tmp){
    $tmp="UPDATE essay SET ptpimag='" . $ptptup;
    $tmp2=$tmp . "' WHERE cid='";
    $tmp3=$tmp2 . $wzxgcid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$ptpsp!="";
if($tmp){
    $tmp="UPDATE essay SET ptpvideo='" . $ptpsp;
    $tmp2=$tmp . "' WHERE cid='";
    $tmp3=$tmp2 . $wzxgcid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$ptpyy!="";
if($tmp){
    $tmp="UPDATE essay SET ptpmusic='" . $ptpyy;
    $tmp2=$tmp . "' WHERE cid='";
    $tmp3=$tmp2 . $wzxgcid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$ptpdw!="";
if($tmp){
    $tmp="UPDATE essay SET ptpdw='" . $ptpdw;
    $tmp2=$tmp . "' WHERE cid='";
    $tmp3=$tmp2 . $wzxgcid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp=$ptpgg!="";
if($tmp){
    $tmp="UPDATE essay SET ptpggurl='" . $ptpgg;
    $tmp2=$tmp . "' WHERE cid='";
    $tmp3=$tmp2 . $wzxgcid;
    $sql=$tmp3 . "'";
    $result=$conn->query($sql);
    $result=$result;
}
$tmp="UPDATE essay SET ptptext='" . $text;
$tmp2=$tmp . "',ptpdw='";
$tmp3=$tmp2 . $dw;
$tmp4=$tmp3 . "' ";
$tmp5=$tmp4 . $wftime;
$tmp6=$tmp5 . ",ptpgg='";
$tmp7=$tmp6 . $gg;
$tmp8=$tmp7 . "',ptpggurl='";
$tmp9=$tmp8 . $gglj;
$tmp10=$tmp9 . "',commauth='";
$tmp11=$tmp10 . $yxplkg;
$tmp12=$tmp11 . "' WHERE id='";
$tmp13=$tmp12 . $edbjwzid;
$sql=$tmp13 . "'";
$result=$conn->query($sql);
$result=$result;
if($result)goto L2xeWjgx1j;
goto L2xldMhx1j;
goto L2xldMhx1j;
L2xeWjgx1j:
$pos=header("location:./auditessh.php?type=all");
goto L2xx1k;
L2xldMhx1j:
$referer=$_SERVER['HTTP_REFERER'];
$tmp='<script language="JavaScript">;alert("文章编辑出错,请重试");location.href="' . $referer;
exit($tmp . '";</script>;');
L2xldMhx1l:
L2xx1k:
echo "<!doctype html>";
echo "
<html lang=\"en\">";
echo "
<head>";
echo "
<meta charset=\"utf-8\">";
echo "
<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0\">";
echo "
<title>审核文章 - ";
echo $name;
echo "</title>";
echo "
<meta name=\"keywords\" content=\"";
echo $filterkeyw;
echo "\">";
echo "
<meta name=\"description\" content=\"";
echo $subtitle;
echo "\">";
echo "
<meta name=\"author\" content=\"";
echo $name;
echo "\">";
echo "
<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"";
$num3=4929;
$pos=strpos($icon, 'http');
$tmp=$pos!==false;
if($tmp){
    $num3=63;
}else{
    $num3=49;
}
switch($num3){
    case 63:{
    echo $icon;
        break;
    }
    case 49:{
        $tmp='.' . $icon;
        echo $tmp;
        break;
    }
}
echo "\">";
echo "
<link rel=\"stylesheet\" href=\"assets/css/css2.css\">";
echo "
<link rel=\"stylesheet\" id=\"css-main\" href=\"assets/css/oneui.min.css\">";
echo "
</head>";
echo "
<body>";
echo "
<div id=\"page-container\" class=\"sidebar-o sidebar-dark page-header-fixed main-content-narrow\">";
echo "
<nav id=\"sidebar\" aria-label=\"Main Navigation\">";
echo "
<!-- Side Header -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Logo -->";
echo "
<a class=\"fw-semibold text-dual\" href=\"index.php\">";
echo "
<span class=\"smini-visible\">";
echo "
<i class=\"fa fa-circle-notch text-primary\"></i>";
echo "
</span>";
echo "
<span class=\"smini-hide fs-5 tracking-wider\">后台管理</span>";
echo "
</a>";
echo "
<!-- END Logo -->";
echo "
";
echo "
<!-- Extra -->";
echo "
<div>";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" data-toggle=\"layout\" data-action=\"dark_mode_toggle\">";
echo "
<i class=\"far fa-moon\"></i>";
echo "
</button>";
echo "
<!-- END Dark Mode -->";
echo "
";
echo "
<!-- Options -->";
echo "
<div class=\"dropdown d-inline-block ms-1\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary\" id=\"sidebar-themes-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<i class=\"far fa-circle\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-end fs-sm smini-hide border-0\" aria-labelledby=\"sidebar-themes-dropdown\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"default\" href=\"#\">";
echo "
<span>默认</span>";
echo "
<i class=\"fa fa-circle text-default\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/amethyst.min.css\" href=\"#\">";
echo "
<span>紫色</span>";
echo "
<i class=\"fa fa-circle text-amethyst\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/city.min.css\" href=\"#\">";
echo "
<span>红色</span>";
echo "
<i class=\"fa fa-circle text-city\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/flat.min.css\" href=\"#\">";
echo "
<span>青色</span>";
echo "
<i class=\"fa fa-circle text-flat\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/modern.min.css\" href=\"#\">";
echo "
<span>蓝色</span>";
echo "
<i class=\"fa fa-circle text-modern\"></i>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between fw-medium\" data-toggle=\"theme\" data-theme=\"assets/css/themes/smooth.min.css\" href=\"#\">";
echo "
<span>粉色</span>";
echo "
<i class=\"fa fa-circle text-smooth\"></i>";
echo "
</a>";
echo "
<!-- END Color Themes -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_light\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"sidebar_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>侧栏 黑色</span>";
echo "
</a>";
echo "
<!-- END Sidebar Styles -->";
echo "
";
echo "
<div class=\"dropdown-divider\"></div>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_light\" href=\"javascript:void(0)\">";
echo "
<span>导航 白色</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item fw-medium\" data-toggle=\"layout\" data-action=\"header_style_dark\" href=\"javascript:void(0)\">";
echo "
<span>导航 黑色</span>";
echo "
</a>";
echo "
<!-- END Header Styles -->";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Options -->";
echo "
<a class=\"d-lg-none btn btn-sm btn-alt-secondary ms-1\" data-toggle=\"layout\" data-action=\"sidebar_close\" href=\"javascript:void(0)\">";
echo "
<i class=\"fa fa-fw fa-times\"></i>";
echo "
</a>";
echo "
<!-- END Close Sidebar -->";
echo "
</div>";
echo "
<!-- END Extra -->";
echo "
</div>";
echo "
<!-- END Side Header -->";
echo "
";
echo "
<!-- Sidebar Scrolling -->";
echo "
<div class=\"js-sidebar-scroll\">";
echo "
<!-- Side Navigation -->";
echo "
<div class=\"content-side\">";
echo "
<ul class=\"nav-main\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./index.php\">";
echo "
<i class=\"nav-main-link-icon si si-speedometer\"></i>";
echo "
<span class=\"nav-main-link-name\">后台首页</span>";
echo "
</a>";
echo "
</li>";
echo "
";
echo "
<li class=\"nav-main-heading\">设置</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-energy\"></i>";
echo "
<span class=\"nav-main-link-name\">网站设置</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./basic.php\">";
echo "
<span class=\"nav-main-link-name\">基础设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./authority.php\">";
echo "
<span class=\"nav-main-link-name\">权限设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./imgset.php\">";
echo "
<span class=\"nav-main-link-name\">图像设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./emailset.php\">";
echo "
<span class=\"nav-main-link-name\">邮箱设置</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./calis.php\">";
echo "
<span class=\"nav-main-link-name\">卡密管理</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-users\"></i>";
echo "
<span class=\"nav-main-link-name\">用户管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./userlist.php\">";
echo "
<span class=\"nav-main-link-name\">用户列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item open\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-book-open\"></i>";
echo "
<span class=\"nav-main-link-name\">文章管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditesli.php\">";
echo "
<span class=\"nav-main-link-name\">文章列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link active\" href=\"./auditessh.php\">";
echo "
<span class=\"nav-main-link-name\">审核文章</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-speech\"></i>";
echo "
<span class=\"nav-main-link-name\">评论管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditcoli.php\">";
echo "
<span class=\"nav-main-link-name\">评论列表</span>";
echo "
</a>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./auditcosh.php\">";
echo "
<span class=\"nav-main-link-name\">审核评论</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link nav-main-link-submenu\" data-toggle=\"submenu\" aria-haspopup=\"true\" aria-expanded=\"false\" href=\"#\">";
echo "
<i class=\"nav-main-link-icon si si-paper-clip\"></i>";
echo "
<span class=\"nav-main-link-name\">友链管理</span>";
echo "
</a>";
echo "
<ul class=\"nav-main-submenu\">";
echo "
<li class=\"nav-main-item\">";
echo "
<a class=\"nav-main-link\" href=\"./linkset.php\">";
echo "
<span class=\"nav-main-link-name\">友链列表</span>";
echo "
</a>";
echo "
</li>";
echo "
</ul>";
echo "
</li>";
echo "
</ul>";
echo "
</div>";
echo "
<!-- END Side Navigation -->";
echo "
</div>";
echo "
<!-- END Sidebar Scrolling -->";
echo "
</nav>";
echo "
<!-- END Sidebar -->";
echo "
";
echo "
<!-- Header -->";
echo "
<header id=\"page-header\">";
echo "
<!-- Header Content -->";
echo "
<div class=\"content-header\">";
echo "
<!-- Left Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- Toggle Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-lg-none\" data-toggle=\"layout\" data-action=\"sidebar_toggle\">";
echo "
<i class=\"fa fa-fw fa-bars\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Sidebar -->";
echo "
";
echo "
<!-- Toggle Mini Sidebar -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout()-->";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary me-2 d-none d-lg-inline-block\" data-toggle=\"layout\" data-action=\"sidebar_mini_toggle\">";
echo "
<i class=\"fa fa-fw fa-ellipsis-v\"></i>";
echo "
</button>";
echo "
<!-- END Toggle Mini Sidebar -->";
echo "
";
echo "
<!-- Open Search Section (visible on smaller screens) -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
";
echo "
<!-- END Open Search Section -->";
echo "
";
echo "
<!-- Search Form (visible on larger screens) -->";
echo "
";
echo "
<!-- END Search Form -->";
echo "
</div>";
echo "
<!-- END Left Section -->";
echo "
";
echo "
<!-- Right Section -->";
echo "
<div class=\"d-flex align-items-center\">";
echo "
<!-- User Dropdown -->";
echo "
<div class=\"dropdown d-inline-block ms-2\">";
echo "
<button type=\"button\" class=\"btn btn-sm btn-alt-secondary d-flex align-items-center\" id=\"page-header-user-dropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">";
echo "
<img class=\"rounded-circle\" src=\"";
$num4=4925;
$pos=strpos($user_img, 'http');
$tmp=$pos!==false;
if($tmp){
    $num4=81;
}else{
    $num4=63;
}
switch($num4){
    case 63:{
    $tmp='.' . $user_img;
    echo $tmp;
        break;
    }
    case 81:{
        echo $user_img;
        break;
    }
}
echo "\" alt=\"Header Avatar\" style=\"width: 21px;\">";
echo "
<span class=\"d-none d-sm-inline-block ms-2\">";
echo $user_name;
echo "</span>";
echo "
<i class=\"fa fa-fw fa-angle-down d-none d-sm-inline-block opacity-50 ms-1 mt-1\"></i>";
echo "
</button>";
echo "
<div class=\"dropdown-menu dropdown-menu-md dropdown-menu-end p-0 border-0\" aria-labelledby=\"page-header-user-dropdown\">";
echo "
<div class=\"p-3 text-center bg-body-light border-bottom rounded-top\">";
echo "
<img class=\"img-avatar img-avatar48 img-avatar-thumb\" src=\"";
$num5=4930;
$pos=strpos($user_img, 'http');
$tmp=$pos!==false;
if($tmp){
    $num5=63;
}else{
    $num5=81;
}
switch($num5){
    case 63:{
    echo $user_img;
        break;
    }
    case 81:{
        $tmp='.' . $user_img;
        echo $tmp;
        break;
    }
}
echo "\" alt=\"\">";
echo "
<p class=\"mt-2 mb-0 fw-medium\">";
echo $user_name;
echo "</p>";
echo "
<!--p class=\"mb-0 text-muted fs-sm fw-medium\">介绍</p-->";
echo "
</div>";
echo "
<div role=\"separator\" class=\"dropdown-divider m-0\"></div>";
echo "
<div class=\"p-2\">";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"../\">";
echo "
<span class=\"fs-sm fw-medium\">返回前台</span>";
echo "
</a>";
echo "
<a class=\"dropdown-item d-flex align-items-center justify-content-between\" href=\"JavaScript:;\" onclick=\"logut()\">";
echo "
<span class=\"fs-sm fw-medium\">退出登录</span>";
echo "
</a>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
";
echo "
<!-- END User Dropdown -->";
echo "
";
echo "
<!-- Notifications Dropdown -->";
echo "
";
echo "
<!-- END Notifications Dropdown -->";
echo "
";
echo "
<!-- Toggle Side Overlay -->";
echo "
<!-- Layout API, functionality initialized in Template._uiApiLayout() -->";
echo "
";
echo "
<!-- END Toggle Side Overlay -->";
echo "
</div>";
echo "
<!-- END Right Section -->";
echo "
</div>";
echo "
<!-- END Header Content -->";
echo "
";
echo "
<!-- Header Loader -->";
echo "
<!-- Please check out the Loaders page under Components category to see examples of showing/hiding it -->";
echo "
<div id=\"page-header-loader\" class=\"overlay-header bg-body-extra-light\">";
echo "
<div class=\"content-header\">";
echo "
<div class=\"w-100 text-center\">";
echo "
<i class=\"fa fa-fw fa-circle-notch fa-spin\"></i>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
<!-- END Header Loader -->";
echo "
</header>";
echo "
<!-- END Header -->";
echo "
";
echo "
<!-- Main Container -->";
echo "
<main id=\"main-container\">";
echo "
";
echo "
<!-- Page Content -->";
echo "
<div class=\"content\">";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
<div class=\"block block-rounded\">";
echo "
<div class=\"block-header block-header-default\">";
echo "
<h3 class=\"block-title\">文章列表</h3>";
echo "
<div class=\"block-options space-x-1\">";
echo "
<button id=\"so-search\" type=\"button\" class=\"btn btn-sm btn-alt-secondary js-class-toggle-enabled\" data-toggle=\"class-toggle\" data-target=\"#one-dashboard-search-orders\" data-class=\"d-none\">";
echo "
<i class=\"fa fa-search\"></i>";
echo "
</button>";
echo "
";
echo "
</div>";
echo "
</div>";
echo "
<div id=\"one-dashboard-search-orders\" class=\"block-content border-bottom d-none\">";
echo "
<!-- Search Form -->";
echo "
<form action=\"be_pages_dashboard.php\" method=\"POST\" onsubmit=\"return false;\">";
echo "
<div class=\"push\">";
echo "
<div class=\"input-group\">";
echo "
<input type=\"text\" class=\"form-control form-control-alt\" id=\"one-ecom-orders-search\" name=\"one-ecom-orders-search\" placeholder=\"Search all orders..\">";
echo "
<span class=\"input-group-text bg-body border-0\">";
echo "
<i class=\"fa fa-search\"></i>";
echo "
</span>";
echo "
</div>";
echo "
</div>";
echo "
</form>";
echo "
<!-- END Search Form -->";
echo "
</div>";
echo "
<div class=\"block-content block-content-full\">";
echo "
<!-- Recent Orders Table -->";
echo "
";
$num6=4927;
$isArray=is_array($_GET);
if($isArray){
    $type=&$_GET['page'];
}else{
    $type=$_GET['page'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$tmp=$escaped2!="";
if($tmp){
    $num6=119;
}else{
    $num6=119;
    $num6=7383;
}
switch($num6){
    case 3751:{
    $page=1;
        break;
    }
    case 119:{
        $page=$_GET['page'];
        break;
    }
}
$perPage=20;
$tmp=$page-1;
$offset=$tmp*20;
$tmp="SELECT * FROM essay where ptpaud= '0' order by id desc LIMIT " . 20;
$tmp2=$tmp . " OFFSET ";
$sql=$tmp2 . $offset;
$result=$conn->query("SELECT COUNT(*) AS total FROM essay where ptpaud= '0'");
$row=$result->fetch_assoc();
$totalRecords=$row;
$num7=4923;
$isArray=is_array($_GET);
if($isArray){
    $num7=81;
}else{
    $num7=63;
}
switch($num7){
    case 81:{
    $type=&$_GET['keyword'];
        break;
    }
    case 63:{
        $type=$_GET['keyword'];
        break;
    }
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$keyword=$escaped2;
if($keyword!=""){
    $tmp="SELECT * FROM essay where ptpaud= '0' and ptptext LIKE '%" . $keyword;
    $sql=$tmp . "%' order by id desc";
}
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0)goto L2xeWjgx59;
goto L2xldMhx59;
L2xeWjgx59:
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!$num10)break;
    $ptpuser=$row["ptpuser"];
    $ptpimg=$row["ptpimg"];
    $ptpname=$row["ptpname"];
    $ptptext=$row["ptptext"];
    $ptpimag=$row["ptpimag"];
    $ptpvideo=$row["ptpvideo"];
    $ptpmusic=$row["ptpmusic"];
    $ptplx=$row["ptplx"];
    $ptpdw=$row["ptpdw"];
    $ptptime=$row["ptptime"];
    $ptpgg=$row["ptpgg"];
    $ptpggurl=$row["ptpggurl"];
    $ptpys=$row["ptpys"];
    $commauth=$row["commauth"];
    $ptpaud=$row["ptpaud"];
    $ptpip=$row["ip"];
    $cid=$row["cid"];
    $wid=$row["id"];
    $pos=explode("|", $ptpvideo);
    $partssp=$pos;
    $ptpvideo=$partssp[0];
    $ptpvideofm=$partssp[1];
    $tmp=$ptpimg=="./assets/img/tx.png";
    if($tmp){
        $ptpimg="../../assets/img/tx.png";
    }else{
        $pos=strpos($ptpimg, './user/headimg/');
        $tmp=$pos!==false;
        if($tmp){
            $ptpimg="../." . $ptpimg;
        }else{
            $pos=strpos($ptpimg, './assets/img/');
            $tmp=$pos!==false;
            if($tmp){
                $ptpimg="../." . $ptpimg;
            }
        }
    }
    $pos=str_replace('./assets/owo/paopao/', '../../assets/owo/paopao/', $ptptext, $count);
    $ptptext=$pos;
    $ptptext=$ptptext . PHP_EOL;
    $pos=str_replace('src="./assets/img/thumbnail.svg"', '', $ptptext, $count);
    $ptptext=$pos;
    $ptptext=$ptptext . PHP_EOL;
    $pos=str_replace('data-src="', 'src="', $ptptext, $count);
    $ptptext=$pos;
    $ptptext=$ptptext . PHP_EOL;
    $pos=str_replace('<img ', '<img style="width: 24px;height: 24px;" ', $ptptext, $count);
    $ptptext=$pos;
    $ptptext=$ptptext . PHP_EOL;
    $tmp=$ptpgg==1;
    if($tmp){
        $ggdiv=-22;
    }else{
        $ggdiv='';
    }
    $pos=strtotime($ptptime);
    $time=$pos;
    $pos=ReckonTime($time);
    $wzfbsj=$pos;
    $tmp='
    <div class="col-sm-12" style="padding: 0px;margin-bottom:10px;" id="sh-content-' . $cid;
    $tmp2=$tmp . '">
    <div class="card">
    <header class="card-header" style="display: flex;justify-content: space-between;align-items: baseline;">
    <div class="card-title"><img class="img-avatar img-avatar-48 m-r-10 rounded" alt="48x48" src="';
    $tmp3=$tmp2 . $ptpimg;
    $tmp4=$tmp3 . '" style="object-fit: cover;margin-right: 10px;" data-holder-rendered="true">';
    $tmp5=$tmp4 . $ptpname;
    $tmp6=$tmp5 . $ggdiv;
    $tmp7=$tmp6 . '</div>
    <ul class="card-actions">
    <li class="dropdown show">';
    $tmp8=$tmp7 . $wzfbsj;
    $tmp9=$tmp8 . '</li>
    </ul>
    </header>
    <div class="card-body">
    <p>';
    $tmp10=$tmp9 . $ptptext;
    $tmp11=$tmp10 . '</p>
    <div class="border-example-border-utils">
    ';
    echo $tmp11;
    $tmp=$ptplx=="img";
if($tmp)goto L2xeWjgx3o;
goto L2xldMhx3o;
goto L2xldMhx3o;
goto L2xldMhx3o;
L2xeWjgx3o:
    $pos=explode('(+@+)', $ptpimag);
    $imgar=$pos;
    $pos=count($imgar);
    $coun=$pos;
    $num10=0;
    $i=$num10;
    while(true){
        $tmp=$i<$coun;
        if(!$tmp)break;
        $isArray=is_array($imgar);
        if($isArray){
            $val=&$imgar[$i];
        }else{
            $val=$imgar[$i];
        }
        $pos=strpos($val, './upload/');
        unset($val);
        $tmp=$pos!==false;
if($tmp)goto L2xeWjgx3v;
goto L2xldMhx3v;
goto L2xldMhx3v;
goto L2xldMhx3v;
goto L2xldMhx3v;
L2xeWjgx3v:
        $tuimg="../." . $imgar[$i];
        $isArray=is_array($imgar);
        if($isArray){
            $val=&$imgar[$i];
        }else{
            $val=$imgar[$i];
        }
        $pos=strpos($val, '../upload/');
        unset($val);
        $tmp=$pos!==false;
if($tmp)goto L2xeWjgx4z;
goto L2xx3s;
goto L2xx3s;
goto L2xx3s;
goto L2xx3s;
L2xeWjgx4z:
        $tuimg="../" . $imgar[$i];
goto L2xx3s;
L2xldMhx3v:
        $tuimg=$imgar[$i];
L2xx3s:
        $tmp='<img src="' . $tuimg;
        $tmp2=$tmp . '" width="70" alt="图片" class="rounded-sm" style="width:70px;height: 100vw;max-height: 100px;object-fit: cover;margin-bottom: 10px;margin-right: 5px;">';
        echo $tmp2;
        $obj=$i;
        $obj2=$i+1;
        $num10=$obj2;
        $i=$num10;
    }
goto L2xx3n;
L2xldMhx3o:
    $tmp=$ptplx=="video";
if($tmp)goto L2xeWjgx4b;
goto L2xldMhx4b;
goto L2xldMhx4b;
goto L2xldMhx4b;
L2xeWjgx4b:
    $tmp='<div class="sh-video">
    <iframe src="../site/library/player.php?url=' . $ptpvideo;
    $tmp2=$tmp . '" allowfullscreen="allowfullscreen" mozallowfullscreen="mozallowfullscreen" msallowfullscreen="msallowfullscreen" oallowfullscreen="oallowfullscreen" webkitallowfullscreen="webkitallowfullscreen" frameBorder="" style="width: fit-content;max-width: 100%;height:100vw;min-height:200px;max-height:400px;border-radius: 4px;"></iframe>
    </div>';
    echo $tmp2;
goto L2xx3n;
L2xldMhx4b:
    $tmp=$ptplx=="music";
if($tmp)goto L2xeWjgx4c;
goto L2xldMhx4c;
goto L2xldMhx4c;
goto L2xldMhx4c;
L2xeWjgx4c:
    $pos=is_numeric($ptpmusic);
if($pos)goto L2xeWjgx4e;
goto L2xldMhx4e;
goto L2xldMhx4e;
goto L2xldMhx4e;
L2xeWjgx4e:
    echo "<span>网易云音乐播放器已取消</span>";
goto L2xx3n;
L2xldMhx4e:
    $pos=explode('|', $ptpmusic);
    $mus=$pos;
    $tmp='<audio controls style="width: 100%;">
    <source src="' . $mus[0];
    $tmp2=$tmp . '" type="audio/mp3">
    </audio>';
    echo $tmp2;
L2xldMhx4c:
L2xx3n:
    $tmp='
    </div>
    </div>
    <footer class="card-footer text-right">
    <button class="btn btn-label btn-danger" style="margin-top: 5px;" lang="' . $cid;
    $tmp2=$tmp . '" onclick="scwzsg()"><label><i class="mdi mdi-close"></i></label> 驳回</button>';
    echo $tmp2;
    $tmp='<button class="btn btn-label btn-primary" style="margin-top: 5px;margin-left: 5px;" lang="' . $cid;
    $tmp2=$tmp . '" onclick="tgwzsg()"><label><i class="mdi mdi-checkbox-marked-circle-outline"></i></label> 通过</button>';
    echo $tmp2;
    echo '
    </footer>
    </div>
    </div>';
}
goto L2xx58;
L2xldMhx59:
L2xx58:
$totalRecords=$totalRecords['total'];
$num11=$totalRecords/$perPage;
$pos=ceil($num11);
$maxPages=$pos;
$tmp='<div class="fixed-table-pagination callout" style="background-color: rgb(255 255 255 / 0%);display: flex;justify-content: space-between;align-items: center;">
<div class="float-left pagination-detail" style="margin-bottom: 10px;">
<span class="pagination-info">
每页显示' . $perPage;
$tmp2=$tmp . '条数据，总共';
$tmp3=$tmp2 . $totalRecords;
$tmp4=$tmp3 . '条数据
</span>
</div>
<div class="float-right pagination">
<ul class="pagination">';
echo $tmp4;
$num=4916;
$isArray=is_array($_GET);
if($isArray){
    $type=&$_GET['type'];
}else{
    $type=$_GET['type'];
}
$escaped=htmlspecialchars($type);
unset($type);
$escaped2=addslashes($escaped);
$tmp=$escaped2!="";
if($tmp){
    $num=153;
}else{
    $num=153;
    $num=9373;
}
switch($num){
    case 153:{
    $isArray=is_array($_GET);
    if($isArray){
        $type=&$_GET['type'];
    }else{
        $type=$_GET['type'];
    }
    $escaped=htmlspecialchars($type);
    unset($type);
    $escaped2=addslashes($escaped);
    $tmp='type=' . $escaped2;
    $typez=$tmp . '&';
        break;
    }
    case 4763:{
        $typez="";
        break;
    }
}
if($maxPages>1)goto L2xeWjgx6y;
goto L2xldMhx6y;
L2xeWjgx6y:
$tmp=$page>1;
if($tmp){
    $tmp='<li class="page-item"><a class="page-link" aria-label="首页" href="./auditessh.php?' . $typez;
    $tmp2=$tmp . 'page=1">首页</a></li>';
    echo $tmp2;
    $tmp='<li class="page-item page-pre"><a class="page-link" aria-label="上一页" href="./auditessh.php?' . $typez;
    $tmp2=$tmp . 'page=';
    $tmp3=$page-1;
    $tmp4=$tmp2 . $tmp3;
    $tmp5=$tmp4 . '">‹</a></li>';
    echo $tmp5;
}
$num11=$page-1;
$pos=max($num11);
$start=$pos;
$num11=$page+1;
$pos=min($num11, $maxPages);
$end=$pos;
$tmp=$start>1;
if(!($tmp)){
}else{
    $num10=$start;
    $i=$num10;
}
while(true){
    $tmp=$i<=$end;
    if(!$tmp)break;
    $tmp=$i==$page;
    if($tmp){
        $tmp='<li class="page-item active"><a class="page-link" aria-label="第' . $i;
        $tmp2=$tmp . '页" href="./auditessh.php?';
        $tmp3=$tmp2 . $typez;
        $tmp4=$tmp3 . 'page=';
        $tmp5=$tmp4 . $i;
        $tmp6=$tmp5 . '">';
        $tmp7=$tmp6 . $i;
        $tmp8=$tmp7 . '</a></li>';
        echo $tmp8;
    }else{
        $tmp='<li class="page-item "><a class="page-link" aria-label="第' . $i;
        $tmp2=$tmp . '页" href="./auditessh.php?';
        $tmp3=$tmp2 . $typez;
        $tmp4=$tmp3 . 'page=';
        $tmp5=$tmp4 . $i;
        $tmp6=$tmp5 . '">';
        $tmp7=$tmp6 . $i;
        $tmp8=$tmp7 . '</a></li>';
        echo $tmp8;
    }
    $obj2=$i;
    $obj3=$i+1;
    $num10=$obj3;
    $i=$num10;
}
L2xx6p:
$tmp=$end<$maxPages;
if($tmp){
    echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
}
$tmp=$page<$maxPages;
if($tmp)goto L2xeWjgx6w;
goto L2xx6x;
goto L2xx6x;
L2xeWjgx6w:
$tmp='<li class="page-item page-pre"><a class="page-link" aria-label="下一页" href="./auditessh.php?' . $typez;
$tmp2=$tmp . 'page=';
$tmp3=$page+1;
$tmp4=$tmp2 . $tmp3;
$tmp5=$tmp4 . '">›</a></li>';
echo $tmp5;
$tmp='<li class="page-item"><a class="page-link" aria-label="尾页" href="./auditessh.php?' . $typez;
$tmp2=$tmp . 'page=';
$tmp3=$tmp2 . $maxPages;
$tmp4=$tmp3 . '">尾页</a></li>';
echo $tmp4;
goto L2xx6x;
L2xldMhx6y:
L2xx6x:
echo '
</ul>
</div>
</div>';
echo "                  <!-- END Recent Orders Table -->";
echo "
</div>";
echo "
";
echo "
</div>";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
";
echo "
</div>";
echo "
<!-- END Page Content -->";
echo "
</main>";
echo "
<!-- END Main Container -->";
echo "
";
echo "
<!-- Footer -->";
echo "
<footer id=\"page-footer\" class=\"bg-body-light\">";
echo "
<div class=\"content py-3\">";
echo "
<div class=\"row fs-sm\">";
echo "
<div class=\"col-sm-6 order-sm-2 py-1 text-center text-sm-end\">";
echo "
Crafted with <i class=\"fa fa-heart text-danger\"></i> by <a class=\"fw-semibold\" href=\"https://qemao.com\" target=\"_blank\">苏画</a>";
echo "
</div>";
echo "
<div class=\"col-sm-6 order-sm-1 py-1 text-center text-sm-start\">";
echo "
<a class=\"fw-semibold\" href=\"https://www.qemao.com\" target=\"_blank\">LAN</a> &copy; <span data-toggle=\"year-copy\"></span>";
echo "
</div>";
echo "
</div>";
echo "
</div>";
echo "
</footer>";
echo "
<!-- END Footer -->";
echo "
</div>";
echo "
<!-- END Page Container -->";
echo "
";
echo "
<!--";
echo "
OneUI JS";
echo "
";
echo "
Core libraries and functionality";
echo "
webpack is putting everything together at assets/_js/main/app.js";
echo "
-->";
echo "
<script src=\"assets/js/oneui.app.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Plugins -->";
echo "
<script src=\"assets/js/chart.min.js\"></script>";
echo "
";
echo "
<!-- Page JS Code -->";
echo "
<script src=\"assets/js/be_pages_dashboard.min.js\"></script>";
echo "
<script>";
echo "
//审核文章事件";
echo "
;function tgwzsg() {
    ";echo "
    var ele = window.event.srcElement.lang;
    ";echo "
    var xhr = new XMLHttpRequest();
    ";echo "
    xhr.open('post', './api/escoaud.php');
    ";echo "
    xhr.setRequestHeader(\"Content-type\", \"application/x-www-form-urlencoded\");";
    echo "
    // 将数据通过send方法传递";
    echo "
    xhr.send('ztm=shwz&cs='+ele);";
    echo "
    // 发送并接受返回值";
    echo "
    xhr.onreadystatechange = function () {";
    echo "
    // 这步为判断服务器是否正确响应";
    echo "
    if (xhr.readyState == 4 && xhr.status == 200) {";
    echo "
    if (xhr.responseText == \"\") {";
    echo "
    alert(\"未获取到数据!\");";
    echo "
    return;";
    echo "
}";
echo "
//alert(xhr.responseText);";
echo "
if (xhr.responseText == \"200\") {";
echo "
var x = document.getElementById(\"sh-content-\"+ele);";
echo "
//如果对象x不为空";
echo "
if (x != null){";
echo "
x.remove();";
echo "
}";
echo "
}else{";
echo "
alert(xhr.responseText);";
echo "
}";
echo "
}";
echo "
};";
echo "
}";echo "
";echo "
//驳回文章事件";echo "
function scwzsg() {
    ";echo "
    var ele = window.event.srcElement.lang;
    ";echo "
    var xhr = new XMLHttpRequest();
    ";echo "
    xhr.open('post', './api/escoaud.php');
    ";echo "
    xhr.setRequestHeader(\"Content-type\", \"application/x-www-form-urlencoded\");";
    echo "
    // 将数据通过send方法传递";
    echo "
    xhr.send('ztm=bhwz&cs='+ele);";
    echo "
    // 发送并接受返回值";
    echo "
    xhr.onreadystatechange = function () {";
    echo "
    // 这步为判断服务器是否正确响应";
    echo "
    if (xhr.readyState == 4 && xhr.status == 200) {";
    echo "
    if (xhr.responseText == \"\") {";
    echo "
    alert(\"未获取到数据!\");";
    echo "
    return;";
    echo "
}";
echo "
//alert(xhr.responseText);";
echo "
if (xhr.responseText == \"200\") {";
echo "
var x = document.getElementById(\"sh-content-\"+ele);";
echo "
//如果对象x不为空";
echo "
if (x != null){";
echo "
x.remove();";
echo "
}";
echo "
}else{";
echo "
alert(xhr.responseText);";
echo "
}";
echo "
}";
echo "
};";
echo "
}";echo "
</script>";echo "
</body>";echo "
</html>";echo "
";function ReckonTime($time) {
    $pos=time();
    $NowTime=$pos;
    if($time>$NowTime){
        return false;
    }
    $TimePoor=$NowTime-$time;
    $num2=5834;
    $tmp=$TimePoor==0;
    if($tmp){
        $num2=9;
    }else{
        $tmp=$TimePoor<60;
        $tmp3=(bool)$tmp;
        if($tmp3){
            $tmp2=$TimePoor>0;
            $tmp3=(bool)$tmp2;
        }
        if($tmp3){
            $num2=324;
        }else{
            $tmp=$TimePoor>=60;
            $tmp4=(bool)$tmp;
            if($tmp4){
                $tmp2=3600;
                $tmp3=$TimePoor<=3600;
                $tmp4=(bool)$tmp3;
            }
            if($tmp4){
                $num2=9;
                $num2=8217;
            }else{
                $tmp=3600;
                $tmp2=$TimePoor>3600;
                $tmp5=(bool)$tmp2;
                if($tmp5){
                    $tmp3=86400;
                    $tmp4=$TimePoor<=86400;
                    $tmp5=(bool)$tmp4;
                }
                if($tmp5){
                    $num2=48;
                }else{
                    $tmp=86400;
                    $tmp2=$TimePoor>86400;
                    $tmp6=(bool)$tmp2;
                    if($tmp6){
                        $tmp3=86400;
                        $tmp4=604800;
                        $tmp5=$TimePoor<=604800;
                        $tmp6=(bool)$tmp5;
                    }
                    if($tmp6){
                        $num2=288;
                    }else{
                        $tmp=86400;
                        $tmp2=604800;
                        $tmp3=$TimePoor>604800;
                        if($tmp3){
                            $num2=256;
                        }
                    }
                }
            }
        }
    }
    $tmp=90;
    $tmp2=48;
    $tmp3=$num2==48;
if($tmp3)goto L2xeWjgx8z;
goto L2xldMhx8z;
L2xeWjgx8z:
    $num11=$TimePoor/3600;
    $pos=floor($num11);
    $str=$pos . '小时前';
goto L2xx7y;
L2xldMhx8z:
    $tmp=180;
    $tmp2=4113;
    $tmp3=$num2==4113;
if($tmp3)goto L2xeWjgx81;
goto L2xldMhx81;
L2xeWjgx81:
    $num11=$TimePoor/60;
    $pos=floor($num11);
    $str=$pos . '分钟前';
goto L2xx7y;
L2xldMhx81:
    $tmp=136;
    $tmp2=324;
    $tmp3=$num2==324;
if($tmp3)goto L2xeWjgx82;
goto L2xldMhx82;
L2xeWjgx82:
    $str=$TimePoor . '秒之前';
goto L2xx7y;
L2xldMhx82:
    $tmp=7;
    $tmp2=9;
    $tmp3=$num2==9;
if($tmp3)goto L2xeWjgx83;
goto L2xldMhx83;
L2xeWjgx83:
    $str='一眨眼之间';
goto L2xx7y;
L2xldMhx83:
    $tmp=60;
    $tmp2=288;
    $tmp3=$num2==288;
if($tmp3)goto L2xeWjgx84;
goto L2xldMhx84;
L2xeWjgx84:
    $num11=86400;
    $val2=$TimePoor/86400;
    $pos=floor($val2);
    $tmp3=$pos==1;
if($tmp3)goto L2xeWjgx7v;
goto L2xldMhx7v;
goto L2xldMhx7v;
L2xeWjgx7v:
    $str="昨天";
goto L2xx7y;
L2xldMhx7v:
    $num11=86400;
    $val2=$TimePoor/86400;
    $pos=floor($val2);
    $tmp3=$pos==2;
if($tmp3)goto L2xeWjgx7w;
goto L2xldMhx7w;
goto L2xldMhx7w;
L2xeWjgx7w:
    $str="前天";
goto L2xx7y;
L2xldMhx7w:
    $num11=86400;
    $val2=$TimePoor/86400;
    $pos=floor($val2);
    $str=$pos . '天前';
L2xldMhx84:
    switch($num2){
        case 256:{
        $pos=date("Y-m-d", $time);
        $str=$pos;
            break;
        }
    }
L2xx7y:
    return $str;
}