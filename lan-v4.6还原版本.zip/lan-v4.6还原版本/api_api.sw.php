<?php
if($_SERVER['REQUEST_METHOD']!=='POST'){
    $val["code"]="201";
    $val["msg"]="非法请求";
    $val2[]=$val;
    $arr=$val2;
    exit(json_encode($arr, JSON_UNESCAPED_UNICODE));
}
$num7=2748;
$isArray=is_array($_POST);
if($isArray){
    $num7=126;
}else{
    $num7=126;
    $num7=5250;
}
switch($num7){
    case 126:{
    $page=&$_POST['page'];
        break;
    }
    case 2688:{
        $page=$_POST['page'];
        break;
    }
}
$escaped=htmlspecialchars($page);
unset($page);
$escaped2=addslashes($escaped);
$page=$escaped2;
if($page==""){
    exit("参数为空!");
}
$tmp2=include '../config.php';
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$num3=2757;
$tmp2=$user_zh=="";
$tmp3=(bool)$tmp2;
$tmp4=!$tmp3;
if($tmp4){
    $tmp5=$user_passid=="";
    $tmp3=(bool)$tmp5;
}
if($tmp3){
    $num3=117;
}else{
    $num3=130;
}
$tmp2=120;
$tmp5=130;
$tmp3=$num3==130;
if($tmp3){
$tmp2=include '../config.php';
$tmp2=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp2;
if($conn->connect_error){
    exit("连接数据库失败");
}
$escaped=htmlspecialchars($user_zh);
$hash=addslashes($escaped);
$user_zhsg=$hash;
$tmp2="select * from user where username='" . $user_zhsg;
$sqls=$tmp2 . "'";
$queryResult=mysqli_query($conn, $sqls);
$data_results=$queryResult;
$queryResult=mysqli_fetch_array($data_results);
$data2s_row=$queryResult;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
}else{
$tmp2=304;
$tmp5=117;
$tmp3=$num3==117;
}
$tmp2=304;
$tmp5=117;
$tmp3=$num3==117;
if(!($tmp3)){
}else{
    $queryResult=session_start();
    $tmp2=new mysqli($servername,$username,$password,$dbname);
    $conn=$tmp2;
    if($conn->connect_error){
        die("连接失败: " . $conn->connect_error);
    }
    $sql="SELECT * FROM admin";
    $result=$conn->query($sql);
    $result=$result;
}
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($str))break;
    $name=$row["name"];
    $name=$row["subtitle"];
    $icon=$row["icon"];
    $logo=$row["logo"];
    $zt=$row["zt"];
    $username=$row["username"];
    $glyadmin=$row["username"];
    $homimg=$row["homimg"];
    $sign=$row["sign"];
    $essgs=$row["essgs"];
    $commgs=$row["commgs"];
    $kqsy=$row["kqsy"];
    $videoauplay=$row["videoauplay"];
}
L2xxx:
$filterpiccir="";
$sql="SELECT text FROM configx WHERE title = 'piccir'";
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0){
    $result=$result->fetch_assoc();
    $row=$result;
    $filterpiccir=$row['text'];
}
$sqly="SELECT * FROM admin";
$result=$conn->query($sqly);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($str))break;
if($row['topes']=="")goto L2xeWjgx19;
goto L2xldMhx19;
goto L2xldMhx19;
goto L2xldMhx19;
L2xeWjgx19:
    $snk=-403;
goto L2xx15;
goto L2xx18;
L2xldMhx19:
L2xx18:
    $ars=$row['topes'];
}
L2xx1g:
L2xx15:
$queryResult=explode(PHP_EOL, $ars);
$ars=$queryResult;
$dqgs=0;
$dqs=0;
$num4=2754;
$isArray=is_array($_POST);
if($isArray){
    $num4=81;
}else{
    $num4=117;
}
switch($num4){
    case 117:{
    $page=$_POST['so'];
        break;
    }
    case 81:{
        $page=&$_POST['so'];
        break;
    }
}
$escaped=htmlspecialchars($page);
unset($page);
$escaped2=addslashes($escaped);
$so=$escaped2;
$num5=2756;
$tmp2=$so!="";
$tmp3=(bool)$tmp2;
if($tmp3){
    $tmp5=$so!="null";
    $tmp3=(bool)$tmp5;
}
if($tmp3){
    $num5=130;
}else{
    $num5=100;
}
switch($num5){
    case 130:{
    $tmp2="SELECT * FROM essay where ptpaud<>'0' and ptpaud<>'-1' and ptpys<>'0' and ptptext LIKE '%" . $so;
    $sql=$tmp2 . "%' order by id desc";
        break;
    }
    case 100:{
        $sql="SELECT * FROM essay where ptpaud<>'0' and ptpaud<>'-1' and ptpys<>'0' order by id desc";
        break;
    }
}
$result=$conn->query($sql);
$result=$result;
L2xx1y:
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($str))break;
    $dqgs=$dqgs+1;
    $ptpuser=$row["ptpuser"];
    $ptpimg=$row["ptpimg"];
    $ptpname=$row["ptpname"];
    $ptptext=$row["ptptext"];
    $ptpimag=$row["ptpimag"];
    $ptpvideo=$row["ptpvideo"];
    $ptpmusic=$row["ptpmusic"];
    $ptplx=$row["ptplx"];
    $ptpdw=$row["ptpdw"];
    $ptptime=$row["ptptime"];
    $ptpgg=$row["ptpgg"];
    $ptpggurl=$row["ptpggurl"];
    $ptpys=$row["ptpys"];
    $commauth=$row["commauth"];
    $ptpaud=$row["ptpaud"];
    $ptpip=$row["ip"];
    $cid=$row["cid"];
    $wid=$row["id"];
    $queryResult=explode("|", $ptpvideo);
    $partssp=$queryResult;
    $ptpvideo=$partssp[0];
    $ptpvideofm=$partssp[1];
if($ptpys!=1)goto L2xx1y;
goto L2xldMhx24;
goto L2xldMhx24;
goto L2xldMhx24;
goto L2xx23;
L2xldMhx24:
L2xx23:
    $num6=2746;
    $tmp2=$snk=='-201-201-1';
    if($tmp2){
        $num6=130;
    }else{
        $num6=90;
    }
    $tmp2=40;
    $tmp5=90;
    $tmp3=$num6==90;
if($tmp3)goto L2xeWjgx2a;
goto L2xldMhx2a;
goto L2xldMhx2a;
goto L2xldMhx2a;
L2xeWjgx2a:
    $queryResult=in_array($wid, $ars);
if($queryResult)goto L2xx1y;
goto L2xx29;
goto L2xx29;
goto L2xx29;
goto L2xx29;
goto L2xx29;
L2xldMhx2a:
    $tmp2=42;
    $tmp5=130;
    $tmp3=$num6==130;
if($tmp3)goto L2xx29;
goto L2xldMhx2d;
L2xldMhx2d:
L2xx29:
if($dqgs>$page)goto L2xeWjgx6w;
goto L2xx1y;
goto L2xx1y;
goto L2xx1y;
L2xeWjgx6w:
    $dqs=$dqs+1;
    $tmp2=$dqs>10;
if($tmp2)goto L2xx2z;
goto L2xldMhx2h;
goto L2xldMhx2h;
goto L2xldMhx2h;
goto L2xldMhx2h;
goto L2xx2g;
L2xldMhx2h:
L2xx2g:
    $queryResult=explode('(+@+)', $ptpimag);
    $imgar=$queryResult;
    $queryResult=count($imgar);
    $coun=$queryResult;
    $tmp2=$coun==1;
    if($tmp2){
        $tusty=155;
    }else{
        $tmp2=$coun==4;
        $tmp3=(bool)$tmp2;
        $tmp4=!$tmp3;
        if($tmp4){
            $tmp5=$coun==2;
            $tmp3=(bool)$tmp5;
        }
        if($tmp3){
            $tusty=1155;
        }else{
            $tusty=111;
        }
    }
    $tmp2=$ptpgg==1;
    if($tmp2){
        $ggdiv='display: flex;';
        $tmp2='<div class="sh-content-right-ggurl"><i class="iconfont icon-lianjie1 ri-sxwzgg"></i><a href="' . $ptpggurl;
        $ggurl=$tmp2 . '" target="_blank">进一步了解</a></div>';
        $gps="";
    }else{
        $ggdiv='display: none;';
        $ggurl="";
        $tmp2='<div class="sh-content-right-gps"><a href="javascript:;">' . $ptpdw;
        $gps=$tmp2 . '</a></div>';
    }
    $queryResult=strtotime($ptptime);
    $time=$queryResult;
    $queryResult=ReckonTime($time);
    $wzfbsj=$queryResult;
    $tmp2=$ptpys==1;
    $tmp3=(bool)$tmp2;
    if($tmp3){
        $tmp5=$ptpaud==1;
        $tmp3=(bool)$tmp5;
    }
if($tmp3)goto L2xeWjgx2s;
goto L2xx1y;
goto L2xx1y;
goto L2xx1y;
goto L2xx1y;
L2xeWjgx2s:
    $str=preg_replace("/<img[^>]+>/i","",$ptptext);
    $contenttext0=$str;
    $str=preg_replace("/<span[^>]+>/i","",$contenttext0);
    $contenttext1=$str;
    $str=preg_replace("/<a href=[^>]+>/i","",$contenttext1);
    $contenttext=$str;
    $queryResult=iconv_strlen($contenttext, "UTF-8");
    $tmp2=$queryResult>100;
    if($tmp2){
        $tmp2='<span class="wzndhycyc" id="sh-content-qwdid-' . $cid;
        $tmp5=$tmp2 . '">';
        $tmp3=$tmp5 . $ptptext;
        $tmp4=$tmp3 . '</span><a href="JavaScript:;" class="sh-content-quanwenan" id="sh-content-quanwenan-';
        $tmp6=$tmp4 . $cid;
        $tmp7=$tmp6 . '" lang="0" onclick="quanwenan()">全文</a>';
        $ptptext=$tmp7;
    }else{
        $tmp2='<span>' . $ptptext;
        $ptptext=$tmp2 . '</span>';
    }
    $tmp2=$ptpname=="匿名用户";
    if($tmp2){
        $arcuserurl='';
    }else{
        $escaped=md5($ptpuser);
        $hash=md5($escaped);
        $tmp2='onclick="location.href=\'./archives.php?user=' . $hash;
        $arcuserurl=$tmp2 . '\'"';
    }
    $tmp2='
    <div class="sh-content"  id="sh-content-' . $cid;
    $tmp5=$tmp2 . '">
    <!-- 左边 -->
    <div class="sh-content-left">
    <!-- 头像 -->
    <img src="./assets/img/thumbnail.svg" data-src="';
    $tmp3=$tmp5 . $ptpimg;
    $tmp4=$tmp3 . '" alt="头像" ';
    $tmp6=$tmp4 . $arcuserurl;
    $tmp7=$tmp6 . '>
    </div>
    <!-- 右边 -->
    <div class="sh-content-right">
    <!-- 昵称与内容 -->
    <div class="sh-content-right-head">
    <!-- 昵称 -->
    <div class="sh-content-right-head-title">
    <p>';
    $tmp8=$tmp7 . $ptpname;
    $tmp9=$tmp8 . '</p>
    <div class="sh-content-right-head-title-ad" style="';
    $tmp10=$tmp9 . $ggdiv;
    $tmp11=$tmp10 . '">
    <p>广告</p>
    </div>
    </div>
    <!-- 内容 -->
    ';
    $tmp12=$tmp11 . $ptptext;
    echo $tmp12;
    $tmp2=$ptplx=="only";
if($tmp2)goto L2xeWjgx2y;
goto L2xldMhx2y;
goto L2xldMhx2y;
goto L2xldMhx2y;
goto L2xldMhx2y;
L2xeWjgx2y:
    echo '<!-- 图片 -->';
goto L2xx2x;
L2xldMhx2y:
    $tmp2=$ptplx=="img";
if($tmp2)goto L2xeWjgx3z;
goto L2xldMhx3z;
goto L2xldMhx3z;
goto L2xldMhx3z;
goto L2xldMhx3z;
L2xeWjgx3z:
    $tmp2=$coun>"1";
    if($tmp2){
        $picimg=100;
    }else{
        $picimg='';
    }
    $tmp2='<!-- 图片 -->
    <div class="sh-content-right-img" id="imglib-' . $cid;
    $tmp5=$tmp2 . '" style="';
    $tmp3=$tmp5 . $tusty;
    $tmp4=$tmp3 . '">';
    echo $tmp4;
    $str=0;
    $i=$str;
    while(true){
        $tmp2=$i<$coun;
        if(!$tmp2)break;
        $tuimg=$imgar[$i];
        $tmp2=$i>7;
if($tmp2)goto L2xeWjgx37;
goto L2xldMhx37;
goto L2xldMhx37;
goto L2xldMhx37;
goto L2xldMhx37;
goto L2xldMhx37;
L2xeWjgx37:
        $tmp2=$coun-$i;
        $duoimg=$tmp2-1;
        $tmp2=$coun>9;
if($tmp2)goto L2xeWjgx39;
goto L2xldMhx39;
goto L2xldMhx39;
goto L2xldMhx39;
goto L2xldMhx39;
goto L2xldMhx39;
L2xeWjgx39:
        $tmp2=$i==8;
if($tmp2)goto L2xeWjgx3b;
goto L2xldMhx3b;
goto L2xldMhx3b;
goto L2xldMhx3b;
goto L2xldMhx3b;
goto L2xldMhx3b;
L2xeWjgx3b:
        $tmp2='<a href="' . $tuimg;
        $tmp5=$tmp2 . '" class="sh-content-right-img-pic" data-fancybox="gallery';
        $tmp3=$tmp5 . $cid;
        $tmp4=$tmp3 . '" data-caption="">
        <span class="sh-content-right-img-pic-mask">+';
        $tmp6=$tmp4 . $duoimg;
        $tmp7=$tmp6 . '</span>
        <img src="./assets/img/thumbnail.svg" data-src="';
        $tmp8=$tmp7 . $tuimg;
        $tmp9=$tmp8 . '" alt="" ';
        $tmp10=$tmp9 . $picimg;
        $tmp11=$tmp10 . '>
        </a>';
        echo $tmp11;
goto L2xx36;
L2xldMhx3b:
        $tmp2='<a href="' . $tuimg;
        $tmp5=$tmp2 . '" class="sh-content-right-img-pic" data-fancybox="gallery';
        $tmp3=$tmp5 . $cid;
        $tmp4=$tmp3 . '" data-caption=""  style="display:none;">
        <img src="';
        $tmp6=$tmp4 . $tuimg;
        $tmp7=$tmp6 . '" data-src="';
        $tmp8=$tmp7 . $tuimg;
        $tmp9=$tmp8 . '" alt="" ';
        $tmp10=$tmp9 . $picimg;
        $tmp11=$tmp10 . '>
        </a>';
        echo $tmp11;
L2xldMhx39:
        $tmp2='<a href="' . $tuimg;
        $tmp5=$tmp2 . '" class="sh-content-right-img-pic" data-fancybox="gallery';
        $tmp3=$tmp5 . $cid;
        $tmp4=$tmp3 . '" data-caption="">
        <img src="./assets/img/thumbnail.svg" data-src="';
        $tmp6=$tmp4 . $tuimg;
        $tmp7=$tmp6 . '" alt="" ';
        $tmp8=$tmp7 . $picimg;
        $tmp9=$tmp8 . '>
        </a>';
        echo $tmp9;
L2xldMhx37:
        $tmp2='<a href="' . $tuimg;
        $tmp5=$tmp2 . '" class="sh-content-right-img-pic" data-fancybox="gallery';
        $tmp3=$tmp5 . $cid;
        $tmp4=$tmp3 . '" data-caption="">
        <img src="./assets/img/thumbnail.svg" data-src="';
        $tmp6=$tmp4 . $tuimg;
        $tmp7=$tmp6 . '" alt="" ';
        $tmp8=$tmp7 . $picimg;
        $tmp9=$tmp8 . '>
        </a>';
        echo $tmp9;
L2xx36:
        $obj=$i;
        $obj2=$i+1;
        $str=$obj2;
        $i=$str;
    }
    echo '</div>';
goto L2xx2x;
L2xldMhx3z:
    $tmp2=$ptplx=="video";
if($tmp2)goto L2xeWjgx3k;
goto L2xldMhx3k;
goto L2xldMhx3k;
goto L2xldMhx3k;
goto L2xldMhx3k;
L2xeWjgx3k:
    $tmp2=$videoauplay==1;
    if($tmp2){
        $videobf='autoplay';
        $videobfplas='';
    }else{
        $videobf='';
        $tmp2='<i class="iconfont icon-sa4f56" id="sh-content-video-videobfb-' . $cid;
        $tmp5=$tmp2 . '" style="width: fit-content;height: fit-content;grid-column: 1;grid-row: 1;z-index: 5;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);font-size: 40px;color: #ffffff;display: flex;cursor: pointer;padding: 15px;pointer-events: none;"></i>';
        $videobfplas=$tmp5;
    }
    $tmp2=$filterpiccir==1;
    if($tmp2){
        $vidoyuan=1;
    }else{
        $vidoyuan=0;
    }
    $tmp2='
    <!-- 视频 -->
    <div class="sh-video" id="sh-content-video-' . $cid;
    $tmp5=$tmp2 . '" onclick="videofdgb()" lang="0">
    <video name="sh-videokid" class="sh-content-video" data-ybs="';
    $tmp3=$tmp5 . $vidoyuan;
    $tmp4=$tmp3 . '" poster="';
    $tmp6=$tmp4 . $ptpvideofm;
    $tmp7=$tmp6 . '" id="sh-content-videok-';
    $tmp8=$tmp7 . $cid;
    $tmp9=$tmp8 . '" src="';
    $tmp10=$tmp9 . $ptpvideo;
    $tmp11=$tmp10 . '" playsinline webkit-playsinline preload="metadata" ';
    $tmp12=$tmp11 . $videobf;
    $tmp13=$tmp12 . ' muted loop onclick="videofd()" lang="0" disablePictureInPicture="true" controlslist="nodownload nofullscreen noremoteplayback"></video>
    ';
    $tmp14=$tmp13 . $videobfplas;
    $tmp15=$tmp14 . '
    <i class="iconfont icon-quxiao" id="sh-content-videog-';
    $tmp16=$tmp15 . $cid;
    $tmp17=$tmp16 . '" lang="0"></i>
    <span class="sh-video-span" id="sh-video-span-';
    $tmp18=$tmp17 . $cid;
    $tmp19=$tmp18 . '">MP4</span>
    </div>
    ';
    echo $tmp19;
goto L2xx2x;
L2xldMhx3k:
    $tmp2=$ptplx=="music";
if($tmp2)goto L2xeWjgx3p;
goto L2xldMhx3p;
goto L2xldMhx3p;
goto L2xldMhx3p;
goto L2xldMhx3p;
L2xeWjgx3p:
    echo '<!-- 音乐 -->';
    $queryResult=is_numeric($ptpmusic);
if($queryResult)goto L2xx2x;
goto L2xldMhx3r;
goto L2xldMhx3r;
L2xldMhx3r:
    $queryResult=explode('|', $ptpmusic);
    $mus=$queryResult;
    $tmp2=include "../site/musicplay.php";
L2xldMhx3p:
    $tmp2=$ptplx=="mony";
if($tmp2)goto L2xeWjgx3s;
goto L2xldMhx3s;
goto L2xldMhx3s;
goto L2xldMhx3s;
goto L2xldMhx3s;
L2xeWjgx3s:
    $tmp2="SELECT * FROM money WHERE ptpmoncid = '" . $cid;
    $sql01=$tmp2 . "'";
    $result=$conn->query($sql01);
    $result01=$result;
    $tmp2=$result01->num_rows>0;
if($tmp2)goto L2xeWjgx3u;
goto L2xx2x;
goto L2xx2x;
goto L2xx2x;
goto L2xx2x;
L2xeWjgx3u:
    while(true){
        $result=$result01->fetch_assoc();
        $row01=$result;
        if(!$str)break;
        $muser=$row01["muser"];
        $type=$row01["type"];
        $zsum=$row01["zsum"];
        $sum=$row01["sum"];
        $total=$row01["total"];
        $recve=$row01["recve"];
        $luser=$row01["luser"];
        $montext=$row01["montext"];
        $monimg=$row01["monimg"];
        $ptpmoncid=$row01["ptpmoncid"];
    }
    $tmp2=$monimg=="";
    if($tmp2){
        $monimg='';
    }else{
        $tmp2='background-image: url(' . $monimg;
        $monimg=$tmp2 . ');';
    }
    $tmp2=$recve<1;
    $tmp3=(bool)$tmp2;
    $tmp4=!$tmp3;
    if($tmp4){
        $tmp5=$sum<0.01;
        $tmp3=(bool)$tmp5;
    }
    if($tmp3){
        $hongbtm="opacity: 0.6;";
        $str='onclick="monyk()"';
        $hongbshij=$str;
        $ptpmoncid='';
    }else{
        $hongbtm="";
        $str='onclick="monyk()"';
        $hongbshij=$str;
    }
    $queryResult=explode(PHP_EOL, $luser);
    $lines=$queryResult;
    unset($tmp);
    foreach($lines as $line){$tmp[]=$line;
}
$tmp20=0;
while(true){
    $queryResult=count($tmp);
    $tmp2=$tmp20<$queryResult;
    if(!$tmp2)break;
    $keys=array_keys($tmp);
    $keys=$keys[$tmp20];
    $line=$tmp[$keys];
    $queryResult=explode("|", $line);
    $parts=$queryResult;
    $before_pipe=$parts[0];
    $after_pipe=$parts[1];
    $tmp2=$before_pipe==$user_zh;
    if($tmp2){
        $hongbtm="opacity: 0.6;";
        $str='onclick="monyk()"';
        $hongbshij=$str;
        $ptpmoncid=-1;
    }
    $tmp20=$tmp20+1;
}
L2xx4d:
$tmp2=$user_zh=="";
$tmp3=(bool)$tmp2;
$tmp4=!$tmp3;
if($tmp4){
    $tmp5=$user_passid=="";
    $tmp3=(bool)$tmp5;
}
if($tmp3)goto L2xeWjgx4k;
goto L2xldMhx4k;
goto L2xldMhx4k;
goto L2xldMhx4k;
goto L2xldMhx4k;
L2xeWjgx4k:
$tmp2=$recve<1;
$tmp3=(bool)$tmp2;
$tmp4=!$tmp3;
if($tmp4){
    $tmp5=$sum<0.01;
    $tmp3=(bool)$tmp5;
}
if($tmp3)goto L2xeWjgx4o;
goto L2xldMhx4o;
goto L2xldMhx4o;
goto L2xldMhx4o;
goto L2xldMhx4o;
L2xeWjgx4o:
$hongbtm="opacity: 0.6;";
$str='onclick="monyk()"';
$hongbshij=$str;
$ptpmoncid=-1;
goto L2xx4h;
L2xldMhx4o:
$hongbtm="";
$str='onclick="monyk()"';
$hongbshij=$str;
$ptpmoncid=-1;
L2xldMhx4k:
L2xx4h:
$tmp2='<div id="sh-redpacket-content" class="sh-redpacket-content" style="' . $hongbtm;
$tmp5=$tmp2 . '">
<div class="sh-redpacket-content-space">
<div class="sh-space-up">
<!-- 上部分圆角框架 背景-->
<div class="sh-space-up-space" style="';
$tmp3=$tmp5 . $monimg;
$tmp4=$tmp3 . '">
<div class="sh-space-up-space-logo"><img src="./assets/img/logogolden.svg" data-src="./assets/img/logogolden.svg"></div>
<div class="sh-space-up-space-title"><span>';
$tmp6=$tmp4 . $montext;
$tmp7=$tmp6 . '</span></div>
</div>
</div>
<div class="sh-space-dw">
<div class="sh-space-dw-btnk"><span class="sh-space-dw-btn" id="sh-space-dw-btn-';
$tmp8=$tmp7 . $cid;
$tmp9=$tmp8 . '" lang="';
$tmp10=$tmp9 . $ptpmoncid;
$tmp11=$tmp10 . '" ';
$tmp12=$tmp11 . $hongbshij;
$tmp13=$tmp12 . '>领</span></div>
</div>
</div>
</div>';
echo $tmp13;
goto L2xx2x;
L2xldMhx3s:
L2xx2x:
echo '
</div>
<!-- 地址 -->';
$tmp2=$ptpdw!="";
if($tmp2){
    echo $gps;
}
echo '<!--广告-->';
echo $ggurl;
$tmp2="select * from lcke where lwz= '" . $cid;
$sql2b=$tmp2 . "'";
$queryResult=mysqli_query($conn, $sql2b);
$result2b=$queryResult;
$queryResult=mysqli_num_rows($result2b);
$tmp2=$queryResult>0;
if($tmp2)goto L2xeWjgx4s;
goto L2xldMhx4s;
goto L2xldMhx4s;
goto L2xldMhx4s;
goto L2xldMhx4s;
L2xeWjgx4s:
$sql2a="SELECT * FROM lcke";
$result=$conn->query($sql2a);
$result2a=$result;
while(true){
    while(true){
        $result=$result2a->fetch_assoc();
        $row2a=$result;
        if(!$str)break;
        $tmp2=$row2a['lwz']==$cid;
        if(!$tmp2)break;
        $dianzmlnr=$row2a['luser'];
        $tmp2=$user_zh=="";
        $tmp3=(bool)$tmp2;
        $tmp4=!$tmp3;
        if($tmp4){
            $tmp5=$user_passid=="";
            $tmp3=(bool)$tmp5;
        }
if($tmp3)goto L2xeWjgx51;
goto L2xldMhx51;
goto L2xldMhx51;
goto L2xldMhx51;
goto L2xldMhx51;
goto L2xldMhx51;
L2xeWjgx51:
        $tmp2=$dianzmlnr==$_SESSION['visykmz_userip'];
if($tmp2)goto L2xeWjgx53;
goto L2xldMhx53;
goto L2xldMhx53;
goto L2xldMhx53;
goto L2xldMhx53;
goto L2xldMhx53;
L2xeWjgx53:
        $dianzmlnr="取消";
        $dianzmlimg="iconfont icon-aixin2 ri-sxdzlikehs";
goto L2xx4r;
    }
L2xldMhx53:
    $dianzmlnr="赞";
    $dianzmlimg="iconfont icon-aixin ri-sxdzlike";
L2xldMhx51:
    $tmp2=$dianzmlnr==$user_zh;
if($tmp2)goto L2xeWjgx55;
goto L2xldMhx55;
goto L2xldMhx55;
goto L2xldMhx55;
goto L2xldMhx55;
goto L2xldMhx55;
L2xeWjgx55:
    $dianzmlnr="取消";
    $dianzmlimg="iconfont icon-aixin2 ri-sxdzlikehs";
goto L2xx4r;
}
L2xldMhx55:
$dianzmlnr="赞";
$dianzmlimg="iconfont icon-aixin ri-sxdzlike";
goto L2xx4r;
L2xldMhx4s:
$dianzmlnr="赞";
$dianzmlimg="iconfont icon-aixin ri-sxdzlike";
L2xx4r:
$tmp2=$commauth==1;
if($tmp2){
    $tmp2='
    <div class="sh-content-right-time-right-left-y" id="' . $cid;
    $tmp5=$tmp2 . '" onclick="plkkg()">
    <i class="iconfont icon-pinglun2 ri-sxdzcomm"></i>
    <span>评论</span>
    </div>
    ';
    $gwzkplzt=$tmp5;
}else{
    $tmp2='
    <div class="sh-content-right-time-right-left-y" id="' . $cid;
    $tmp5=$tmp2 . '">
    <i class="iconfont icon-pinglun2 ri-sxdzcomm"></i>
    <span>评论关闭</span>
    </div>
    ';
    $gwzkplzt=$tmp5;
}
$tmp2='
<!-- 时间与点赞 -->
<div class="sh-content-right-time">
<!-- 时间 -->
<a class="sh-content-right-time-left" href="./view.php?cid=' . $cid;
$tmp5=$tmp2 . '" target="_blank"><span>';
$tmp3=$tmp5 . $wzfbsj;
$tmp4=$tmp3 . '</span></a>
<!-- 点赞 -->
<div class="sh-content-right-time-right">
<!-- 左边合集 -->
<div class="sh-content-right-time-right-left" id="pl-';
$tmp6=$tmp4 . $cid;
$tmp7=$tmp6 . '" name="pl">
<div class="sh-content-right-time-right-left-z" onclick="dinazan()">
<i class="';
$tmp8=$tmp7 . $dianzmlimg;
$tmp9=$tmp8 . '" id="tiezimg-';
$tmp10=$tmp9 . $cid;
$tmp11=$tmp10 . '"></i>
<span id="tiezdz-';
$tmp12=$tmp11 . $cid;
$tmp13=$tmp12 . '">';
$tmp14=$tmp13 . $dianzmlnr;
$tmp15=$tmp14 . '</span>
</div>
<p></p>
';
$tmp16=$tmp15 . $gwzkplzt;
$tmp17=$tmp16 . '
</div>
<!-- 右边点赞控制按钮 -->
<div class="sh-content-right-time-right-right" id="';
$tmp18=$tmp17 . $cid;
$tmp19=$tmp18 . '" onclick="plk()">
<p class="zp1"></p>
<p></p>
</div>
</div>
</div>
<!-- 点赞列表与评论 -->
<div class="sh-zanp" id="zanss-';
$tmp21=$tmp19 . $cid;
$tmp22=$tmp21 . '">
';
echo $tmp22;
$tmp2="select * from lcke where lwz= '" . $cid;
$sql2=$tmp2 . "'";
$queryResult=mysqli_query($conn, $sql2);
$result2=$queryResult;
$queryResult=mysqli_num_rows($result2);
$tmp2=$queryResult>0;
if($tmp2)goto L2xeWjgx5l;
goto L2xldMhx5l;
goto L2xldMhx5l;
goto L2xldMhx5l;
goto L2xldMhx5l;
L2xeWjgx5l:
$tmp2='
<!-- 点赞列表 -->
<div class="sh-zanp-zan" id="zans-' . $cid;
$tmp5=$tmp2 . '">
<!-- 左侧点赞图标 -->
<div class="sh-zanp-zan-left"><!--img src="./assets/img/likel.svg" alt=""--><i class="iconfont icon-aixin ri-sxwzlike"></i></div>
<!-- 右边点赞名列表 -->
<ul class="sh-zanp-zan-right" id="zlbeh-';
$tmp3=$tmp5 . $cid;
$tmp4=$tmp3 . '">
';
echo $tmp4;
$iw=0;
$dwys=0;
while(true){
    while(true){
        $queryResult=mysqli_fetch_assoc($result2);
        $row2=$queryResult;
        if(!$str)break;
        $dianzmys=$row2["luser"];
        $queryResult=strpos($dianzmys, 'vis#-[');
        $tmp2=$queryResult!==false;
        $tmp3=(bool)$tmp2;
        $tmp4=!$tmp3;
        if($tmp4){
            $hash=strpos($dianzmys, ']-#vis');
            $tmp5=$hash!==false;
            $tmp3=(bool)$tmp5;
        }
        if(!$tmp3)break;
        $obj2=$dwys;
        $dwys=$dwys+1;
    }
    $obj3=$iw;
    $iw=$iw+1;
    $dianzms=$row2["lname"];
    $tmp2='<li id="zan-' . $cid;
    $tmp5=$tmp2 . '" lang="';
    $tmp3=$tmp5 . $dianzms;
    $tmp4=$tmp3 . '">';
    $tmp6=$tmp4 . $dianzms;
    $tmp7=$tmp6 . '</li>';
    echo $tmp7;
}
L2xx5s:
$tmp2=$dwys!=0;
if($tmp2){
    $tmp2='<li id="fkzan-' . $cid;
    $tmp5=$tmp2 . '">';
    $tmp3=$tmp5 . $dwys;
    $tmp4=$tmp3 . '位访客</li>';
    echo $tmp4;
}
echo '
</ul>
</div>
';
goto L2xx5k;
L2xldMhx5l:
$tmp2='
<!-- 点赞列表 -->
<div class="sh-zanp-zan" id="zans-' . $cid;
$tmp5=$tmp2 . '" style="display:none;">
<!-- 左侧点赞图标 -->
<div class="sh-zanp-zan-left"><i class="iconfont icon-aixin ri-sxwzlike"></i></div>
<!-- 右边点赞名列表 -->
<ul class="sh-zanp-zan-right" id="zlbeh-';
$tmp3=$tmp5 . $cid;
$tmp4=$tmp3 . '">
</ul>
</div>
';
echo $tmp4;
L2xx5k:
echo '
<!-- 评论列表 -->';
$tmp2="select * from comm where wzcid= '" . $cid;
$sql3=$tmp2 . "' and comaud<>'0' and comaud<>'-1'";
$queryResult=mysqli_query($conn, $sql3);
$result3=$queryResult;
$pls=0;
$queryResult=mysqli_num_rows($result3);
$tmp2=$queryResult>0;
if($tmp2)goto L2xeWjgx62;
goto L2xldMhx62;
goto L2xldMhx62;
goto L2xldMhx62;
goto L2xldMhx62;
L2xeWjgx62:
$tmp2='<ul class="sh-zanp-pl" id="sh-zanp-pl-' . $cid;
$tmp5=$tmp2 . '">';
echo $tmp5;
while(true){
    $queryResult=mysqli_fetch_assoc($result3);
    $row3=$queryResult;
    if(!$str)break;
    $pls=$pls+1;
    $tmp2=$pls>$commgs;
if($tmp2)goto L2xeWjgx66;
goto L2xldMhx66;
goto L2xldMhx66;
goto L2xldMhx66;
goto L2xldMhx66;
goto L2xldMhx66;
L2xeWjgx66:
    $pls=$pls-1;
    $plgd="display:flex";
goto L2xx64;
goto L2xx65;
L2xldMhx66:
    $plgd="display:none";
L2xx65:
    $couser=$row3["couser"];
    $coname=$row3["coname"];
    $courl=$row3["courl"];
    $cotext=$row3["cotext"];
    $bcouser=$row3["bcouser"];
    $bconame=$row3["bconame"];
    $comaud=$row3["comaud"];
    $tmp2=$comaud!=1;
    if($tmp2){
        $cotext="该条评论未通过审核!";
    }
    $tmp2=$courl=="";
    if($tmp2){
        $plzwze='';
    }else{
        $tmp2='href="' . $courl;
        $plzwze=$tmp2 . '" style="pointer-events: all;"';
    }
    $tmp2=$commauth==1;
    if($tmp2){
        $str='onclick="plhuifu()"';
        $pldjhf=$str;
    }else{
        $pldjhf='';
    }
    $tmp2=$bcouser=="false";
    $tmp3=(bool)$tmp2;
    $tmp4=!$tmp3;
    if($tmp4){
        $tmp5=$bconame=="false";
        $tmp3=(bool)$tmp5;
    }
if($tmp3)goto L2xeWjgx6g;
goto L2xldMhx6g;
goto L2xldMhx6g;
goto L2xldMhx6g;
goto L2xldMhx6g;
goto L2xldMhx6g;
L2xeWjgx6g:
    $tmp2='
    <li lang="' . $coname;
    $tmp5=$tmp2 . '" ';
    $tmp3=$tmp5 . $pldjhf;
    $tmp4=$tmp3 . ' id="';
    $tmp6=$tmp4 . $cid;
    $tmp7=$tmp6 . '" value="';
    $tmp8=$tmp7 . $couser;
    $tmp9=$tmp8 . '" data-comkzt="0">
    <div class="sh-zanp-pl-n">
    <a ';
    $tmp10=$tmp9 . $plzwze;
    $tmp11=$tmp10 . ' class="sh-zanp-pl-n-nc" onclick="hfljurl()" target="_blank">';
    $tmp12=$tmp11 . $coname;
    $tmp13=$tmp12 . '</a>：
    <span class="sh-zanp-pl-n-nr">';
    $tmp14=$tmp13 . $cotext;
    $tmp15=$tmp14 . '</span>
    </div>
    </li>
    ';
    echo $tmp15;
}
L2xldMhx6g:
$tmp2='
<li lang="' . $coname;
$tmp5=$tmp2 . '" ';
$tmp3=$tmp5 . $pldjhf;
$tmp4=$tmp3 . ' id="';
$tmp6=$tmp4 . $cid;
$tmp7=$tmp6 . '" value="';
$tmp8=$tmp7 . $couser;
$tmp9=$tmp8 . '" data-comkzt="0">
<div class="sh-zanp-pl-n">
<a ';
$tmp10=$tmp9 . $plzwze;
$tmp11=$tmp10 . ' class="sh-zanp-pl-n-nc" onclick="hfljurl()" target="_blank">';
$tmp12=$tmp11 . $coname;
$tmp13=$tmp12 . '</a>
<span>回复</span>
<span class="sh-zanp-pl-n-nc">';
$tmp14=$tmp13 . $bconame;
$tmp15=$tmp14 . '</span>：
<span class="sh-zanp-pl-n-nr">';
$tmp16=$tmp15 . $cotext;
$tmp17=$tmp16 . '</span>
</div>
</li>
';
echo $tmp17;
L2xx64:
echo '</ul>';
goto L2xx61;
L2xldMhx62:
$plgd="display:none";
$tmp2='<ul class="sh-zanp-pl" id="sh-zanp-pl-' . $cid;
$tmp5=$tmp2 . '" style="display:none;"></ul>';
echo $tmp5;
L2xx61:
$tmp2='
<!-- 显示更多评论 -->
<div class="sh-zanp-pl-ku">
<a href="./view.php?cid=' . $cid;
$tmp5=$tmp2 . '" target="_blank" class="sh-zanp-pl-gd" style="';
$tmp3=$tmp5 . $plgd;
$tmp4=$tmp3 . '">
<p class="zp1"></p>
<p class="zp1"></p>
<p></p>
</a>
</div>
</div>
</div>
</div>
';
echo $tmp4;
}
L2xxdq:
L2xx2z:
$result=$conn->close();
$tmp2=include '../config.php';
$tmp2=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp2;
if($conn->connect_error){
    die("连接失败: " . $conn->connect_error);
}
$str="Select count(*) as AllNum from essay where ptpaud<>'0' and ptpaud<>'-1' and ptpys<>'0'";
$Query=$str;
$queryResult=mysqli_query($conn, $Query);
$str=$queryResult;
$a=$str;
$queryResult=mysqli_fetch_assoc($a);
$str=$queryResult;
$b=$str;
$shujukts=$b['AllNum'];
$xyts=$dqgs;
$num=2753;
$tmp2=$dqgs==$shujukts;
if($tmp2){
    $num=90;
}else{
    $num=100;
}
switch($num){
    case 90:{
    $dqgqsa=$shujukts;
        break;
    }
    case 100:{
        $dqgqsa=$dqgs-1;
        break;
    }
}
$result=$conn->close();
$tmp2='8965896582315263skfjskfjsgdfgdgddjskdjgdsdsjhd' . $dqgqsa;
$tmp5=$tmp2 . 'fedfrtgg6h5j8u5j5d45hgd5s4fh5sd5gdf8w5dss48sd1fds56ds156';
echo $tmp5;function ReckonTime($time) {
    $queryResult=time();
    $NowTime=$queryResult;
    if($time>$NowTime){
        return false;
    }
    $TimePoor=$NowTime-$time;
    $num2=5842;
    $tmp2=$TimePoor==0;
    if($tmp2){
        $num2=132;
    }else{
        $tmp2=$TimePoor<60;
        $tmp3=(bool)$tmp2;
        if($tmp3){
            $tmp5=$TimePoor>0;
            $tmp3=(bool)$tmp5;
        }
        if($tmp3){
            $num2=144;
        }else{
            $tmp2=$TimePoor>=60;
            $tmp4=(bool)$tmp2;
            if($tmp4){
                $tmp5=3600;
                $tmp3=$TimePoor<=3600;
                $tmp4=(bool)$tmp3;
            }
            if($tmp4){
                $num2=121;
            }else{
                $tmp2=3600;
                $tmp5=$TimePoor>3600;
                $tmp6=(bool)$tmp5;
                if($tmp6){
                    $tmp3=86400;
                    $tmp4=$TimePoor<=86400;
                    $tmp6=(bool)$tmp4;
                }
                if($tmp6){
                    $num2=216;
                }else{
                    $tmp2=86400;
                    $tmp5=$TimePoor>86400;
                    $tmp7=(bool)$tmp5;
                    if($tmp7){
                        $tmp3=86400;
                        $tmp4=604800;
                        $tmp6=$TimePoor<=604800;
                        $tmp7=(bool)$tmp6;
                    }
                    if($tmp7){
                        $num2=72;
                    }else{
                        $tmp2=86400;
                        $tmp5=604800;
                        $tmp3=$TimePoor>604800;
                        if($tmp3){
                            $num2=216;
                            $num2=6582;
                        }
                    }
                }
            }
        }
    }
    $tmp2=196;
    $tmp5=3399;
    $tmp3=$num2==3399;
if($tmp3)goto L2xeWjgxib;
goto L2xldMhxib;
L2xeWjgxib:
    $queryResult=date("Y-m-d", $time);
    $str=$queryResult;
goto L2xxia;
L2xldMhxib:
    $tmp2=20;
    $tmp5=216;
    $tmp3=$num2==216;
if($tmp3)goto L2xeWjgxic;
goto L2xldMhxic;
L2xeWjgxic:
    $num8=$TimePoor/3600;
    $queryResult=floor($num8);
    $str=$queryResult . '小时前';
goto L2xxia;
L2xldMhxic:
    $tmp2=121;
    $tmp5=121;
    $tmp3=$num2==121;
if($tmp3)goto L2xeWjgxid;
goto L2xldMhxid;
L2xeWjgxid:
    $num8=$TimePoor/60;
    $queryResult=floor($num8);
    $str=$queryResult . '分钟前';
goto L2xxia;
L2xldMhxid:
    $tmp2=51;
    $tmp5=144;
    $tmp3=$num2==144;
if($tmp3)goto L2xeWjgxie;
goto L2xldMhxie;
L2xeWjgxie:
    $str=$TimePoor . '秒之前';
goto L2xxia;
L2xldMhxie:
    $tmp2=12;
    $tmp5=132;
    $tmp3=$num2==132;
if($tmp3)goto L2xeWjgxif;
goto L2xldMhxif;
L2xeWjgxif:
    $str='一眨眼之间';
goto L2xxia;
L2xldMhxif:
    $tmp2=198;
    $tmp5=72;
    $tmp3=$num2==72;
if($tmp3)goto L2xeWjgxig;
goto L2xldMhxig;
L2xeWjgxig:
    $num8=86400;
    $val3=$TimePoor/86400;
    $queryResult=floor($val3);
    $tmp3=$queryResult==1;
if($tmp3)goto L2xeWjgxi7;
goto L2xldMhxi7;
goto L2xldMhxi7;
L2xeWjgxi7:
    $str="昨天";
goto L2xxia;
L2xldMhxi7:
    $num8=86400;
    $val3=$TimePoor/86400;
    $queryResult=floor($val3);
    $tmp3=$queryResult==2;
if($tmp3)goto L2xeWjgxi8;
goto L2xldMhxi8;
goto L2xldMhxi8;
L2xeWjgxi8:
    $str="前天";
goto L2xxia;
L2xldMhxi8:
    $num8=86400;
    $val3=$TimePoor/86400;
    $queryResult=floor($val3);
    $str=$queryResult . '天前';
L2xldMhxig:
L2xxia:
    return $str;
}