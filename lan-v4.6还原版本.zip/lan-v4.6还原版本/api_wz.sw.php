<?php
$user_zh=$_COOKIE["username"];
$user_passid=$_COOKIE["passid"];
$num6=8000;
$tmp2=$user_zh=="";
$tmp3=(bool)$tmp2;
$tmp4=!$tmp3;
if($tmp4){
    $tmp5=$user_passid=="";
    $tmp3=(bool)$tmp5;
}
if($tmp3){
    $num6=198;
}else{
    $num6=162;
}
switch($num6){
    case 162:{
    $userdlzt=1;
        break;
    }
    case 198:{
        $userdlzt=0;
        break;
    }
}
$tmp2=new mysqli($servername,$username,$password,$dbname);
$conn=$tmp2;
if($conn->connect_error){
    exit("连接数据库失败");
}
$currentTime=htmlspecialchars($user_zh);
$cookieResult=addslashes($currentTime);
$user_zhsg=$cookieResult;
$tmp2="select * from user where username='" . $user_zhsg;
$sqls=$tmp2 . "'";
$fileExists=mysqli_query($conn, $sqls);
$data_results=$fileExists;
$fileExists=mysqli_fetch_array($data_results);
$data2s_row=$fileExists;
$user_zh=$data2s_row["username"];
$user_name=$data2s_row["name"];
$user_img=$data2s_row["img"];
$user_url=$data2s_row["url"];
if(!isset($iteace)){
    exit("请设置状态!");
}
$num2=8000;
$tmp2=$iteace=='0';
if($tmp2){
    $num2=110;
}else{
    $tmp2=$iteace=='1';
    if($tmp2){
        $num2=162;
    }else{
        $tmp2=$iteace=='2';
        if($tmp2){
            $num2=360;
        }else{
            $num2=198;
        }
    }
}
$tmp2=288;
$tmp5=198;
$tmp3=$num2==198;
if($tmp3)goto L2xeWjgx1e;
goto L2xldMhx1e;
L2xeWjgx1e:
exit("状态错误!");
goto L2xx1d;
L2xldMhx1e:
$tmp2=48;
$tmp5=360;
$tmp3=$num2==360;
if($tmp3)goto L2xeWjgx1f;
goto L2xldMhx1f;
L2xeWjgx1f:
$auth_keylocation='../api/key.php';
$auth_keyauth='../api/auth.php';
$fileExists=file_exists($auth_keyauth);
if($fileExists)goto L2xeWjgx18;
goto L2xldMhx18;
goto L2xldMhx18;
L2xeWjgx18:
$tmp2=require $auth_keyauth;
$tmp2=!defined("sh_auth_state");
if($tmp2){
    exit('授权验证失败,请确保文件完整且未篡改!');
}
$tmp2=sh_auth_state!="ok";
if($tmp2)goto L2xeWjgx1c;
goto L2xx1d;
goto L2xx1d;
L2xeWjgx1c:
exit('程序未授权,您的请求已被拒绝,请授权后使用!');
goto L2xx1d;
L2xldMhx18:
exit("授权验证文件不存在或被篡改,请确保文件完整且未篡改!");
L2xldMhx1f:
$tmp2=36;
$tmp5=162;
$tmp3=$num2==162;
if($tmp3)goto L2xeWjgx1m;
goto L2xldMhx1m;
L2xeWjgx1m:
$fileExists=is_dir('../install');
if($fileExists)goto L2xeWjgxu;
goto L2xldMhxu;
goto L2xldMhxu;
L2xeWjgxu:
$fileExists=is_file('../install/ins.bak');
$tmp2=!$fileExists;
if($tmp2)goto L2xeWjgxw;
goto L2xxt;
goto L2xxt;
L2xeWjgxw:
exit('请先安装程序！<a href="../install/">点击安装</a>');
goto L2xxt;
L2xldMhxu:
L2xxt:
$fileExists=is_file('../config.php');
$tmp2=!$fileExists;
if($tmp2){
    exit('未检测到配置文件：<span style="color: red;">config.php</span>，若您是首次使用请先进行安装,删除文件夹 <span style="color: red;">[install/]</span> 下的 <span style="color: red;">[ins.bak]</span> 文件后进行安装。');
}
$auth_keylocation='../api/key.php';
$auth_keyauth='../api/auth.php';
$fileExists=file_exists($auth_keyauth);
if($fileExists)goto L2xeWjgx11;
goto L2xldMhx11;
goto L2xldMhx11;
L2xeWjgx11:
$tmp2=require $auth_keyauth;
$tmp2=!defined("sh_auth_state");
if($tmp2){
    exit('授权验证失败,请确保文件完整且未篡改!');
}
$tmp2=sh_auth_state!="ok";
if($tmp2)goto L2xeWjgx15;
goto L2xx1d;
goto L2xx1d;
L2xeWjgx15:
$fileExists=header("Location: authver.php?condition=error");
exit();
goto L2xx1d;
L2xldMhx11:
exit("授权验证文件不存在或被篡改,请确保文件完整且未篡改!");
L2xldMhx1m:
$tmp2=104;
$tmp5=110;
$tmp3=$num2==110;
if($tmp3)goto L2xeWjgx2z;
goto L2xldMhx2z;
L2xeWjgx2z:
$fileExists=is_dir('./install');
if($fileExists)goto L2xeWjgxj;
goto L2xldMhxj;
goto L2xldMhxj;
L2xeWjgxj:
$fileExists=is_file('./install/ins.bak');
$tmp2=!$fileExists;
if($tmp2)goto L2xeWjgxl;
goto L2xxi;
goto L2xxi;
L2xeWjgxl:
exit('请先安装程序！<a href="./install/">点击安装</a>');
goto L2xxi;
L2xldMhxj:
L2xxi:
$fileExists=is_file('./config.php');
$tmp2=!$fileExists;
if($tmp2){
    exit('未检测到配置文件：<span style="color: red;">config.php</span>，若您是首次使用请先进行安装,删除文件夹 <span style="color: red;">[install/]</span> 下的 <span style="color: red;">[ins.bak]</span> 文件后进行安装。');
}
$auth_keylocation='./api/key.php';
$auth_keyauth='./api/auth.php';
$fileExists=file_exists($auth_keyauth);
if($fileExists)goto L2xeWjgxp;
goto L2xldMhxp;
goto L2xldMhxp;
L2xeWjgxp:
$tmp2=require $auth_keyauth;
$tmp2=!defined("sh_auth_state");
if($tmp2)goto L2xeWjgxr;
goto L2xx1d;
goto L2xx1d;
L2xeWjgxr:
exit('授权验证失败,请确保文件完整且未篡改!');
goto L2xx1d;
L2xldMhxp:
exit("授权验证文件不存在或被篡改,请确保文件完整且未篡改!");
L2xldMhx2z:
L2xx1d:
if(!isset($_COOKIE['dark_theme'])){
    $fileExists=setcookie('dark_theme', 'root', '/');
}
$sql="SELECT * FROM admin";
$result=$conn->query($sql);
$result=$result;
while(true){
    $result=$result->fetch_assoc();
    $row=$result;
    if(!($sentinel))break;
    $name=$row["name"];
    $subtitle=$row["subtitle"];
    $icon=$row["icon"];
    $logo=$row["logo"];
    $zt=$row["zt"];
    $username=$row["username"];
    $glyadmin=$row["username"];
    $homimg=$row["homimg"];
    $sign=$row["sign"];
    $wzmusic=$row["music"];
    $essgs=$row["essgs"];
    $commgs=$row["commgs"];
    $lnkzt=$row["lnkzt"];
    $regqx=$row["regqx"];
    $kqsy=$row["kqsy"];
    $comaud=$row["comaud"];
    $ptpaud=$row["ptpaud"];
    $ptpfan=$row["ptpfan"];
    $loginkg=$row["loginkg"];
    $notname=$row["notname"];
    $imgpres=$row["imgpres"];
    $rosdomain=$row["rosdomain"];
    $daymode=$row["daymode"];
    $gotop=$row["gotop"];
    $search=$row["search"];
    $videoauplay=$row["videoauplay"];
    $regverify=$row["regverify"];
    $pagepass=$row["pagepass"];
    $emydz=$row["emydz"];
    $emssl=$row["emssl"];
    $emduk=$row["emduk"];
    $emkey=$row["emkey"];
    $emzh=$row["emzh"];
    $emfs=$row["emfs"];
    $emfszm=$row["emfszm"];
    $copyright=$row["copyright"];
    $beian=$row["beian"];
    $topes=$row["topes"];
    $scfont=$row["scfont"];
    $viscomm=$row["viscomm"];
    $musplay=$row["musplay"];
    $sigin=$row["sigin"];
    $rnking=$row["rnking"];
    $rnggy=$row["rnggy"];
    $dywptp=$row["dywptp"];
    $topwcz=$row["topwcz"];
    $imgyunc=$row["imgyunc"];
    $ipregx=$row["ipregx"];
    $date=$row["date"];
}
L2xx2j:
if($pagepass=="")goto L2xeWjgx2q;
goto L2xldMhx2q;
L2xeWjgx2q:
if(isset($_COOKIE['pagepass']))goto L2xeWjgx2o;
goto L2xx2p;
goto L2xx2p;
L2xeWjgx2o:
$currentTime=time();
$str=$currentTime+0;
$cookieResult=setcookie("pagepass", "", $str, "/");
goto L2xx2p;
L2xldMhx2q:
L2xx2p:
$sql="SELECT * FROM configx WHERE title = 'pljg'";
$result=$conn->query($sql);
$result=$result;
if($result->num_rows==0){
    $insertSql=1;
    $result=$conn->query($insertSql);
    $tmp2=$result===TRUE;
}
$filtertext="";
$sql="SELECT text FROM configx WHERE title = 'filtertext'";
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0){
    $result=$result->fetch_assoc();
    $row=$result;
    $filtertext=$row['text'];
}
$filterupy="";
$sql="SELECT text FROM configx WHERE title = 'upyun'";
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0){
    $result=$result->fetch_assoc();
    $row=$result;
    $filterupy=$row['text'];
}
$filteraliyun="";
$sql="SELECT text FROM configx WHERE title = 'aliyun'";
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0){
    $result=$result->fetch_assoc();
    $row=$result;
    $filteraliyun=$row['text'];
}
$filterpiccir="";
$sql="SELECT text FROM configx WHERE title = 'piccir'";
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0){
    $result=$result->fetch_assoc();
    $row=$result;
    $filterpiccir=$row['text'];
}
$filtercucss="";
$sql="SELECT text FROM configx WHERE title = 'cucss'";
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0){
    $result=$result->fetch_assoc();
    $row=$result;
    $isArray=is_array($row);
    if($isArray){
        $val2=&$row['text'];
    }else{
        $val2=$row['text'];
    }
    $fileExists=htmlspecialchars_decode($val2);
    unset($val2);
    $filtercucss=$fileExists;
}
$filtercujs="";
$sql="SELECT text FROM configx WHERE title = 'cujs'";
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0){
    $result=$result->fetch_assoc();
    $row=$result;
    $isArray=is_array($row);
    if($isArray){
        $val2=&$row['text'];
    }else{
        $val2=$row['text'];
    }
    $fileExists=htmlspecialchars_decode($val2);
    unset($val2);
    $filtercujs=$fileExists;
}
$filterkeyw="";
$sql="SELECT text FROM configx WHERE title = 'keyw'";
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0){
    $result=$result->fetch_assoc();
    $row=$result;
    $isArray=is_array($row);
    if($isArray){
        $val2=&$row['text'];
    }else{
        $val2=$row['text'];
    }
    $fileExists=htmlspecialchars_decode($val2);
    unset($val2);
    $filterkeyw=$fileExists;
}
$filterpljg="";
$sql="SELECT text FROM configx WHERE title = 'pljg'";
$result=$conn->query($sql);
$result=$result;
if($result->num_rows>0){
    $result=$result->fetch_assoc();
    $row=$result;
    $isArray=is_array($row);
    if($isArray){
        $val2=&$row['text'];
    }else{
        $val2=$row['text'];
    }
    $fileExists=htmlspecialchars_decode($val2);
    unset($val2);
    $filterpljg=$fileExists;
}
$num3=8007;
$tmp2=$iteace=='0';
if($tmp2){
    $num3=100;
}else{
    $tmp2=$iteace=='1';
    if($tmp2){
        $num3=200;
    }else{
        $num3=162;
    }
}
$tmp2=64;
$tmp5=200;
$tmp3=$num3==200;
if($tmp3)goto L2xx4k;
$tmp2=90;
$tmp5=100;
$tmp3=$num3==100;
if($tmp3)goto L2xeWjgx4m;
goto L2xldMhx4m;
L2xeWjgx4m:
$tmp2=$zt!=1;
if($tmp2)goto L2xeWjgx4i;
goto L2xx4k;
goto L2xx4k;
L2xeWjgx4i:
$fileExists=header("Location: ../404.php?close=true");
exit();
goto L2xx4k;
L2xldMhx4m:
switch($num3){
    case 162:{
    exit("状态错误!");
        break;
    }
}
L2xx4k:
$num4=8011;
if($HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"]){
    $num4=90;
}else{
    if($HTTP_SERVER_VARS["HTTP_CLIENT_IP"]){
        $num4=360;
    }else{
        if($HTTP_SERVER_VARS["REMOTE_ADDR"]){
            $num4=324;
        }else{
            $fileExists=getenv("HTTP_X_FORWARDED_FOR");
            if($fileExists){
                $num4=121;
            }else{
                $fileExists=getenv("HTTP_CLIENT_IP");
                if($fileExists){
                    $num4=360;
                    $num4=6370;
                }else{
                    $fileExists=getenv("REMOTE_ADDR");
                    if($fileExists){
                        $num4=162;
                    }else{
                        $num4=110;
                    }
                }
            }
        }
    }
}
switch($num4){
    case 3365:{
    $fileExists=getenv("HTTP_CLIENT_IP");
    $ip=$fileExists;
        break;
    }
    case 360:{
        $ip=$HTTP_SERVER_VARS["HTTP_CLIENT_IP"];
        break;
    }
    case 90:{
            $ip=$HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"];
        break;
    }
    case 324:{
                $ip=$HTTP_SERVER_VARS["REMOTE_ADDR"];
        break;
    }
    case 121:{
                    $fileExists=getenv("HTTP_X_FORWARDED_FOR");
                    $ip=$fileExists;
        break;
    }
    case 162:{
                        $fileExists=getenv("REMOTE_ADDR");
                        $ip=$fileExists;
        break;
    }
    case 110:{
                            $ip="Unknown";
        break;
    }
}
$length=64;
$fileExists=generateRandomString($length);
$allkey=$fileExists;
$fileExists=generateRandomString();
$visykmz_userzh="游客" . $fileExists;
$tmp2='vis#-[' . $ip;
$visykmz_userip=$tmp2 . ']-#vis';
$fileExists=session_start();
$sentinel=$allkey;
$_SESSION['allkey']=$sentinel;
$tmp2=$_SESSION['visykmz_userzh']=="";
$tmp3=(bool)$tmp2;
$tmp4=!$tmp3;
if($tmp4){
    $tmp5=$_SESSION['visykmz_userip']=="";
    $tmp3=(bool)$tmp5;
}
if($tmp3){
    $sentinel=$visykmz_userzh;
    $_SESSION['visykmz_userzh']=$sentinel;
    $sentinel=$visykmz_userip;
    $_SESSION['visykmz_userip']=$sentinel;
}
$num5=8001;
$tmp2=$scfont!="";
if($tmp2){
    $num5=90;
}else{
    $num5=360;
}
switch($num5){
    case 90:{
    $tmp2='<style>
    @font-face {
        font-family: "MyFont";
        src: url("' . $scfont;
        $tmp5=$tmp2 . '");
    }
    body{
        font-family: "MyFont";
    }
    </style>';
    $scfontzt=$tmp5;
        break;
    }
    case 360:{
        $scfontzt="";
        break;
    }
}
$str="select * from user where username='" . $username;
$str2=$str . "'";
$fileExists=mysqli_query($conn, $str2);
$data_result=$fileExists;
$fileExists=mysqli_fetch_array($data_result);
$data_row=$fileExists;
$glyname=$data_row["name"];
$glyimg=$data_row["img"];
$glyuserzha=$data_row["username"];
$str="select * from user where username='" . $user_zh;
$str2=$str . "'";
$fileExists=mysqli_query($conn, $str2);
$data_result=$fileExists;
$fileExists=mysqli_fetch_array($data_result);
$data2_row=$fileExists;
$zjzhq=$data2_row["username"];
$zjnc=$data2_row["name"];
$zjimg=$data2_row["img"];
$zjhomeimg=$data2_row["homeimg"];
$zjsign=$data2_row["sign"];
$zjemail=$data2_row["email"];
$zjwallet=$data2_row["wallet"];
$zjussig=$data2_row["ussig"];
$zjurl=$data2_row["url"];
$zjfbqx=$data2_row["essqx"];
$zjemtz=$data2_row["esseam"];
$passid=$data2_row["passid"];
$ban=$data2_row["ban"];
$bantime=$data2_row["bantime"];
if($userdlzt==1)goto L2xeWjgx5q;
goto L2xldMhx5q;
L2xeWjgx5q:
$tmp2=$ban!="0";
$tmp3=(bool)$tmp2;
if($tmp3){
    $tmp5=$bantime!="false";
    $tmp3=(bool)$tmp5;
}
if($tmp3)goto L2xeWjgx5m;
goto L2xx5p;
goto L2xx5p;
L2xeWjgx5m:
$tmp2=$bantime==="true";
if($tmp2)goto L2xeWjgx5o;
goto L2xldMhx5o;
goto L2xldMhx5o;
L2xeWjgx5o:
$currentTime=time();
$str=$currentTime+ -1;
$cookieResult=setcookie("username", "", $str, "/");
$currentTime=time();
$str=$currentTime+ -1;
$cookieResult=setcookie("passid", "", $str, "/");
exit('<script language="JavaScript">;alert("该账号涉嫌违规,已被永久封禁!");location.href="./index.php";</script>');
goto L2xx5p;
L2xldMhx5o:
$currentTime=time();
$str=$currentTime+ -1;
$cookieResult=setcookie("username", "", $str, "/");
$currentTime=time();
$str=$currentTime+ -1;
$cookieResult=setcookie("passid", "", $str, "/");
$tmp2='<script language="JavaScript">;alert("你的账号已被封禁！解封时间为:' . $bantime;
exit($tmp2 . '");location.href="./index.php";</script>');
L2xldMhx5q:
L2xx5p:
if($user_passid!=$passid){
    $currentTime=time();
    $str=$currentTime+ -1;
    $cookieResult=setcookie("username", "", $str, "/");
    $currentTime=time();
    $str=$currentTime+ -1;
    $cookieResult=setcookie("passid", "", $str, "/");
    exit('<script language="JavaScript">;alert("账号信息异常,请重新登录!");location.href="./index.php";</script>');
}
$iconurl_url=37816241360562;
$num=8005;
$tmp2=$iteace=='0';
if($tmp2){
    $num=220;
}else{
    $num=198;
}
$tmp2=104;
$tmp5=198;
$tmp3=$num==198;
if($tmp3)goto L2xeWjgx78;
goto L2xldMhx78;
L2xeWjgx78:
$fileExists=file_exists("../upfile/");
if($fileExists)goto L2xeWjgx6o;
goto L2xldMhx6o;
goto L2xldMhx6o;
L2xeWjgx6o:
$fileExists=file_exists('../upfile/up.ins');
if($fileExists)goto L2xeWjgx6q;
goto L2xldMhx6q;
goto L2xldMhx6q;
L2xeWjgx6q:
$folderPath='../upfile/';
$fileExists=is_dir($folderPath);
if($fileExists)goto L2xeWjgx6s;
goto L2xx6n;
goto L2xx6n;
L2xeWjgx6s:
$str=$folderPath . '/*';
$fileExists=glob($str);
$files=$fileExists;
unset($tmp);
foreach($files as $file){$tmp[]=$file;
}
$tmp6=0;
while(true){
    $fileExists=count($tmp);
    $tmp2=$tmp6<$fileExists;
    if(!$tmp2)break;
    $keys=array_keys($tmp);
    $keys=$keys[$tmp6];
    $file=$tmp[$keys];
    $fileExists=is_file($file);
    if($fileExists){
        $fileExists=unlink($file);
    }
    $tmp6=$tmp6+1;
}
L2xx71:
$fileExists=rmdir($folderPath);
goto L2xx6n;
L2xldMhx6q:
$fileExists=Header("location:../upfile/");
exit();
L2xldMhx6o:
L2xx6n:
$zipFile="../lan.zip";
$fileExists=file_exists($zipFile);
if($fileExists)goto L2xeWjgx76;
goto L2xx77;
goto L2xx77;
L2xeWjgx76:
$fileExists=unlink($zipFile);
goto L2xx77;
L2xldMhx78:
$tmp2=51;
$tmp5=220;
$tmp3=$num==220;
if($tmp3)goto L2xeWjgx7l;
goto L2xldMhx7l;
L2xeWjgx7l:
$fileExists=file_exists("./upfile/");
if($fileExists)goto L2xeWjgx65;
goto L2xldMhx65;
goto L2xldMhx65;
L2xeWjgx65:
$fileExists=file_exists('./upfile/up.ins');
if($fileExists)goto L2xeWjgx67;
goto L2xldMhx67;
goto L2xldMhx67;
L2xeWjgx67:
$folderPath='./upfile/';
$fileExists=is_dir($folderPath);
if($fileExists)goto L2xeWjgx69;
goto L2xx64;
goto L2xx64;
L2xeWjgx69:
$str=$folderPath . '/*';
$fileExists=glob($str);
$files=$fileExists;
unset($tmp);
foreach($files as $file){$tmp[]=$file;
}
$tmp6=0;
while(true){
    $fileExists=count($tmp);
    $tmp2=$tmp6<$fileExists;
    if(!$tmp2)break;
    $keys=array_keys($tmp);
    $keys=$keys[$tmp6];
    $file=$tmp[$keys];
    $fileExists=is_file($file);
    if($fileExists){
        $fileExists=unlink($file);
    }
    $tmp6=$tmp6+1;
}
L2xx6h:
$fileExists=rmdir($folderPath);
goto L2xx64;
L2xldMhx67:
$fileExists=Header("location:./upfile/");
exit();
L2xldMhx65:
L2xx64:
$zipFile="./lan.zip";
$fileExists=file_exists($zipFile);
if($fileExists)goto L2xeWjgx6m;
goto L2xx77;
goto L2xx77;
L2xeWjgx6m:
$fileExists=unlink($zipFile);
goto L2xx77;
L2xldMhx7l:
L2xx77:
$fileExists=file_exists('./updatb.php');
if($fileExists){
    exit('<style>
    .sh-k-suha2517270540{
        width: 100%;
        /*height: 100vh;*/
        display: flex;
        flex-direction: column;
        align-items: center;
    }
    .sh-abq{
        background: #09c362;
        color: #ffffff;
        text-decoration: none;
        padding: 10px 10px;
        margin-top: 25px;
        font-size: 15px;
        border-radius: 4px;
    }
    h4{
        color:#586c97;
    }
    .sh-gxnr{
        color:#4c5254;
    }
    </style>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0,minimum-scale=1.0, user-scalable=no minimal-ui">
    <div class="sh-k-suha2517270540">
    <div><h4>升级数据库</h4></div>
    <div class="sh-gxnr">本次更新了部分数据库字段,请先升级数据库再运行此程序!</div>
    <a href="./updatb.php" class="sh-abq">点击一键升级</a>
    </div>');
};function generateRandomString($length) {
    $characters='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString='';
    $i=0;
    while(true){
        $tmp2=$i<$length;
        if(!($tmp2))break;
        $length=strlen($characters);
        $val=$length-1;
        $rand=rand($val);
        $randomString=$randomString . $characters[$rand];
        $val3=$randomString;
        $obj=$i;
        $obj2=$i+1;
        $sentinel=$obj2;
        $i=$sentinel;
    }
    return $randomString;
}