<?php
if($_GET['up']=="up"){
    $tmp=$_SERVER["HTTP_HOST"]=="ce.qemao.com";
    if($tmp){
        exit("白名单域名不会自动更新");
    }
    $tmp=new ZipArchive();
    $zip=$tmp;
    $zipFile="../../lan.zip";
    $curlOptResult=file_exists($zipFile);
    $tmp=!$curlOptResult;
    if($tmp){
        exit("安装包不存在");
    }
    $cond=$zip->open($zipFile);
    $tmp=$cond===TRUE;
    if($tmp){
        $cond=$zip->extractTo("../../");
        $cond=$zip->close();
        $curlOptResult=unlink($zipFile);
        exit("更新完成");
    }else{
        exit("无法打开ZIP文件,请尝试手动更新");
    }
    exit();
}
if(!defined('sh_auth_state')){
    exit("非法访问");
}
$vernum=46;
$key=511347255008708804022;
$url="https://www.qemao.com/files/lan/api/updatedow.php";
$val['key']=$key;
$data=$val;
$val[]='Content-Type: application/x-www-form-urlencoded';
$headers=$val;
$curlOptResult=curl_init();
$curl=$curlOptResult;
$curlOptResult=curl_setopt($curl, CURLOPT_URL, $url);
$curlOptResult=curl_setopt($curl, CURLOPT_SSL_VERIFYPEER);
$curlOptResult=curl_setopt($curl, CURLOPT_SSL_VERIFYHOST);
$num=5840;
$isArray=is_array($_SERVER);
if($isArray){
    $num=198;
}else{
    $num=198;
    $num=6452;
}
switch($num){
    case 3325:{
    $serverVal=$_SERVER['HTTP_USER_AGENT'];
        break;
    }
    case 198:{
        $serverVal=&$_SERVER['HTTP_USER_AGENT'];
        break;
    }
}
$curlOptResult=curl_setopt($curl, CURLOPT_USERAGENT, $serverVal);
unset($serverVal);
$curlOptResult=curl_setopt($curl, CURLOPT_FOLLOWLOCATION);
$curlOptResult=curl_setopt($curl, CURLOPT_AUTOREFERER);
$curlOptResult=curl_setopt($curl, CURLOPT_POST);
$env=http_build_query($data);
$curlOptResult2=curl_setopt($curl, CURLOPT_POSTFIELDS, $env);
$curlOptResult=curl_setopt($curl, CURLOPT_TIMEOUT);
$curlOptResult=curl_setopt($curl, CURLOPT_HEADER);
$curlOptResult=curl_setopt($curl, CURLOPT_RETURNTRANSFER);
$curlOptResult=curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
$curlOptResult=curl_exec($curl);
$result=$curlOptResult;
$curlOptResult=curl_errno($curl);
if($curlOptResult)goto L2xxs;
L2xxs:
$curlOptResult=curl_close($curl);
$curlOptResult=json_decode($result, true);
$arr=$curlOptResult;
$code=$arr[0]['code'];
$vernumx=$arr[0]['vernumx'];
$uplog=$arr[0]['uplog'];
$curlOptResult=explode(PHP_EOL, $uplog);
$uplog=$curlOptResult;
$dow=$arr[0]['dow'];
$num2=5832;
$tmp=sh_auth_state!="ok";
if($tmp){
    $num2=128;
}else{
    $num2=121;
}
$tmp=108;
$tmp2=121;
$tmp3=$num2==121;
if($tmp3)goto L2xeWjgx1h;
goto L2xldMhx1h;
L2xeWjgx1h:
$tmp=$code==200;
if($tmp)goto L2xeWjgxx;
goto L2xx1g;
goto L2xx1g;
L2xeWjgxx:
$tmp=$vernumx>46;
if($tmp)goto L2xeWjgxz;
goto L2xx1g;
goto L2xx1g;
L2xeWjgxz:
$tmp=$dow!="JavaScript:;";
$tmp3=(bool)$tmp;
if($tmp3){
    $tmp2=$dow!="";
    $tmp3=(bool)$tmp2;
}
if($tmp3)goto L2xeWjgx14;
goto L2xldMhx14;
goto L2xldMhx14;
L2xeWjgx14:
$remoteFileUrl=$dow;
$localFilePath='../lan.zip';
$unzips='../upfile/';
$curlOptResult=curl_init($remoteFileUrl);
$ch=$curlOptResult;
$curlOptResult=fopen($localFilePath, 'wb');
$file=$curlOptResult;
$curlOptResult=curl_setopt($ch, CURLOPT_FILE, $file);
$curlOptResult=curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
$curlOptResult=curl_exec($ch);
$result=$curlOptResult;
$curlOptResult=curl_close($ch);
$curlOptResult=fclose($file);
$tmp=$result===false;
if($tmp)goto L2xeWjgx16;
goto L2xldMhx16;
goto L2xldMhx16;
L2xeWjgx16:
$ysbts="(请手动下载安装包至服务器)";
goto L2xx11;
L2xldMhx16:
$ysbts="(安装包已下载至服务器)";
L2xldMhx14:
$ysbts="(请手动下载安装包至服务器)";
L2xx11:
$tmp=$dow=="JavaScript:;";
$tmp3=(bool)$tmp;
$tmp4=!$tmp3;
if($tmp4){
    $tmp2=$dow=="";
    $tmp3=(bool)$tmp2;
}
if($tmp3){
    $gxan='<button type="button" class="btn btn-sm btn-primary">请在官方群下载最新版</button>';
}else{
    $cond2='<button type="button" class="btn btn-sm btn-primary" onclick="upfile()">立即更新</button>';
    $gxan=$cond2;
}
$tmp='<div class="col-md-12">
<div class="block block-rounded">
<div class="block-header block-header-default">
<h3 class="block-title">版本更新V' . $vernumx;
$tmp2=$tmp . ' <small>';
$tmp3=$tmp2 . $ysbts;
$tmp4=$tmp3 . '</small></h3>
<div class="block-options">
';
$tmp5=$tmp4 . $gxan;
$tmp6=$tmp5 . '
</div>
</div>
<div class="block-content">
<p>';
echo $tmp6;
$cond2=0;
$i=$cond2;
while(true){
    $curlOptResult=count($uplog);
    $tmp=$i<$curlOptResult;
    if(!$tmp)break;
    $tmp=$uplog[$i] . "<br>";
    echo $tmp;
    $obj=$i;
    $obj2=$i+1;
    $cond2=$obj2;
    $i=$cond2;
}
L2xx1e:
echo '</p>
</div>
</div>
</div>';
goto L2xx1g;
L2xldMhx1h:
$tmp=48;
$tmp2=128;
$tmp3=$num2==128;
if($tmp3)goto L2xx1g;
L2xx1g: